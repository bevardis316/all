<?php
/**
 * tool1/api/actions/delete_chat_entry.php
 * Ištrina pokalbio įrašą iš _log.json pagal id.
 * Jei įrašas buvo approved — palieka qa_approved.json nepaliestą.
 *
 * POST: { id }
 */

if (!defined('CHATS_LOG')) {
    define('CHATS_LOG', DATA_DIR . 'chats/_log.json');
}

$input = getBody();
$id    = trim($input['id'] ?? '');

if (!$id) {
    err(400, 'Trūksta id');
}

if (!file_exists(CHATS_LOG)) {
    ok(['deleted' => false]);
    return;
}

$lines    = file(CHATS_LOG, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$filtered = [];
$deleted  = false;

foreach ($lines as $line) {
    $e = json_decode($line, true);
    if (!$e) continue;
    if (($e['id'] ?? '') === $id) {
        $deleted = true;
        continue; // praleisti — ištriname
    }
    $filtered[] = json_encode($e, JSON_UNESCAPED_UNICODE);
}

file_put_contents(CHATS_LOG, $filtered ? implode("\n", $filtered) . "\n" : '', LOCK_EX);

ok(['deleted' => $deleted]);
