/**
 * pages-chats.js — Pokalbių peržiūra ir redagavimas
 *
 * Rodo vartotojų pokalbius su AI. Leidžia admin:
 *  - Redaguoti AI atsakymą ir vartotojo klausimą
 *  - Išsaugoti kaip patvirtintą pavyzdį (pateks į AI kaip few-shot)
 *  - Ištrinti įrašą iš žurnalo
 */

let _chatsData = [];

async function loadChats() {
  const wrap = document.getElementById('chats-list');
  if (!wrap) return;
  wrap.innerHTML = '<div style="color:var(--td);padding:20px;text-align:center">⏳ Kraunama...</div>';

  try {
    const r = await apiPost('load_chats', {});
    _chatsData = r.entries || [];
    _renderChats();
  } catch (e) {
    wrap.innerHTML = '<div style="color:#ef4444;padding:20px">Klaida: ' + e.message + '</div>';
  }
}

function _renderChats() {
  const wrap = document.getElementById('chats-list');
  if (!wrap) return;

  const onlyUnapproved = document.getElementById('chatsShowUnapproved')?.checked;
  let entries = _chatsData;
  if (onlyUnapproved) entries = entries.filter(e => !e.approved);

  const countEl = document.getElementById('chatsCount');
  if (countEl) countEl.textContent = entries.length + ' pokalbių';

  // Badge nav
  const unapprovedCount = _chatsData.filter(e => !e.approved).length;
  const badge = document.getElementById('chatsBadge');
  if (badge) {
    badge.textContent = unapprovedCount;
    badge.style.display = unapprovedCount > 0 ? '' : 'none';
  }

  if (!entries.length) {
    wrap.innerHTML = '<div style="color:var(--td);padding:40px;text-align:center">Pokalbių nėra' + (onlyUnapproved ? ' (visi patikrinti)' : '') + '</div>';
    return;
  }

  wrap.innerHTML = entries.map(e => _chatCard(e)).join('');
}

function _chatCard(e) {
  const approved = e.approved;
  const intentLabel = {
    'KAINA': '💰 Kaina', 'GEDIMAS': '🔴 Gedimas', 'SISTEMOS_PASIRINKIMAS': '🏗 Sistema',
    'SPECIALISTAS': '👤 Specialistas', 'KAS_VEIKIA': '❓ Kaip veikia', 'KITA': '💬 Kita'
  }[e.intent] || e.intent || '?';

  const userHtml = _esc(e.user || '');
  const aiHtml   = _esc(e.ai   || '');
  const cardId   = 'chat-' + e.id;
  const approvedBadge = approved
    ? '<span style="background:#d1fae5;color:#065f46;font-size:10px;padding:2px 7px;border-radius:8px;font-weight:600">✓ patikrinta</span>'
    : '<span style="background:#fef3c7;color:#92400e;font-size:10px;padding:2px 7px;border-radius:8px;font-weight:600">laukia</span>';

  return `
<div id="${cardId}" style="border:1px solid var(--b1);border-radius:10px;margin-bottom:10px;overflow:hidden;background:var(--s1)">
  <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;cursor:pointer;user-select:none"
       onclick="_toggleChat('${e.id}')">
    <span style="font-size:11px;color:var(--td);flex-shrink:0">${intentLabel}</span>
    <span style="flex:1;font-size:13px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"
          title="${userHtml}">${userHtml}</span>
    ${approvedBadge}
    <span style="font-size:12px;color:var(--td)" id="chat-arrow-${e.id}">▼</span>
  </div>
  <div id="chat-body-${e.id}" style="display:none;padding:0 14px 14px">
    <div style="margin-bottom:10px">
      <div style="font-size:11px;font-weight:600;color:var(--td);margin-bottom:4px">KLAUSIMAS <span style="font-weight:400">(galima redaguoti)</span></div>
      <textarea id="chat-user-${e.id}"
        style="width:100%;box-sizing:border-box;min-height:50px;resize:vertical;background:var(--bg);border:1.5px solid var(--b1);border-radius:6px;padding:10px;font-size:13px;line-height:1.5;font-family:inherit;color:var(--text)"
      >${userHtml}</textarea>
    </div>
    <div style="margin-bottom:12px">
      <div style="font-size:11px;font-weight:600;color:var(--td);margin-bottom:4px">AI ATSAKYMAS <span style="font-weight:400">(redaguokite ir išsaugokite)</span></div>
      <textarea id="chat-ta-${e.id}"
        style="width:100%;box-sizing:border-box;min-height:100px;resize:vertical;background:var(--bg);border:1.5px solid var(--b1);border-radius:6px;padding:10px;font-size:13px;line-height:1.5;font-family:inherit;color:var(--text)"
      >${aiHtml}</textarea>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button id="chat-save-btn-${e.id}" class="btn pri sm" onclick="_saveChat('${e.id}')">💾 Išsaugoti kaip pavyzdį</button>
      <button class="btn ghost sm" onclick="_toggleChat('${e.id}')">Uždaryti</button>
      <button class="btn ghost sm" style="margin-left:auto;color:#ef4444;border-color:#ef4444"
              onclick="_deleteChat('${e.id}')">🗑 Ištrinti</button>
    </div>
    <div id="chat-msg-${e.id}" style="display:none;margin-top:8px;font-size:12px;padding:6px 10px;border-radius:6px"></div>
  </div>
</div>`;
}

function _toggleChat(id) {
  const body  = document.getElementById('chat-body-' + id);
  const arrow = document.getElementById('chat-arrow-' + id);
  if (!body) return;
  const open = body.style.display !== 'none';
  body.style.display  = open ? 'none' : '';
  if (arrow) arrow.textContent = open ? '▼' : '▲';
}

function _showChatMsg(id, text, ok) {
  const el = document.getElementById('chat-msg-' + id);
  if (!el) return;
  el.textContent = text;
  el.style.display = '';
  el.style.background = ok ? '#d1fae5' : '#fee2e2';
  el.style.color      = ok ? '#065f46' : '#991b1b';
  setTimeout(() => { el.style.display = 'none'; }, 3000);
}

async function _saveChat(id) {
  const ta   = document.getElementById('chat-ta-' + id);
  const uTa  = document.getElementById('chat-user-' + id);
  if (!ta) return;

  const entry = _chatsData.find(e => e.id === id);
  if (!entry) return;

  const assistant = ta.value.trim();
  const userMsg   = uTa ? uTa.value.trim() : entry.user;

  if (!assistant) { _showChatMsg(id, 'Atsakymas negali būti tuščias', false); return; }
  if (!userMsg)   { _showChatMsg(id, 'Klausimas negali būti tuščias', false); return; }

  const btn = document.getElementById('chat-save-btn-' + id);
  if (btn) { btn.disabled = true; btn.textContent = '⏳...'; }

  try {
    await apiPost('save_chat_edit', { id, user: userMsg, assistant });

    // Atnaujinti lokaliai — kortelė LIEKA atidaryta
    entry.approved = true;
    entry.ai       = assistant;
    entry.user     = userMsg;

    // Atnaujinti badge ir skaitiklį be pilno perkrovimo
    const unapprovedCount = _chatsData.filter(e => !e.approved).length;
    const badge = document.getElementById('chatsBadge');
    if (badge) { badge.textContent = unapprovedCount; badge.style.display = unapprovedCount > 0 ? '' : 'none'; }

    // Atnaujinti approved badge kortelės antraštėje
    const card = document.getElementById('chat-' + id);
    if (card) {
      const badgeEl = card.querySelector('span[style*="background"]');
      if (badgeEl) {
        badgeEl.style.background = '#d1fae5';
        badgeEl.style.color      = '#065f46';
        badgeEl.textContent      = '✓ patikrinta';
      }
    }

    _showChatMsg(id, '✓ Išsaugota kaip pavyzdys', true);
    if (btn) { btn.disabled = false; btn.textContent = '💾 Išsaugoti kaip pavyzdį'; }
  } catch (e) {
    _showChatMsg(id, 'Klaida: ' + e.message, false);
    if (btn) { btn.disabled = false; btn.textContent = '💾 Išsaugoti kaip pavyzdį'; }
  }
}

async function _deleteChat(id) {
  if (!confirm('Ištrinti šį pokalbį iš žurnalo?')) return;

  try {
    await apiPost('delete_chat_entry', { id });
    // Pašalinti iš lokalaus masyvo ir perkrauti sąrašą
    _chatsData = _chatsData.filter(e => e.id !== id);
    _renderChats();
  } catch (e) {
    alert('Klaida trinant: ' + e.message);
  }
}

function _esc(s) {
  return String(s)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}
