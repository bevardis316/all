<?php
/**
 * auth_check.php — įtraukti viršuje bet kuriame saugomame puslapyje.
 * Jei sesija negalioja — nukreipia į gate.php su ?dest= parametru.
 */

session_name('ibnvs_gate');
session_set_cookie_params([
    'lifetime' => 28800,
    'path'     => '/',
    'secure'   => true,
    'httponly' => true,
    'samesite' => 'Strict',
]);
session_start();

$TTL = 28800; // 8 val

if (
    empty($_SESSION['ibnvs_auth']) ||
    empty($_SESSION['ibnvs_time']) ||
    (time() - $_SESSION['ibnvs_time']) > $TTL
) {
    // Išvalome sesiją
    $_SESSION = [];
    session_destroy();

    // Saugi dabartinio kelio konstravimas
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    if (!preg_match('/^\/[a-zA-Z0-9\/_\-\.]*$/', $uri)) {
        $uri = '/';
    }
    $dest = urlencode($uri);
    header('Location: /gate.php?dest=' . $dest);
    exit;
}

// Atnaujinti laiką kiekvienam puslapiui (idle TTL)
$_SESSION['ibnvs_time'] = time();
