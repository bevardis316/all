<?php
require_once dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

apiHeaders();

apiHeaders();

$labelsFile = DATA_DIR . 'meta/ui_labels.json';

// GET - grąžina labels
if ($_SERVER['REQUEST_METHOD'] === 'GET' || $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!file_exists($labelsFile)) {
        apiErr(404, 'ui_labels.json nerastas');
    }
    $data = json_decode(file_get_contents($labelsFile), true);
    if (!is_array($data)) {
        apiErr(500, 'Sugadintas ui_labels.json');
    }
    apiOk(['labels' => $data]);
    exit;
}

apiErr(405, 'Tik GET arba POST');
