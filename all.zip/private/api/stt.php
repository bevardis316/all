<?php
/**
 * private/api/stt.php — Balso atpažinimas (Speech-to-Text)
 *
 * Priima audio failą (multipart/form-data, laukas "audio"),
 * persiunčia į OpenAI Whisper API su lietuvių kalbos nustatymu,
 * grąžina transkribuotą tekstą.
 *
 * Naudojamas iš mobilaus app.
 */

require_once dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

// CORS headers — native mobile apps nesiunčia Origin, bet webview gali
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Session-ID');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { apiErr(405, 'Tik POST'); }

rateLimit(20, 1, 'stt'); // 20 STT užklausų per minutę per IP

if (!OPENAI_KEY) apiErr(500, 'Konfigūracijos klaida');

$audioFile = $_FILES['audio'] ?? null;
if (!$audioFile || $audioFile['error'] !== UPLOAD_ERR_OK) {
    $errCode = $audioFile['error'] ?? 'nėra failo';
    error_log('stt: upload error=' . $errCode);
    apiErr(400, 'Audio failas nerastas arba įkėlimo klaida (' . $errCode . ')');
}

if ($audioFile['size'] > 5 * 1024 * 1024) {
    apiErr(400, 'Audio failas per didelis (max 5MB)');
}

if ($audioFile['size'] < 100) {
    apiErr(400, 'Audio failas per mažas — greičiausiai įrašymas nepavyko');
}

$mime = mime_content_type($audioFile['tmp_name']) ?: 'audio/m4a';

$ch = curl_init('https://api.openai.com/v1/audio/transcriptions');
$cFile = new CURLFile($audioFile['tmp_name'], $mime, 'audio.m4a');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . OPENAI_KEY],
    CURLOPT_POSTFIELDS     => [
        'file'            => $cFile,
        'model'           => 'whisper-1',
        'language'        => 'lt',
        'response_format' => 'json',
    ],
    CURLOPT_TIMEOUT => 30,
]);

$result   = curl_exec($ch);
$curlErr  = curl_error($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($curlErr) {
    error_log('stt curl: ' . $curlErr);
    apiErr(502, 'Ryšio klaida su STT servisu');
}

$data = json_decode($result, true);
if ($httpCode !== 200 || empty($data['text'])) {
    error_log('stt openai [' . $httpCode . ']: ' . substr($result, 0, 300));
    apiErr(502, 'Kalbos atpažinimas nepavyko');
}

$text = trim($data['text']);
if (!$text) {
    apiErr(400, 'Nepavyko atpažinti kalbos — pamėginkite dar kartą');
}

apiOk(['text' => $text]);
