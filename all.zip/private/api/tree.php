<?php
require_once dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__) . '/engine/DiagnosticEngine.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

apiHeaders();
requirePost();
rateLimit(20, 1, 'tree');

try {
    apiOk(DiagnosticEngine::getTree());
} catch (Throwable $e) {
    error_log('tree: ' . $e->getMessage());
    apiErr(500, 'Serverio klaida');
}
