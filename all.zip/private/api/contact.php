<?php
require_once dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

apiHeaders();
requirePost();
rateLimit(5, 1, 'contact');

$body = getBody();
$name    = mb_substr(strip_tags($body['name']    ?? ''), 0, 100);
$phone   = mb_substr(strip_tags($body['phone']   ?? ''), 0, 50);
$email   = mb_substr(strip_tags($body['email']   ?? ''), 0, 100);
$message = mb_substr(strip_tags($body['message'] ?? ''), 0, 1000);
$symptoms = array_slice(array_map('strval', $body['symptoms'] ?? []), 0, 20);

if (!$name || (!$phone && !$email)) {
    apiErr(400, 'Trūksta duomenų');
}

$to      = defined('CONTACT_EMAIL') ? CONTACT_EMAIL : 'info@manonuotekos.lt';
$subject = "IBNVS diagnostika — {$name}";
$text    = "Vardas: {$name}\n";
if ($phone)   $text .= "Tel.: {$phone}\n";
if ($email)   $text .= "El. p.: {$email}\n";
if ($message) $text .= "\nŽinutė:\n{$message}\n";
if ($symptoms) $text .= "\nDiagnostikos simptomai:\n" . implode("\n", $symptoms) . "\n";

$headers  = "From: noreply@manonuotekos.lt\r\n";
$headers .= "Reply-To: {$email}\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

if (mail($to, $subject, $text, $headers)) {
    apiOk(['sent' => true]);
} else {
    error_log('contact mail() failed');
    apiErr(500, 'Nepavyko išsiųsti');
}
