<?php
require_once dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/kb-reader.php';

apiHeaders();
requirePost();
rateLimit(10, 1, 'ai');

if (!OPENAI_KEY) apiErr(500, 'Konfigūracijos klaida');

$body     = getBody();
$userText = trim($body['message'] ?? $body['text'] ?? '');
if (!$userText) apiErr(400, 'Tuščia žinutė');
$userText = mb_substr($userText, 0, 600);

// Pokalbio istorija - iki 6 paskutinių žinučių
$history = [];
foreach (array_slice($body['history'] ?? [], -6) as $h) {
    $role  = ($h['role'] ?? '') === 'user' ? 'user' : 'assistant';
    $htext = mb_substr(trim($h['content'] ?? ''), 0, 600);
    if ($htext) $history[] = ['role' => $role, 'content' => $htext];
}

// Surinkti visus praeitusius tekstus kontekstui
$allText = $userText;
foreach ($history as $h) $allText .= ' ' . $h['content'];

$context = buildSmartContext($allText);

$systemPrompt = <<<PROMPT
Tu esi patyręs nuotekų sistemų specialistas. Atsakai TIKTAI lietuviškai.

CHARAKTERIS:
Kalbi trumpai — kaip žmogus telefonu. Ne kaip robotas ar svetainė.
Jei klausimas aiškus — atsakai iš karto.
Jei trūksta info — klausi konkrečiai (1-3 klausimai), tada atsakai.
Niekada nerašai: "puikus klausimas", "mielai padėsiu", "žinoma", "suprantama".

KAIP ATSAKYTI:
Klausia KAINOS → orientacinis intervalas + [KONSTRUKTORIUS], ne kainų sąrašas
Klausia GEDIMO → 1-2 klausimai jei neaišku → priežastis + [DIAGNOSTIKA]
Klausia SPECIALISTO → [ŽEMĖLAPIS] + pasiūlyk parašyti iš kur yra
Klausia KĄ PIRKTI → dydis pagal žmonių skaičių, gamintojas ne tiek svarbus + [KONSTRUKTORIUS]
Klausia KAIP VEIKIA → 2-3 sakiniai paprastai + tinkamas mygtukas

NIEKADA nerašyk kainų ar modelių sąrašų — tik orientacinį intervalą ir nuorodą.

NUORODOS:
[KONSTRUKTORIUS] — kainos, medžiagos, sistemos pasirinkimas
[DIAGNOSTIKA] — gedimas, simptomas, kas neveikia
[ŽEMĖLAPIS] — specialistas, meistras, montavimas, aptarnavimas
[KON:KODAS] — konkretus įrenginys, pvz [KON:BNVI]
Jei žmogus nori suprasti daugiau — pridėk visus tris.

ŽINIŲ BAZĖ:
$context
PROMPT;

$messages = [['role' => 'system', 'content' => $systemPrompt]];
foreach ($history as $h) $messages[] = $h;
$messages[] = ['role' => 'user', 'content' => $userText];

$ch = curl_init('https://api.openai.com/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . OPENAI_KEY,
    ],
    CURLOPT_POSTFIELDS => json_encode([
        'model'       => OPENAI_MODEL,
        'messages'    => $messages,
        'max_tokens'  => 500,
        'temperature' => 0.2,
    ]),
    CURLOPT_TIMEOUT => 20,
]);
$resp = curl_exec($ch);
$curlErr = curl_error($ch);
curl_close($ch);

if ($curlErr) {
    error_log('ai curl: ' . $curlErr);
    apiErr(502, 'Ryšio klaida');
}
$data = json_decode($resp, true);
if (!empty($data['error'])) {
    error_log('ai openai error: ' . json_encode($data['error']));
    apiErr(502, 'AI klaida: ' . ($data['error']['message'] ?? 'nežinoma'));
}
$text = $data['choices'][0]['message']['content'] ?? null;
if (!$text) {
    error_log('ai tuščias atsakymas: ' . $resp);
    apiErr(502, 'AI nepavyko atsakyti');
}

apiOk(['text' => $text]);

// ─── Protingas kontekstas pagal pokalbio turinį ───────────────────────────────
function buildSmartContext(string $allText): string {
    $q       = mb_strtolower($allText);
    $domain  = kbReadJson(DATA_DIR . 'meta/domain.json') ?? [];
    $apr     = $domain['aprasymai'] ?? [];
    $lines   = [];

    // ── SPECIALISTO PAIEŠKA — grąžinti tik žemėlapio duomenis ──
    $askingSpecialist = preg_match('/montuoja|aptarnauja|meistras|specialistas|kas gali atvažiuoti|kas tvarko|rajone|vilniuje|kaune|klaipėdoje|švenčion|ignalino|molėt|utenos|alyt|taurag|plungė|telši|panevėž|šiaulių/u', $q);
    if ($askingSpecialist) {
        $mapFile = DATA_DIR . 'map/entries.json';
        if (file_exists($mapFile)) {
            $entries  = kbReadJson($mapFile) ?? [];
            $approved = array_values(array_filter($entries, fn($e) => !empty($e['approved'])));
            $cityMap  = [
                'vilni'=>'vilnius','kaun'=>'kaunas','klaipėd'=>'klaipėda',
                'šiaulių'=>'šiauliai','panevėž'=>'panevėžys',
                'švenčion'=>'švenčionys','ignalino'=>'ignalina',
                'molėt'=>'molėtai','utenos'=>'utena','alyt'=>'alytus',
                'taurag'=>'tauragė','telši'=>'telšiai','plungė'=>'plungė',
            ];
            $foundCity = '';
            foreach ($cityMap as $kw => $city) {
                if (str_contains($q, $kw)) { $foundCity = $city; break; }
            }
            $lines[] = '=== SPECIALISTAI (žemėlapis) ===';
            $shown = 0;
            foreach ($approved as $e) {
                $eCity = mb_strtolower($e['city'] ?? '');
                if ($foundCity && !str_contains($eCity, $foundCity) && !str_contains($foundCity, $eCity)) continue;
                $etype = $e['type'] ?? '';
                if ($etype === 'montavimas')       $type = 'Montavimas';
                elseif ($etype === 'aptarnavimas') $type = 'Aptarnavimas';
                elseif ($etype === 'prekyba')      $type = 'Prekyba';
                else                               $type = 'Kita';
                $lines[] = '  ' . ($e['name'] ?? '') . ' | ' . ($e['city'] ?? '') . ' | ' . $type;
                if (!empty($e['tel']))  $lines[] = '    Tel: ' . $e['tel'];
                if (!empty($e['info'])) $lines[] = '    ' . $e['info'];
                $shown++;
            }
            if ($shown === 0) {
                $lines[] = '  (Jūsų rajone dar nėra įregistruotų specialistų)';
                foreach ($approved as $e) {
                    $lines[] = '  ' . ($e['name'] ?? '') . ' | ' . ($e['city'] ?? '') . ' | Tel: ' . ($e['tel'] ?? '');
                }
            }
        }
        return implode("
", $lines);
    }

    // Nustatom apie ką kalbama
    $objMap = [
        'BNVI'      => ['biologinis','valymo įrenginys','bnvi','orapūtė','burbuliuoja'],
        'FEKSIURB'  => ['fekalinė','siurblinė','fekalinius','siurblys neveikia','nenusileidžia'],
        'DRENSIURB' => ['drenažinis','drenažo','drenažas'],
        'INFSUL'    => ['infiltracinis šulinys','šulinys','infsul'],
        'INFLAUK'   => ['infiltracinis laukas','laukas','inflauk'],
        'INFKAUB'   => ['kauburys','infkaub'],
        'UZDTALP'   => ['uždara','talpykla','talpa','išsiurbiama'],
        'MEGSUL'    => ['mėginių','mėginys'],
        'ZEMPAV'    => ['paviršius','zempav'],
        'SLAIT'     => ['šlaitas','nuolydis'],
    ];

    $focusOids = [];
    foreach ($objMap as $oid => $kws) {
        foreach ($kws as $kw) {
            if (str_contains($q, $kw)) { $focusOids[] = $oid; break; }
        }
    }

    // Sistemų tipai - visada
    if (!empty($domain['sistemu_tipai'])) {
        $lines[] = '=== SISTEMŲ TIPAI ===';
        foreach ($domain['sistemu_tipai'] as $s) {
            $g = implode(' → ', array_map(fn($o) => $apr[$o] ?? $o, $s['grandine']));
            $lines[] = "Sistema {$s['id']}: {$g}";
        }
    }

    // GVL/grunto info jei klausiama
    if (preg_match('/gvl|gruntinis vanduo|gruntas|infiltraci|molis|smėlis/u', $q)) {
        if (!empty($domain['gvl_blokuoja'])) {
            $lines[] = ''; $lines[] = '=== GVL APRIBOJIMAI ===';
            foreach ($domain['gvl_blokuoja'] as $gvl => $bl) {
                $lines[] = $bl ? "{$gvl} blokuoja: " . implode(', ', $bl) : "{$gvl}: apribojimų nėra";
            }
        }
        if (!empty($domain['mol_blokuoja'])) {
            $lines[] = 'Molis blokuoja sistemas: ' . implode(', ', $domain['mol_blokuoja']);
        }
    }

    // Objektai - fokusavimasis arba visi
    $allOids = array_keys($domain['objektai'] ?? []);
    if (empty($allOids)) {
        $allOids = array_map('basename', glob(DATA_DIR . 'objects/*', GLOB_ONLYDIR) ?: []);
    }
    $loadOids = !empty($focusOids) ? array_unique($focusOids) : $allOids;

    $lines[] = ''; $lines[] = '=== OBJEKTAI ===';
    foreach ($loadOids as $oid) {
        $base = kbReadJson(DATA_DIR . "objects/{$oid}/base.json");
        if (!$base) continue;
        $lines[] = "[ {$oid} — {$base['name']} ]";
        if (!empty($base['function'])) $lines[] = "  {$base['function']}";
        if (!empty($base['models'])) {
            foreach ($base['models'] as $m) {
                $l = "  Modelis: {$m['name']}";
                if (!empty($m['price_eur'])) $l .= " — {$m['price_eur']} €";
                $lines[] = $l;
            }
        }
        if (!empty($base['maintenance_schedule']['interval_months'])) {
            $lines[] = "  Priežiūra: kas {$base['maintenance_schedule']['interval_months']} mėn.";
        }

        // Ryšiai grandinėje
        $rels = kbReadJson(DATA_DIR . "objects/{$oid}/relations.json");
        if (!empty($rels['upstream'])) {
            $lines[] = "  Prieš šį: " . implode(', ', array_map(fn($o) => isset($apr[$o]) ? $apr[$o] : $o, $rels['upstream']));
        }
        if (!empty($rels['downstream'])) {
            $lines[] = "  Po šio: " . implode(', ', array_map(fn($o) => isset($apr[$o]) ? $apr[$o] : $o, $rels['downstream']));
        }

        // Gedimai
        $index = kbReadJson(DATA_DIR . "objects/{$oid}/failures/_index.json") ?? [];
        foreach ($index as $entry) {
            $fid = is_array($entry) ? ($entry['id'] ?? null) : $entry;
            if (!$fid) continue;
            $fm = kbReadJson(DATA_DIR . "objects/{$oid}/failures/{$fid}.json");
            if (!$fm || empty($fm['name'])) continue;
            $fl = "  Gedimas: {$fm['name']}";
            if (!empty($fm['symptoms'])) $fl .= ' | ' . implode(', ', array_slice($fm['symptoms'], 0, 3));
            if (!empty($fm['resolution'])) $fl .= ' → ' . mb_substr($fm['resolution'], 0, 60);
            $lines[] = $fl;
            $ctx = $fm['context'] ?? [];
            if (!empty($ctx['ctx_short'])) $lines[] = "    Trumpai: {$ctx['ctx_short']}";
            if (!empty($ctx['ctx_long']))  $lines[] = "    Ilgai: {$ctx['ctx_long']}";
        }
    }

    // Komponentai - tik jei klausiama arba fokusas
    if (!empty($focusOids) || preg_match('/komponent|dalis|kaina|kiek kainuoja|pirkti/u', $q)) {
        $compBase = DATA_DIR . 'components';
        if (is_dir($compBase)) {
            $lines[] = ''; $lines[] = '=== KOMPONENTAI ===';
            foreach (glob($compBase . '/*', GLOB_ONLYDIR) ?: [] as $pDir) {
                $pid = basename($pDir);
                if (!empty($focusOids) && !in_array($pid, $focusOids)) continue;
                foreach (glob($pDir . '/*.json') ?: [] as $f) {
                    $c = kbReadJson($f);
                    if (!$c || (isset($c['active']) && $c['active'] === false)) continue;
                    $l = "  {$c['id']}: {$c['name']}";
                    if (!empty($c['pricing']['part_price']))    $l .= " — dalis {$c['pricing']['part_price']} €";
                    if (!empty($c['pricing']['install_price'])) $l .= ", mont. {$c['pricing']['install_price']} €";
                    $lines[] = $l;
                }
            }
        }
    }

    return implode("\n", $lines);
}
