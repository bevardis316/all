<?php
require_once dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__) . '/engine/DiagnosticEngine.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

apiHeaders();
rateLimit(60, 1, 'sym');

try {
    apiOk(DiagnosticEngine::getSymptoms());
} catch (Throwable $e) {
    error_log('symptoms: ' . $e->getMessage());
    apiErr(500, 'Serverio klaida');
}
