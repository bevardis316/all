<?php
/**
 * private/api/chat/session_state.php — Vartotojo profilio kaupimas per pokalbį
 *
 * Analizuoja visą pokalbio istoriją + dabartinį intent ir grąžina
 * struktūrizuotą "profilį" — ką sistema JAUTIES žino apie šį vartotoją.
 *
 * Tai leidžia:
 *  - Claude NIEKADA nekartoti jau atsakytų klausimų
 *  - Filtruoti KB tik pagal aktualius faktus (ne viską)
 *  - Tiksliai žinoti ko trūksta norint atsakyti
 *  - Atsakymus personalizuoti pagal vartotojo situaciją
 *
 * PRINCIPAS: ne Claude klausia ir prisimena — sistema kaupia žinias
 * deterministiškai iš teksto, Claude tik naudoja rezultatą.
 */

if (!defined('DATA_DIR')) {
    throw new RuntimeException('session_state.php: DATA_DIR turi būti apibrėžtas.');
}

/**
 * Pagrindinė funkcija.
 * Iš istorijos + dabartinio intent surenka struktūrizuotą profilį.
 */
function buildUserProfile(array $history, array $currentIntent): array {
    $profile = [
        'gvl'                => null,   // 'gvl-1' | 'gvl-2' | 'gvl-3'
        'gruntas'            => null,   // 'molis' | 'smelis' | 'zvyras'
        'zmones'             => null,   // int — nuolatinių gyventojų skaičius
        'naudojimas'         => null,   // 'nuolatinis' | 'sezoninis'
        'miestas'            => null,   // string
        'turimi_komponentai' => [],     // OID'ai: ['BNVI', 'FEKSIURB', ...]
        'temos_aptartos'     => [],     // OID'ai aptarti šiame pokalbyje
    ];

    // 1. Skaityti VISĄ vartotojo istorijos tekstą
    $allText = '';
    foreach ($history as $h) {
        if (($h['role'] ?? '') === 'user') {
            $allText .= ' ' . ($h['content'] ?? '');
        }
    }
    if ($allText) {
        _spExtract(_spNorm($allText), $profile);
    }

    // 2. Dabartinio intent signalai — viršija istorijos ištrauką (naujesni)
    $sig = $currentIntent['signals'] ?? [];
    if (!empty($sig['gvl']))     $profile['gvl']     = $sig['gvl'];
    if (!empty($sig['gruntas'])) $profile['gruntas'] = ($sig['gruntas'] === 'mol') ? 'molis' : 'smėlis';
    if (!empty($sig['zmones']))  $profile['zmones']  = (int)$sig['zmones'];
    if (!empty($sig['miestas'])) $profile['miestas'] = $sig['miestas'];
    if (!empty($sig['regimas'])) {
        $profile['naudojimas'] = ($sig['regimas'] === 'sezonas') ? 'sezoninis' : 'nuolatinis';
    }

    // 3. Komponentai iš intent focus_oids
    foreach ($currentIntent['focus_oids'] ?? [] as $oid) {
        if (!in_array($oid, $profile['turimi_komponentai'])) {
            $profile['turimi_komponentai'][] = $oid;
        }
        if (!in_array($oid, $profile['temos_aptartos'])) {
            $profile['temos_aptartos'][] = $oid;
        }
    }

    return $profile;
}

function _spNorm(string $s): string {
    $s = mb_strtolower($s);
    return strtr($s, [
        'ą'=>'a','č'=>'c','ę'=>'e','ė'=>'e','į'=>'i',
        'š'=>'s','ų'=>'u','ū'=>'u','ž'=>'z',
    ]);
}

function _spExtract(string $tn, array &$p): void {

    // GVL — gruntinio vandens lygis
    if (!$p['gvl']) {
        if (preg_match('/gvl[\s\-]*1|labai\s*aukst.{0,10}grunt|vanduo.{0,15}0[,\.]5\s*m/u', $tn))
            $p['gvl'] = 'gvl-1';
        elseif (preg_match('/gvl[\s\-]*2|80.{0,5}120.{0,5}cm|vidutinis\s*grunt|gruntinis.{0,20}vidut/u', $tn))
            $p['gvl'] = 'gvl-2';
        elseif (preg_match('/gvl[\s\-]*3|sausas\s*grunt|gilus\s*grunt|>1[,\.]5\s*m/u', $tn))
            $p['gvl'] = 'gvl-3';
    }

    // Gruntas
    if (!$p['gruntas']) {
        if (preg_match('/molis|priemolis|molinga/u', $tn))
            $p['gruntas'] = 'molis';
        elseif (preg_match('/smelis|smeling|zvyras|zvyringa/u', $tn))
            $p['gruntas'] = 'smelis';
    }

    // Žmonių skaičius
    if (!$p['zmones']) {
        if (preg_match('/(\d+)\s*(zmoni|gyventoj|asmen|zmoniu|zmones)\b/u', $tn, $m))
            $p['zmones'] = (int)$m[1];
        elseif (preg_match('/\bvienas\s*(zmogus|gyventojas|asmuo)/u', $tn))
            $p['zmones'] = 1;
        elseif (preg_match('/\bdviem\s*(asmenims|zmonems)/u', $tn))
            $p['zmones'] = 2;
    }

    // Naudojimo tipas
    if (!$p['naudojimas']) {
        if (preg_match('/nuolatin|visus\s*metus|visada\s*gyvena|pastovi/u', $tn))
            $p['naudojimas'] = 'nuolatinis';
        elseif (preg_match('/sezonin|sodyba|vasaros|retai\s*naudo/u', $tn))
            $p['naudojimas'] = 'sezoninis';
    }

    // Turimi komponentai — paminėti tekste
    $compMap = [
        'biomax'              => 'BNVI',
        'biosystem'           => 'BNVI',
        'biotornado'          => 'BNVI',
        'bnvi'                => 'BNVI',
        'biologin'            => 'BNVI',
        'oraput'              => 'BNVI',
        'fekaline siurbline'  => 'FEKSIURB',
        'feksiurb'            => 'FEKSIURB',
        'drenazine siurbline' => 'DRENSIURB',
        'drensiurb'           => 'DRENSIURB',
        'uzdara talp'         => 'UZDTALP',
        'uzdtalp'             => 'UZDTALP',
    ];
    foreach ($compMap as $kw => $oid) {
        if (str_contains($tn, $kw) && !in_array($oid, $p['turimi_komponentai'])) {
            $p['turimi_komponentai'][] = $oid;
        }
    }
}

/**
 * Suformatuoja profilį kaip aiškų tekstą Claude'ui.
 * Nurodo ir KĄ ŽINOME ir KO TRŪKSTA.
 */
function formatUserProfile(array $profile, string $intent = 'KITA'): string {
    $known   = [];
    $missing = [];

    $gvlLabel = [
        'gvl-1' => 'GVL-1 — labai aukštas (<0.5m nuo paviršiaus) ⚠️ riboja sistemas',
        'gvl-2' => 'GVL-2 — vidutinis (0.5–1.5m)',
        'gvl-3' => 'GVL-3 — žemas arba sausas (>1.5m, jokių apribojimų)',
    ];

    if ($profile['gvl'])
        $known[] = 'GVL: ' . ($gvlLabel[$profile['gvl']] ?? $profile['gvl']);
    elseif (in_array($intent, ['SISTEMOS_PASIRINKIMAS', 'KAINA']))
        $missing[] = 'GVL — gruntinio vandens gylis (tai svarbiausia klausti pirma)';

    if ($profile['gruntas'])
        $known[] = 'Gruntas: ' . $profile['gruntas'];
    elseif (in_array($intent, ['SISTEMOS_PASIRINKIMAS']) && $profile['gvl'])
        $missing[] = 'grunto tipas (molis/smėlis/žvyras)';

    if ($profile['zmones'])
        $known[] = 'Nuolatiniai gyventojai: ' . $profile['zmones'];
    elseif (in_array($intent, ['SISTEMOS_PASIRINKIMAS', 'KAINA']))
        $missing[] = 'nuolatinių gyventojų skaičius';

    if ($profile['naudojimas'])
        $known[] = 'Naudojimas: ' . $profile['naudojimas'];

    if ($profile['miestas'])
        $known[] = 'Miestas/rajonas: ' . $profile['miestas'];

    if (!empty($profile['turimi_komponentai']))
        $known[] = 'Turimi komponentai: ' . implode(', ', $profile['turimi_komponentai']);

    if (!$known && !$missing) return '';

    $lines = ['=== KĄ ŽINOME APIE VARTOTOJĄ ==='];
    foreach ($known as $k) $lines[] = '✓ ' . $k;

    if ($missing) {
        $lines[] = '';
        $lines[] = '⚠️ TRŪKSTA — paklausk tik VIENO svarbiausiojo:';
        $lines[] = '   → ' . reset($missing); // Tik pirmasis prioritetas
    }

    $lines[] = '';
    $lines[] = '(Remkis šia informacija — NIEKADA neklausk to ką jau žinome)';

    return implode("\n", $lines);
}
