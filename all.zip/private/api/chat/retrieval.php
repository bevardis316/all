<?php
/**
 * private/api/chat/retrieval.php
 *
 * Scoped retrieval — pagal intent'ą surinktą iš intent.php, grąžina
 * SIAURĄ ir struktūruotą žinių aprašą tinkamą įdėti į GPT system prompt'ą.
 *
 * SVARBU: NIEKADA negrąžina chaotiško viso KB sąvartyno. Maksimaliai
 * 5–20 eilučių, scope'uotų pagal vartotojo poreikį.
 *
 * Naudoja:
 *   - ibnvs_data/meta/domain.json
 *   - ibnvs_data/objects/{oid}/base.json
 *   - ibnvs_data/objects/{oid}/relations.json
 *   - ibnvs_data/objects/{oid}/failures/{fid}.json
 *   - ibnvs_data/symptoms/_index.json
 *   - ibnvs_data/map/entries.json
 *   - public_html/shared/php/ibnvs-engine.php (IBNVS:: klasė)
 */

if (!defined('DATA_DIR')) {
    throw new RuntimeException('chat/retrieval.php: DATA_DIR turi būti apibrėžtas.');
}
if (!defined('PUBLIC_DIR')) {
    throw new RuntimeException('chat/retrieval.php: PUBLIC_DIR turi būti apibrėžtas.');
}

require_once __DIR__ . '/security.php';
require_once PUBLIC_DIR . 'shared/php/ibnvs-engine.php';

/**
 * Pagrindinis viešas API.
 *
 * @param array $intent  Iš chatExtractIntent() grąžintas masyvas.
 * @return array {
 *   knowledge:   string  // įdedama į <KNOWLEDGE>...</KNOWLEDGE>
 *   escalation:  array   // mygtukų pasiūlymai promptui
 *   meta:        array   // diagnostikos info
 * }
 */
function chatBuildKnowledge(array $intent): array {
    $type = $intent['intent'] ?? 'KITA';
    $oids = $intent['focus_oids'] ?? [];
    $sigs = $intent['signals'] ?? [];

    $lines      = [];
    $escalation = [];
    $metaInfo   = [];
    $missing    = [];

    switch ($type) {
        case 'KAINA':
            [$lines, $escalation, $metaInfo, $missing] = _crKaina($oids, $sigs);
            break;
        case 'GEDIMAS':
            [$lines, $escalation, $metaInfo, $missing] = _crGedimas($oids, $intent['matched_failures'] ?? [], $intent['matched_symptoms'] ?? []);
            break;
        case 'KAS_VEIKIA':
            [$lines, $escalation, $metaInfo, $missing] = _crKasVeikia($oids);
            break;
        case 'SPECIALISTAS':
            [$lines, $escalation, $metaInfo, $missing] = _crSpecialistas($sigs);
            break;
        case 'SISTEMOS_PASIRINKIMAS':
            [$lines, $escalation, $metaInfo, $missing] = _crSistemosPasirinkimas($sigs);
            break;
        case 'KITA':
        default:
            [$lines, $escalation, $metaInfo, $missing] = _crKita();
            break;
    }

    $kbConfidence = !$lines        ? 'none'
                  : ($missing      ? 'partial'
                  :                  'high');

    return [
        'knowledge'       => implode("\n", $lines),
        'escalation'      => $escalation,
        'missing_context' => $missing,
        'kb_confidence'   => $kbConfidence,
        'meta'            => array_merge(['intent_type' => $type], $metaInfo),
    ];
}

// ─── KAINA ───────────────────────────────────────────────────────────────────

function _crKaina(array $oids, array $sigs): array {
    $lines = [];
    if (!$oids) {
        $oids = ['BNVI', 'FEKSIURB', 'UZDTALP'];
    }
    foreach (array_slice($oids, 0, 3) as $oid) {
        $base = chatReadJson(DATA_DIR . "objects/{$oid}/base.json");
        if (!$base) continue;
        $lines[] = "Objektas: {$base['name']}";
        if (!empty($base['models'])) {
            foreach ($base['models'] as $m) {
                $line = "  - {$m['name']}";
                if (!empty($m['price_eur'])) $line .= ": {$m['price_eur']} €";
                $lines[] = $line;
            }
        } else {
            $lines[] = "  - (kainos diapazonas matomas konstruktoriuje)";
        }
        if (!empty($base['maintenance_schedule']['interval_months'])) {
            $lines[] = "  Priežiūros intervalas: kas {$base['maintenance_schedule']['interval_months']} mėn.";
        }
        $lines[] = '';
    }
    if (!empty($sigs['zmones'])) {
        $rec = _crRecommendSize((int)$sigs['zmones']);
        if ($rec) $lines[] = "Rekomendacija pagal žmonių skaičių ({$sigs['zmones']}): " . $rec;
    }

    $missing = [];
    if (count($oids) === 3 && $oids === ['BNVI', 'FEKSIURB', 'UZDTALP']) {
        // Nebuvo konkretaus OID — vartotojas nepatikslino įrenginio
        $missing[] = 'Koks konkretus įrenginys jus domina? (biologinis valytuvas, fekalinė siurblė, infiltracinis šulinys, uždara talpykla...)';
    }

    return [$lines, ['KONSTRUKTORIUS'], ['oids_used' => $oids], $missing];
}

/**
 * Iš FB pokalbių istorijos: 1-2 nuolatiniai → 4 asm., 3 nuolat. → 6 asm.,
 * 4-5 nuolat. → 8 asm., 6+ nuolat. → 10-15 asm.
 */
function _crRecommendSize(int $zmones): string {
    if ($zmones <= 2) return 'pakanka 4 asmenims skirto BNVI';
    if ($zmones <= 3) return 'rinkitės 6 asmenims skirtą BNVI';
    if ($zmones <= 5) return 'rinkitės 8 asmenims skirtą BNVI';
    if ($zmones <= 8) return 'rinkitės 10 asmenims skirtą BNVI';
    return 'reikalingas 15+ asmenims BNVI arba dviejų BNVI sistema';
}

// ─── GEDIMAS ─────────────────────────────────────────────────────────────────

function _crGedimas(array $oids, array $matchedFailures, array $matchedSymptoms): array {
    $lines = [];
    $shownFailures = 0;

    // Pirmiausiai — visi konkrečiai sumatch'inti gedimai
    foreach ($matchedFailures as $mf) {
        $oid = $mf['oid']; $fid = $mf['fid'];
        $failure = chatReadJson(DATA_DIR . "objects/{$oid}/failures/{$fid}.json");
        if (!$failure) continue;
        $lines[] = "GEDIMAS [{$oid} / {$fid}]: " . ($failure['name'] ?? '');
        if (!empty($failure['symptoms'])) {
            $lines[] = "  Simptomai: " . implode(', ', array_slice($failure['symptoms'], 0, 4));
        }
        $causes = $failure['causes']['list'] ?? [];
        if ($causes) {
            $lines[] = "  Tikėtinos priežastys:";
            foreach (array_slice($causes, 0, 3) as $c) {
                $cn = $c['name'] ?? '';
                $cf = $c['fix']  ?? '';
                $cp = isset($c['pct']) && $c['pct'] !== null ? " (~{$c['pct']}%)" : '';
                $lines[] = "    - {$cn}{$cp}: {$cf}";
            }
        }
        $ctx = $failure['context'] ?? [];
        if (!empty($ctx['ctx_short'])) $lines[] = "  Trumpai: {$ctx['ctx_short']}";
        if (!empty($failure['prevention'])) $lines[] = "  Prevencija: " . mb_substr($failure['prevention'], 0, 200);
        $lines[] = '';
        $shownFailures++;
        if ($shownFailures >= 3) break;
    }

    // Jei failures'ų neradom, bet radom simptomus — pamininam apie kuriuos objektus
    if (!$shownFailures && $matchedSymptoms) {
        $sympData = chatReadJson(DATA_DIR . 'symptoms/_index.json');
        if ($sympData && !empty($sympData['symptoms'])) {
            $lines[] = "Sumatch'inti simptomai (be aiškaus konkretaus gedimo):";
            foreach ($sympData['symptoms'] as $s) {
                if (!in_array($s['id'] ?? '', $matchedSymptoms, true)) continue;
                $objs = implode(', ', $s['objects'] ?? []);
                $lines[] = "  - " . ($s['name'] ?? '') . " → susiję objektai: {$objs}";
                if (!empty($s['description'])) $lines[] = "    " . mb_substr($s['description'], 0, 160);
            }
            $lines[] = '';
        }
    }

    // Jei iš viso nieko — duodam normalų objekto kontekstą fallback'ui
    if (!$lines && $oids) {
        $oid = $oids[0];
        $base = chatReadJson(DATA_DIR . "objects/{$oid}/base.json");
        if ($base) {
            $lines[] = "Objektas: {$base['name']}";
            if (!empty($base['function'])) $lines[] = "Funkcija: {$base['function']}";
            if (!empty($base['normal_operation'])) $lines[] = "Normalus veikimas: {$base['normal_operation']}";
            if (!empty($base['normal_signs'])) $lines[] = "Normalūs požymiai: " . implode('; ', $base['normal_signs']);
        }
    }

    $missing = [];
    if (!$shownFailures && !$matchedSymptoms && !$oids) {
        $missing[] = 'Apie kurį įrenginį kalbate? (biologinis valytuvas, infiltracinis šulinys, fekalinė siurblė...)';
        $missing[] = 'Koks konkretus simptomas? (pvz. smirda, neburbulina, nesusigeria, vanduo drumzlinas)';
    } elseif ($oids && !$shownFailures && !$matchedSymptoms) {
        $missing[] = 'Koks konkretus simptomas pastebėtas? (pvz. smirda, neburbulina, nesusigeria, nepasileido)';
    }

    return [$lines, ['DIAGNOSTIKA', 'ZEMELAPIS'], ['failures_shown' => $shownFailures], $missing];
}

// ─── KAS_VEIKIA ──────────────────────────────────────────────────────────────

function _crKasVeikia(array $oids): array {
    $lines = [];
    if (!$oids) $oids = ['BNVI'];
    $oid = $oids[0];

    $base = chatReadJson(DATA_DIR . "objects/{$oid}/base.json");
    if ($base) {
        $lines[] = "Objektas: {$base['name']} ({$oid})";
        if (!empty($base['function']))         $lines[] = "Funkcija: {$base['function']}";
        if (!empty($base['normal_operation'])) $lines[] = "Veikimas: {$base['normal_operation']}";
        if (!empty($base['normal_signs']))     $lines[] = "Normalūs požymiai: " . implode('; ', $base['normal_signs']);
    }

    // Pridedam kontekstą — kas šiame objekte yra prieš/po (sistemos grandinė)
    $rels = chatReadJson(DATA_DIR . "objects/{$oid}/relations.json");
    if ($rels && is_array($rels)) {
        $domain = chatReadJson(DATA_DIR . 'meta/domain.json');
        $names = $domain['objektai'] ?? [];
        if (!empty($rels['upstream'])) {
            $up = array_map(fn($o) => $names[$o]['name'] ?? $o, $rels['upstream']);
            $lines[] = "Prieš šį objektą sistemoje gali būti: " . implode(', ', $up);
        }
        if (!empty($rels['downstream'])) {
            $down = array_map(fn($o) => $names[$o]['name'] ?? $o, $rels['downstream']);
            $lines[] = "Po šio objekto sistemoje gali būti: " . implode(', ', $down);
        }
    }

    $missing = [];
    if (!$oids) {
        $missing[] = 'Apie kurį komponentą norite sužinoti? (biologinis valytuvas, infiltracinis šulinys, fekalinė siurblė, drenažinė siurblė, uždara talpykla...)';
    }

    return [$lines, ['KONSTRUKTORIUS'], ['oid_used' => $oid ?? null], $missing];
}

// ─── SPECIALISTAS ────────────────────────────────────────────────────────────

function _crSpecialistas(array $sigs): array {
    $lines = [];
    $miestas = $sigs['miestas'] ?? null;
    $mapFile = DATA_DIR . 'map/entries.json';

    $entries = chatReadJson($mapFile) ?? [];
    $approved = array_values(array_filter(
        is_array($entries) ? $entries : [],
        fn($e) => is_array($e) && !empty($e['approved'])
    ));

    if (!$approved) {
        $lines[] = "Specialistų bazė šiuo metu tuščia.";
        return [$lines, ['ZEMELAPIS'], ['shown' => 0]];
    }

    $shown = 0;
    if ($miestas) {
        $miestasN = mb_strtolower($miestas);
        $lines[] = "Specialistai šalia: {$miestas}";
        foreach ($approved as $e) {
            $eCity = mb_strtolower($e['city'] ?? '');
            if (!$eCity) continue;
            // švelnus match'as (substring abiem pusėm)
            if (mb_strpos($eCity, $miestasN) === false && mb_strpos($miestasN, $eCity) === false) continue;
            $type = _crFormatType($e['type'] ?? '');
            $name = $e['name'] ?? 'be vardo';
            $tel  = $e['tel']  ?? '';
            $info = isset($e['info']) ? mb_substr($e['info'], 0, 100) : '';
            $line = "  - {$name} | {$type}";
            if ($tel) $line .= " | tel. {$tel}";
            $lines[] = $line;
            if ($info) $lines[] = "    {$info}";
            $shown++;
            if ($shown >= 5) break;
        }
        if (!$shown) {
            $lines[] = "  (Šiuo metu kontaktų bazėje nėra įrašų jūsų rajone.)";
            $lines[] = "  Pavyzdys iš artimiausio bendro sąrašo:";
            foreach (array_slice($approved, 0, 3) as $e) {
                $type = _crFormatType($e['type'] ?? '');
                $lines[] = "  - " . ($e['name'] ?? '') . " | " . ($e['city'] ?? '?') . " | {$type}";
            }
        }
    } else {
        $lines[] = "Vartotojas neminėjo miesto. Trumpas bendros bazės pavyzdys:";
        foreach (array_slice($approved, 0, 3) as $e) {
            $type = _crFormatType($e['type'] ?? '');
            $lines[] = "  - " . ($e['name'] ?? '') . " | " . ($e['city'] ?? '?') . " | {$type}";
        }
    }

    $missing = [];
    if (!$miestas) {
        $missing[] = 'Kuriame mieste ar rajone ieškote specialisto?';
    }

    return [$lines, ['ZEMELAPIS'], ['shown' => $shown, 'city' => $miestas], $missing];
}

function _crFormatType(string $t): string {
    return match ($t) {
        'montavimas'   => 'Montavimas',
        'aptarnavimas' => 'Aptarnavimas',
        'prekyba'      => 'Prekyba',
        default        => 'Kita',
    };
}

// ─── SISTEMOS_PASIRINKIMAS ───────────────────────────────────────────────────

function _crSistemosPasirinkimas(array $sigs): array {
    $lines = [];
    $gvl = $sigs['gvl'] ?? null;
    $grnt = $sigs['gruntas'] ?? null;
    $regimas = $sigs['regimas'] ?? null;
    $zmones = $sigs['zmones'] ?? null;

    $domain = chatReadJson(DATA_DIR . 'meta/domain.json');

    // Surinkti visas sistemas iš domain.json
    $allSystems = [];
    foreach (($domain['sistemu_tipai'] ?? []) as $s) {
        $allSystems[$s['id']] = $s['grandine'] ?? [];
    }

    if ($gvl) {
        // DETERMINISTINIS FILTRAVIMAS NAUDOJANT IBNVS:: KLASĘ
        // (vienas taisyklių šaltinis — domain.json + ibnvs-engine.php).
        // Kiekvienai sistemai simuliuojam jos statymą žingsnis po žingsnio,
        // tikrinant ar IBNVS::gvlLeidzia leidžia kiekvieną kitą objektą.
        $allowed = [];
        $blocked = [];
        foreach ($allSystems as $id => $grandine) {
            $partialPath = [];
            $ok = true;
            foreach ($grandine as $next) {
                if (!IBNVS::gvlLeidzia($next, $partialPath, $gvl, $grnt)) {
                    $ok = false;
                    break;
                }
                $partialPath[] = $next;
            }
            if ($ok) $allowed[$id] = $grandine;
            else     $blocked[] = $id;
        }

        $signalDesc = "GVL={$gvl}" . ($grnt ? ", gruntas={$grnt}" : '');
        $lines[] = "Vartotojo sąlygos: {$signalDesc}";
        if ($blocked) {
            $lines[] = "Pagal IBNVS taisykles netinka šios sistemos: " . implode(', ', array_map(fn($i) => "Sist.{$i}", $blocked));
        }
        if ($allowed) {
            $lines[] = "Tinkančios sistemos:";
            $shown = 0;
            foreach ($allowed as $id => $grandine) {
                $names = array_map(fn($o) => ($domain['objektai'][$o]['name'] ?? $o), $grandine);
                $lines[] = "  Sistema {$id}: " . implode(' → ', $names);
                $shown++;
                if ($shown >= 6) break;
            }
            if (count($allowed) > 6) {
                $lines[] = "  ... ir dar " . (count($allowed) - 6) . " variantai (žr. konstruktoriuje).";
            }
        } else {
            $lines[] = "ĮSPĖJIMAS: jokia iš 12 sistemų neatitinka šių sąlygų — patikrink GVL/grunto duomenis.";
        }
    } elseif ($grnt) {
        // Tik gruntas paminėtas be GVL — IBNVS taisyklės molio apribojimą
        // taiko tik kartu su GVL. Vietoj klaidingo filtravimo — paklausk vartotojo.
        $lines[] = "Vartotojas paminėjo gruntą ({$grnt}), bet ne GVL (gruntinio vandens lygį).";
        $lines[] = "Tikslus sistemos pasirinkimas su moliu/smėliu priklauso ir nuo GVL.";
        $lines[] = "PATARIMAS: paklausk apie GVL, kad galėtum nurodyti tikslias leidžiamas sistemas.";
    } else {
        // Be konteksto signalų — duodam bendros struktūros santrauką
        $lines[] = "Pagrindinės sistemų grupės (12 tipų iš viso):";
        $lines[] = "  - Su BNVI + infiltracija (sist. 1-6, 9-12) — labiausiai paplitusios";
        $lines[] = "  - Tik talpykla be valymo (sist. 7-8) — retam naudojimui";
        $lines[] = "Konkretų pasirinkimą lemia: gruntas, gruntinio vandens lygis (GVL), žmonių skaičius, naudojimo režimas (nuolatos/sezonas).";
    }

    // 2) Pridedam rekomendaciją pagal žmones
    if ($zmones) {
        $rec = _crRecommendSize((int)$zmones);
        if ($rec) $lines[] = "Rekomenduojamas dydis: " . $rec;
    }
    // 3) Sezoninis vs nuolatinis
    if ($regimas === 'sezonas') {
        $lines[] = "Sezoniniam (retam) naudojimui dažniausiai patariama UŽDARA TALPYKLA, ne BNVI — bakterijos žūsta be apkrovos.";
    }

    $missing = [];
    // GVL yra kritinis — be jo negalima tiksliai filtruoti sistemų
    if (!$gvl && $regimas !== 'sezonas') {
        $missing[] = 'Koks gruntinio vandens lygis jūsų sklype? (aukštas — vanduo rodo arčiau nei 0,5 m / vidutinis / žemas — sausas gruntas)';
    }
    if (!$zmones) {
        $missing[] = 'Kiek žmonių nuolatos gyvens name?';
    }

    return [$lines, ['KONSTRUKTORIUS'], ['gvl' => $gvl, 'gruntas' => $grnt], $missing];
}

// ─── KITA (fallback) ─────────────────────────────────────────────────────────

function _crKita(): array {
    return [
        [],
        ['KONSTRUKTORIUS', 'DIAGNOSTIKA', 'ZEMELAPIS'],
        [],
        ['Tiksliau apie ką klausiate? Ar tai: gedimas / kaina / kaip veikia / sistemos pasirinkimas / specialisto paieška?'],
    ];
}
