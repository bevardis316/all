<?php
/**
 * private/api/chat/_eval.php — admin'ui skirtas chat'o pipeline'o
 * diagnostikos endpoint'as. NEKVIEČIA OpenAI — saugiai pinigų.
 *
 * Naudojimas: HTTP'u prieš šitą failą turi būti gate.php / auth_check.php.
 * Pridėk į apsaugos kelią analogiškai kaip /tool1/.
 *
 * POST /api/v1/chat-eval
 *   { "message": "...", "history": [...] }
 *
 * Grąžina:
 *   {
 *     ok: true,
 *     intent:    {...},
 *     knowledge: "...",
 *     escalation:[...],
 *     prompt_estimate: { chars, tokens_approx },
 *     legacy_used: false   // ar būtų aktyvuotas failed-safe?
 *   }
 *
 * Naudoti: kai nori patikrinti, kaip chat'as „supranta" konkretų klausimą,
 * arba kai reikia debug'inti, kodėl atsakymas atrodo neteisingas.
 */

require_once dirname(dirname(__DIR__)) . '/bootstrap.php';
require_once dirname(dirname(dirname(__DIR__))) . '/public_html/shared/php/helpers.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/intent.php';
require_once __DIR__ . '/retrieval.php';

// Bazinis API headers'as. AUTH čia nedaroma — tikimės, kad
// public_html/api/v1/chat-eval.php (proxy failas) yra už auth_check'o.
// Jei nori dar vienos apsaugos linijos — atkomentuok šią dalį:
//
// session_name('ibnvs_gate');
// session_start();
// if (empty($_SESSION['ibnvs_auth'])) apiErr(403, 'Tik admin\'ui');

apiHeaders();
requirePost();

$body = getBody();
$msg = chatCleanUserInput($body['message'] ?? '', 600);
if (!$msg) apiErr(400, 'Tuščia žinutė');

$history = [];
foreach (array_slice($body['history'] ?? [], -6) as $h) {
    $role  = (($h['role'] ?? '') === 'user') ? 'user' : 'assistant';
    $hText = chatCleanUserInput($h['content'] ?? '', 600);
    if ($hText !== '') $history[] = ['role' => $role, 'content' => $hText];
}

$intent = chatExtractIntent($msg, $history);
$kb     = chatBuildKnowledge($intent);
$adv    = chatDetectAdversarial($msg);

// Promptai estimavimui — be OpenAI'aus
$style = chatReadJson(DATA_DIR . 'meta/chat_style.json') ?? [];
$styleCharsBase = 0;
foreach ($style['tone_rules'] ?? [] as $r) $styleCharsBase += strlen($r) + 4;
foreach (array_slice($style['examples'] ?? [], 0, 4) as $ex) {
    $styleCharsBase += strlen(($ex['user'] ?? '') . ($ex['assistant'] ?? '')) + 50;
}
$kbChars = strlen($kb['knowledge'] ?? '');
$totalCharsApprox = 800 + $styleCharsBase + $kbChars + 400; // ROLE+SAFETY overhead

apiOk([
    'intent'     => $intent,
    'knowledge'  => $kb['knowledge'] ?? '',
    'escalation' => $kb['escalation'] ?? [],
    'kb_meta'    => $kb['meta'] ?? [],
    'adversarial'=> $adv,
    'prompt_estimate' => [
        'kb_chars'        => $kbChars,
        'kb_tokens_approx'=> intval($kbChars / 3.5),
        'total_chars_approx' => $totalCharsApprox,
        'total_tokens_approx'=> intval($totalCharsApprox / 3.5),
    ],
    'history_count' => count($history),
]);
