<?php
/**
 * private/api/chat/security.php
 *
 * Saugumo helper'iai chat'o moduliui:
 *   - rateLimitTiered($limits, $prefix) — pakopinis rate limit'as,
 *     grąžina structured info per 429 atveju.
 *   - cleanUserInput($text) — pašalina control / zero-width simbolius.
 *   - detectAdversarial($text) — flag'ina (ne blokuoja) įtartinas frazes.
 *   - filterAssistantResponse($text) — saugiklis, kad atsakyme
 *     neištrūktų KB struktūros tag'ų, system instrukcijų ir pan.
 *
 * Šitas failas SAVO funkcijų į global helpers.php nedubliuoja —
 * jis atskiras ir naudojamas TIK chat moduliui.
 */

if (!defined('DATA_DIR')) {
    throw new RuntimeException('chat/security.php: DATA_DIR turi būti apibrėžtas (require bootstrap.php).');
}

/**
 * Pakopinis rate limit'as. Pavyzdys:
 *   chatRateLimitTiered([
 *     ['max'=>5,   'period_sec'=>60,    'kind'=>'minute'],
 *     ['max'=>30,  'period_sec'=>3600,  'kind'=>'hour'],
 *     ['max'=>100, 'period_sec'=>86400, 'kind'=>'day'],
 *   ], 'ai');
 *
 * Grąžina null jei užklausa leidžiama, arba asociatyvų masyvą su
 * info kai blokuojama. Jokio exit() — caller'is sprendžia ką daryti.
 */
function chatRateLimitTiered(array $limits, string $prefix = 'ai'): ?array {
    $ip  = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $key = sys_get_temp_dir() . '/rlt_' . $prefix . '_' . md5($ip) . '.json';
    $now = time();

    $d = ['hits' => []];
    if (file_exists($key)) {
        $raw = @file_get_contents($key);
        if ($raw) {
            $p = json_decode($raw, true);
            if (is_array($p) && isset($p['hits']) && is_array($p['hits'])) {
                $d = $p;
            }
        }
    }

    $longest = 0;
    foreach ($limits as $tier) {
        if (($tier['period_sec'] ?? 0) > $longest) {
            $longest = $tier['period_sec'];
        }
    }
    $d['hits'] = array_values(array_filter(
        $d['hits'],
        fn($t) => is_numeric($t) && $t > $now - $longest
    ));

    foreach ($limits as $tier) {
        $window = (int)($tier['period_sec'] ?? 60);
        $max    = (int)($tier['max']        ?? 0);
        $kind   = $tier['kind']             ?? 'unknown';
        if ($max <= 0) continue;

        $hitsInWindow = array_filter($d['hits'], fn($t) => $t > $now - $window);
        if (count($hitsInWindow) >= $max) {
            $oldest    = min($hitsInWindow);
            $retryAfter = max(1, ($oldest + $window) - $now);
            return [
                'blocked'         => true,
                'retry_after_sec' => $retryAfter,
                'limit_kind'      => $kind,
                'limit_max'       => $max,
                'limit_period_sec'=> $window,
                'used'            => count($hitsInWindow),
            ];
        }
    }

    $d['hits'][] = $now;
    @file_put_contents($key, json_encode($d), LOCK_EX);
    return null;
}

/**
 * Pašalina control characters, zero-width chars, BOM. Apkarpo ilgį.
 * Negriauna teksto reikšmės — tik valo.
 */
function chatCleanUserInput(string $text, int $maxChars = 600): string {
    $text = str_replace(["\u{FEFF}", "\u{200B}", "\u{200C}", "\u{200D}", "\u{2060}"], '', $text);
    $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text) ?? $text;
    $text = trim($text);
    return mb_substr($text, 0, $maxChars);
}

/**
 * Aptinka įtartinas frazes (prompt injection bandymai, KB išsiurbimo bandymai).
 * GRĄŽINA flag'ą + reason'ą — NEBLOKUOJA pati. Caller'is sprendžia.
 *
 * Net jei flag = true, mes vis tiek leidžiam užklausą — tik:
 *   (a) loginsim,
 *   (b) prompt'e pridėsim papildomą įspėjimą GPT'ui.
 */
function chatDetectAdversarial(string $text): array {
    $tl = mb_strtolower($text);
    $patterns = [
        'system_prompt'  => '/(system\s*prompt|tavo\s*instrukcij|atspausdink\s*tavo|atskleisk\s*tavo|parodyk\s*tavo\s*prompt|show\s+your\s+(system\s+)?prompt|reveal\s+(your|the)\s+prompt)/u',
        'ignore_prev'    => '/(ignore\s+(all\s+)?previous|ignoruok\s+(visas\s+)?ankstesnes|forget\s+(all\s+)?previous|pamiršk\s+visa)/u',
        'role_override'  => '/(you\s+are\s+now|tu\s+esi\s+dabar|new\s+role|nauja\s+rol|act\s+as|elkis\s+kaip|persona)/u',
        'kb_dump'        => '/(visa\s+(tavo\s+)?žinių\s+baz|atspausdink\s+visa|pakartok\s+(visa|viską)|dump\s+(your\s+)?(kb|knowledge|database))/u',
        'jailbreak_tag'  => '/(\[\s*INST\s*\]|<\|im_start\|>|<\|system\|>|\[\/INST\]|DAN\s+mode|jailbreak)/u',
    ];
    foreach ($patterns as $name => $rgx) {
        if (preg_match($rgx, $tl)) {
            return ['suspicious' => true, 'reason' => $name];
        }
    }
    return ['suspicious' => false, 'reason' => ''];
}

/**
 * Atsakymo saugiklis. Jei GPT'as netyčia (ar piktybiškai) bandytų išspjauti
 * mūsų system prompt'o struktūrą — nukirpsime ir pakeisime į neutralų atsakymą.
 *
 * Šitas yra paskutinis sluoksnis "diržo + petnešų" filosofijoje.
 */
function chatFilterAssistantResponse(string $text): string {
    $leakSignals = [
        '<KNOWLEDGE>', '</KNOWLEDGE>',
        '<STYLE_RULES>', '</STYLE_RULES>',
        '<STYLE_EXAMPLES>', '</STYLE_EXAMPLES>',
        '<ROLE>', '</ROLE>',
        '<ESCALATION>', '</ESCALATION>',
        'system prompt', 'system_prompt',
        'tone_rules', 'never_say',
        'chat_style.json', 'domain.json',
        'IBNVS::', 'getGalimiObjektai', 'gvlLeidzia',
    ];
    $tl = mb_strtolower($text);
    foreach ($leakSignals as $sig) {
        if (mb_strpos($tl, mb_strtolower($sig)) !== false) {
            error_log('chat: response leak detected, signal=' . $sig);
            return 'Atsiprašau — negaliu atsakyti į šį prašymą. Pamėginkite užduoti kitą klausimą arba pasinaudokite [KONSTRUKTORIUS], [DIAGNOSTIKA], [ŽEMĖLAPIS].';
        }
    }
    return $text;
}

/**
 * Skaitymas su saugiu fallback'u.
 */
function chatReadJson(string $path): ?array {
    if (!file_exists($path)) return null;
    $raw = @file_get_contents($path);
    if ($raw === false) return null;
    $d = json_decode($raw, true);
    return is_array($d) ? $d : null;
}

/**
 * Sesijos rate limitas mobiliajam app.
 * Klientas siunčia UUID session_id, serveris seka žinučių kiekį per sesiją.
 * Jokių asmeninių duomenų — tik UUID hash ir counter.
 *
 * Grąžina null jei užklausa leidžiama, arba array su info kai blokuojama.
 */
function chatRateLimitSession(string $sessionId, int $maxPerSession = 10): ?array {
    if (!$sessionId || !preg_match('/^[a-f0-9\-]{8,64}$/i', $sessionId)) return null;

    $key = sys_get_temp_dir() . '/msess_' . md5($sessionId) . '.json';
    $d = ['count' => 0, 'created' => time()];

    if (file_exists($key)) {
        $p = json_decode(@file_get_contents($key), true);
        if (is_array($p) && isset($p['count'])) $d = $p;
    }

    if ($d['count'] >= $maxPerSession) {
        return [
            'blocked'   => true,
            'limit_kind'=> 'session',
            'used'      => $d['count'],
            'limit_max' => $maxPerSession,
        ];
    }

    $d['count']++;
    @file_put_contents($key, json_encode($d), LOCK_EX);
    return null;
}
