<?php
/**
 * private/api/chat/intent.php
 *
 * Intent extractor'ius. Iš vartotojo žinutės + istorijos surenka:
 *   - intent: KAINA | GEDIMAS | KAS_VEIKIA | SPECIALISTAS |
 *             SISTEMOS_PASIRINKIMAS | KITA
 *   - focus_oids: kuriuos objektus vartotojas mini
 *   - matched_symptoms: SYM-XXX kodai iš ibnvs_data/symptoms/_index.json
 *   - matched_failures: [{oid, fid}] iš objects/X/failures/_index.json
 *   - signals: gvl, gruntas, regimas, zmones, miestas
 *
 * SVARBU: visas teksto match'inimas vyksta NORMALIZUOTA forma —
 * t.y. mažosiomis + diakritinių ženklų folded į ASCII (ę→e, š→s, į→i, ...).
 * Realūs vartotojai dažnai rašo be diakritikų:
 *   "molėtų" / "moletu", "nenusileidžia" / "nenusileidzia".
 *
 * VISKAS skaitomas iš ibnvs_data/ kiekvieną kartą — joks cache.
 * Šitas modulis NIEKADA nesikreipia į OpenAI. Jis yra tik PHP.
 */

if (!defined('DATA_DIR')) {
    throw new RuntimeException('chat/intent.php: DATA_DIR turi būti apibrėžtas.');
}

require_once __DIR__ . '/security.php';

function chatExtractIntent(string $userText, array $history = []): array {
    $combined = $userText;
    foreach (array_slice($history, -4) as $h) {
        $combined .= ' ' . ($h['content'] ?? '');
    }
    $tn = _ciNormalize($combined); // tn = text-normalized

    $signals    = _ciExtractSignals($tn);
    $symptoms   = _ciMatchSymptoms($tn);
    $focusOids  = _ciDetectObjects($tn, $symptoms);
    $failures   = _ciMatchFailures($tn, $focusOids);
    $intent     = _ciClassifyIntent($tn, $focusOids, $symptoms, $failures, $signals);

    return [
        'intent'           => $intent,
        'focus_oids'       => array_values(array_unique($focusOids)),
        'matched_symptoms' => $symptoms,
        'matched_failures' => $failures,
        'signals'          => $signals,
        '_debug_input'     => mb_substr($userText, 0, 200),
    ];
}

function _ciNormalize(string $s): string {
    $s = mb_strtolower($s);
    $map = [
        'ą'=>'a', 'č'=>'c', 'ę'=>'e', 'ė'=>'e', 'į'=>'i',
        'š'=>'s', 'ų'=>'u', 'ū'=>'u', 'ž'=>'z',
    ];
    return strtr($s, $map);
}

function _ciExtractSignals(string $tn): array {
    $sig = [
        'gvl'     => null,
        'gruntas' => null,
        'regimas' => null,
        'zmones'  => null,
        'miestas' => null,
    ];

    // GVL — gruntinio vandens lygis
    if (preg_match('/(auksti|aukstas|aukstu)\s*(gruntini|vandeny|vandens)/u', $tn)
        || preg_match('/gvl[\s\-]*1/u', $tn)
        || str_contains($tn, 'vanduo is zemes')
        || str_contains($tn, 'kyla is zemes')) {
        $sig['gvl'] = 'gvl-1';
    } elseif (preg_match('/gvl[\s\-]*2/u', $tn) || str_contains($tn, 'vidutinis grunt')) {
        $sig['gvl'] = 'gvl-2';
    } elseif (preg_match('/gvl[\s\-]*3/u', $tn) || str_contains($tn, 'sausa') || str_contains($tn, 'sausas grunt')) {
        $sig['gvl'] = 'gvl-3';
    }

    // Gruntas
    if (preg_match('/molis|moli[ou]|priemoli|molingame|molingam/u', $tn)) {
        $sig['gruntas'] = 'mol';
    } elseif (preg_match('/smeli|zvyr[ao]|priesmeli/u', $tn)) {
        $sig['gruntas'] = 'smel';
    }

    // Naudojimo režimas
    if (preg_match('/sezon|sodybo|sodybai|sodyba\b|vasarna|tik\s*vasaros|tik\s*sezon|retai\s*naudo|kelis\s*kartus\s*per\s*met|2.{0,5}3\s*kartus/u', $tn)) {
        $sig['regimas'] = 'sezonas';
    } elseif (preg_match('/nuolatos|nuolatini|kasdien|gyvenam[ee]\s*nuolat|pastovi[ai]/u', $tn)) {
        $sig['regimas'] = 'nuolatos';
    }

    // Žmonių skaičius
    if (preg_match('/(\d+)\s*(asmen|zmoni|zmones|seim|gyventoj)/u', $tn, $m)) {
        $n = (int)$m[1];
        if ($n > 0 && $n < 100) $sig['zmones'] = $n;
    } elseif (preg_match('/(viena|vieno|vienam)\s*(asmen|zmog)/u', $tn)) {
        $sig['zmones'] = 1;
    } elseif (preg_match('/(dviem|dviems|dvejiem)\s*(asmen|zmog)/u', $tn)) {
        $sig['zmones'] = 2;
    }

    // Miestas — visi LT savivaldybės centrai (NORMALIZUOTI)
    $cityKeywords = [
        'vilni'    => 'vilnius',
        'kaun'     => 'kaunas',
        'klaiped'  => 'klaipėda',
        'siauli'   => 'šiauliai',
        'panevez'  => 'panevėžys',
        'alyt'     => 'alytus',
        'marijampol' => 'marijampolė',
        'mariampol'=> 'marijampolė',
        'utenos'   => 'utena',
        'taurag'   => 'tauragė',
        'telsi'    => 'telšiai',
        'plung'    => 'plungė',
        'mazeiki'  => 'mažeikiai',
        'akmen'    => 'akmenė',
        'kreting'  => 'kretinga',
        'rasein'   => 'raseiniai',
        'jurbark'  => 'jurbarkas',
        'kedaini'  => 'kėdainiai',
        'pasval'   => 'pasvalys',
        'birzu'    => 'biržai',
        'birzai'   => 'biržai',
        'rokisk'   => 'rokiškis',
        'visagin'  => 'visaginas',
        'ignalin'  => 'ignalina',
        'molet'    => 'molėtai',
        'svencion' => 'švenčionys',
        'ukmerg'   => 'ukmergė',
        'jonav'    => 'jonava',
        'kaisiad'  => 'kaišiadorys',
        'lazdij'   => 'lazdijai',
        'druskinink' => 'druskininkai',
        'varen'    => 'varėna',
        'prien'    => 'prienai',
        'birston'  => 'birštonas',
        'sakiu'    => 'šakiai',
        'sakiai'   => 'šakiai',
        'vilkavisk'=> 'vilkaviškis',
        'kalvarij' => 'kalvarija',
        'silut'    => 'šilutė',
        'palang'   => 'palanga',
        'neringa'  => 'neringa',
        'skuod'    => 'skuodas',
        'kelm'     => 'kelmė',
        'pakruoj'  => 'pakruojis',
        'radvil'   => 'radviliškis',
        'jonisk'   => 'joniškis',
        'kupisk'   => 'kupiškis',
        'zaras'    => 'zarasai',
        'anyksc'   => 'anykščiai',
        'sirvint'  => 'širvintos',
        'elektren' => 'elektrėnai',
        'salcinink'=> 'šalčininkai',
        'trakai'   => 'trakai',
    ];
    foreach ($cityKeywords as $kw => $city) {
        if (str_contains($tn, $kw)) {
            $sig['miestas'] = $city;
            break;
        }
    }

    return $sig;
}

function _ciMatchSymptoms(string $tn): array {
    $matched = [];
    $data = chatReadJson(DATA_DIR . 'symptoms/_index.json');
    if (!$data || empty($data['symptoms'])) return [];

    foreach ($data['symptoms'] as $s) {
        $terms = array_merge([$s['name'] ?? ''], $s['synonyms'] ?? []);
        foreach ($terms as $term) {
            $tnTerm = _ciNormalize(trim($term));
            if (mb_strlen($tnTerm) < 5) continue;
            if (mb_strpos($tn, $tnTerm) !== false) {
                $matched[] = $s['id'];
                break;
            }
        }
    }
    return array_values(array_unique($matched));
}

function _ciDetectObjects(string $tn, array $matchedSymptomIds): array {
    $score = []; // oid => score

    // Sinonimai jau NORMALIZUOTI (be diakritikų, mažosiomis).
    $synMap = [
        'BNVI' => [
            'biologinis', 'biologin',
            'valymo irengin', 'valymo  irengin', 'biol.\s*nuotek',
            'bnvi',
            'oraput',
            'aerator', 'erlift',
            'aktyvus dumbl', 'aktyvaus dumbl', 'aktyvujį dumbl',
            'biotornado', 'tornado',
            'august', 'at-?\d', 'at\s*\d',
            'feliksnav', 'biomax', 'svaist',
            'traidenis', 'deimant', 'walis', 'buiteka', 'biocare',
            'burbul',
            'bakterij',
        ],
        'FEKSIURB' => [
            'fekalin',
            'siurblin',
            'plude',
            'feksiurb',
        ],
        'DRENSIURB' => [
            'drenazin',
            'drenaz',
            'drensiurb',
        ],
        'INFSUL' => [
            'infiltracinis sulinys',
            'inf\.\s*sulin',
            'infsul',
            'infiltracin.{0,8}sulin',
        ],
        'INFLAUK' => [
            'infiltracinis laukas',
            'inf\.\s*lauk',
            'inflauk',
            'infiltracin.{0,8}lauk',
        ],
        'INFKAUB' => [
            'kauburys', 'kauburi',
            'kauptuv',
            'infkaub',
        ],
        'UZDTALP' => [
            'uzdara\s*talp',
            'talpykl',
            'uzdtalp',
            'kaupiamoj',
            'issiurbiama\s*talp',
        ],
        'MEGSUL' => [
            'meginiu',
            'meginys',
            'megsul',
        ],
        'ZEMPAV' => [
            'zempav',
        ],
        'SLAIT' => [
            'slait',
            'nuokal',
            'nuolyd',
        ],
    ];

    foreach ($synMap as $oid => $patterns) {
        foreach ($patterns as $p) {
            // Jei pattern atrodo kaip regex (turi metakaraktrų) — naudoju regex
            if (preg_match('/[\\\\\.\*\+\?\[\]\(\)\{\}\|\^\$]/', $p)) {
                if (@preg_match('/' . $p . '/u', $tn)) {
                    $score[$oid] = ($score[$oid] ?? 0) + 1;
                    break;
                }
            } else {
                if (mb_strpos($tn, $p) !== false) {
                    $score[$oid] = ($score[$oid] ?? 0) + 1;
                    break;
                }
            }
        }
    }

    // Iš simptomų — kiekvienas match'intas simptomas paskirsto svorinį balą
    if ($matchedSymptomIds) {
        $sympData = chatReadJson(DATA_DIR . 'symptoms/_index.json');
        if ($sympData && !empty($sympData['symptoms'])) {
            foreach ($sympData['symptoms'] as $s) {
                if (!in_array($s['id'] ?? '', $matchedSymptomIds, true)) continue;
                foreach ($s['objects'] ?? [] as $oid) {
                    $score[$oid] = ($score[$oid] ?? 0) + 2;
                }
            }
        }
    }

    // domain.json objektų vardai
    $domain = chatReadJson(DATA_DIR . 'meta/domain.json');
    if ($domain && !empty($domain['objektai'])) {
        foreach ($domain['objektai'] as $oid => $obj) {
            $name = _ciNormalize($obj['name'] ?? '');
            if ($name && mb_strlen($name) > 5 && mb_strpos($tn, $name) !== false) {
                $score[$oid] = ($score[$oid] ?? 0) + 1;
            }
        }
    }

    if (!$score) return [];
    arsort($score);
    return array_keys($score);
}

function _ciMatchFailures(string $tn, array $focusOids): array {
    $matched = [];
    $checkOids = $focusOids ?: [];

    if (!$checkOids && preg_match('/smirda|neburbuli|kvap|nesvar|drumst|drumzlin|rud[oa]\s*vand|pluta|uzsikims|sugedo|neveikia|nustojo|prisilild|perpildy|persipildi/u', $tn)) {
        $checkOids = ['BNVI', 'FEKSIURB', 'DRENSIURB', 'INFSUL'];
    }

    foreach ($checkOids as $oid) {
        $idxPath = DATA_DIR . 'objects/' . $oid . '/failures/_index.json';
        $idx = chatReadJson($idxPath);
        if (!$idx || !is_array($idx)) continue;

        foreach ($idx as $entry) {
            $fid  = is_array($entry) ? ($entry['id']   ?? null) : $entry;
            $name = is_array($entry) ? ($entry['name'] ?? '')   : '';
            if (!$fid) continue;

            if ($name && mb_strlen($name) > 4) {
                $tnName = _ciNormalize($name);
                if (mb_strpos($tn, $tnName) !== false) {
                    $matched[] = ['oid' => $oid, 'fid' => $fid];
                    continue;
                }
                $words = preg_split('/\s+/u', $tnName);
                $hits = 0;
                foreach ($words as $w) {
                    if (mb_strlen($w) >= 5 && mb_strpos($tn, $w) !== false) $hits++;
                }
                if ($hits >= 2) {
                    $matched[] = ['oid' => $oid, 'fid' => $fid];
                }
            }
        }
    }

    return $matched;
}

function _ciClassifyIntent(string $tn, array $focusOids, array $symptoms, array $failures, array $signals): string {
    $hasMiestas = !empty($signals['miestas']);
    $hasSpecKw = (bool)preg_match('/montuoja|aptarnauja|meistr|specialist|kas\s*gali\s*(atvazi|sutv|pajun|patikrinti)|kas\s*tvarko|ieskau\s*(kas|imones|firmos)|kontaktai|kontaktu\s|kontaktu$|kreipt[ie]s/u', $tn);

    // SISTEMOS_PASIRINKIMAS einas PRIEŠ SPECIALISTAS, kai kalba apie firmą/gamintoją
    // o ne apie konkretų žmogų atvažiuoti.
    $sistRekom = preg_match(
        '/(rekomenduoki?t|patarki?t|patark|kokia\s+(firma|gamintoj)|kokios?\s+sistemos?|koks?\s+geriausias\s+irengin|ka\s+statyt|ka\s+rinkt|kokio?\s+(dyd|tip)|kokia\s+nuoteku\s+(sistema|talp|valym))/u',
        $tn
    );
    $sistKlausimas = preg_match(
        '/(ka|kok|kuri|kuria)\s*\w*\s*(stat|rink|pasirin|sumontuo|ireng|valym|nuoteku)/u',
        $tn
    );
    $hasContextSignal = ($signals['gvl'] || $signals['gruntas'] || $signals['regimas'] || $signals['zmones']);
    $sistContext = $hasContextSignal && preg_match('/sistem|ireng|valym|talp|rinkt|stat|patark|rekomend|kok|sodyb|naudo|namui|seimai/u', $tn);

    if (($sistRekom || $sistKlausimas) && !$hasSpecKw) {
        return 'SISTEMOS_PASIRINKIMAS';
    }

    // SPECIALISTAS — tik kai aiškūs žmogaus/paslaugos žodžiai
    if ($hasSpecKw) {
        return 'SPECIALISTAS';
    }
    // Miestas + montavimo intencija (be aiškaus "kas gali atvažiuoti")
    if ($hasMiestas && preg_match('/sumontu|montavim|pajung|aptarnav|patikrinti|atvyksta|kas\s*galetu|reikia\s*sumontuoti|ieskau/u', $tn)) {
        return 'SPECIALISTAS';
    }

    // GEDIMAS
    if ($symptoms || $failures) return 'GEDIMAS';
    if (preg_match(
        '/sugedo|neveikia|nustojo|smirda|smarve|kvap|nesvar|drumst|drumzlin|pluta|nesusigeria|uzsikims|nedirba|perdege|zybcio|klaida|avarij|nepasileidz|nepradeda\s*veikti|sustojo|prisilild|persipildi|perpildy|uzpildy|uzsipild|atsirado\s*kvap|leidzi[ae]\s*(daug|nesvar)/u',
        $tn
    )) {
        return 'GEDIMAS';
    }

    // KAINA
    if (preg_match('/kain|uz\s*kiek|kiek\s*kainuo|preliminari|orientacin|biudzet|nebrangi|uz\s*\d+\s*eur/u', $tn)) {
        return 'KAINA';
    }

    // SISTEMOS_PASIRINKIMAS — fallback per kontekstą (regimas+zmones be eksplicitinio žodžio)
    if ($sistContext) {
        return 'SISTEMOS_PASIRINKIMAS';
    }

    // KAS_VEIKIA
    if (preg_match('/kaip\s*veikia|kas\s*tai\s*per|kas\s*yra\s+(bnvi|valymo|irenginys|orap)|ka\s*daro|kaip\s*dirba|kam\s*reikalin|paaiskink|kokia\s*paskirti|kokia\s*funkcij/u', $tn)) {
        return 'KAS_VEIKIA';
    }

    return 'KITA';
}
