<?php
/**
 * private/api/chat/knowledge_builder.php — Tikslinis žinių konstravimas v4
 *
 * PRINCIPAS: Claude gauna TIK tai kas reikalinga šiam klausimui.
 * Buvo: ~2800 tokenų visada.
 * Dabar: 300–700 tokenų pagal klausimo tipą.
 *
 * Rezultatas:
 *  - Atsakymai trumpesni (mažiau "triukšmo" kontekste)
 *  - Tiksliau (Claude negali nuklysti į nesusijusias temas)
 *  - GEDIMAS klausimams — diagnostinis medis (ekspertų sistema)
 *
 * Pagrindinė funkcija: buildExpertKnowledge(array $intent, array $userProfile): string
 */

/**
 * PAGRINDINĖ FUNKCIJA — Smart context dispatcher.
 * Pagal intent tipą parenka TIK reikalingus KB blokus.
 */
function buildExpertKnowledge(array $intent = [], array $userProfile = []): string {
    $intentType = $intent['intent']            ?? 'KITA';
    $focusOids  = $intent['focus_oids']        ?? [];
    $symptoms   = $intent['matched_symptoms']  ?? [];
    $failures   = $intent['matched_failures']  ?? [];
    $domain     = chatReadJson(DATA_DIR . 'meta/domain.json') ?? [];

    // Vartotojo profilis — VISADA pirmasis blokas (nurodo ką žinome/ko trūksta)
    $profileBlock = formatUserProfile($userProfile, $intentType);

    switch ($intentType) {

        case 'KAINA':
            return implode("\n\n", array_filter([
                $profileBlock,
                _kbPricesOnly($focusOids),
                _kbSizeRules(),
            ]));

        case 'GEDIMAS':
            return implode("\n\n", array_filter([
                $profileBlock,
                _kbDiagnosticContext($focusOids, $symptoms, $failures),
            ]));

        case 'SISTEMOS_PASIRINKIMAS':
            return implode("\n\n", array_filter([
                $profileBlock,
                _kbSystemLogic($domain),
                _kbComponentsFull(),
                _kbGvlRules(),
            ]));

        case 'SPECIALISTAS':
            return implode("\n\n", array_filter([
                $profileBlock,
                _kbSpecialists(),
            ]));

        case 'KAS_VEIKIA':
            $oids = $focusOids ?: array_keys(_kbAllComponentCtx());
            return implode("\n\n", array_filter([
                $profileBlock,
                _kbComponentBrief($oids),
                _kbCommonRules(),
            ]));

        default: // KITA
            return implode("\n\n", array_filter([
                $profileBlock,
                _kbSystemLogic($domain),
                _kbCommonRules(),
            ]));
    }
}

// ─── GEDIMAS: Diagnostinis kontekstas ─────────────────────────────────────────

/**
 * Gedimo klausimui: surinkai simptomų aprašus + tiksliai atitinkančius gedimus
 * + diagnostinį medį jei egzistuoja. Tai yra ekspertų sistemos branduolys.
 */
function _kbDiagnosticContext(array $focusOids, array $matchedSymptomIds, array $matchedFailures): string {
    $lines = [];
    $lines[] = '=== DIAGNOSTINIS KONTEKSTAS ===';
    $lines[] = 'Esi diagnostikas. Vartotojas aprašo problemą. Tavo užduotis:';
    $lines[] = '1. Identifikuok tikėtiniausią gedimą pagal simptomus';
    $lines[] = '2. Jei yra diagnostinis medis — vyk per jį žingsnis po žingsnio';
    $lines[] = '3. Jei medžio nėra — pateik tikrinimo žingsnius pagal gedimų sąrašą';
    $lines[] = '4. Klausk TIK VIENO klausimo vienu metu (TAIP/NE arba konkretus)';

    // Simptomų atpažinimas
    if ($matchedSymptomIds) {
        $sympData = chatReadJson(DATA_DIR . 'symptoms/_index.json');
        if ($sympData && !empty($sympData['symptoms'])) {
            $lines[] = '';
            $lines[] = '--- Atpažinti simptomai ---';
            foreach ($sympData['symptoms'] as $s) {
                if (!in_array($s['id'] ?? '', $matchedSymptomIds, true)) continue;
                $objStr = !empty($s['objects']) ? ' [' . implode(', ', $s['objects']) . ']' : '';
                $lines[] = '• ' . ($s['name'] ?? '') . $objStr;
                if (!empty($s['description'])) {
                    $lines[] = '  ' . $s['description'];
                }
            }
        }
    }

    // OID'ai iš simptomų (jei focus_oids tuščias)
    if (!$focusOids && $matchedSymptomIds) {
        $sympData = chatReadJson(DATA_DIR . 'symptoms/_index.json');
        if ($sympData) {
            foreach ($sympData['symptoms'] as $s) {
                if (!in_array($s['id'] ?? '', $matchedSymptomIds, true)) continue;
                foreach ($s['objects'] ?? [] as $oid) {
                    if (!in_array($oid, $focusOids)) $focusOids[] = $oid;
                }
            }
        }
    }

    // Tiksliniai gedimai
    $hasFailures = false;
    $processedOids = $focusOids ?: ['BNVI', 'FEKSIURB', 'DRENSIURB'];

    foreach ($processedOids as $oid) {
        $failures = glob(DATA_DIR . 'objects/' . $oid . '/failures/*.json') ?: [];
        foreach ($failures as $file) {
            if (str_ends_with($file, '_index.json')) continue;
            $f = chatReadJson($file);
            if (!$f || empty($f['id'])) continue;

            $hasFailures = true;
            $sev = match($f['severity'] ?? '') {
                'high' => ' 🔴 RIMTA', 'med' => ' 🟡 vidutinis', default => ''
            };

            $lines[] = '';
            $lines[] = '--- Gedimas: ' . ($f['name'] ?? '') . $sev . ' ---';

            // Simptomai
            if (!empty($f['symptoms'])) {
                $lines[] = 'Simptomai: ' . implode(', ', $f['symptoms']);
            }

            // Priežastys su tikimybėmis
            $causes = $f['causes']['list'] ?? [];
            if ($causes) {
                $lines[] = 'Galimos priežastys:';
                // Rūšiuoti pagal tikimybę
                usort($causes, fn($a, $b) => ($b['pct'] ?? 0) <=> ($a['pct'] ?? 0));
                foreach ($causes as $c) {
                    $name = trim($c['name'] ?? '');
                    $fix  = trim($c['fix'] ?? '');
                    $pct  = isset($c['pct']) && $c['pct'] !== null ? ' (' . $c['pct'] . '%)' : '';
                    if ($name) {
                        $line = '  → ' . $name . $pct;
                        if ($fix) $line .= ': ' . $fix;
                        $lines[] = $line;
                    }
                }
            }

            // Prevencija
            if (!empty($f['prevention'])) {
                $lines[] = 'Prevencija: ' . $f['prevention'];
            }

            // ★ Diagnostinis medis — jei egzistuoja, tai yra ekspertų sistemos širdis
            $treePath = DATA_DIR . 'objects/' . $oid . '/trees/' . ($f['id'] ?? '') . '_tree.json';
            if (file_exists($treePath)) {
                $tree = chatReadJson($treePath);
                if ($tree && !empty($tree['root'])) {
                    $lines[] = '';
                    $lines[] = '★ DIAGNOSTINIS MEDIS (sek žingsnis po žingsnio):';
                    $lines[] = _kbTreeToText($tree['root']);
                    $lines[] = '(Pradėk nuo pirmo klausimo. Eik pagal vartotojo atsakymą. Klausk TIK VIENO klausimo.)';
                }
            }
        }
    }

    if (!$hasFailures) {
        $lines[] = '';
        $lines[] = '⚠️ Šiam komponentui gedimų bazėje dar nėra duomenų.';
        $lines[] = 'Pasakyk vartotojui ką gali pagal bendrą žinojimą ir nukreipk į [DIAGNOSTIKA].';
    }

    return implode("\n", $lines);
}

/**
 * Konvertuoja diagnostinį medį į skaitomą teksto formatą.
 * Rekursyviai eina per medžio mazgus ir formuoja žingsnius.
 */
function _kbTreeToText(array $node, string $prefix = ''): string {
    $type     = $node['type']     ?? '';
    $text     = trim($node['text'] ?? '');
    $children = $node['children'] ?? [];
    $branches = $node['branches'] ?? [];
    $out      = '';

    if ($type === 'start') {
        foreach ($children as $child) {
            $out .= _kbTreeToText($child, $prefix);
        }
        return $out;
    }

    if ($type === 'klausimas') {
        $out .= $prefix . '❓ ' . $text . "\n";
        foreach ($children as $i => $child) {
            $label     = $branches[$i] ?? ($i === 0 ? 'TAIP' : 'NE');
            $childType = $child['type'] ?? '';
            $childText = trim($child['text'] ?? '');
            if ($childType === 'sprendimas') {
                $out .= $prefix . "  [{$label}] → ✅ " . $childText . "\n";
            } else {
                $out .= $prefix . "  [{$label}] →\n";
                $out .= _kbTreeToText($child, $prefix . '    ');
            }
        }
        return $out;
    }

    if ($type === 'sprendimas') {
        $out .= $prefix . '✅ ' . $text . "\n";
        return $out;
    }

    return $out;
}

// ─── KAINA: Tik kainos ────────────────────────────────────────────────────────

function _kbPricesOnly(array $focusOids): string {
    $ctx   = _kbAllComponentCtx();
    $lines = ['=== KAINOS ==='];

    $oidsToShow = $focusOids ?: array_keys($ctx);

    foreach ($oidsToShow as $oid) {
        if (!isset($ctx[$oid])) continue;
        $baseFile = DATA_DIR . 'objects/' . $oid . '/base.json';
        if (!file_exists($baseFile)) continue;
        $base   = chatReadJson($baseFile) ?? [];
        $models = $base['models'] ?? [];
        if (!$models) continue;

        $lines[] = '';
        $lines[] = $ctx[$oid]['pavadinimas'] . ':';
        foreach ($models as $m) {
            $n     = trim($m['name']  ?? '');
            $price = $m['price_eur']  ?? '';
            $note  = trim($m['notes'] ?? '');
            $str   = ($n ? $n . ' — ' : '') . $price . '€';
            if ($note) $str .= ' (' . $note . ')';
            $lines[] = '  ' . $str;
        }

        $mi = $base['maintenance_schedule']['interval_months'] ?? null;
        if ($mi) $lines[] = '  Priežiūra: kas ' . $mi . ' mėn. (~120€)';
    }

    return implode("\n", $lines);
}

function _kbSizeRules(): string {
    return "=== BNVI DYDŽIO TAISYKLĖS ===\n"
         . "1–2 gyventojai → B4A (4 asmenų, 1590€)\n"
         . "3 gyventojai → B6A (6 asmenų, 1780€)\n"
         . "4–5 gyventojai → B8A (8 asmenų, 2340€)\n"
         . "6–8 gyventojai → B10A (10 asmenų, 3000€)\n"
         . "12–15 gyventojų → B15A (15 asmenų, 4400€)\n"
         . "Sezoninis/sodybos naudojimas → UZDTALP (uždara talpykla, ne BNVI)\n"
         . "Taisyklė: gyventojų skaičius × 2 = rekomenduojamas modelio asmenų sk.";
}

// ─── KAS_VEIKIA: Komponentų aprašai ──────────────────────────────────────────

function _kbComponentBrief(array $oids): string {
    $ctx   = _kbAllComponentCtx();
    $lines = ['=== KOMPONENTAI ==='];

    foreach ($oids as $oid) {
        $c = $ctx[$oid] ?? null;
        if (!$c) continue;

        // Papildomi laukai iš base.json (normal_operation, normal_signs, function)
        $base = chatReadJson(DATA_DIR . 'objects/' . $oid . '/base.json') ?? [];

        $lines[] = '';
        $lines[] = $c['pavadinimas'] . ':';
        $lines[] = '  Paskirtis: ' . $c['paskirtis'];

        // Normalaus veikimo požymiai iš base.json
        $normalOp = trim($base['normal_operation'] ?? '');
        if ($normalOp) $lines[] = '  Normalus veikimas: ' . $normalOp;

        $normalSigns = $base['normal_signs'] ?? [];
        if ($normalSigns) $lines[] = '  Normalaus veikimo požymiai: ' . implode(', ', $normalSigns);

        if (!empty($c['kada']))     $lines[] = '  Kada naudojamas: ' . $c['kada'];
        if (!empty($c['nereikia'])) $lines[] = '  Kada NEREIKIA: ' . $c['nereikia'];
        if (!empty($c['svarbu']))   $lines[] = '  Svarbu: ' . $c['svarbu'];
        if (!empty($c['draudimas'])) $lines[] = '  ' . $c['draudimas'];
    }

    return implode("\n", $lines);
}

// ─── SISTEMOS_PASIRINKIMAS: Pilni aprašai ─────────────────────────────────────

function _kbComponentsFull(): string {
    $ctx   = _kbAllComponentCtx();
    $lines = ['=== KOMPONENTAI IR KAINOS ==='];

    foreach ($ctx as $oid => $c) {
        $baseFile = DATA_DIR . 'objects/' . $oid . '/base.json';
        if (!file_exists($baseFile)) continue;
        $base = chatReadJson($baseFile) ?? [];

        $lines[] = '';
        $lines[] = '--- ' . $c['pavadinimas'] . ' ---';
        $lines[] = 'Paskirtis: ' . $c['paskirtis'];
        if ($c['kada'])      $lines[] = 'Kada: ' . $c['kada'];
        if ($c['nereikia'])  $lines[] = 'Kada NEREIKIA: ' . $c['nereikia'];
        if ($c['svarbu'])    $lines[] = 'Svarbu: ' . $c['svarbu'];
        if ($c['draudimas']) $lines[] = $c['draudimas'];

        $models = $base['models'] ?? [];
        if ($models) {
            $ps = [];
            foreach ($models as $m) {
                $n     = trim($m['name'] ?? '');
                $price = $m['price_eur'] ?? '';
                $note  = trim($m['notes'] ?? '');
                $str   = ($n ? $n . '=' : '') . $price . '€';
                if ($note) $str .= '(' . $note . ')';
                $ps[] = $str;
            }
            $lines[] = 'Kainos: ' . implode(', ', $ps);
        }

        $mi = $base['maintenance_schedule']['interval_months'] ?? null;
        if ($mi) $lines[] = 'Priežiūra: kas ' . $mi . ' mėn. (~120€)';
    }

    return implode("\n", $lines);
}

// ─── Sistemų logika + GVL ────────────────────────────────────────────────────

function _kbSystemLogic(array $domain): string {
    $systems   = $domain['sistemu_tipai'] ?? [];
    $objects   = $domain['objektai']      ?? [];
    $gvlBlocks = $domain['gvl_blokuoja'] ?? [];
    $molBlocks = $domain['mol_blokuoja'] ?? [];

    // Pilni lietuviški pavadinimai vietoje trumpinimų
    $fullNames = [
        'NAM1'     => 'Namas (seklas išvadas)',
        'NAM2'     => 'Namas (gilus išvadas)',
        'FEKSIURB' => 'Fekalinė siurblinė',
        'BNVI'     => 'Biologinis valymo įrenginys',
        'MEGSUL'   => 'Mėginių šulinys',
        'DRENSIURB'=> 'Drenažinė siurblinė',
        'UZDTALP'  => 'Uždara talpykla',
        'INFSUL'   => 'Infiltracinis šulinys',
        'INFKAUB'  => 'Infiltracinis kauburys',
        'INFLAUK'  => 'Infiltracinis laukas',
        'ZEMPAV'   => 'Paviršius/griovys',
        'SLAIT'    => 'Šlaitas',
    ];

    $lines   = [];
    $lines[] = '=== SISTEMŲ TIPAI ===';
    $lines[] = 'Principas: Namas → [Valymas arba kaupimas] → [Išleidimas arba išsiurbimas]';
    $lines[] = 'Jei namo kanalizacijos išvadas seklesnis nei 1.4m — gravitacija pakanka. Jei giliau (1.6m+) — reikalinga fekalinė siurblinė.';
    $lines[] = '';

    foreach ($systems as $sys) {
        $id    = $sys['id'];
        $chain = $sys['grandine'] ?? [];
        $parts = array_map(fn($oid) => $fullNames[$oid] ?? ($objects[$oid]['name'] ?? $oid), $chain);

        $blocks = [];
        foreach ($gvlBlocks as $gvl => $ids) {
            if (in_array($id, $ids, true)) {
                $blocks[] = match($gvl) {
                    'gvl-1' => 'GVL aukštas (<0.5m)',
                    'gvl-2' => 'GVL vidutinis (0.5–1.5m)',
                    default => $gvl
                };
            }
        }
        if (in_array($id, $molBlocks, true)) $blocks[] = 'molis';

        $blockStr = $blocks ? ' — neveikia kai: ' . implode(', ', $blocks) : ' — universali';
        $lines[]  = 'Sistema ' . $id . ': ' . implode(' → ', $parts) . $blockStr;
    }

    return implode("\n", $lines);
}

function _kbGvlRules(): string {
    return "=== GRUNTINIO VANDENS LYGIO (GVL) APRIBOJIMAI ===\n"
         . "GVL aukštas (<0.5m nuo žemės): draudžia bet kokią infiltraciją žemyn — tinka tik infiltracinis kauburys ant žemės paviršiaus\n"
         . "GVL vidutinis (0.5–1.5m): draudžia infiltracinį šulinį ir lauką — tinka tik kauburys\n"
         . "GVL žemas (>1.5m): visi variantai leistini\n"
         . "Molis: draudžia infiltracinį šulinį ir lauką — tinka kauburys arba drenažinė siurblinė į paviršių";
}

// ─── Specialistai ────────────────────────────────────────────────────────────

function _kbSpecialists(): string {
    $entries  = chatReadJson(DATA_DIR . 'map/entries.json') ?? [];
    $approved = array_values(array_filter($entries, fn($e) => !empty($e['approved'])));

    if (!$approved) return '';

    $lines   = ['=== PATVIRTINTI SPECIALISTAI ==='];
    $lines[] = 'Rodyk VISUS tinkančius. Filtruok pagal miestą jei nurodyta.';

    foreach ($approved as $e) {
        $name  = $e['name']  ?? '';
        $city  = $e['city']  ?? '';
        $tel   = $e['tel']   ?? '';
        $types = $e['types'] ?? [$e['type'] ?? ''];
        $tStr  = implode(', ', array_filter($types));
        $info  = trim($e['info'] ?? '');
        $line  = $name . ' | ' . $city . ' | ' . $tStr . ' | ' . $tel;
        if ($info) $line .= ' | ' . $info;
        $lines[] = $line;
    }

    return implode("\n", $lines);
}

// ─── Bendros taisyklės ───────────────────────────────────────────────────────

function _kbCommonRules(): string {
    return <<<'RULES'
=== DRAUDIMAI IR TAISYKLĖS ===

ABSOLIUTŪS DRAUDIMAI:
- Cheminiai valymo preparatai (Ajax, Domestos, kanalizacijos atkimšikliai) biologiniame įrenginyje — NIEKADA. Iš karto žudo bakterijų koloniją.
- Drėgnos servetėlės (net jei ant pakuotės "tirpios") — kemia siurblius ir smulkintuvus.
- Biologinis valymo įrenginys sezoninio naudojimo sodybai — bakterijos žūsta. Tokiu atveju — tik uždara talpykla.

DAŽNI MITAI:
- "Bakterijų tabletės / milteliai" — NEEGZISTUOJA. Bakterijos imamos tik iš veikiančio biologinio įrenginio arba nuotekų valyklų (bent 200L aktyvaus dumblo).
- "BioTornado yra geriausias" — vieno geriausio NĖRA. Problemos kyla dėl per mažo įrenginio, blogo montavimo arba savininko klaidų.
- "Tualetinis popierius gadina" — įprastas tualetinis popierius yra normalu.
- "Naujam įrenginiui nereikia bakterijų" — reikia. Pačios neatsiranda.
- "Orapūtė tyli — įrenginys sugedo" — dažniau: rozetė, saugiklis, drėgnas orapūtės kibirėlis.

NAUDINGA:
- Putos po skalbimo: normalu, dingsta per 1–2 dienas.
- Bakterijų kvapas iki 24h po aptarnavimo: normalu. Ilgiau — tikrinti orapūtę.
- Garsas nuo orapūtės: pastatyti ant nedegios vatos ar gumos.
RULES;
}

// ─── Komponentų statinis kontekstas ──────────────────────────────────────────

function _kbAllComponentCtx(): array {
    return [
        'BNVI' => [
            'pavadinimas' => 'Biologinis nuotekų valymo įrenginys (BNVI)',
            'paskirtis'   => 'Orapūtė tiekia orą → bakterijų kolonija (aktyvus dumblas) → skaido nuotekas → išleidžia techniškai švarų vandenį.',
            'kada'        => 'Visose sistemose išskyrus uždarą talpyklą.',
            'nereikia'    => 'Sezoninis naudojimas (sodybos) — bakterijos žūsta be nuolatinės apkrovos.',
            'svarbu'      => 'Be oro bakterijos žūsta per 2–3 dienas. Gyventojų sk. × 2 = rekomenduojamas modelio asmenų sk.',
            'draudimas'   => '⛔ Jokie cheminiai valymo preparatai. Drėgnos servetėlės — net "tirpios".',
        ],
        'FEKSIURB' => [
            'pavadinimas' => 'Fekalinė siurblinė (FEKSIURB)',
            'paskirtis'   => 'Kai namo išvadas gilus (1.6m+) — pompa nuotekas aukštyn iki BNVI.',
            'kada'        => 'NAM2 situacija — namo išvadas giliau nei ~1.4m.',
            'nereikia'    => 'Kai namo išvadas seklesnis ~1.2–1.4m — gravitacija pakanka.',
            'svarbu'      => 'Dažniausias gedimas: užsikimša smulkintuvas (plaukai, drėgnos servetėlės).',
            'draudimas'   => '',
        ],
        'DRENSIURB' => [
            'pavadinimas' => 'Drenažinė siurblinė (DRENSIURB)',
            'paskirtis'   => 'Surenka išvalytą vandenį ir išpumpa į paviršių/griovį. Veikia pagal plūdę.',
            'kada'        => 'GVL-1, molis, arba kai infiltracija žemyn neįmanoma.',
            'nereikia'    => 'Kai gruntas gerai sugeria (smėlis, GVL-3).',
            'svarbu'      => '',
            'draudimas'   => '',
        ],
        'UZDTALP' => [
            'pavadinimas' => 'Uždara talpykla (UZDTALP)',
            'paskirtis'   => 'Kaupia nuotekas be valymo. Išsiurbimas ~30–50€/m³.',
            'kada'        => 'Sezoninis naudojimas (sodybos, ≤3 kartai/metus).',
            'nereikia'    => 'Nuolatiniams gyventojams — per brangus išlaikymas.',
            'svarbu'      => 'Priežiūra kas 6 mėn.',
            'draudimas'   => '',
        ],
        'INFSUL' => [
            'pavadinimas' => 'Infiltracinis šulinys (INFSUL)',
            'paskirtis'   => 'Absorbuoja išvalytą vandenį į gruntą per šulinio dugno poras.',
            'kada'        => 'Geras gruntas (smėlis, žvyras), GVL-2 arba GVL-3.',
            'nereikia'    => 'GVL-1 arba molis — vanduo nesugeria.',
            'svarbu'      => '',
            'draudimas'   => '',
        ],
        'INFLAUK' => [
            'pavadinimas' => 'Infiltracinis laukas (INFLAUK)',
            'paskirtis'   => 'Horizontali infiltracija per vamzdžius sklype. Platesnis paviršius.',
            'kada'        => 'Geras gruntas, GVL-2/3, kai šulinys per mažas.',
            'nereikia'    => 'Molis, GVL-1.',
            'svarbu'      => '1 sekcija = 30m. Priežiūra kas 3 metai.',
            'draudimas'   => '',
        ],
        'INFKAUB' => [
            'pavadinimas' => 'Infiltracinis kauburys (INFKAUB)',
            'paskirtis'   => 'Vanduo filtruojamas per žemės kauburį — pakyla virš gruntinio vandens lygio. Veikia kai GVL aukštas arba molis.',
            'kada'        => 'GVL-2, molis — kai kiti infiltracijos variantai neveikia.',
            'nereikia'    => '',
            'svarbu'      => '1 tunelis ≈ 1m. Priežiūra kas 3 metai.',
            'draudimas'   => '',
        ],
        'MEGSUL' => [
            'pavadinimas' => 'Mėginių ėmimo šulinys (MEGSUL)',
            'paskirtis'   => 'Kontrolinis taškas — tikrina išleidžiamo vandens kokybę. Privalomas LT taisyklėse.',
            'kada'        => 'Sistemose su BNVI + infiltracija.',
            'nereikia'    => '',
            'svarbu'      => 'Priežiūra kas 6 mėn.',
            'draudimas'   => '',
        ],
        'SLAIT' => [
            'pavadinimas' => 'Šlaitas (SLAIT)',
            'paskirtis'   => 'Išvalytas vanduo išleidžiamas per natūralų šlaitą gravitaciškai.',
            'kada'        => 'Kai sklype yra tinkamas šlaitas.',
            'nereikia'    => '',
            'svarbu'      => 'Priežiūra kas 6 mėn.',
            'draudimas'   => '',
        ],
        'ZEMPAV' => [
            'pavadinimas' => 'Žemės paviršius (ZEMPAV)',
            'paskirtis'   => 'Drenažinė siurblinė išpumpa vandenį tiesiogiai į paviršių arba griovį.',
            'kada'        => 'Su drenažine siurblyne kai infiltracija žemyn neįmanoma.',
            'nereikia'    => '',
            'svarbu'      => '',
            'draudimas'   => '',
        ],
    ];
}
