<?php
require_once dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__) . '/engine/DiagnosticEngine.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

apiHeaders();
rateLimit(30, 1, 'kb');

try {
    apiOk(['kb' => DiagnosticEngine::getKb()]);
} catch (Throwable $e) {
    error_log('kb: ' . $e->getMessage());
    apiErr(500, 'Serverio klaida');
}
