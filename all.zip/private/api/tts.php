<?php
require_once dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

requirePost();
rateLimit(10, 1, 'tts');

if (!OPENAI_KEY) { http_response_code(500); exit; }

$body = json_decode(file_get_contents('php://input'), true) ?? [];
$text = mb_substr(trim($body['text'] ?? ''), 0, 500);
if (!$text) { http_response_code(400); exit; }

$ch = curl_init('https://api.openai.com/v1/audio/speech');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . OPENAI_KEY],
    CURLOPT_POSTFIELDS     => json_encode(['model' => 'tts-1', 'voice' => TTS_VOICE, 'input' => $text, 'speed' => TTS_SPEED]),
    CURLOPT_TIMEOUT        => 20,
]);

$audio    = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if (!$audio || $httpCode !== 200) { http_response_code(502); exit; }

header('Content-Type: audio/mpeg');
header('Content-Length: ' . strlen($audio));
echo $audio;
