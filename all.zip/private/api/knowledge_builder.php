<?php
/**
 * private/api/chat/knowledge_builder.php — Pilnas KB briefingas v5
 *
 * FILOSOFIJA:
 * Geresnis chatas = tikslus kontekstas, ne daugiau kodo.
 * Claude gauna VISĄ turimą KB informaciją, gerai struktūrizuotą.
 * Sistema pati nusprendžia kas svarbu — ne PHP filtrai.
 *
 * Kas čia yra:
 *  - Pilna sistemų suderinamumo matrica (deterministinė iš domain.json)
 *  - Visi komponentai su kainomis ir aprašais
 *  - Visi simptomai ir gedimai
 *  - Visi specialistai
 *  - Vartotojo profilis (kas žinoma apie šį žmogų)
 *
 * Pagrindinė funkcija: buildExpertKnowledge(array $intent, array $userProfile): string
 */

function buildExpertKnowledge(array $intent = [], array $userProfile = []): string {
    $domain = chatReadJson(DATA_DIR . 'meta/domain.json') ?? [];

    return implode("\n\n", array_filter([
        formatUserProfile($userProfile, $intent['intent'] ?? 'KITA'),
        _kbCompatibilityMatrix($domain),
        _kbAllComponents(),
        _kbSymptomsAndFailures(),
        _kbSpecialists(),
        _kbRulesAndMyths(),
    ]));
}

// ─── 1. SISTEMŲ SUDERINAMUMO MATRICA ─────────────────────────────────────────
// Deterministinė — apskaičiuota iš domain.json, ne spėliojama.

function _kbCompatibilityMatrix(array $domain): string {
    $systems   = $domain['sistemu_tipai'] ?? [];
    $objects   = $domain['objektai']      ?? [];
    $gvlBlocks = $domain['gvl_blokuoja'] ?? [];
    $molBlocks = $domain['mol_blokuoja'] ?? [];

    $lines   = [];
    $lines[] = '=== SISTEMŲ PASIRINKIMAS PAGAL SĄLYGAS ===';
    $lines[] = 'NAM1 = namo išvadas <1.4m (nereikia fekalinės siurblinės)';
    $lines[] = 'NAM2 = namo išvadas >1.6m (reikalinga fekalinė siurblinė FS)';
    $lines[] = '';

    // Komponentų pilni pavadinimai
    $names = [
        'NAM1' => 'Namas', 'NAM2' => 'Namas+FS',
        'FEKSIURB' => 'Fek.siurblinė', 'BNVI' => 'BNVI',
        'MEGSUL' => 'Mėg.šulinys', 'DRENSIURB' => 'Dren.siurblinė',
        'UZDTALP' => 'Už.talpykla', 'INFSUL' => 'Inf.šulinys',
        'INFKAUB' => 'Inf.kauburys', 'INFLAUK' => 'Inf.laukas',
        'ZEMPAV' => 'Žemės pavršius', 'SLAIT' => 'Šlaitas',
    ];

    // Visos 6 sąlygų kombinacijos
    $combos = [
        ['label' => 'GVL-1 (<0.5m) + MOLIS',  'gvl' => 'gvl-1', 'mol' => true],
        ['label' => 'GVL-1 (<0.5m) + SMĖLIS', 'gvl' => 'gvl-1', 'mol' => false],
        ['label' => 'GVL-2 (0.5-1.5m) + MOLIS',  'gvl' => 'gvl-2', 'mol' => true],
        ['label' => 'GVL-2 (0.5-1.5m) + SMĖLIS', 'gvl' => 'gvl-2', 'mol' => false],
        ['label' => 'GVL-3 (>1.5m) + MOLIS',  'gvl' => 'gvl-3', 'mol' => true],
        ['label' => 'GVL-3 (>1.5m) + SMĖLIS', 'gvl' => 'gvl-3', 'mol' => false],
    ];

    foreach ($combos as $combo) {
        $blocked = [];
        foreach ($gvlBlocks as $gvl => $ids) {
            if ($gvl === $combo['gvl']) {
                $blocked = array_merge($blocked, $ids);
            }
        }
        if ($combo['mol']) {
            $blocked = array_merge($blocked, $molBlocks);
        }
        $blocked = array_unique($blocked);

        $allowed = [];
        foreach ($systems as $sys) {
            if (!in_array($sys['id'], $blocked)) {
                $chain = array_map(fn($o) => $names[$o] ?? $o, $sys['grandine']);
                $allowed[] = 'Sist.' . $sys['id'] . ': ' . implode(' → ', $chain);
            }
        }

        $lines[] = $combo['label'] . ' — ' . count($allowed) . ' sistemų:';
        foreach ($allowed as $a) $lines[] = '  ✓ ' . $a;
        $lines[] = '';
    }

    $lines[] = 'BLOKAVIMO LOGIKA:';
    $lines[] = 'Molis blokuoja: infiltracinius šulinius (IS) ir laukus (IL) — vanduo nesugeria';
    $lines[] = 'GVL-1 blokuoja: viską kas leidžia vandenį į žemę žemyn (IS, IL)';
    $lines[] = 'GVL-2 blokuoja: tiesioginę infiltraciją (IS) — bet leidžia kauburį (IK)';
    $lines[] = 'Jei nežinomas GVL — klausk jo PIRMA. Tai svarbiausia informacija.';

    return implode("\n", $lines);
}

// ─── 2. VISI KOMPONENTAI ──────────────────────────────────────────────────────

function _kbAllComponents(): string {
    $lines   = [];
    $lines[] = '=== KOMPONENTAI, KAINOS, APRAŠAI ===';

    $components = _componentDefinitions();

    foreach ($components as $oid => $def) {
        $baseFile = DATA_DIR . 'objects/' . $oid . '/base.json';
        $base     = file_exists($baseFile) ? (chatReadJson($baseFile) ?? []) : [];

        $lines[] = '';
        $lines[] = '--- ' . $def['pavadinimas'] . ' (' . $oid . ') ---';
        $lines[] = 'Funkcija: ' . ($base['function'] ?? $def['funkcija']);

        if (!empty($base['normal_operation'])) {
            $lines[] = 'Veikimas: ' . $base['normal_operation'];
        }
        if (!empty($base['normal_signs'])) {
            $lines[] = 'Normalūs požymiai: ' . implode(', ', $base['normal_signs']);
        }

        if ($def['kada'])     $lines[] = 'Kada reikia: ' . $def['kada'];
        if ($def['nereikia']) $lines[] = 'Kada NEREIKIA: ' . $def['nereikia'];
        if ($def['svarbu'])   $lines[] = 'Svarbu: ' . $def['svarbu'];
        if ($def['draud'])    $lines[] = '⛔ ' . $def['draud'];

        // Kainos
        $models = $base['models'] ?? [];
        if ($models) {
            $ps = [];
            foreach ($models as $m) {
                $n    = trim($m['name'] ?? '');
                $p    = $m['price_eur'] ?? '';
                $note = trim($m['notes'] ?? '');
                $str  = ($n ? $n . ' ' : '') . $p . '€';
                if ($note) $str .= ' (' . $note . ')';
                $ps[] = $str;
            }
            $lines[] = 'Kainos: ' . implode(' | ', $ps);
        }

        $mi = $base['maintenance_schedule']['interval_months'] ?? null;
        if ($mi) $lines[] = 'Priežiūra: kas ' . $mi . ' mėn. (~120€)';
    }

    return implode("\n", $lines);
}

// ─── 3. VISI SIMPTOMAI IR GEDIMAI ────────────────────────────────────────────

function _kbSymptomsAndFailures(): string {
    $lines   = [];
    $lines[] = '=== SIMPTOMAI IR GEDIMAI ===';
    $lines[] = 'KB turi tik žemiau išvardytus gedimus. Kitiems — sakyk "KB neturi šio gedimo".';

    // Simptomai
    $sympData = chatReadJson(DATA_DIR . 'symptoms/_index.json');
    if ($sympData && !empty($sympData['symptoms'])) {
        $lines[] = '';
        $lines[] = '--- Žinomi simptomai ir jų komponentai ---';
        foreach ($sympData['symptoms'] as $s) {
            $objs = implode(', ', $s['objects'] ?? []);
            $lines[] = $s['id'] . ': ' . ($s['name'] ?? '') . ' → ' . $objs;
            if (!empty($s['description'])) {
                $lines[] = '  ' . $s['description'];
            }
        }
    }

    // Visi gedimai
    $lines[] = '';
    $lines[] = '--- Žinomi gedimai ---';

    foreach (glob(DATA_DIR . 'objects/*/failures/*.json') ?: [] as $file) {
        if (str_ends_with($file, '_index.json')) continue;

        $f = chatReadJson($file);
        if (!$f || empty($f['id'])) continue;
        if (empty($f['name']) && empty($f['symptoms'])) continue; // Tuščias

        $sev = match($f['severity'] ?? '') {
            'high', 'critical' => ' 🔴', 'med' => ' 🟡', default => ''
        };

        $lines[] = '';
        $lines[] = $f['id'] . ': ' . ($f['name'] ?? '') . $sev;

        if (!empty($f['symptoms'])) {
            $lines[] = '  Simptomai: ' . implode(', ', $f['symptoms']);
        }

        // Priežastys (rūšiuotos pagal tikimybę)
        $causes = $f['causes']['list'] ?? [];
        if ($causes) {
            usort($causes, fn($a, $b) => ($b['pct'] ?? 0) <=> ($a['pct'] ?? 0));
            foreach ($causes as $c) {
                $n   = trim($c['name'] ?? '');
                $fix = trim($c['fix']  ?? '');
                $pct = isset($c['pct']) && $c['pct'] !== null ? ' ' . $c['pct'] . '%' : '';
                if (!$n) continue;
                $line = '  → ' . $n . $pct;
                if ($fix) $line .= ': ' . $fix;
                $lines[] = $line;
            }
        }

        if (!empty($f['prevention'])) {
            $lines[] = '  Prevencija: ' . $f['prevention'];
        }

        // Diagnostinis medis
        $oid  = $f['object_id'] ?? dirname(dirname($file));
        $tree = chatReadJson(DATA_DIR . 'objects/' . $oid . '/trees/' . $f['id'] . '_tree.json');
        if ($tree && !empty($tree['root'])) {
            $lines[] = '  Diagnostinis medis:';
            $treeText = _treeToText($tree['root'], '    ');
            if ($treeText) $lines[] = $treeText;
        }
    }

    return implode("\n", $lines);
}

function _treeToText(array $node, string $pad = ''): string {
    $type     = $node['type']     ?? '';
    $text     = trim($node['text'] ?? '');
    $children = $node['children'] ?? [];
    $branches = $node['branches'] ?? [];
    $out      = '';

    if ($type === 'start') {
        foreach ($children as $child) $out .= _treeToText($child, $pad);
        return $out;
    }
    if ($type === 'klausimas') {
        $out .= $pad . '❓ ' . $text . "\n";
        foreach ($children as $i => $child) {
            $label = $branches[$i] ?? ($i === 0 ? 'TAIP' : 'NE');
            if (($child['type'] ?? '') === 'sprendimas') {
                $out .= $pad . "  [{$label}] ✅ " . trim($child['text'] ?? '') . "\n";
            } else {
                $out .= $pad . "  [{$label}]\n" . _treeToText($child, $pad . '    ');
            }
        }
    }
    if ($type === 'sprendimas') {
        $out .= $pad . '✅ ' . $text . "\n";
    }
    return $out;
}

// ─── 4. SPECIALISTAI ─────────────────────────────────────────────────────────

function _kbSpecialists(): string {
    $entries  = chatReadJson(DATA_DIR . 'map/entries.json') ?? [];
    $approved = array_values(array_filter($entries, fn($e) => !empty($e['approved'])));
    if (!$approved) return '';

    $lines   = ['=== SPECIALISTAI ==='];
    $lines[] = 'Rodyti VISUS. Filtruoti pagal miestą ar tipą jei vartotojas nurodo.';

    foreach ($approved as $e) {
        $types = implode(', ', array_filter($e['types'] ?? [$e['type'] ?? '']));
        $info  = trim($e['info'] ?? '');
        $line  = ($e['name'] ?? '') . ' | ' . ($e['city'] ?? '') . ' | ' . $types . ' | ' . ($e['tel'] ?? '');
        if ($info) $line .= ' | ' . $info;
        $lines[] = '  ' . $line;
    }

    return implode("\n", $lines);
}

// ─── 5. TAISYKLĖS IR MITAI ────────────────────────────────────────────────────

function _kbRulesAndMyths(): string {
    return <<<'TXT'
=== TAISYKLĖS, DRAUDIMAI, MITAI ===

ABSOLIUTŪS DRAUDIMAI (BNVI):
- Jokių cheminių valymo priemonių (Ajax, Domestos, WC kacheliukai, kanalizacijos atkimšikliai) — NIEKADA. Iš karto žudo bakterijų koloniją.
- Drėgnos servetėlės (net jei "tirpios") — kimša smulkintuvus ir siurblius.
- Sezoninis naudojimas su BNVI (sodybos, retai) — bakterijos žūsta. Tokiu atveju tik UZDTALP.

DAŽNI MITAI:
- "Bakterijų tabletės / milteliai" — NEEGZISTUOJA. Bakterijoms atkurti reikia 200+ litrų aktyvaus dumblo iš veikiančio įrenginio arba centralizuotos nuotekų valyklos. Jokiose parduotuvėse tokio produkto nėra.
- "BioTornado yra geriausias" — vieno geriausio gamintojo NĖRA. Problemos kyla dėl per mažo modelio, blogo montavimo ar savininko klaidų.
- "Tualetinis popierius gadina" — įprastas tualetinis popierius yra normalu.
- "Naujam įrenginiui bakterijos atsiras savaime" — NEATSIRADO. Reikalingas aktyvus dumblas.
- "Orapūtė tyli = viskas sudegė" — dažniau: nekvepia saugiklis, drėgnas kibirėlis, atjungta rozetė.

DYDŽIO TAISYKLĖ (BNVI):
Gyventojų skaičius × 2 = minimalus modelio asmenų skaičius.
1–2 asm → B4A | 3 asm → B6A | 4–5 asm → B8A | 6–8 asm → B10A | 12–15 asm → B15A

PRIEŽIŪROS KAINOS:
- BNVI aptarnavimas: ~120€ (kas 12 mėn., privalomas)
- Uždara talpykla išsiurbimas: 30–50€/m³ (priklausomai nuo tūrio)

NORMALŪS REIŠKINIAI (ne gedimai):
- Putos po skalbimo: normalu, dingsta per 1–2 dienas
- Bakterijų kvapas iki 24h po aptarnavimo: normalu (ilgiau — tikrinti orapūtę)
- Garsas nuo orapūtės namuose: pastatyti ant vatos ar gumos — sumažina vibraciją
TXT;
}

// ─── Komponentų apibrėžimai (statinis žinojimas) ─────────────────────────────

function _componentDefinitions(): array {
    return [
        'BNVI' => [
            'pavadinimas' => 'Biologinis nuotekų valymo įrenginys',
            'funkcija'    => 'Orapūtė tiekia orą → bakterijų kolonija (aktyvus dumblas) → valo nuotekas → išleidžia techniškai švarų vandenį',
            'kada'        => 'Nuolatinis gyvenimas (ne sezoninis). Visose sistemose išskyrus uždara talpyklą.',
            'nereikia'    => 'Sezoninis naudojimas (sodyba, retas apsilankymas) — bakterijos žūsta',
            'svarbu'      => 'Be oro (orapūtė sugedo) bakterijos žūsta per 2–3 dienas',
            'draud'       => 'Chemija, drėgnos servetėlės',
        ],
        'FEKSIURB' => [
            'pavadinimas' => 'Fekalinė siurblinė',
            'funkcija'    => 'Pakelia nuotekas iš gilaus namo išvado aukštyn į BNVI',
            'kada'        => 'NAM2 — kai namo kanalizacijos išvadas >1.6m gylyje',
            'nereikia'    => 'NAM1 — kai išvadas <1.4m (gravitacija pakanka)',
            'svarbu'      => 'Dažniausia gedimo priežastis: smulkintuvo užsikimšimas (plaukai, drėgnos servetėlės)',
            'draud'       => '',
        ],
        'DRENSIURB' => [
            'pavadinimas' => 'Drenažinė siurblinė',
            'funkcija'    => 'Surenka išvalytą vandenį iš BNVI ir išpumpa į paviršių/griovį. Veikia pagal plūdę.',
            'kada'        => 'Kai infiltracija žemyn neįmanoma: GVL-1 arba molis',
            'nereikia'    => 'Kai gruntas gerai sugeria (smėlis/žvyras, GVL-3)',
            'svarbu'      => '',
            'draud'       => '',
        ],
        'UZDTALP' => [
            'pavadinimas' => 'Uždara talpykla',
            'funkcija'    => 'Kaupia nuotekas be valymo. Periodiškai išsiurbiama. Kaina: 30–50€/m³',
            'kada'        => 'Sezoninis naudojimas (sodyba, ≤3 vizitai/metus)',
            'nereikia'    => 'Nuolatinis gyvenimas — per brangus (dažnas išsiurbimas)',
            'svarbu'      => 'Priežiūra kas 6 mėn.',
            'draud'       => '',
        ],
        'INFSUL' => [
            'pavadinimas' => 'Infiltracinis šulinys',
            'funkcija'    => 'Absorbuoja išvalytą vandenį į gruntą per šulinio dugną ir sienas',
            'kada'        => 'Geras gruntas (smėlis, žvyras), GVL-3',
            'nereikia'    => 'GVL-1, GVL-2, molis — vanduo nesugeria arba gruntinis vanduo per aukštas',
            'svarbu'      => '',
            'draud'       => '',
        ],
        'INFLAUK' => [
            'pavadinimas' => 'Infiltracinis laukas',
            'funkcija'    => 'Horizontali infiltracija per vamzdžius — didesnis paviršius nei šulinys',
            'kada'        => 'Geras gruntas, GVL-2/3, kai šulinys per mažas',
            'nereikia'    => 'Molis, GVL-1',
            'svarbu'      => '1 sekcija = 30m ilgio. Priežiūra kas 3 metus.',
            'draud'       => '',
        ],
        'INFKAUB' => [
            'pavadinimas' => 'Infiltracinis kauburys',
            'funkcija'    => 'Vanduo filtruojamas per žemės kauburį VIRŠ žemės — pakyla aukščiau gruntinio vandens. 1 tunelis = 1m ilgio.',
            'kada'        => 'GVL-2 + molis, kai kiti inf. variantai neveikia. Tvarkingas, galima paslėpti žolė.',
            'nereikia'    => '',
            'svarbu'      => 'Priežiūra kas 3 metus.',
            'draud'       => '',
        ],
        'MEGSUL' => [
            'pavadinimas' => 'Mėginių ėmimo šulinys',
            'funkcija'    => 'Kontrolinis taškas — galima patikrinti išleidžiamo vandens kokybę. Privalomas LT taisyklėse.',
            'kada'        => 'Sistemose su BNVI + infiltracija (Sist. 1,2,4,5,6,9,11,12)',
            'nereikia'    => '',
            'svarbu'      => 'Priežiūra kas 6 mėn.',
            'draud'       => '',
        ],
        'ZEMPAV' => [
            'pavadinimas' => 'Žemės paviršius (išleidimas)',
            'funkcija'    => 'Drenažinė siurblinė išpumpa valytą vandenį tiesiogiai į paviršių arba griovį',
            'kada'        => 'Sist.3 ir 10 — su drenažine siurblyne',
            'nereikia'    => '',
            'svarbu'      => '',
            'draud'       => '',
        ],
        'SLAIT' => [
            'pavadinimas' => 'Šlaitas / nuokalnė',
            'funkcija'    => 'Išvalytas vanduo išleidžiamas gravitaciškai per natūralų šlaitą',
            'kada'        => 'Kai sklype yra tinkamas šlaitas ir tai atitinka normatyvus',
            'nereikia'    => '',
            'svarbu'      => '',
            'draud'       => '',
        ],
    ];
}
