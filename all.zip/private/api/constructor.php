<?php
require_once dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/ibnvs-engine.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/kb-reader.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

apiHeaders();
requirePost();
rateLimit(30, 1, 'kon');

$data   = getBody();
$action = $data['action'] ?? '';

switch ($action) {

    case 'getGalimiObjektai':
        $sistema = $data['sistema'] ?? [];
        $gvl     = $data['gvl']     ?? null;
        $gruntas = $data['gruntas'] ?? null;
        $galimi  = IBNVS::getGalimiObjektai($sistema, $gvl, $gruntas);
        $result  = array_map(fn($t) => [
            'tipas'     => $t,
            'aprasymas' => IBNVS::aprasymas($t),
        ], $galimi);
        apiOk(['galimi' => $result]);
        break;

    case 'pridetiObjekta':
        $sistema             = $data['sistema']             ?? [];
        $naujasTipas         = $data['naujasTipas']         ?? '';
        $dabartinisSektorius = $data['dabartinisSektorius'] ?? 'A';
        if (!$naujasTipas) apiErr(400, 'Trūksta naujasTipas');
        apiOk(IBNVS::pridetiObjekta($sistema, $naujasTipas, $dabartinisSektorius));
        break;

    case 'getKomponentai':
        $kompTipas = preg_replace('/[^A-Za-z0-9_\-]/', '', $data['tipas'] ?? '');
        if (!$kompTipas) {
            apiOk(['komponentai' => []]);
            break;
        }
        $kompDir     = DATA_DIR . 'components/' . $kompTipas . '/';
        $komponentai = [];
        if (is_dir($kompDir)) {
            foreach (glob($kompDir . '*.json') ?: [] as $file) {
                $k = json_decode(file_get_contents($file), true);
                if ($k && isset($k['id'])) {
                    $komponentai[] = [
                        'id'          => $k['id'],
                        'pavadinimas' => $k['name']        ?? $k['id'],
                        'aprasymas'   => $k['description'] ?? '',
                        'lygis'       => $k['y_level']     ?? 1,
                    ];
                }
            }
        }
        usort($komponentai, fn($a, $b) =>
            $a['lygis'] <=> $b['lygis'] ?: strcmp($a['pavadinimas'], $b['pavadinimas'])
        );
        apiOk(['komponentai' => $komponentai]);
        break;

    case 'load_all':
        try {
            apiOk(['data' => kbLoadPublic()]);
        } catch (Throwable $e) {
            error_log('constructor load_all: ' . $e->getMessage());
            apiErr(500, 'Serverio klaida');
        }
        break;

    case 'ping':
        $domainPath = DATA_DIR . 'meta/domain.json';
        apiOk([
            'domain_json' => file_exists($domainPath),
            'objects_dir' => is_dir(DATA_DIR . 'objects'),
        ]);
        break;

    default:
        apiErr(400, 'Nežinomas veiksmas');
}
