<?php
require_once dirname(__DIR__) . '/bootstrap.php';
require_once dirname(__DIR__) . '/engine/DiagnosticEngine.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

apiHeaders();
requirePost();
rateLimit(30, 1, 'diag');

$body = getBody();
rateLimit(30, 1, 'diag');

$body = getBody();

$symptoms = array_slice(
    array_filter(
        array_map('strval', $body['symptoms'] ?? []),
        fn($s) => mb_strlen($s) > 0 && mb_strlen($s) < 200
    ),
    0, 20
);

if (empty($symptoms)) {
    apiErr(400, 'Nepasirinkti simptomai');
}

$env = [];
foreach ($body['env'] ?? [] as $k => $v) {
    $k = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string) $k);
    $v = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string) $v);
    if ($k && $v) $env[$k] = $v;
}

$objectFilter = preg_replace('/[^A-Z0-9\-_]/', '', strtoupper(trim($body['object'] ?? '')));

try {
    $diag = DiagnosticEngine::diagnose($symptoms, $env, $objectFilter);
    apiOk([
        'results' => $diag['results'] ?? $diag,
        'related' => $diag['related'] ?? [],
    ]);
} catch (Throwable $e) {
    error_log('diagnose: ' . $e->getMessage());
    apiErr(500, 'Serverio klaida');
}
