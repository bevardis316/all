<?php

if (!defined('DATA_DIR')) {
    throw new RuntimeException('DATA_DIR turi būti apibrėžtas prieš įtraukiant DiagnosticEngine.php');
}

require_once dirname(__DIR__, 2) . '/public_html/shared/php/kb-reader.php';

class DiagnosticEngine {

    
    
    

    public static function getSymptoms(): array {
        $objectIds = self::resolveObjectIds();
        $groups    = [];
        $foundOids = [];

        foreach ($objectIds as $oid) {
            $index = kbReadJson(DATA_DIR . "objects/{$oid}/failures/_index.json");
            if (!$index) continue;

            $foundOids[] = $oid;

            foreach ($index as $entry) {
                $fid = is_array($entry) ? ($entry['id'] ?? null) : $entry;
                if (!$fid) continue;

                $fm = kbReadJson(DATA_DIR . "objects/{$oid}/failures/{$fid}.json");
                if (!$fm) continue;

                $group = $fm['tags'][0] ?? 'Kiti';

                foreach ($fm['symptoms'] ?? [] as $symptom) {
                    if (!$symptom) continue;
                    if (!isset($groups[$group][$symptom])) {
                        $groups[$group][$symptom] = 0;
                    }
                    $groups[$group][$symptom]++;
                }
            }
        }

        $formatted = [];
        foreach ($groups as $group => $items) {
            arsort($items);
            $formatted[$group] = array_map(
                fn($s, $n) => ['s' => $s, 'n' => $n],
                array_keys($items),
                $items
            );
        }

        return [
            'groups'  => $formatted,
            'objects' => $foundOids,
        ];
    }

    
    
    

    public static function diagnose(array $symptoms, array $env = [], string $objectFilter = ''): array {
        if (empty($symptoms)) return [];

        $objectIds = self::resolveObjectIds();
        $raw       = [];

        foreach ($objectIds as $oid) {
            if ($objectFilter !== '' && $oid !== $objectFilter) continue;

            $index = kbReadJson(DATA_DIR . "objects/{$oid}/failures/_index.json");
            if (!$index) continue;

            $percentages = kbReadJson(DATA_DIR . "percentages/{$oid}.json") ?? [];
            $pctMap      = $percentages['failures'] ?? [];

            foreach ($index as $entry) {
                $fid = is_array($entry) ? ($entry['id'] ?? null) : $entry;
                if (!$fid) continue;

                $fm       = kbReadJson(DATA_DIR . "objects/{$oid}/failures/{$fid}.json");
                if (!$fm) continue;

                $fSymptoms = $fm['symptoms'] ?? [];
                if (empty($fSymptoms)) continue;

                $hits = array_values(array_intersect($symptoms, $fSymptoms));
                if (empty($hits)) continue;

                $missed = array_values(array_diff($fSymptoms, $symptoms));
                $score  = min(99, (int) round(count($hits) / max(1, count($fSymptoms)) * 100));

                
                $envChips = [];
                foreach ($env as $envKey => $envVal) {
                    if ($envVal && isset($fm['env_modifiers'][$envVal])) {
                        $mult = (float) ($fm['env_modifiers'][$envVal]['prob_mult'] ?? 1.0);
                        if ($mult !== 1.0) {
                            $envChips[] = ['k' => $envVal, 'm' => $mult];
                            $score = min(99, (int) round($score * $mult));
                        }
                    }
                }

                $base = (int) ($pctMap[$fid]['base'] ?? 0);

                
                $causeList    = $fm['causes']['list'] ?? [];
                $causeSummary = implode('; ', array_map(
                    fn($c) => $c['name'],
                    array_slice(array_filter($causeList, fn($c) => !empty($c['name'])), 0, 2)
                ));

                $raw[] = [
                    'oid'             => $oid,
                    'fid'             => $fid,
                    'score'           => $score,
                    'base'            => $base,
                    'severity'        => $fm['severity'] ?? 'low',
                    'hits'            => $hits,
                    'miss'            => array_slice($missed, 0, 3),
                    'chips'           => $envChips,
                    'name'            => $fm['name'] ?? $fid,
                    'causes'          => $causeSummary,
                    'causes_primary'  => $fm['causes']['primary'] ?? '',
                    'resolution'      => $fm['resolution'] ?? '',
                    'prevention'      => $fm['prevention'] ?? '',
                    'diag_tree'       => self::filterDiagTree($fm['diag_tree'] ?? []),
                    'diagnosis_steps' => self::filterDiagSteps($fm['diagnosis_steps'] ?? []),
                    
                ];
            }
        }

        usort($raw, function ($a, $b) {
            static $order = ['critical' => 0, 'high' => 1, 'med' => 2, 'low' => 3];
            $sa = $order[$a['severity']] ?? 9;
            $sb = $order[$b['severity']] ?? 9;
            return $sa !== $sb ? $sa - $sb : $b['score'] - $a['score'];
        });

        $results = array_slice($raw, 0, 10);

        // E6: surinkti leads_to susijusias problemas
        $related = [];
        $seenRel = [];
        foreach ($results as $r) {
            $fm = kbReadJson(DATA_DIR . "objects/{$r['oid']}/failures/{$r['fid']}.json");
            foreach ($fm['relations']['leads_to'] ?? [] as $relFid) {
                foreach (self::resolveObjectIds() as $roid) {
                    $relFm = kbReadJson(DATA_DIR . "objects/{$roid}/failures/{$relFid}.json");
                    if ($relFm && !in_array($relFid, $seenRel)) {
                        $seenRel[] = $relFid;
                        $related[] = [
                            'fid'  => $relFid,
                            'oid'  => $roid,
                            'name' => $relFm['name'] ?? $relFid,
                            'from' => $r['name'],
                        ];
                    }
                }
            }
        }

        return ['results' => $results, 'related' => $related];
    }

    
    
    
    
    

    public static function getTree(): array {
        $domain    = kbReadJson(DATA_DIR . 'meta/domain.json') ?? [];
        $aprasymai = $domain['aprasymai'] ?? [];

        $objects = [];
        foreach (array_keys($domain['objektai'] ?? []) as $oid) {
            $base  = kbReadJson(DATA_DIR . "objects/{$oid}/base.json");
            $index = kbReadJson(DATA_DIR . "objects/{$oid}/failures/_index.json") ?? [];

            $objects[$oid] = [
                'name'          => $base['name'] ?? ($aprasymai[$oid] ?? $oid),
                'failure_count' => count($index),
            ];
        }

        $components = [];
        if (is_dir(DATA_DIR . 'components')) {
            foreach (glob(DATA_DIR . 'components/*', GLOB_ONLYDIR) ?: [] as $parentDir) {
                foreach (glob($parentDir . '/*.json') ?: [] as $compFile) {
                    $comp = kbReadJson($compFile);
                    if (!$comp) continue;
                    if (isset($comp['active']) && $comp['active'] === false) continue;

                    $cid = $comp['id'] ?? basename($compFile, '.json');
                    $components[$cid] = [
                        'id'        => $cid,
                        'name'      => $comp['name'] ?? $cid,
                        'parent_id' => $comp['parent_id'] ?? basename($parentDir),
                    ];
                }
            }
        }

        return [
            'objects'    => $objects,
            'components' => $components,
        ];
    }

    
    
    
    
    
    
    

    public static function getKb(): array {
        $full = kbLoadPublic();

        
        
        foreach ($full['components'] as $cid => $comp) {
            unset($full['components'][$cid]['failure_modes']);
        }

        
        
        foreach ($full['objects'] as $oid => $obj) {
            $slim = [];
            foreach ($obj['failure_modes'] ?? [] as $fid => $fm) {
                $slim[$fid] = [
                    'name'     => $fm['name']     ?? '',
                    'severity' => $fm['severity'] ?? '',
                ];
            }
            $full['objects'][$oid]['failure_modes'] = $slim;
        }

        return $full;
    }

    
    
    

    private static function resolveObjectIds(): array {
        $domain     = kbReadJson(DATA_DIR . 'meta/domain.json') ?? [];
        $fromDomain = array_keys($domain['objektai'] ?? []);

        $extra = [];
        if (is_dir(DATA_DIR . 'objects')) {
            foreach (glob(DATA_DIR . 'objects/*', GLOB_ONLYDIR) ?: [] as $dir) {
                $id = basename($dir);
                if (!in_array($id, $fromDomain, true)) $extra[] = $id;
            }
        }

        return array_merge($fromDomain, $extra);
    }

    private static function filterDiagTree(array $tree): array {
        return array_slice(
            array_map(fn($s) => [
                'question' => is_array($s)
                    ? ($s['question'] ?? $s['step'] ?? '')
                    : (string) $s,
            ], $tree),
            0, 5
        );
    }

    private static function filterDiagSteps(array $steps): array {
        return array_slice(
            array_map(fn($s) => [
                'step' => is_array($s)
                    ? ($s['step'] ?? $s['instruction'] ?? '')
                    : (string) $s,
            ], $steps),
            0, 8
        );
    }
}
