<?php

define('BASE_DIR',    dirname(__DIR__) . '/');
define('DATA_DIR',    dirname(__DIR__) . '/ibnvs_data/');
define('PRIVATE_DIR', __DIR__ . '/');
define('PUBLIC_DIR',  dirname(__DIR__) . '/public_html/');

$_envFile = BASE_DIR . '.env';
if (file_exists($_envFile)) {
    foreach (file($_envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $_line) {
        if (str_starts_with(trim($_line), '#') || !str_contains($_line, '=')) continue;
        $_parts = array_map('trim', explode('=', $_line, 2));
        if (count($_parts) < 2) continue;
        [$_k, $_v] = $_parts;
        putenv("$_k=$_v");
        $_ENV[$_k] = $_v;
    }
}
unset($_envFile, $_line, $_parts, $_k, $_v);

define('OPENAI_KEY',          getenv('OPENAI_KEY') ?: '');
define('OPENAI_MODEL',        'gpt-4o-mini');
define('ANTHROPIC_KEY',       getenv('ANTHROPIC_KEY') ?: '');
define('ANTHROPIC_MODEL',     'claude-haiku-4-5-20251001');
define('TTS_VOICE',           'onyx');
define('TTS_SPEED',           1.1);
define('ADMIN_PASSWORD_HASH', getenv('ADMIN_PASSWORD_HASH') ?: '');
define('SESSION_TTL',         28800);
define('MAX_MB',              32);
define('API_VER',             '7.0');
define('GOOGLE_MAPS_KEY',     getenv('GOOGLE_MAPS_KEY') ?: '');

define('ADMIN_EMAIL', getenv('ADMIN_EMAIL') ?: 'info@manonuotekos.lt');
define('ANALYTICS_DIR',   DATA_DIR . 'analytics/');

define('MAP_DATA_DIR',    DATA_DIR . 'map/');
