<?php
// Ikelti i public_html/tool1/css_check.php
// Atidaryti tiesiogiai (ne per tool1 login)
// Testuoja ar CSS failai pasiekiami
header('Content-Type: text/html; charset=utf-8');
?><!DOCTYPE html>
<html><head><meta charset="UTF-8">
<link rel="stylesheet" href="assets/css/base.css">
<link rel="stylesheet" href="assets/css/layout.css">
</head>
<body style="margin:20px;font-family:monospace">
<h2>CSS testas</h2>
<div id="test" style="padding:10px">Testuojamas elementas</div>
<div id="app"><div id="page-k" class="page active" style="min-height:100px;background:green">Jei žalias - CSS veikia</div></div>
<script>
var styles = window.getComputedStyle(document.documentElement);
var bg = styles.getPropertyValue('--bg').trim();
var pri = styles.getPropertyValue('--pri').trim();
document.body.innerHTML += '<pre style="background:#111;color:#0f0;padding:12px">'
  + '--bg: "' + bg + '" ' + (bg ? '✓ CSS ĮKELTAS' : '✗ CSS NEĮKELTAS - tuščias!') + '\n'
  + '--pri: "' + pri + '" \n'
  + 'page-k height: ' + document.getElementById("page-k").getBoundingClientRect().height + 'px\n'
  + 'Stylesheets: ' + document.styleSheets.length + '\n'
  + Array.from(document.styleSheets).map(s => {
      try { return (s.href||'inline') + ': ' + s.cssRules.length + ' rules'; }
      catch(e) { return (s.href||'inline') + ': KLAIDA (403?)'; }
    }).join('\n')
  + '</pre>';
</script>
</body></html>
