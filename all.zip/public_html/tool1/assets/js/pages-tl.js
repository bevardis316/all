function initTlSels() {
  const s=document.getElementById('tl-obj');
  if(s) s.innerHTML=`<option value="">Visi objektai</option>`+Object.keys(KB.objects_meta).map(id=>`<option value="${id}">${id}</option>`).join('');
}

function renderTl() {
  const el=document.getElementById('tl-main'); if(!el) return;
  const tf=document.getElementById('tl-type')?.value||'all';
  const of=document.getElementById('tl-obj')?.value||'';
  const tcols={'ev-failure':'#c62828','ev-case':'#e65100','ev-fix':'#1565c0','ev-env':'#2e7d32'};
  const tlbls={'ev-failure':'GEDIMAS','ev-case':'ATVEJIS','ev-fix':'SPRENDIMAS','ev-env':'APLINKA'};
  let evts=[...KB.timeline_events,...KB.field_cases.map(c=>({id:'C_'+c.id,type:'ev-case',date:c.date,object_id:c.object_id,text:`Lauko atvejis: ${(c.symptoms||[]).join(', ')||c.object_id}`,meta:c.meta}))];
  const seen=new Set(); evts=evts.filter(e=>{if(seen.has(e.id))return false;seen.add(e.id);return true;});
  if(tf!=='all') evts=evts.filter(e=>e.type===tf);
  if(of) evts=evts.filter(e=>e.object_id===of);
  evts.sort((a,b)=>a.date>b.date?1:-1);
  const byY={}; evts.forEach(ev=>{const y=(ev.date||'???').substring(0,4);if(!byY[y])byY[y]=[];byY[y].push(ev);});
  el.innerHTML=Object.keys(byY).sort().reverse().map(y=>`
    <div class="tl-year">${y}</div>
    <div class="tl-line">${(byY[y]||[]).map(ev=>{
      const col=tcols[ev.type]||'#aaa';
      return `<div class="tl-event ${ev.type}">
        <div class="tl-card">
          <div class="tl-card-head">
            <span class="tl-date">${ev.date}</span>
            <span class="tl-badge" style="background:${col}20;border:1px solid ${col}40;color:${col}">${tlbls[ev.type]||ev.type}</span>
            ${ev.object_id?`<span class="tl-obj">${ev.object_id}</span>`:''}
          </div>
          <div class="tl-text">${ev.text||''}</div>
          ${ev.meta?`<div style="display:flex;flex-wrap:wrap;gap:3px;margin-top:4px">${Object.entries(ev.meta||{}).filter(([k,vv])=>vv).map(([k,vv])=>`<span class="dtag">${k}: ${vv}</span>`).join('')}</div>`:''}
        </div>
      </div>`;
    }).join('')}</div>`).join('')||`<div style="text-align:center;color:var(--td);padding:60px;font-size:12px">Nėra įvykių</div>`;
}

function showAddTl() {
  openModal('Naujas laiko juostos įvykis',`
    <div class="row2">
      <div><div class="lbl">Data</div><input type="date" id="m-tl-d" value="${new Date().toISOString().split('T')[0]}"></div>
      <div><div class="lbl">Tipas</div><select id="m-tl-t"><option value="ev-failure">Gedimas</option><option value="ev-case">Atvejis</option><option value="ev-fix">Sprendimas</option><option value="ev-env">Aplinkos pokytis</option></select></div>
    </div>
    <div class="lbl">Objektas</div>
    <select id="m-tl-o">${Object.keys(KB.objects_meta).map(id=>`<option value="${id}">${id}</option>`).join('')}</select>
    <div class="lbl">Aprašymas</div>
    <textarea id="m-tl-txt" rows="3" placeholder="Įvykio aprašymas..."></textarea>
  `,()=>{
    const ev={id:'TL-'+Date.now(),type:v('m-tl-t'),date:v('m-tl-d'),object_id:v('m-tl-o'),text:v('m-tl-txt'),meta:{},created:new Date().toISOString()};
    KB.timeline_events.push(ev); renderTl(); closeModal(); toast('Įvykis pridėtas ✓');
  });
}

function exportTlJson() {
  const all=[...KB.timeline_events,...KB.field_cases.map(c=>({id:'C_'+c.id,type:'ev-case',date:c.date,object_id:c.object_id,text:'Lauko atvejis',meta:c.meta}))];
  all.sort((a,b)=>a.date>b.date?1:-1);
  dl(JSON.stringify({schema:'ibnvs-timeline-v1',exported:new Date().toISOString(),events:all},null,2),'ibnvs_timeline.json');
  toast('Laiko juosta eksportuota ✓');
}

function renderTagsPage() {
  const cloud=document.getElementById('tag-cloud');
  if(cloud) {
    const at={};
    Object.values(KB.objects).forEach(kb=>{(kb.tags||[]).forEach(t=>at[t]=(at[t]||0)+1);Object.values(kb.failure_modes||{}).forEach(fm=>(fm.tags||[]).forEach(t=>at[t]=(at[t]||0)+1));});
    const cols=['#2e7d32','#1565c0','#c62828','#e65100','#6a1b9a'];
    cloud.innerHTML=Object.entries(at).sort((a,b)=>b[1]-a[1]).map(([t,c],i)=>`
      <div class="cloud-tag" style="color:${cols[i%5]};border-color:${cols[i%5]}40;font-size:${10+c}px">${t} <small style="opacity:.5">×${c}</small></div>`).join('')||'<div style="color:var(--td);font-size:11px">Tagų dar nėra</div>';
  }
  renderTagCatsEd();
  const ts=document.getElementById('tag-stats');
  if(ts) {
    const at={};
    Object.values(KB.objects).forEach(kb=>{(kb.tags||[]).forEach(t=>at[t]=(at[t]||0)+1);Object.values(kb.failure_modes||{}).forEach(fm=>(fm.tags||[]).forEach(t=>at[t]=(at[t]||0)+1));});
    const max=Math.max(...Object.values(at),1);
    ts.innerHTML=Object.entries(at).sort((a,b)=>b[1]-a[1]).slice(0,20).map(([t,c])=>`
      <div class="bar-row"><span class="bar-lbl">${t}</span><div class="bar-track"><div class="bar-fill" style="width:${(c/max)*100}%"></div></div><span class="bar-val">${c}</span></div>`).join('')||'<div style="color:var(--td)">Nėra</div>';
  }
}

function renderTagCatsEd() {
  const html=Object.entries(KB.tag_categories||{}).map(([cat,data])=>`
    <div style="background:var(--bg);border:1px solid var(--b1);border-radius:var(--r);padding:10px;margin-bottom:8px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:7px">
        <div style="width:12px;height:12px;border-radius:50%;background:${data.color||'#ccc'}"></div>
        <span style="font-size:11px;font-weight:700;color:var(--pri)">${cat}</span>
        <button class="btn ghost sm" onclick="addTagToCat('${cat}')">+ Tagas</button>
        <input type="color" value="${data.color||'#2e7d32'}" style="width:24px;height:20px;border:none;background:none;cursor:pointer" onchange="KB.tag_categories['${cat}'].color=this.value;renderTagCatsEd()">
        <button class="btn red sm" style="margin-left:auto" onclick="delTagCat('${cat}')">Ištrinti</button>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:4px">
        ${(data.tags||[]).map(t=>`<span style="display:inline-flex;align-items:center;gap:3px;padding:2px 8px;border-radius:20px;border:1px solid ${data.color||'#ccc'}60;color:${data.color||'#333'};font-size:10px">
          ${t}<span style="cursor:pointer;opacity:.5;margin-left:2px" onclick="rmTagFromCat('${cat}','${t}')">×</span></span>`).join('')}
      </div>
    </div>`).join('');
  const el=document.getElementById('tag-cats-ed'); if(el) el.innerHTML=html;
  const adm=document.getElementById('admin-tag-cats'); if(adm) adm.innerHTML=html;
}

function addTagCat() {
  openModal('Nauja tagų kategorija',`
    <div class="lbl">Pavadinimas</div><input type="text" id="m-cn" placeholder="pvz. Mano kategorija">
    <div class="lbl">Spalva</div><input type="color" id="m-cc" value="#2e7d32" style="width:60px;height:28px;border:none;background:none;cursor:pointer">
  `,()=>{const n=v('m-cn');if(!n)return;KB.tag_categories[n]={color:document.getElementById('m-cc').value,tags:[]};renderTagCatsEd();renderTagsPage();closeModal();toast('Kategorija sukurta ✓');});
}

function rmTagFromAllObjects(tag) {
  if(!tag) return;
  Object.entries(KB.objects).forEach(([oid,kb])=>{
    if(kb.tags?.includes(tag)){kb.tags=kb.tags.filter(t=>t!==tag);markDirty('obj_'+oid);}
    Object.entries(kb.failure_modes||{}).forEach(([fid,fm])=>{
      let changed=false;
      if(fm.tags?.includes(tag)){fm.tags=fm.tags.filter(t=>t!==tag);changed=true;}
      if(fm.symptoms?.includes(tag)){fm.symptoms=fm.symptoms.filter(t=>t!==tag);changed=true;}
      if(changed) markDirty('fail_'+oid+'_'+fid);
    });
  });
  KB.field_cases?.forEach((c,i)=>{if(c.symptoms?.includes(tag)){KB.field_cases[i].symptoms=c.symptoms.filter(t=>t!==tag);markDirty('case_'+c.id);}});
}

function addTagToCat(cat) {
  openModal(`Pridėti tagą: ${cat}`,`<div class="lbl">Tago pavadinimas</div><input type="text" id="m-tv" placeholder="@tagas">`,()=>{
    const t=v('m-tv');if(!t)return;if(!KB.tag_categories[cat].tags.includes(t))KB.tag_categories[cat].tags.push(t);renderTagCatsEd();renderTagsPage();closeModal();toast('Tagas pridėtas ✓');
  });
}

function rmTagFromCat(cat,tag) {
  KB.tag_categories[cat].tags=KB.tag_categories[cat].tags.filter(t=>t!==tag);
  rmTagFromAllObjects(tag);
  markDirty('meta_tags'); flushDirty();
  renderTagCatsEd(); renderKTab();
  toast('🗑 Tagas "'+tag+'" ištrintas visur');
}

function delTagCat(cat) {
  if(!confirm('Ištrinti kategoriją "'+cat+'" su VISAIS jos tagais?')) return;
  (KB.tag_categories[cat]?.tags||[]).forEach(tag=>rmTagFromAllObjects(tag));
  delete KB.tag_categories[cat];
  markDirty('meta_tags'); flushDirty();
  renderTagCatsEd(); renderKTab();
  toast('🗑 Kategorija "'+cat+'" ištrinta');
}
