function renderObjList() {
  const objRows = Object.keys(KB.objects_meta).map(id=>{
    const kb=KB.objects[id]; const fc=Object.keys(kb?.failure_modes||{}).length;
    const filled=kb?.function&&fc>0;
    const partial=kb?.function||fc>0;
    const dot=filled?'d1':partial?'d2':'';
    return `<div class="obj-row ${id===curObj?'active':''}" onclick="selObj('${id}')">
      <div class="obj-id">${id}</div>
      <div><div class="obj-name-s">${KB.objects_meta[id].name||id}</div>
      <div style="font-size:9px;color:var(--td)">${(KB.objects_meta[id].sek||[]).join(',')} · ${fc} ged.</div></div>
      <div class="obj-dot ${dot}"></div>
    </div>`;
  }).join('');

  
  function renderCompNode(parentId, depth) {
    const children = Object.keys(KB.components_meta||{}).filter(cid => KB.components_meta[cid].parent_id === parentId);
    if (!children.length) return '';
    return children.map(cid => {
      const comp = KB.components[cid];
      const meta = KB.components_meta[cid];
      const fc = Object.keys(comp?.failure_modes||{}).length;
      const dot = comp?.function&&fc>0?'d1':comp?.function||fc>0?'d2':'';
      const hasChildren = Object.keys(KB.components_meta||{}).some(x => KB.components_meta[x].parent_id === cid);
      const isOpen = _compOpen.has(cid);
      const indent = depth * 12;
      const isSel = cid === curComp;
      const isInactive = KB.components_meta[cid]?.active === false || KB.components[cid]?.active === false;
      let html = `<div class="obj-row ${isSel?'active':''}" style="padding-left:${8+indent}px;${isInactive?'opacity:.45;':''}" onclick="selComp('${cid}')">
        ${hasChildren ? `<span style="color:var(--td);font-size:10px;margin-right:3px;cursor:pointer" onclick="event.stopPropagation();toggleCompNode('${cid}')">${isOpen?'▾':'▸'}</span>` : '<span style="display:inline-block;width:13px"></span>'}
        <div class="obj-id" style="color:${depth===0?'#1565c0':'#7b1fa2'};font-size:9px">${cid}</div>
        <div><div class="obj-name-s">${meta.name||cid}</div>
        <div style="font-size:9px;color:var(--td)">${fc} ged.</div></div>
        <div class="obj-dot ${dot}"></div>
      </div>`;
      if (hasChildren && isOpen) html += renderCompNode(cid, depth + 1);
      return html;
    }).join('');
  }

  
  const compSection = Object.keys(KB.objects_meta).map(oid => {
    const rootComps = Object.keys(KB.components_meta||{}).filter(cid => KB.components_meta[cid].parent_id === oid);
    if (!rootComps.length) return '';
    const hasObj = rootComps.length > 0;
    const isObjOpen = _compOpen.has('__obj_' + oid);
    return `<div class="obj-row" style="background:var(--s2);cursor:pointer" onclick="toggleCompNode('__obj_${oid}')">
      <span style="color:var(--td);font-size:10px;margin-right:3px">${isObjOpen?'▾':'▸'}</span>
      <div class="obj-id" style="color:var(--pri2)">${oid}</div>
      <div><div class="obj-name-s" style="color:var(--td)">${KB.objects_meta[oid]?.name||oid}</div></div>
    </div>` + (isObjOpen ? renderCompNode(oid, 0) : '');
  }).join('');

  document.getElementById('obj-list').innerHTML =
    objRows +
    `<div style="margin:10px 0 4px;padding:6px 8px;font-size:9px;font-weight:700;color:var(--td);text-transform:uppercase;letter-spacing:.05em;border-top:1px solid var(--b1)">
      Objektų komponentai
      <button class="btn grn sm" style="float:right;margin-top:-2px" onclick="addCompModal()">＋Naujas</button>
    </div>` +
    (compSection || `<div style="font-size:10px;color:var(--td);padding:4px 8px">Komponentų dar nėra</div>`);
}

const _compOpen = new Set(); 

function toggleCompNode(id) {
  if (_compOpen.has(id)) _compOpen.delete(id);
  else _compOpen.add(id);
  renderObjList();
}

function selObj(id) { saveKTab(); curObj=id; curComp=null; renderObjList(); renderKTab(); updateJson(); updateCounts(); }

function _curId()  { return curComp || curObj; }
function _curKB()  {
  if(curComp) {
    const c = KB.components[curComp];
    if(!c) return null;
    
    if(!c.failure_modes || Array.isArray(c.failure_modes)) c.failure_modes = {};
    return c;
  }
  return KB.objects[curObj];
}

function selComp(cid) {
  saveKTab();
  curComp = cid; curObj = null;
  renderObjList();
  renderCompTab(cid);
  updateJson();
}

function addCompModal() {
  
  const objOptions = Object.keys(KB.objects_meta).map(id=>
    `<option value="${id}">🏗 ${id} – ${KB.objects_meta[id].name||id}</option>`
  ).join('');
  const compOptions = Object.keys(KB.components_meta||{}).map(cid=>{
    const meta = KB.components_meta[cid];
    return `<option value="${cid}">🔧 ${cid} – ${meta.name||cid} (Y${meta.y_level||1})</option>`;
  }).join('');

  openModal('Naujas komponentas',`
    <div class="row2">
      <div><div class="lbl">ID (pvz. BNVI-ORAPUTE)</div><input type="text" id="m-cid" placeholder="OBJEKTAS-PAVADINIMAS"></div>
      <div><div class="lbl">Pavadinimas</div><input type="text" id="m-cname" placeholder="pvz. Orapūtė"></div>
    </div>
    <div class="lbl">Priklauso (objektui arba komponentui)</div>
    <select id="m-cpid">
      <optgroup label="── Pagrindiniai objektai ──">${objOptions}</optgroup>
      ${compOptions ? `<optgroup label="── Komponentai (sub-komponentui) ──">${compOptions}</optgroup>` : ''}
    </select>
    <div style="font-size:10px;color:var(--td);margin-top:3px">🏗 = priskirti tiesiai prie objekto &nbsp;|&nbsp; 🔧 = priskirti prie kito komponento</div>
  `,()=>{
    const cid=v('m-cid').trim().toUpperCase();
    const name=v('m-cname').trim();
    const pid=v('m-cpid');
    if(!cid||!name){toast('Reikia ID ir pavadinimo');return;}
    if(KB.components[cid]){toast('Komponentas su tokiu ID jau egzistuoja');return;}

    
    let ylv = 1;
    if(KB.components_meta[pid]) {
      
      ylv = (KB.components_meta[pid].y_level || 1) + 1;
    }
    

    KB.components[cid] = emptyComp(cid, name, pid, ylv);
    KB.components_meta[cid] = {id:cid, name, parent_id:pid, y_level:ylv};
    markDirty('comp_'+cid);
    renderObjList();
    selComp(cid);
    closeModal();
    toast('✓ Komponentas sukurtas: '+cid+' (Y'+ylv+', tėvas: '+pid+')');
  });
}

function renderCompTab(cid) {
  const comp = KB.components[cid];
  const meta = KB.components_meta[cid];
  const el = document.getElementById('k-content');
  if(!comp||!meta||!el) return;

  el.innerHTML = `
  <div class="sec">
    <div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')">
      <h3 style="color:#1565c0">${cid}</h3>
      <span style="font-size:10px;color:var(--td)">Komponentas · ${meta.parent_id} · Y${meta.y_level}</span>
      <span class="caret">▾</span>
    </div>
    <div class="sec-b">
      <div class="lbl">Pavadinimas</div>
      <input type="text" id="cf_name" value="${e(comp.name||'')}" placeholder="Komponento pavadinimas">
      <div class="lbl">Priklauso (objektui arba komponentui)</div>
      <select id="cf_pid">
        <optgroup label="── Pagrindiniai objektai ──">
          ${Object.keys(KB.objects_meta).map(id=>`<option value="${id}" ${id===meta.parent_id?'selected':''}>🏗 ${id} – ${KB.objects_meta[id].name||id}</option>`).join('')}
        </optgroup>
        ${Object.keys(KB.components_meta||{}).filter(x=>x!==cid).length ? `<optgroup label="── Komponentai (sub-komponentui) ──">
          ${Object.keys(KB.components_meta||{}).filter(x=>x!==cid).map(x=>`<option value="${x}" ${x===meta.parent_id?'selected':''}>🔧 ${x} – ${KB.components_meta[x].name||x} (Y${KB.components_meta[x].y_level||1})</option>`).join('')}
        </optgroup>` : ''}
      </select>
      <div style="font-size:10px;color:var(--td);margin-top:2px">Y lygis skaičiuojamas automatiškai pagal tėvą</div>
      <div class="lbl">Funkcija</div>
      <input type="text" id="cf_func" value="${e(comp.function||'')}" placeholder="Ką šis komponentas daro">
      <div class="lbl">Normalus veikimas</div>
      <textarea id="cf_norm">${e(comp.normal_operation||'')}</textarea>
    </div>
  </div>

  <div class="sec">
    <div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')">
      <h3>💰 Kainos ir modeliai</h3>
      <span style="font-size:10px;color:var(--td)">Dalies kaina · montavimas · modeliai</span>
      <span class="caret">▾</span>
    </div>
    <div class="sec-b">

      <div style="background:var(--s2);border:1.5px solid var(--b1);border-radius:var(--r);padding:10px 12px;margin-bottom:8px;display:flex;align-items:center;gap:10px">
        <input type="checkbox" id="cf_in_package" ${comp.in_package!==false?'checked':''} style="width:18px;height:18px;accent-color:var(--pri);cursor:pointer;flex-shrink:0">
        <div>
          <div style="font-size:12px;font-weight:700;color:var(--text)">✓ Įeina į objekto kainą</div>
          <div style="font-size:10px;color:var(--td);margin-top:1px">Klientas mato šį komponentą sąraše, bet jo kaina <b>neskaičiuojama atskirai</b> — ji jau įskaičiuota į įrenginio kainą. Išjunk jei komponentas perkamas papildomai (pvz. pasirenkamas priedas).</div>
        </div>
      </div>

      <div style="background:${comp.active===false?'#fff3e0':'var(--s2)'};border:1.5px solid ${comp.active===false?'#ffb74d':'var(--b1)'};border-radius:var(--r);padding:10px 12px;margin-bottom:12px;display:flex;align-items:center;gap:10px">
        <input type="checkbox" id="cf_active" ${comp.active!==false?'checked':''} style="width:18px;height:18px;accent-color:#2e7d32;cursor:pointer;flex-shrink:0">
        <div>
          <div style="font-size:12px;font-weight:700;color:var(--text)">👁 Aktyvus konstruktoriuje</div>
          <div style="font-size:10px;color:var(--td);margin-top:1px">Išjunk jei komponentas laikinai <b>neprieinamas arba nebeparduodamas</b> — jis nebebus rodomas vartotojams konstruktoriuje.</div>
        </div>
      </div>

      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
        <div class="lbl" style="margin:0">Modeliai / dalių versijos</div>
        <button class="btn grn sm" onclick="addCompModel('${cid}')">＋ Modelis</button>
      </div>
      <div id="comp-models-${cid}">${renderCompModels(comp.models||[], cid)}</div>

      <div style="margin-top:12px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
        <div>
          <div class="lbl">🔩 Dalies kaina (€)</div>
          <div style="font-size:9px;color:var(--td);margin-bottom:3px">tik jei perkama atskirai</div>
          <input type="number" id="cf_part_price" min="0" step="5" value="${comp.pricing?.part_price||0}" style="width:100%;text-align:center;font-weight:700;font-size:14px">
        </div>
        <div>
          <div class="lbl">👷 Montavimo darbai (€)</div>
          <div style="font-size:9px;color:var(--td);margin-bottom:3px">specialisto darbo kaina</div>
          <input type="number" id="cf_install_price" min="0" step="10" value="${comp.pricing?.install_price||0}" style="width:100%;text-align:center;font-weight:700;font-size:14px">
        </div>
        <div>
          <div class="lbl">🔢 Kiekis sistemoje</div>
          <div style="font-size:9px;color:var(--td);margin-bottom:3px">vnt. tipinėje sistemoje</div>
          <input type="number" id="cf_qty" min="1" step="1" value="${comp.pricing?.quantity_per_system||1}" style="width:100%;text-align:center;font-weight:700;font-size:14px">
        </div>
      </div>
      <div style="margin-top:8px;display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div>
          <div class="lbl">🛡 Garantija (mėn.)</div>
          <input type="number" id="cf_guarantee" min="0" step="1" value="${comp.pricing?.guarantee_months||12}" style="width:100%;text-align:center">
        </div>
        <div>
          <div class="lbl">🔧 Pats gali taisyti?</div>
          <select id="cf_diy" style="width:100%">
            <option value="true"  ${comp.pricing?.diy_possible!==false?'selected':''}>✅ Taip – galima pačiam</option>
            <option value="false" ${comp.pricing?.diy_possible===false?'selected':''}>❌ Ne – reikia specialisto</option>
          </select>
        </div>
      </div>
      <div id="comp-price-summary-${cid}" style="margin-top:10px"></div>
    </div>
  </div>

  <div class="sec">
    <div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')">
      <h3>Gedimai</h3><span class="caret">▾</span>
    </div>
    <div class="sec-b">
      ${renderFails(comp)}
    </div>
  </div>
  <div class="save-bar">
    <button class="btn pri" onclick="saveCompTab()">Išsaugoti</button>
    <button class="btn red sm" onclick="deleteComp('${cid}')" style="margin-left:auto">Ištrinti</button>
  </div>`;
}

function saveCompTab() {
  if(!curComp) return;
  const comp = KB.components[curComp];
  const meta = KB.components_meta[curComp];
  if(!comp||!meta) return;
  comp.name = v('cf_name'); meta.name = comp.name;
  const newPid = v('cf_pid');
  comp.parent_id = newPid; meta.parent_id = newPid;
  
  let newYlv = 1;
  if(KB.components_meta[newPid]) {
    newYlv = (KB.components_meta[newPid].y_level || 1) + 1;
  }
  meta.y_level = newYlv; comp.y_level = newYlv;
  comp.function = v('cf_func');
  comp.normal_operation = v('cf_norm');
  comp.in_package = document.getElementById('cf_in_package')?.checked !== false;
  comp.active     = document.getElementById('cf_active')?.checked !== false; 
  comp.models = readCompModels(curComp);
  comp.pricing = {
    part_price:          parseFloat(v('cf_part_price'))||0,
    install_price:       parseFloat(v('cf_install_price'))||0,
    quantity_per_system: parseInt(v('cf_qty'))||1,
    guarantee_months:    parseInt(v('cf_guarantee'))||12,
    diy_possible:        v('cf_diy')==='true'
  };
  markDirty('comp_'+curComp);
  renderObjList();
  toast('✓ Komponentas išsaugotas (Y'+newYlv+', tėvas: '+newPid+')');
}

function deleteComp(cid) {
  if(!confirm('Ištrinti komponentą "'+cid+'"?')) return;
  apiPost('delete_component', {id:cid, parent_id:KB.components_meta[cid]?.parent_id||''}).catch(()=>{});
  delete KB.components[cid];
  delete KB.components_meta[cid];
  curComp = null;
  renderObjList();
  document.getElementById('k-content').innerHTML = '<div style="text-align:center;padding:40px;color:var(--td)">Pasirinkite objektą arba komponentą</div>';
  toast('🗑 Komponentas ištrintas');
}

function kt(tab, el) {
  saveKTab(); curKTab=tab;
  document.querySelectorAll('.ktab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active'); renderKTab();
}

function renderKTab() {
  const el=document.getElementById('k-content');
  
  if(curComp) {
    renderCompTab(curComp);
    
    if(curKTab==='failures') {
      setTimeout(()=>{
        const secs = el.querySelectorAll('.sec');
        secs.forEach(s=>{
          const h=s.querySelector('.sec-h h3');
          if(h && h.textContent.includes('Gedimai')) {
            s.classList.remove('col'); 
            s.scrollIntoView({behavior:'smooth', block:'start'});
          }
        });
      }, 60);
    }
    return;
  }
  const obj=KB.objects_meta[curObj], kb=KB.objects[curObj];
  if(!obj||!kb) return;
  if(curKTab==='base')        el.innerHTML=renderBase(obj,kb);
  else if(curKTab==='failures') el.innerHTML=renderFails(kb);
  else if(curKTab==='env')    el.innerHTML=renderEnv(kb);
  else if(curKTab==='errors') el.innerHTML=renderErrs(kb);
  else if(curKTab==='rels')   el.innerHTML=renderRels(obj,kb);
  else if(curKTab==='packages') el.innerHTML=renderPackages(obj,kb);
  updateJson();
}

function renderBase(obj, kb) {
  return `
  <div class="sec">
    <div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')">
      <h3>${obj.id} · ${obj.name}</h3>
      <span style="font-size:10px;color:var(--td)">${(obj.sek||[]).join(',')} · ${obj.z||''}</span>
      <span class="caret">▾</span>
    </div>
    <div class="sec-b">
      <div class="lbl">Pavadinimas</div>
      <input type="text" id="f_name" value="${e(kb.name||obj.name||'')}" placeholder="pvz. Fekalinė siurblinė">
      <div class="lbl">Funkcija</div>
      <input type="text" id="f_func" value="${e(kb.function||'')}" placeholder="Ką šis objektas daro sistemoje">
      <div class="lbl">Normalus veikimas</div>
      <textarea id="f_norm">${e(kb.normal_operation||'')}</textarea>
      <div class="lbl">Normalaus veikimo požymiai
        <i class="tip" data-t="Rašyk ką nori ir spausk Enter. Pvz: Burbuliuoja, Nesmirda, Vanduo skaidrus">?</i>
      </div>
      ${renderTagPanel('base-signs', kb.normal_signs||[])}
      <div class="row3" style="margin-top:12px">
        <div>
          <div class="lbl">Pasitikėjimas</div>
          <div class="conf-wrap">
            <input type="range" id="f_conf" min="0" max="100" value="${kb.meta?.confidence||0}" oninput="document.getElementById('f_cv').textContent=this.value">
            <div id="f_cv" class="conf-val">${kb.meta?.confidence||0}</div>
          </div>
        </div>
        <div>
          <div class="lbl">Šaltiniai</div>
          <input type="text" id="f_src" value="${e((kb.meta?.sources||[]).join(', '))}" placeholder="field, manual, ekspertas">
        </div>
        <div>
          <div class="lbl">Peržiūrėta</div>
          <select id="f_rev"><option value="false" ${!kb.meta?.reviewed?'selected':''}>Ne</option><option value="true" ${kb.meta?.reviewed?'selected':''}>Taip</option></select>
        </div>
      </div>
      <div class="lbl">Objekto tagai</div>
      ${renderTagPanel('base-tags', kb.tags||[])}
    </div>
  </div>

  <div class="sec">
    <div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')">
      <h3>💰 Modeliai ir kainos</h3>
      <span style="font-size:10px;color:var(--td)">Įrangos modeliai · kainų lentelė · priežiūros intervalas</span>
      <span class="caret">▾</span>
    </div>
    <div class="sec-b">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
        <div class="lbl" style="margin:0">Įrangos modeliai</div>
        <button class="btn grn sm" onclick="addObjModel()">＋ Modelis</button>
      </div>
      <div id="obj-models-list">${renderObjModels(kb.models||[])}</div>

      <div style="margin-top:14px;display:grid;grid-template-columns:140px 1fr;gap:10px;align-items:start">
        <div>
          <div class="lbl">Priežiūros intervalas</div>
          <div style="display:flex;align-items:center;gap:5px">
            <input type="number" id="f_maint_interval" min="1" max="120" value="${kb.maintenance_schedule?.interval_months||6}" style="width:60px;text-align:center;font-weight:700">
            <span style="font-size:11px;color:var(--td)">mėn.</span>
          </div>
        </div>
        <div>
          <div class="lbl">Priežiūros užduotys</div>
          ${renderTagPanel('base-maint', kb.maintenance_schedule?.tasks||[])}
        </div>
      </div>
    </div>
  </div>

  <div class="save-bar">
    <button class="btn pri" onclick="saveKTabAndSync();toast('✓ Bazė išsaugota')">Išsaugoti</button>
    <div class="idbadge">v${kb.meta?.version||1} · ${kb.meta?.updated?new Date(kb.meta.updated).toLocaleDateString('lt-LT'):'–'}</div>
  </div>`;
}

function renderObjModels(models) {
  if(!models.length) return `<div style="font-size:11px;color:var(--td);padding:6px 0">Nėra modelių. Spusk „＋ Modelis".</div>`;
  return `<table style="width:100%;border-collapse:collapse;font-size:11px">
    <thead><tr style="background:var(--s2)">
      <th style="padding:5px 6px;text-align:left;color:var(--td)">ID / Modelis</th>
      <th style="padding:5px 6px;text-align:left;color:var(--td)">Pavadinimas</th>
      <th style="padding:5px 6px;text-align:center;color:var(--td)">Kaina €</th>
      <th style="padding:5px 6px;text-align:left;color:var(--td)">Pastabos</th>
      <th style="width:28px"></th>
    </tr></thead>
    <tbody>
    ${models.map((m,i)=>`<tr style="border-bottom:1px solid var(--b1)">
      <td style="padding:4px 6px"><input type="text" class="om-id" data-i="${i}" value="${e(m.id||'')}" placeholder="A" style="width:60px;font-size:11px;font-weight:700;font-family:'JetBrains Mono',monospace"></td>
      <td style="padding:4px 6px"><input type="text" class="om-name" data-i="${i}" value="${e(m.name||'')}" placeholder="Modelis A" style="width:100%;font-size:11px"></td>
      <td style="padding:4px 6px;text-align:center"><input type="number" class="om-price" data-i="${i}" value="${m.price_eur||0}" min="0" step="10" style="width:70px;text-align:center;font-weight:700;color:#2e7d32"></td>
      <td style="padding:4px 6px"><input type="text" class="om-notes" data-i="${i}" value="${e(m.notes||'')}" placeholder="..." style="width:100%;font-size:11px"></td>
      <td style="padding:4px;text-align:center"><button class="rm" onclick="rmObjModel(${i})">×</button></td>
    </tr>`).join('')}
    </tbody></table>`;
}

function addObjModel() {
  const kb=KB.objects[curObj]; if(!kb) return;
  if(!kb.models) kb.models=[];
  kb.models=readObjModels();
  kb.models.push({id:String.fromCharCode(65+(kb.models.length%26)), name:'', price_eur:0, notes:''});
  document.getElementById('obj-models-list').innerHTML=renderObjModels(kb.models);
}

function rmObjModel(i) {
  const kb=KB.objects[curObj]; if(!kb) return;
  kb.models=readObjModels();
  kb.models.splice(i,1);
  document.getElementById('obj-models-list').innerHTML=renderObjModels(kb.models);
}

function readObjModels() {
  const rows=[];
  document.querySelectorAll('.om-id').forEach((el,i)=>{
    rows.push({
      id:   el.value.trim(),
      name: document.querySelector(`.om-name[data-i="${i}"]`)?.value.trim()||'',
      price_eur: parseFloat(document.querySelector(`.om-price[data-i="${i}"]`)?.value)||0,
      notes: document.querySelector(`.om-notes[data-i="${i}"]`)?.value.trim()||''
    });
  });
  return rows;
}

function toggleNS(btn, sign) {
  const kb=KB.objects[curObj];
  if(!kb.normal_signs) kb.normal_signs=[];
  if(kb.normal_signs.includes(sign)){kb.normal_signs=kb.normal_signs.filter(s=>s!==sign);btn.classList.remove('on');}
  else{kb.normal_signs.push(sign);btn.classList.add('on');}
}

function renderFails(kb) {
  const fkeys=Object.keys(kb.failure_modes||{});
  return `<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
    <span style="font-size:11px;color:var(--td)">${fkeys.length} gedimas (-ai)</span>
    <button class="btn pri sm" onclick="addFail()">+ Gedimas</button>
    <button class="btn sec sm" onclick="openImportModal()" style="margin-left:4px">📥 Importuoti</button>
  </div>
  ${fkeys.map(fid=>renderFailCard(fid,kb.failure_modes[fid])).join('')}
  ${!fkeys.length?`<div style="text-align:center;padding:40px;color:var(--td);font-size:12px">Nėra gedimų. Spusk "+ Gedimas"</div>`:''}`;
}

function renderFailCard(fid, fm) {
  const scol={low:'#4caf50',med:'#ff9800',high:'#f44336',critical:'#e91e63'}[fm.severity]||'#ccc';
  const causes=fm.causes?.list||[];
  const causesPreview=causes.length?`<div style="font-size:10px;color:var(--td);margin-top:4px">🔍 ${causes.length} priežastis(-ys)</div>`:'';
  return `<div class="dyn-item" id="fc-${fid}" style="border-left:3px solid ${scol}">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
      <span style="font-size:10px;color:var(--td);font-family:'JetBrains Mono',monospace">${fid}</span>
      <strong style="font-size:13px;flex:1">${fm.name||'(be pavadinimo)'}</strong>
      <span class="sev-badge sev-${fm.severity||'med'}">${{low:'Mažas',med:'Vidutinis',high:'Didelis',critical:'Kritinis'}[fm.severity]||'?'}</span>
      <button onclick="toggleFE('${fid}')" class="btn ghost sm">✏ Redaguoti</button>
      <button class="rm" onclick="rmFail('${fid}')">×</button>
    </div>
    ${fm.symptoms?.length?`<div style="font-size:10px;color:var(--td)">👁 ${fm.symptoms.map(s=>`<span style="color:var(--pri2)">${s}</span>`).join(', ')}</div>`:''}
    ${causesPreview}
    ${(fm.economics?.user_saved>0||fm.economics?.specialist_cost_avg>0)?`<div style="display:inline-flex;align-items:center;gap:5px;margin-top:4px;padding:3px 8px;background:#e8f5e9;border:1px solid #a5d6a7;border-radius:20px;font-size:10px;font-weight:700;color:#2e7d32">💰 Sutaupoma ~${fm.economics.user_saved||fm.economics.specialist_cost_avg}€</div>`:''}
    <div id="fe-${fid}" style="display:none;margin-top:14px;border-top:2px solid var(--b1);padding-top:14px">
      <div class="fail-section">
        <div class="fail-section-title">① Identifikacija</div>
        <div class="row2">
          <div>
            <div class="lbl">Gedimo pavadinimas</div>
            <input type="text" class="fe-n" data-f="${fid}" value="${e(fm.name||'')}" placeholder="pvz. Orapūtė neveikia">
          </div>
          <div>
            <div class="lbl">Sunkumas</div>
            <div class="sevrow">
              ${['low','med','high','critical'].map(sv=>`<button class="sevbtn ${fm.severity===sv?'on':''}" data-v="${sv}" data-f="${fid}" onclick="setSev(this,'${fid}')">${{low:'Mažas',med:'Vidutin.',high:'Didelis',critical:'Kritinis'}[sv]}</button>`).join('')}
            </div>
          </div>
        </div>
      </div>
      <div class="fail-section">
        <div class="fail-section-title">② Simptomai <span style="font-size:9px;font-weight:400;color:var(--td)">– kas matoma iš išorės (ką sako/mato klientas)</span></div>
        ${renderTagPanel('fes-'+fid, fm.symptoms||[], true)}
      </div>
      <div class="fail-section">
        <div class="fail-section-title">③ Priežastys
          <span style="font-size:9px;font-weight:400;color:var(--td)">– kodėl taip atsitinka (gali būti kelios)</span>
          <button class="btn grn sm" style="margin-left:auto" onclick="addScenario('${fid}')">+ Situacija</button>
        </div>
        <div style="font-size:10px;color:var(--td);margin-bottom:8px;padding:6px 8px;background:var(--s2);border-radius:6px">
          💡 Kiekvienai situacijai: <strong>jei matai tai</strong> → <strong>daryk tai</strong>. Sistema automatiškai sudarys diagnostikos medį.
        </div>
        <div id="scenarios-${fid}">
          ${renderScenarios(fid, fm.causes?.list||[])}
        </div>
      </div>
      <div class="fail-section">
        <div class="fail-section-title">④ Kontekstas – laiko sąlygos
          <span style="font-size:9px;font-weight:400;color:var(--td)">– kas skiriasi priklausomai nuo to kiek laiko gedimas truko</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:8px">
          ${[
            ['ctx_short','⚡ Trumpai (val/diena)','pvz. bakterijos gyvos — tik sutvarkyti','#e8f5e9','#2e7d32'],
            ['ctx_long','⏳ Ilgai (savaitė+)','pvz. bakterijos mirė — sutvarkyti + papildyti','#fff3e0','#e65100'],
            ['ctx_very_long','⚠ Itin ilgai (mėn+)','pvz. infiltracija užsikimšo — tikrinti visą sistemą','#ffebee','#c62828']
          ].map(([k,lbl,ph,bg,col])=>`
            <div style="background:${bg};border-left:3px solid ${col};border-radius:6px;padding:8px">
              <div style="font-size:10px;font-weight:700;color:${col};margin-bottom:4px">${lbl}</div>
              <input type="text" class="fe-ctx" data-f="${fid}" data-k="${k}"
                value="${e((fm.context||{})[k]||'')}" placeholder="${ph}"
                style="background:transparent;border:none;border-bottom:1px solid ${col}40;width:100%;font-size:11px;padding:2px 0">
            </div>`).join('')}
        </div>
      </div>
      <div class="fail-section">
        <div class="fail-section-title">⑤ Profilaktika <span style="font-size:9px;font-weight:400;color:var(--td)">– kaip išvengti</span></div>
        <textarea class="fe-prev" data-f="${fid}" rows="2" placeholder="pvz. Tikrinti filtrą kas 6 mėn.">${e(fm.prevention||'')}</textarea>
      </div>
      <div class="fail-section">
        <div class="fail-section-title">⑥ Aplinkos įtaka <span style="font-size:9px;font-weight:400;color:var(--td)">1.0=normalu · 2.0=dvigubai dažniau · 0.5=rečiau</span></div>
        <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px">
          ${[['gvl1','🌊 GVL↑'],['gvl2','💧 GVL↓'],['smel','🟡 Smėlis'],['mol','🟤 Molis'],['old','⏳ 7m+']].map(([k,l])=>`
          <div style="text-align:center">
            <div style="font-size:9px;color:var(--td);margin-bottom:3px">${l}</div>
            <input type="number" step="0.1" min="0.1" max="10" class="fe-em-${k}" data-f="${fid}"
              value="${e(String(((fm.env_modifiers||{})[k]||{}).prob_mult||'1.0'))}"
              style="text-align:center;font-weight:700;font-size:12px"
              oninput="updEnvMod('${fid}','${k}',this.value)">
          </div>`).join('')}
        </div>
      </div>
      <div class="fail-section">
        <div class="fail-section-title">⑦ Meta</div>
        <div class="row3">
          <div>
            <div class="lbl">Pirmas atvejis</div>
            <div class="micro">${['2021','2022','2023','2024','2025'].map(y=>`<button class="mb" onclick="setFD('.fe-fs','${fid}','${y}')">${y}</button>`).join('')}</div>
            <input type="text" class="fe-fs" data-f="${fid}" value="${e((fm.meta||{}).first_seen||'')}" placeholder="2023">
          </div>
          <div>
            <div class="lbl">Pasitikėjimas</div>
            <div class="conf-wrap">
              <input type="range" class="fe-conf" data-f="${fid}" min="0" max="100" value="${(fm.meta||{}).confidence||50}" oninput="this.nextSibling.textContent=this.value">
              <div class="conf-val">${(fm.meta||{}).confidence||50}</div>
            </div>
          </div>
          <div>
            <div class="lbl">Tagai</div>
            ${renderTagPanel('fet-'+fid, fm.tags||[])}
          </div>
        </div>
      </div>
      <div class="fail-section">
        <div class="fail-section-title">⑧ Ekonomika
          <span style="font-size:9px;font-weight:400;color:var(--td)">– kiek sutaupo, jei problema išsprendžiama pačiam</span>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;align-items:end">
          <div>
            <div class="lbl">💰 Pats sutaiso (€)</div>
            <div style="font-size:9px;color:var(--td);margin-bottom:3px">medžiagų/dalių kaina</div>
            <input type="number" min="0" step="5" class="fe-eco-self" data-f="${fid}"
              value="${fm.economics?.self_fix_cost||0}"
              oninput="updEcoSaved('${fid}')"
              style="text-align:center;font-weight:700;font-size:14px;width:100%">
          </div>
          <div>
            <div class="lbl">👷 Specialisto iškvietimas (€)</div>
            <div style="font-size:9px;color:var(--td);margin-bottom:3px">vidutinė rinkos kaina</div>
            <input type="number" min="0" step="10" class="fe-eco-spec" data-f="${fid}"
              value="${fm.economics?.specialist_cost_avg||120}"
              oninput="updEcoSaved('${fid}')"
              style="text-align:center;font-weight:700;font-size:14px;width:100%">
          </div>
          <div style="background:linear-gradient(135deg,#e8f5e9,#c8e6c9);border:2px solid #4caf50;border-radius:10px;padding:10px;text-align:center">
            <div style="font-size:10px;font-weight:700;color:#1b5e20;margin-bottom:2px">🟢 SUTAUPOMA</div>
            <div class="eco-saved-disp" id="eco-disp-${fid}" style="font-size:22px;font-weight:900;color:#2e7d32;line-height:1.1">
              ~${((fm.economics?.specialist_cost_avg||120)-(fm.economics?.self_fix_cost||0))}€
            </div>
            <div style="font-size:9px;color:#388e3c;margin-top:2px">vs specialisto</div>
          </div>
        </div>
        <div style="margin-top:8px;padding:8px 12px;background:#f3e5f5;border-left:3px solid #7b1fa2;border-radius:6px;font-size:10px;color:#4a148c;line-height:1.5">
          💡 Diagnostikos ekrane bus rodoma:<br>
          <strong>"Problema išspręsta. Sutaupyta ~<span id="eco-msg-${fid}">${((fm.economics?.specialist_cost_avg||120)-(fm.economics?.self_fix_cost||0))}</span>€ – specialisto iškvietimas kainuotų ~${fm.economics?.specialist_cost_avg||120}€"</strong>
        </div>
      </div>
      <div class="save-bar">
        <button class="btn pri" onclick="saveFailAndSync('${fid}');toast('✓ Išsaugota')">💾 Išsaugoti</button>
        <button class="btn sec sm" onclick="genAndShowTree('${fid}')">🌿 Rodyti medį</button>
        <button class="btn ghost sm" onclick="toggleFE('${fid}')">Uždaryti</button>
      </div>
    </div>
    <div id="inline-tree-${fid}" style="display:none;margin-top:12px;border-top:2px solid var(--pri);padding-top:10px">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px">
        <span style="font-size:11px;font-weight:700;color:var(--pri)">🌿 Diagnostikos medis</span>
        <button class="btn ghost sm" onclick="document.getElementById('inline-tree-${fid}').style.display='none'">✕</button>
      </div>
      <div id="inline-tree-render-${fid}" style="overflow-x:auto;padding:12px 8px;background:var(--bg);border-radius:var(--r);min-height:80px;border:1px solid var(--b1)"></div>
    </div>
  </div>`;
}

function renderDiagSteps(fid, steps) {
  if(!steps.length) return `<div style="text-align:center;padding:20px;color:var(--td);font-size:11px">Nėra žingsnių. Spusk "+ Žingsnis"</div>`;
  return steps.map((step, i)=>`
    <div class="diag-step-card" id="dsc-${fid}-${i}">
      <div class="diag-step-num">${i+1}</div>
      <div class="diag-step-body">
        <div class="lbl">Klausimas / tikrinimas</div>
        <input type="text" class="ds-q" data-f="${fid}" data-i="${i}"
          value="${e(step.question||'')}" placeholder="pvz. Ar oro filtras užsikimšęs?">
        <div class="row2" style="margin-top:8px">
          <div class="diag-branch taip">
            <div class="branch-lbl">✓ TAIP → sprendimas:</div>
            <textarea class="ds-yes" data-f="${fid}" data-i="${i}" rows="2"
              placeholder="pvz. Atsuk varžtą, nuimk dangteli, išplauk filtrą, surink atgal">${e(step.yes||'')}</textarea>
            <div style="margin-top:4px">
              <label style="font-size:10px;color:var(--td)">Statusas:</label>
              <select class="ds-yes-status" data-f="${fid}" data-i="${i}" style="font-size:10px;padding:2px 6px">
                <option value="fixed" ${(step.yes_status||'fixed')==='fixed'?'selected':''}>✅ Išspręsta</option>
                <option value="next" ${step.yes_status==='next'?'selected':''}>→ Kitas žingsnis</option>
                <option value="specialist" ${step.yes_status==='specialist'?'selected':''}>📞 Specialistas</option>
              </select>
            </div>
          </div>
          <div class="diag-branch ne">
            <div class="branch-lbl">✗ NE → toliau:</div>
            <select class="ds-no" data-f="${fid}" data-i="${i}" style="font-size:11px;padding:4px 8px">
              ${steps.map((_,j)=>j!==i?`<option value="${j+1}" ${step.no_next===j+1?'selected':''}>→ Žingsnis ${j+1}</option>`:'').join('')}
              <option value="specialist" ${step.no_next==='specialist'?'selected':''}>📞 Specialistas</option>
              <option value="end" ${step.no_next==='end'?'selected':''}>■ Neaiški priežastis</option>
            </select>
          </div>
        </div>
      </div>
      <div class="diag-step-actions">
        <button class="btn ghost sm" onclick="moveDiagStep('${fid}',${i},-1)" ${i===0?'disabled':''}>↑</button>
        <button class="btn ghost sm" onclick="moveDiagStep('${fid}',${i},1)" ${i===steps.length-1?'disabled':''}>↓</button>
        <button class="rm" onclick="rmDiagStep('${fid}',${i})">×</button>
      </div>
    </div>`).join('');
}

function addDiagStep(fid) {
  const fm=_curKB()?.failure_modes?.[fid]; if(!fm) return;
  if(!fm.diag_tree) fm.diag_tree=[];
  fm.diag_tree.push({question:'',yes:'',yes_status:'fixed',no_next:'specialist'});
  document.getElementById('diag-steps-'+fid).innerHTML=renderDiagSteps(fid, fm.diag_tree);
}

function rmDiagStep(fid, i) {
  const fm=_curKB()?.failure_modes?.[fid]; if(!fm) return;
  fm.diag_tree.splice(i,1);
  document.getElementById('diag-steps-'+fid).innerHTML=renderDiagSteps(fid, fm.diag_tree);
}

function moveDiagStep(fid, i, dir) {
  const fm=_curKB()?.failure_modes?.[fid]; if(!fm) return;
  const j=i+dir; if(j<0||j>=fm.diag_tree.length) return;
  [fm.diag_tree[i],fm.diag_tree[j]]=[fm.diag_tree[j],fm.diag_tree[i]];
  document.getElementById('diag-steps-'+fid).innerHTML=renderDiagSteps(fid, fm.diag_tree);
}

function saveDiagSteps(fid) {
  const fm=_curKB()?.failure_modes?.[fid]; if(!fm) return;
  const steps=[];
  document.querySelectorAll(`.ds-q[data-f="${fid}"]`).forEach((el,i)=>{
    const yesEl=document.querySelector(`.ds-yes[data-f="${fid}"][data-i="${i}"]`);
    const noEl=document.querySelector(`.ds-no[data-f="${fid}"][data-i="${i}"]`);
    const statusEl=document.querySelector(`.ds-yes-status[data-f="${fid}"][data-i="${i}"]`);
    steps.push({
      question:el.value.trim(),
      yes:yesEl?.value.trim()||'',
      yes_status:statusEl?.value||'fixed',
      no_next:noEl?.value||'specialist'
    });
  });
  fm.diag_tree=steps;
}

function updEnvMod(fid, key, val) {
  const fm=_curKB()?.failure_modes?.[fid]; if(!fm) return;
  if(!fm.env_modifiers) fm.env_modifiers={};
  fm.env_modifiers[key]={prob_mult:val};
  const _sId=_curId(); if(!KB.percentages[_sId]) KB.percentages[_sId]={};
  if(!KB.percentages[_sId][fid]) KB.percentages[_sId][fid]={base:10};
  KB.percentages[_sId][fid][key]=parseFloat(val)||1.0;
}

function renderEnv(kb) {
  const env=kb.env_behavior||{};
  return `
  <div class="sec"><div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')"><h3>Gruntinis vanduo</h3><span class="caret">▾</span></div>
  <div class="sec-b">
    ${[['gvl1','🌊 Aukštas GVL'],['gvl2','💧 Žemas GVL'],['gvl3','🏜 Nėra GVL']].map(([k,l])=>`
      <div class="lbl">${l}</div><textarea id="fenv_${k}" rows="2">${e((env.gvl||{})[k]||'')}</textarea>`).join('')}
  </div></div>
  <div class="sec"><div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')"><h3>Gruntas</h3><span class="caret">▾</span></div>
  <div class="sec-b">
    <div class="lbl">🟡 Smėlis @smel</div><textarea id="fenv_smel" rows="2">${e((env.soil||{}).smel||'')}</textarea>
    <div class="lbl">🟤 Molis @mol</div><textarea id="fenv_mol" rows="2">${e((env.soil||{}).mol||'')}</textarea>
  </div></div>
  <div class="sec"><div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')"><h3>Senėjimas ir reljefas</h3><span class="caret">▾</span></div>
  <div class="sec-b">
    <div class="lbl">Senėjimo efektai</div>
    <textarea id="fenv_age" rows="3">${e(env.age_effects||'')}</textarea>
    <div class="micro">
      <button class="mb" onclick="appE('fenv_age','Po 3m: filtro keitimas.')">+Po 3m</button>
      <button class="mb" onclick="appE('fenv_age','Po 5m: membrana.')">+Po 5m</button>
      <button class="mb" onclick="appE('fenv_age','Po 10m: pilnas apsitarnavimas.')">+Po 10m</button>
    </div>
    <div class="lbl">Reljefas</div>
    <textarea id="fenv_rel" rows="2">${e(env.reljefas||'')}</textarea>
  </div></div>
  <div class="save-bar"><button class="btn pri" onclick="saveKTabAndSync();toast('✓ Aplinka išsaugota')">Išsaugoti</button></div>`;
}

function renderErrs(kb) {
  const errs=kb.exploitation_errors||[];
  return `<div id="errs-list">${errs.map((er,i)=>`
  <div class="dyn-item">
    <button class="rm" onclick="rmErr(${i})">×</button>
    <div class="lbl">Klaida</div>
    <input type="text" class="er-k" data-i="${i}" value="${e(er.klaida||'')}">
    <div class="row3">
      <div><div class="lbl">Pasekmė</div><input type="text" class="er-p" data-i="${i}" value="${e(er.pasekme||'')}"></div>
      <div>
        <div class="lbl">Trukmė iki poveikio</div>
        <div class="micro">
          <button class="mb" onclick="setET(${i},'&lt;1val')">&lt;1val</button>
          <button class="mb" onclick="setET(${i},'1-3d')">1-3d</button>
          <button class="mb" onclick="setET(${i},'1sav')">1sav</button>
        </div>
        <input type="text" class="er-t" data-i="${i}" value="${e(er.trukme||'')}">
      </div>
      <div><div class="lbl">Prevencija</div><input type="text" class="er-pr" data-i="${i}" value="${e(er.prevencija||'')}"></div>
    </div>
  </div>`).join('')}</div>
  <button class="add-btn" onclick="addErr()">+ Pridėti klaidą</button>
  <div class="save-bar"><button class="btn pri" onclick="saveKTabAndSync();toast('✓ Klaidos išsaugotos')">Išsaugoti</button></div>`;
}

function renderRels(obj, kb) {
  const other=Object.keys(KB.objects_meta).filter(id=>id!==curObj);
  return `
  <div class="sec"><div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')"><h3>Sistemos topologija</h3><span class="caret">▾</span></div>
  <div class="sec-b">
    <div style="font-size:11px;color:var(--td);margin-bottom:10px">Nurodyk kur šis objektas yra sistemoje – prieš ką ir po ko</div>
    ${[['upstream','← Prieš šį (upstream)'],['downstream','→ Po šio (downstream)'],['alternatives','⇄ Alternatyvūs'],['depends_on','↳ Priklauso nuo']].map(([type,lbl])=>`
      <div class="lbl">${lbl}</div>
      <div class="micro">${other.map(id=>{
        const nm=(KB.objects_meta[id]&&KB.objects_meta[id].name)||id;
        const on=(kb.relations?.[type]||[]).includes(id);
        return '<button class="mb '+(on?'on':'')+'" onclick="toggleRel(\''+type+'\',\''+id+'\',this)" title="'+id+'">'+nm+'</button>';
      }).join('')}</div>`).join('')}
    <div class="save-bar"><button class="btn pri" onclick="saveKTabAndSync();toast('✓ Ryšiai išsaugoti')">Išsaugoti</button></div>
  </div></div>`;
}

function toggleRel(type,id,btn) {
  const r=KB.objects[curObj].relations;
  if(!r) KB.objects[curObj].relations={};
  if(!KB.objects[curObj].relations[type]) KB.objects[curObj].relations[type]=[];
  const arr=KB.objects[curObj].relations[type];
  if(arr.includes(id)){KB.objects[curObj].relations[type]=arr.filter(i=>i!==id);btn.classList.remove('on');}
  else{arr.push(id);btn.classList.add('on');}
}

function addFail() {
  
  const isComp = !!curComp;
  const activeId = isComp ? curComp : curObj;
  const activeKB = isComp ? KB.components[curComp] : KB.objects[curObj];
  if(!activeKB) return;
  
  if(!activeKB.failure_modes || Array.isArray(activeKB.failure_modes)) activeKB.failure_modes = {};
  const fms=activeKB.failure_modes;
  const n=Object.keys(fms).length+1;
  const fid=`${activeId}-F${String(n).padStart(3,'0')}`;
  fms[fid]={
    id:fid, name:'', severity:'med', frequency:0, tags:[], symptoms:[],
    causes:{list:[]},
    context:{ctx_short:'', ctx_long:'', ctx_very_long:''},
    prevention:'',
    env_modifiers:{gvl1:{prob_mult:'1.0'},gvl2:{prob_mult:'1.0'},smel:{prob_mult:'1.0'},mol:{prob_mult:'1.0'},old:{prob_mult:'1.0'}},
    relations:{also_in:[],leads_to:[]},
    economics:{self_fix_cost:0, specialist_cost_avg:120, user_saved:120},
    meta:{confidence:50, first_seen:'', created:new Date().toISOString()}
  };
  if(!KB.percentages[activeId]) KB.percentages[activeId]={};
  KB.percentages[activeId][fid]={base:10,gvl1:1.0,gvl2:1.0,smel:1.0,mol:1.0,old:1.0};
  if(isComp) {
    markDirty('comp_'+activeId);
    flushDirty(); 
    renderCompTab(activeId);
  } else { markDirty('fail_'+activeId+'_'+fid); ui('ktab'); }
  setTimeout(()=>{const fe=document.getElementById('fe-'+fid);if(fe)fe.style.display='block';},80);
}

function toggleFE(fid) {
  const el=document.getElementById('fe-'+fid);
  if(el) el.style.display=el.style.display==='none'?'block':'none';
}

function rmFail(fid) {
  if(!confirm('Ištrinti '+fid+'?')) return;
  const _rId=_curId(); delete _curKB().failure_modes[fid];
  if(KB.percentages[_rId]) delete KB.percentages[_rId][fid];
  if(KB.decision_trees[fid]) delete KB.decision_trees[fid];
  clearTimeout(_saveTimer); _dirty.clear();
  showSaveInd('Trinamas…','#e65100');
  apiPost('delete_failure', {object_id:_rId, id:fid})
    .then(()=>{ showSaveInd('🗑 Ištrinta','#2e7d32'); toast('🗑 '+fid+' ištrinta'); })
    .catch(err=>{ showSaveInd('✗ Klaida','#c62828'); toast('⚠ '+err.message); });
  ui('ktab');
}

function saveFail(fid) {
  const fm=_curKB()?.failure_modes?.[fid]; if(!fm) return;
  fm.name=fv('.fe-n',fid);
  const sb=document.querySelector(`.sevbtn.on[data-f="${fid}"]`);
  if(sb) fm.severity=sb.dataset.v;
  fm.symptoms=getTagsFrom('fes-'+fid);
  
  fm.causes={list:readScenarios(fid)};
  
  fm.context={};
  document.querySelectorAll(`.fe-ctx[data-f="${fid}"]`).forEach(el=>{
    fm.context[el.dataset.k]=el.value.trim();
  });
  fm.prevention=fv('.fe-prev',fid);
  fm.tags=getTagsFrom('fet-'+fid);
  fm.meta={...(fm.meta||{}), confidence:parseInt(fv('.fe-conf',fid))||50, first_seen:fv('.fe-fs',fid)};
  
  const ecoSelf=parseFloat(document.querySelector(`.fe-eco-self[data-f="${fid}"]`)?.value||'0')||0;
  const ecoSpec=parseFloat(document.querySelector(`.fe-eco-spec[data-f="${fid}"]`)?.value||'120')||120;
  fm.economics={self_fix_cost:ecoSelf, specialist_cost_avg:ecoSpec, user_saved:Math.max(0,ecoSpec-ecoSelf)};
  fm.env_modifiers={};
  ['gvl1','gvl2','smel','mol','old'].forEach(k=>{
    fm.env_modifiers[k]={prob_mult:fv('.fe-em-'+k,fid)||'1.0'};
    const _pId=_curId(); if(!KB.percentages[_pId]) KB.percentages[_pId]={};
    if(!KB.percentages[_pId][fid]) KB.percentages[_pId][fid]={base:10};
    KB.percentages[_pId][fid][k]=parseFloat(fv('.fe-em-'+k,fid)||'1.0');
  });
  updateJson(); updateCounts();
}

function setSev(btn,fid) {
  document.querySelectorAll(`.sevbtn[data-f="${fid}"]`).forEach(b=>b.classList.remove('on'));
  btn.classList.add('on');
}

function updEcoSaved(fid) {
  const selfEl=document.querySelector(`.fe-eco-self[data-f="${fid}"]`);
  const specEl=document.querySelector(`.fe-eco-spec[data-f="${fid}"]`);
  const dispEl=document.getElementById('eco-disp-'+fid);
  const msgEl=document.getElementById('eco-msg-'+fid);
  if(!selfEl||!specEl) return;
  const saved=Math.max(0,(parseFloat(specEl.value)||120)-(parseFloat(selfEl.value)||0));
  if(dispEl) dispEl.textContent='~'+saved+'€';
  if(msgEl) msgEl.textContent=saved;
}

// ─── E7: GLB Kalibratoriaus įrankis ─────────────────────────────────────────

function renderKalib(obj, kb) {
  const el = document.getElementById('k-content');
  const s3d = kb.scene_3d || {glb:'', scale:1.0, rotation_y:0, offset_y:0,
    socket_in:{x:0,y:0,z:0}, socket_out:{x:0,y:0,z:0}};

  el.innerHTML = `
    <div class="sec">
      <div class="sec-h"><h3>🎯 GLB Kalibratorius — ${e(obj.name||curObj)}</h3></div>
      <div class="sec-b">

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
          <div>
            <div class="lbl">GLB failo pavadinimas</div>
            <input type="text" id="kalib-glb" value="${e(s3d.glb||'')}"
              placeholder="pvz. BNVI.glb"
              style="width:100%;padding:6px 10px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:11px;font-family:inherit">
            <div style="font-size:9px;color:var(--td);margin-top:3px">Failas turi būti įkeltas į <code>/shared/glb/</code></div>
          </div>
          <div>
            <button class="btn pri" onclick="kalibLoadGlb()" style="margin-top:18px;width:100%">
              ▶ Įkelti ir peržiūrėti
            </button>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:16px">
          <div>
            <div class="lbl">Skalė</div>
            <input type="range" id="kalib-scale" min="0.1" max="5" step="0.05"
              value="${s3d.scale||1}" oninput="kalibUpdate()" style="width:100%">
            <div style="text-align:center;font-size:11px;font-weight:700" id="kalib-scale-v">${s3d.scale||1}</div>
          </div>
          <div>
            <div class="lbl">Rotacija Y (rad)</div>
            <input type="range" id="kalib-rot" min="-3.14" max="3.14" step="0.05"
              value="${s3d.rotation_y||0}" oninput="kalibUpdate()" style="width:100%">
            <div style="text-align:center;font-size:11px;font-weight:700" id="kalib-rot-v">${s3d.rotation_y||0}</div>
          </div>
          <div>
            <div class="lbl">Aukščio poslinkis Y</div>
            <input type="range" id="kalib-off" min="-2" max="2" step="0.05"
              value="${s3d.offset_y||0}" oninput="kalibUpdate()" style="width:100%">
            <div style="text-align:center;font-size:11px;font-weight:700" id="kalib-off-v">${s3d.offset_y||0}</div>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
          <div>
            <div class="lbl" style="color:#2e7d32">🟢 Įvadas (socket_in) — X, Y, Z</div>
            <div style="display:flex;gap:6px">
              ${['x','y','z'].map(ax=>`
                <div style="flex:1">
                  <div style="font-size:9px;color:var(--td);text-align:center">${ax.toUpperCase()}</div>
                  <input type="number" id="kalib-in-${ax}" step="0.05"
                    value="${(s3d.socket_in||{})[ax]||0}"
                    style="width:100%;padding:4px 6px;border:1.5px solid #a5d6a7;border-radius:var(--r);font-size:11px;text-align:center"
                    oninput="kalibUpdate()">
                </div>`).join('')}
            </div>
          </div>
          <div>
            <div class="lbl" style="color:#c62828">🔴 Išvadas (socket_out) — X, Y, Z</div>
            <div style="display:flex;gap:6px">
              ${['x','y','z'].map(ax=>`
                <div style="flex:1">
                  <div style="font-size:9px;color:var(--td);text-align:center">${ax.toUpperCase()}</div>
                  <input type="number" id="kalib-out-${ax}" step="0.05"
                    value="${(s3d.socket_out||{})[ax]||0}"
                    style="width:100%;padding:4px 6px;border:1.5px solid #ef9a9a;border-radius:var(--r);font-size:11px;text-align:center"
                    oninput="kalibUpdate()">
                </div>`).join('')}
            </div>
          </div>
        </div>

        <canvas id="kalib-canvas" width="500" height="300"
          style="width:100%;border:2px solid var(--b1);border-radius:var(--r2);background:#f2f8f3;display:block;margin-bottom:12px">
        </canvas>

        <div id="kalib-status" style="font-size:11px;color:var(--td);margin-bottom:8px;min-height:16px"></div>

        <div class="save-bar">
          <button class="btn pri" onclick="kalibSave()">💾 Išsaugoti scene_3d</button>
          <button class="btn ghost" onclick="kalibClear()">✕ Išvalyti GLB</button>
        </div>

      </div>
    </div>`;

  // Init Three.js preview
  kalibInitScene();
}

let _kalibScene = null;

function kalibInitScene() {
  const canvas = document.getElementById('kalib-canvas');
  if (!canvas || typeof THREE === 'undefined') {
    // Load Three.js if not loaded
    if (typeof THREE === 'undefined') {
      const sc = document.createElement('script');
      sc.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r134/three.min.js';
      sc.onload = () => kalibInitScene();
      document.head.appendChild(sc);
      return;
    }
  }
  if (!canvas) return;

  // Stop previous
  if (_kalibScene) { _kalibScene.stop(); _kalibScene = null; }

  const W = canvas.clientWidth || 500, H = 300;
  canvas.width = W; canvas.height = H;

  const scene    = new THREE.Scene();
  scene.background = new THREE.Color(0xf2f8f3);
  const camera   = new THREE.PerspectiveCamera(45, W/H, 0.1, 100);
  camera.position.set(0, 1.5, 4);
  camera.lookAt(0, 0, 0);
  const renderer = new THREE.WebGLRenderer({canvas, antialias:true});
  renderer.setSize(W, H);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  scene.add(new THREE.AmbientLight(0xffffff, 0.8));
  const dl = new THREE.DirectionalLight(0xffffff, 0.6);
  dl.position.set(5, 10, 5); scene.add(dl);

  // Grid
  const grid = new THREE.GridHelper(6, 12, 0x4a9d6f, 0xc8e6c9);
  scene.add(grid);

  // Placeholder sphere (shown when no GLB loaded)
  const sphere = new THREE.Mesh(
    new THREE.SphereGeometry(0.38, 16, 16),
    new THREE.MeshPhongMaterial({color: 0x2e7d32})
  );
  scene.add(sphere);

  // Socket markers
  const inMesh  = new THREE.Mesh(new THREE.SphereGeometry(0.08,8,8), new THREE.MeshBasicMaterial({color:0x2e7d32}));
  const outMesh = new THREE.Mesh(new THREE.SphereGeometry(0.08,8,8), new THREE.MeshBasicMaterial({color:0xc62828}));
  scene.add(inMesh); scene.add(outMesh);

  let model = null;
  let stopped = false;
  let animId;

  function animate() {
    if (stopped) return;
    animId = requestAnimationFrame(animate);
    renderer.render(scene, camera);
  }
  animate();

  // Orbit controls (simple mouse drag)
  let drag = false, lastM = {x:0,y:0};
  let theta = 0.4, phi = 1.2, r = 4;
  function applyOrbit() {
    camera.position.set(
      r * Math.sin(phi) * Math.sin(theta),
      r * Math.cos(phi),
      r * Math.sin(phi) * Math.cos(theta)
    );
    camera.lookAt(0, 0, 0);
  }
  applyOrbit();

  canvas.addEventListener('mousedown', e => { drag=true; lastM={x:e.clientX,y:e.clientY}; });
  canvas.addEventListener('mousemove', e => {
    if (!drag) return;
    theta -= (e.clientX-lastM.x)*0.01;
    phi    = Math.max(0.1, Math.min(Math.PI-0.1, phi+(e.clientY-lastM.y)*0.01));
    lastM  = {x:e.clientX,y:e.clientY};
    applyOrbit();
  });
  canvas.addEventListener('mouseup', () => { drag=false; });
  canvas.addEventListener('wheel', e => {
    r = Math.max(1, Math.min(10, r + e.deltaY*0.01));
    applyOrbit(); e.preventDefault();
  }, {passive:false});

  _kalibScene = {
    scene, renderer, camera, sphere, inMesh, outMesh,
    stop: () => { stopped=true; cancelAnimationFrame(animId); renderer.dispose(); },
    setModel: (gltf) => {
      if (model) scene.remove(model);
      model = gltf.scene;
      scene.remove(sphere);
      scene.add(model);
      kalibUpdateScene();
    },
    clearModel: () => {
      if (model) { scene.remove(model); model=null; }
      if (!scene.children.includes(sphere)) scene.add(sphere);
    },
    updateTransform: () => kalibUpdateScene(),
    applyOrbit,
  };

  kalibUpdateScene();
}

function kalibUpdateScene() {
  if (!_kalibScene) return;
  const scale = parseFloat(document.getElementById('kalib-scale')?.value||1);
  const rot   = parseFloat(document.getElementById('kalib-rot')?.value||0);
  const off   = parseFloat(document.getElementById('kalib-off')?.value||0);
  const inX   = parseFloat(document.getElementById('kalib-in-x')?.value||0);
  const inY   = parseFloat(document.getElementById('kalib-in-y')?.value||0);
  const inZ   = parseFloat(document.getElementById('kalib-in-z')?.value||0);
  const outX  = parseFloat(document.getElementById('kalib-out-x')?.value||0);
  const outY  = parseFloat(document.getElementById('kalib-out-y')?.value||0);
  const outZ  = parseFloat(document.getElementById('kalib-out-z')?.value||0);

  // Update labels
  if (document.getElementById('kalib-scale-v')) document.getElementById('kalib-scale-v').textContent = scale.toFixed(2);
  if (document.getElementById('kalib-rot-v'))   document.getElementById('kalib-rot-v').textContent   = rot.toFixed(2);
  if (document.getElementById('kalib-off-v'))   document.getElementById('kalib-off-v').textContent   = off.toFixed(2);

  // Apply to scene objects
  const {scene, inMesh, outMesh} = _kalibScene;
  scene.children.forEach(c => {
    if (c === inMesh || c === outMesh || c.isLight || c.isGridHelper) return;
    c.scale.setScalar(scale);
    c.rotation.y = rot;
    c.position.y = off;
  });
  inMesh.position.set(inX, inY + off, inZ);
  outMesh.position.set(outX, outY + off, outZ);
}

function kalibUpdate() {
  kalibUpdateScene();
}

function kalibLoadGlb() {
  const glbName = (document.getElementById('kalib-glb')?.value||'').trim();
  if (!glbName) { toast('Įveskite GLB failo pavadinimą'); return; }
  if (!_kalibScene) { kalibInitScene(); setTimeout(()=>kalibLoadGlb(), 500); return; }

  const status = document.getElementById('kalib-status');
  if (status) status.textContent = 'Kraunamas ' + glbName + '...';

  // Load GLTFLoader dynamically
  function doLoad() {
    if (typeof THREE.GLTFLoader === 'undefined') {
      const sc = document.createElement('script');
      sc.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r134/examples/js/loaders/GLTFLoader.js';
      sc.onload = () => doLoad();
      document.head.appendChild(sc);
      return;
    }
    const loader = new THREE.GLTFLoader();
    loader.load(
      '/shared/glb/' + glbName,
      gltf => {
        _kalibScene.setModel(gltf);
        if (status) status.textContent = '✓ ' + glbName + ' įkeltas';
        toast('GLB įkeltas ✓');
      },
      null,
      err => {
        if (status) status.textContent = '⚠ Klaida: ' + (err.message||'nepavyko įkelti');
        toast('⚠ GLB klaida: patikrinkite ar failas yra /shared/glb/');
      }
    );
  }
  doLoad();
}

function kalibClear() {
  if (_kalibScene) _kalibScene.clearModel();
  if (document.getElementById('kalib-glb')) document.getElementById('kalib-glb').value = '';
  const status = document.getElementById('kalib-status');
  if (status) status.textContent = 'GLB išvalytas';
}

function kalibSave() {
  const glb   = (document.getElementById('kalib-glb')?.value||'').trim();
  const scale = parseFloat(document.getElementById('kalib-scale')?.value||1);
  const rot   = parseFloat(document.getElementById('kalib-rot')?.value||0);
  const off   = parseFloat(document.getElementById('kalib-off')?.value||0);
  const s3d = {
    glb, scale, rotation_y: rot, offset_y: off,
    socket_in:  {x: parseFloat(document.getElementById('kalib-in-x')?.value||0),
                 y: parseFloat(document.getElementById('kalib-in-y')?.value||0),
                 z: parseFloat(document.getElementById('kalib-in-z')?.value||0)},
    socket_out: {x: parseFloat(document.getElementById('kalib-out-x')?.value||0),
                 y: parseFloat(document.getElementById('kalib-out-y')?.value||0),
                 z: parseFloat(document.getElementById('kalib-out-z')?.value||0)},
  };

  apiPost('save_scene_3d', {tipas: curObj, scene_3d: s3d}).then(d => {
    if (d && d.ok) {
      if (KB.objects[curObj]) KB.objects[curObj].scene_3d = s3d;
      toast('scene_3d išsaugota ✓');
    } else {
      toast('⚠ Klaida išsaugant');
    }
  });
}


function addErr() { KB.objects[curObj].exploitation_errors.push({klaida:'',pasekme:'',trukme:'',prevencija:''}); renderKTab(); }
function rmErr(i) { KB.objects[curObj].exploitation_errors.splice(i,1); markDirty('obj_'+curObj); renderKTab(); }
function setET(i,val) { const el=document.querySelector(`.er-t[data-i="${i}"]`); if(el)el.value=val; }
function setFD(sel,fid,val) { const el=document.querySelector(`${sel}[data-f="${fid}"]`); if(el)el.value=val; }

function saveKTab() {
  const kb=KB.objects[curObj]; if(!kb) return;
  if(curKTab==='base') {
    const newName=v('f_name'); if(newName){kb.name=newName;KB.objects_meta[curObj].name=newName;}
    kb.function=v('f_func'); kb.normal_operation=v('f_norm');
    kb.normal_signs=getTagsFrom('base-signs');
    if(!kb.meta) kb.meta={};
    kb.meta.confidence=parseInt(v('f_conf'))||0;
    kb.meta.sources=v('f_src').split(',').map(s=>s.trim()).filter(Boolean);
    kb.meta.reviewed=v('f_rev')==='true';
    kb.meta.updated=new Date().toISOString();
    kb.meta.version=(kb.meta.version||1)+1;
    kb.tags=getTagsFrom('base-tags');
    kb.models=readObjModels();
    kb.maintenance_schedule={
      interval_months: parseInt(v('f_maint_interval'))||6,
      tasks: getTagsFrom('base-maint')
    };
  } else if(curKTab==='env') {
    kb.env_behavior={
      gvl:{gvl1:v('fenv_gvl1'),gvl2:v('fenv_gvl2'),gvl3:v('fenv_gvl3')},
      soil:{smel:v('fenv_smel'),mol:v('fenv_mol')},
      age_effects:v('fenv_age'), reljefas:v('fenv_rel')
    };
  } else if(curKTab==='packages') {
    savePackages();
  } else if(curKTab==='errors') {
    kb.exploitation_errors=(kb.exploitation_errors||[]).map((_,i)=>({
      klaida:fvI('.er-k',i), pasekme:fvI('.er-p',i), trukme:fvI('.er-t',i), prevencija:fvI('.er-pr',i)
    }));
  }
  kb.meta=kb.meta||{};
  kb.meta.updated=new Date().toISOString();
  updateCounts(); renderObjList(); updateJson();
}

function saveKTabAndSync() {
  saveKTab();
  if(curComp) markDirty('comp_'+curComp); else markDirty('obj_'+curObj);
  flushDirty();
}

function saveFailAndSync(fid) {
  saveFail(fid);
  const _id = _curId();
  if(curComp) {
    
    markDirty('comp_'+_id);
  } else {
    markDirty('fail_'+_id+'_'+fid);
    markDirty('obj_'+_id);
  }
  flushDirty();
}

function getAllFailOptions(excludeFid) {
  const grouped = {};
  Object.entries(KB.objects||{}).forEach(function(e1) {
    var oid = e1[0];
    var oname = KB.objects_meta[oid]&&KB.objects_meta[oid].name || oid;
    Object.entries(e1[1].failure_modes||{}).forEach(function(e2) {
      if(e2[0]===excludeFid || !e2[1].name) return;
      if(!grouped[oid]) grouped[oid]={label:oname, opts:[]};
      var s={low:'●',med:'●●',high:'●●●',critical:'!!!'}[e2[1].severity]||'';
      grouped[oid].opts.push({id:e2[0], name:(s?s+' ':'')+e2[1].name});
    });
  });
  return grouped;
}

function renderScenarios(fid, list) {
  if(!list||!list.length) return `<div style="text-align:center;padding:16px;color:var(--td);font-size:11px">Nėra situacijų. Spusk "+ Situacija"</div>`;
  const failOpts=getAllFailOptions(fid);
  return `
    <table style="width:100%;border-collapse:collapse;font-size:11px">
      <thead>
        <tr style="background:var(--s2)">
          <th style="padding:6px 8px;text-align:left;color:var(--td);font-weight:600;width:38%">Požymis</th>
          <th style="padding:6px 8px;text-align:left;color:var(--td);font-weight:600;width:34%">Sprendimas</th>
          <th style="padding:6px 8px;text-align:left;color:var(--td);font-weight:600;width:10%">Tikimybė</th>
          <th style="padding:6px 8px;text-align:left;color:var(--td);font-weight:600;width:14%">Sukelia</th>
          <th style="width:4%"></th>
        </tr>
      </thead>
      <tbody>
        ${list.map((c,i)=>`
        <tr style="border-bottom:1px solid var(--b1)">
          <td style="padding:6px">
            <input type="text" class="scen-if" data-f="${fid}" data-i="${i}"
              value="${e(c.name||'')}"
              placeholder="pvz. ūžia bet nesiurbia"
              style="width:100%;font-size:11px;border:none;background:transparent;border-bottom:1px solid var(--b1)"
              onblur="autoSaveScenarios('${fid}')">
          </td>
          <td style="padding:6px">
            <input type="text" class="scen-then" data-f="${fid}" data-i="${i}"
              value="${e(c.fix||'')}"
              placeholder="pvz. valyti smulkintuną"
              style="width:100%;font-size:11px;border:none;background:transparent;border-bottom:1px solid #2e7d3240"
              onblur="autoSaveScenarios('${fid}')">
          </td>
          <td style="padding:6px">
            <input type="number" class="scen-pct" data-f="${fid}" data-i="${i}"
              value="${c.pct!=null?c.pct:''}"
              placeholder="%" min="0" max="100"
              style="width:100%;font-size:11px;border:none;background:transparent;border-bottom:1px solid #1565c040;text-align:center"
              onblur="autoSaveScenarios('${fid}')">
          </td>
          <td style="padding:6px">
            ${Object.keys(failOpts).length ? `
            <select class="scen-leads" data-f="${fid}" data-i="${i}"
              onchange="autoSaveScenarios('${fid}')"
              style="font-size:10px;width:100%;border:none;background:transparent;color:#c62828">
              <option value="">–</option>
              ${Object.entries(failOpts).map(([oid,g])=>
                '<optgroup label="'+e(g.label)+'">' +
                g.opts.map(o=>'<option value="'+o.id+'" '+((c.leads_to||[]).includes(o.id)?'selected':'')+'>'+o.name+'</option>').join('') +
                '</optgroup>'
              ).join('')}
            </select>` : `<span style="font-size:9px;color:var(--td)">–</span>`}
          </td>
          <td style="padding:4px;text-align:center">
            <button class="rm" onclick="rmScenario('${fid}',${i})">×</button>
          </td>
        </tr>`).join('')}
      </tbody>
    </table>`;
}

function addScenario(fid) {
  const fm=_curKB()?.failure_modes?.[fid]; if(!fm) return;
  if(!fm.causes) fm.causes={list:[]};
  fm.causes.list=readScenarios(fid);
  fm.causes.list.push({name:'', fix:'', pct:null, leads_to:[]});
  document.getElementById('scenarios-'+fid).innerHTML=renderScenarios(fid, fm.causes.list);
  setTimeout(()=>{
    const inputs=document.querySelectorAll(`.scen-if[data-f="${fid}"]`);
    if(inputs.length) inputs[inputs.length-1].focus();
  },30);
}

function rmScenario(fid, i) {
  const fm=_curKB()?.failure_modes?.[fid]; if(!fm) return;
  fm.causes.list=readScenarios(fid);
  fm.causes.list.splice(i,1);
  document.getElementById('scenarios-'+fid).innerHTML=renderScenarios(fid, fm.causes.list);
}

function readScenarios(fid) {
  const list=[];
  document.querySelectorAll(`.scen-if[data-f="${fid}"]`).forEach((el,i)=>{
    const fix=document.querySelector(`.scen-then[data-f="${fid}"][data-i="${i}"]`)?.value.trim()||'';
    const pctEl=document.querySelector(`.scen-pct[data-f="${fid}"][data-i="${i}"]`);
    const pct=pctEl?.value!==''&&pctEl?.value!=null ? parseInt(pctEl.value) : null;
    const leadsSel=document.querySelector(`.scen-leads[data-f="${fid}"][data-i="${i}"]`);
    const leads=leadsSel?.value ? [leadsSel.value] : [];
    const ifText=el.value.trim();
    if(ifText||fix) list.push({name:ifText, signs:[ifText].filter(Boolean), fix, pct, leads_to:leads});
  });
  return list;
}

function autoSaveScenarios(fid) {
  const fm=_curKB()?.failure_modes?.[fid]; if(!fm) return;
  if(!fm.causes) fm.causes={list:[]};
  fm.causes.list=readScenarios(fid);
}

function genAndShowTree(fid) {
  const fm=_curKB()?.failure_modes?.[fid]; if(!fm) return;
  fm.causes={list:readScenarios(fid)};
  const list=(fm.causes.list||[]).filter(c=>c.name||c.fix);
  if(!list.length){ toast('Pirmiausia užpildyk bent vieną situaciją'); return; }

  let uid=0;
  const mkN=(type,text)=>({id:'n'+(uid++),type,text,branches:[],children:[],note:''});

  function buildNode(ci) {
    if(ci>=list.length) return null;
    const c=list[ci];
    const next=buildNode(ci+1);
    
    const qText=c.question || ('Ar '+((c.name||'').toLowerCase())+'?');
    const leadsText=c.leads_to?.length ? '\n→ Tikrinti: '+c.leads_to.map(lid=>{
      let name=lid;
      Object.values(KB.objects||{}).forEach(obj=>{
        if(obj.failure_modes?.[lid]?.name) name=obj.failure_modes[lid].name;
      });
      return name;
    }).join(', ') : '';
    const fixNode=mkN('sprendimas','✅ '+(c.fix||c.name)+leadsText);
    const node=mkN('klausimas', qText);
    node.branches=['TAIP','NE'];
    node.children=[fixNode, next||mkN('sprendimas','✅ Visos situacijos patikrintos')];
    return node;
  }

  const root=mkN('start', fm.name||fid);
  const first=buildNode(0);
  root.children=first?[first]:[];
  KB.decision_trees[fid]={id:fid, object_id:curObj, failure_id:fid, root};

  const treeEl=document.getElementById('inline-tree-'+fid);
  const renderEl=document.getElementById('inline-tree-render-'+fid);
  if(!treeEl||!renderEl) return;
  treeEl.style.display='block';
  renderEl.innerHTML='';
  const wrap=document.createElement('div');
  wrap.style.cssText='display:inline-flex;flex-direction:column;align-items:center;padding:8px 16px 24px';
  renderEl.style.textAlign='center';
  renderEl.appendChild(wrap);
  if(typeof drawNode==='function') drawNode(root, fid, wrap, null, 0);
  markDirty('tree_'+curObj+'_'+fid);
  toast('🌿 Medis sugeneruotas iš '+list.length+' situacijų');
}

function renderCompModels(models, cid) {
  if(!models||!models.length) return `<div style="font-size:11px;color:var(--td);padding:4px 0">Nėra modelių. Spusk „＋ Modelis".</div>`;
  return `<table style="width:100%;border-collapse:collapse;font-size:11px">
    <thead><tr style="background:var(--s2)">
      <th style="padding:5px 6px;text-align:left;color:var(--td)">ID</th>
      <th style="padding:5px 6px;text-align:left;color:var(--td)">Pavadinimas</th>
      <th style="padding:5px 6px;text-align:center;color:var(--td)">Kaina €</th>
      <th style="padding:5px 6px;text-align:left;color:var(--td)">Tiekėjas</th>
      <th style="width:28px"></th>
    </tr></thead><tbody>
    ${models.map((m,i)=>`<tr style="border-bottom:1px solid var(--b1)">
      <td style="padding:4px 6px"><input type="text" class="cm-id" data-c="${cid}" data-i="${i}" value="${e(m.id||'')}" placeholder="A" style="width:55px;font-weight:700;font-size:11px;font-family:'JetBrains Mono',monospace"></td>
      <td style="padding:4px 6px"><input type="text" class="cm-name" data-c="${cid}" data-i="${i}" value="${e(m.name||'')}" placeholder="Standartinis" style="width:100%;font-size:11px"></td>
      <td style="padding:4px 6px;text-align:center"><input type="number" class="cm-price" data-c="${cid}" data-i="${i}" value="${m.price_eur||0}" min="0" step="5" style="width:65px;text-align:center;font-weight:700;color:#2e7d32"></td>
      <td style="padding:4px 6px"><input type="text" class="cm-supplier" data-c="${cid}" data-i="${i}" value="${e(m.supplier||'')}" placeholder="pvz. Grundfos" style="width:100%;font-size:11px"></td>
      <td style="padding:4px;text-align:center"><button class="rm" onclick="rmCompModel('${cid}',${i})">×</button></td>
    </tr>`).join('')}
    </tbody></table>`;
}

function addCompModel(cid) {
  const comp=KB.components[cid]; if(!comp) return;
  if(!comp.models) comp.models=[];
  comp.models=readCompModels(cid);
  comp.models.push({id:String.fromCharCode(65+(comp.models.length%26)), name:'', price_eur:0, supplier:''});
  const el=document.getElementById('comp-models-'+cid);
  if(el) el.innerHTML=renderCompModels(comp.models, cid);
}

function rmCompModel(cid, i) {
  const comp=KB.components[cid]; if(!comp) return;
  comp.models=readCompModels(cid);
  comp.models.splice(i,1);
  const el=document.getElementById('comp-models-'+cid);
  if(el) el.innerHTML=renderCompModels(comp.models, cid);
}

function readCompModels(cid) {
  const rows=[];
  document.querySelectorAll(`.cm-id[data-c="${cid}"]`).forEach((el,i)=>{
    rows.push({
      id:       el.value.trim(),
      name:     document.querySelector(`.cm-name[data-c="${cid}"][data-i="${i}"]`)?.value.trim()||'',
      price_eur:parseFloat(document.querySelector(`.cm-price[data-c="${cid}"][data-i="${i}"]`)?.value)||0,
      supplier: document.querySelector(`.cm-supplier[data-c="${cid}"][data-i="${i}"]`)?.value.trim()||''
    });
  });
  return rows;
}

function getCompPriceForFailure(failName) {
  let best=null;
  const n=(failName||'').toLowerCase();
  Object.values(KB.components||{}).forEach(comp=>{
    const cn=(comp.name||'').toLowerCase();
    if(!cn||!n) return;
    
    if(n.includes(cn)||cn.includes(n.split(' ')[0])) {
      const p=comp.pricing?.part_price||0;
      const inst=comp.pricing?.install_price||0;
      if(best===null||p<best.part) best={part:p, install:inst, diy:comp.pricing?.diy_possible!==false, name:comp.name, id:comp.id||''};
    }
  });
  return best;
}
