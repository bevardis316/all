async function renderOrders() {
  const wrap = document.getElementById('orders-wrap');
  if (!wrap) return;
  wrap.innerHTML = `<div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Kraunama...</div>`;

  let orders = [];
  try {
    const r = await fetch('api.php?action=load_orders', { credentials: 'include' });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Klaida');
    orders = d.orders || [];
  } catch (e) {
    wrap.innerHTML = `<div style="color:#e53935;padding:20px">⚠ Nepavyko užkrauti: ${e.message}</div>`;
    return;
  }

  const total = orders.length;
  const gauta = orders.filter(o => o.mail_sent).length;

  wrap.innerHTML = `
    <div style="max-width:1100px;margin:0 auto">

      <!-- STAT BAR -->
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:20px;max-width:400px">
        ${_ordStatBox(total, 'Viso užsakymų', 'var(--pri)')}
        ${_ordStatBox(gauta, 'El. paštas išsiųstas', '#2e7d32')}
      </div>

      <!-- FILTRAS -->
      <div style="display:flex;gap:8px;margin-bottom:12px;align-items:center;flex-wrap:wrap">
        <input type="text" id="ord-search" placeholder="Ieškoti pagal vardą, el. paštą, nr..."
               style="max-width:280px" oninput="_ordFilter()">
        <select id="ord-sort" onchange="_ordFilter()" style="width:160px;font-size:11px;padding:5px 8px">
          <option value="desc">Naujausi viršuje</option>
          <option value="asc">Seniausieji viršuje</option>
        </select>
        <span id="ord-count" style="font-size:10px;color:var(--td);margin-left:auto"></span>
      </div>

      <!-- LENTELĖ -->
      <div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);overflow:hidden">
        <div style="display:grid;grid-template-columns:120px 1fr 130px 110px 90px 80px;gap:0;padding:8px 14px;background:var(--s2);border-bottom:1px solid var(--b1);font-size:9px;font-weight:700;color:var(--td);text-transform:uppercase;letter-spacing:.5px">
          <div>Nr.</div><div>Kontaktai</div><div>Data</div><div>Suma</div><div>El.paštas</div><div></div>
        </div>
        <div id="ord-list"></div>
      </div>
    </div>
  `;

  window._ordersData = orders;
  _ordFilter();
}

function _ordStatBox(val, label, col) {
  return `<div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);padding:14px;text-align:center">
    <div style="font-size:26px;font-weight:700;font-family:'JetBrains Mono',monospace;color:${col};line-height:1">${val}</div>
    <div style="font-size:9px;color:var(--td);margin-top:4px;text-transform:uppercase;letter-spacing:.5px">${label}</div>
  </div>`;
}

function _ordFilter() {
  const orders = window._ordersData || [];
  const q = (document.getElementById('ord-search')?.value || '').toLowerCase();
  const sort = document.getElementById('ord-sort')?.value || 'desc';

  let filtered = orders.filter(o => {
    if (!q) return true;
    return (o.id || '').toLowerCase().includes(q)
      || (o.vardas || '').toLowerCase().includes(q)
      || (o.email || '').toLowerCase().includes(q)
      || (o.tel || '').includes(q);
  });

  if (sort === 'asc') filtered = [...filtered].reverse();

  const countEl = document.getElementById('ord-count');
  if (countEl) countEl.textContent = `Rodoma: ${filtered.length} / ${orders.length}`;

  const list = document.getElementById('ord-list');
  if (!list) return;

  if (!filtered.length) {
    list.innerHTML = `<div style="padding:24px;text-align:center;color:var(--td);font-size:12px">Nėra užsakymų pagal šį filtrą</div>`;
    return;
  }

  list.innerHTML = filtered.map((o, i) => {
    const dt = o.ts ? new Date(o.ts).toLocaleString('lt-LT', {dateStyle:'short', timeStyle:'short'}) : '—';
    const suma = o.grand > 0 ? '~' + Math.round(o.grand).toLocaleString('lt') + ' €' : '—';
    const mailBadge = o.mail_sent
      ? `<span style="font-size:9px;padding:2px 6px;background:#e8f5e9;color:#2e7d32;border-radius:20px">✓ išsiųstas</span>`
      : `<span style="font-size:9px;padding:2px 6px;background:#fff3e0;color:#e65100;border-radius:20px">⚠ nepavyko</span>`;
    const priceBadge = o.price_warning
      ? `<span title="Klientas siuntė: ${o.price_warning.klientas}€ | Serveris: ${o.price_warning.serveris}€" style="font-size:9px;padding:2px 6px;background:#fce4ec;color:#c62828;border-radius:20px;cursor:help">⚠ kaina skyrėsi ${o.price_warning.skirtumas_pct}%</span>`
      : '';

    return `
      <div style="display:grid;grid-template-columns:120px 1fr 130px 110px 90px 80px;gap:0;padding:9px 14px;border-bottom:1px solid var(--b1);font-size:11px;align-items:center${i % 2 === 1 ? ';background:var(--s2)' : ''}">
        <div style="font-family:'JetBrains Mono',monospace;font-size:10px;color:var(--pri);font-weight:700">${e(o.id||'')}</div>
        <div>
          <div style="font-weight:600">${e(o.vardas||'')}</div>
          <div style="font-size:10px;color:var(--td)">${e(o.email||'')}${o.tel ? (o.email ? ' · ' : '') + e(o.tel) : ''}</div>
          ${o.zinute ? `<div style="font-size:9px;color:var(--td);margin-top:2px;font-style:italic">${e(o.zinute.slice(0,60))}${o.zinute.length>60?'…':''}</div>` : ''}
        </div>
        <div style="font-size:10px;color:var(--td)">${dt}</div>
        <div style="font-weight:700;color:#1565c0">${suma}</div>
        <div style="display:flex;flex-direction:column;gap:3px">${mailBadge}${priceBadge}</div>
        <div><button class="btn ghost sm" style="font-size:9px" onclick="_ordDetail(${i})">Detalės →</button></div>
      </div>
    `;
  }).join('');

  window._ordersFiltered = filtered;
}

function _ordDetail(idx) {
  const orders = window._ordersFiltered || window._ordersData || [];
  const o = orders[idx];
  if (!o) return;

  const dt = o.ts ? new Date(o.ts).toLocaleString('lt-LT', {dateStyle:'long', timeStyle:'short'}) : '—';
  const suma = o.grand > 0 ? '~' + Math.round(o.grand).toLocaleString('lt') + ' €' : 'nenurodytas';

  openModal(`Užsakymas ${o.id}`, `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
      <div><div style="font-size:9px;color:var(--td);text-transform:uppercase;margin-bottom:2px">Vardas</div><div style="font-weight:600">${e(o.vardas||'—')}</div></div>
      <div><div style="font-size:9px;color:var(--td);text-transform:uppercase;margin-bottom:2px">Data</div><div>${dt}</div></div>
      <div><div style="font-size:9px;color:var(--td);text-transform:uppercase;margin-bottom:2px">El. paštas</div><div>${e(o.email||'—')}</div></div>
      <div><div style="font-size:9px;color:var(--td);text-transform:uppercase;margin-bottom:2px">Telefonas</div><div>${e(o.tel||'—')}</div></div>
      <div style="grid-column:span 2"><div style="font-size:9px;color:var(--td);text-transform:uppercase;margin-bottom:2px">El. paštas išsiųstas</div><div>${o.mail_sent ? '✅ Taip' : '❌ Nepavyko'}</div></div>
    </div>
    ${o.zinute ? `<div style="margin-bottom:10px"><div style="font-size:9px;color:var(--td);text-transform:uppercase;margin-bottom:4px">Žinutė</div><div style="background:var(--s2);padding:8px 10px;border-radius:var(--r);font-size:11px">${e(o.zinute)}</div></div>` : ''}
    <div style="font-size:9px;color:var(--td);text-transform:uppercase;margin-bottom:6px">Pirkimo sąrašas</div>
    <div style="background:var(--s2);border:1px solid var(--b1);border-radius:var(--r);padding:10px 14px;font-size:11px;max-height:200px;overflow-y:auto">
      ${o.saraso_html || '<span style="color:var(--td)">Sąrašas neišsaugotas email siuntimo metu</span>'}
    </div>
    ${o.price_warning ? `<div style="margin-top:8px;padding:8px 10px;background:#fce4ec;border-radius:var(--r);font-size:10px;color:#c62828">
      ⚠ <b>Kainų neatitikimas:</b> klientas siuntė <b>${o.price_warning.klientas} €</b>, serveris perskaičiavo <b>${o.price_warning.serveris} €</b> (skirtumas ${o.price_warning.skirtumas_pct}%). Užsakyme naudota serverio suma.
    </div>` : ''}
    <div style="font-size:9px;color:var(--td);margin-top:8px">IP: ${e(o.ip||'—')} · Failas: ${e(o.id||'')}.json</div>
  `, null);
}

let _pricesData = [];
let _pricesDirty = {};

async function renderPrices() {
  const wrap = document.getElementById('prices-wrap');
  if (!wrap) return;
  wrap.innerHTML = `<div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Kraunama...</div>`;

  try {
    const r = await fetch('api.php?action=load_components', { credentials: 'include' });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Klaida');
    _pricesData = d.components || [];
  } catch (err) {
    wrap.innerHTML = `<div style="color:#e53935;padding:20px">⚠ Nepavyko užkrauti: ${err.message}</div>`;
    return;
  }

  _pricesDirty = {};
  _renderPricesTable();
}

function _renderPricesTable() {
  const wrap = document.getElementById('prices-wrap');
  if (!wrap) return;

  const grouped = {};
  _pricesData.forEach(c => {
    const pid = c.parent_id || 'Kita';
    if (!grouped[pid]) grouped[pid] = [];
    grouped[pid].push(c);
  });

  const hasDirty = Object.keys(_pricesDirty).length > 0;

  wrap.innerHTML = `
    <div style="max-width:1200px;margin:0 auto">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;flex-wrap:wrap">
        <div>
          <div style="font-size:16px;font-weight:700;color:var(--pri)">💰 Komponentų kainos</div>
          <div style="font-size:11px;color:var(--td);margin-top:2px">Inline redagavimas — pakeitimai išsaugomi į /ibnvs_data/components/</div>
        </div>
        <button id="prices-save-btn" class="btn pri" style="margin-left:auto;${hasDirty ? '' : 'opacity:.4;pointer-events:none'}" onclick="_saveAllPrices()">
          💾 Išsaugoti pakeitimus ${hasDirty ? `(${Object.keys(_pricesDirty).length})` : ''}
        </button>
      </div>

      <div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);overflow:hidden">
        <div style="display:grid;grid-template-columns:180px 1fr 90px 90px 60px 90px 70px 80px;gap:0;padding:8px 12px;background:var(--s2);border-bottom:1px solid var(--b1);font-size:9px;font-weight:700;color:var(--td);text-transform:uppercase;letter-spacing:.5px">
          <div>Komponentas</div><div>Grupė</div>
          <div style="text-align:right">Dalis (€)</div>
          <div style="text-align:right">Montavimas (€)</div>
          <div style="text-align:center">Kiekis</div>
          <div style="text-align:center">Garantija (mėn.)</div>
          <div style="text-align:center">DIY</div>
          <div style="text-align:center" title="Ar rodyti sąskaitoje kaip atskirą eilutę">Sąskaita</div>
        </div>
        ${Object.entries(grouped).map(([gid, comps]) => `
          <div style="padding:6px 12px;background:var(--s3);border-bottom:1px solid var(--b1);font-size:9px;font-weight:700;color:var(--pri);text-transform:uppercase;letter-spacing:.7px">
            📦 ${e(gid)} <span style="font-weight:400;color:var(--td)">(${comps.length})</span>
          </div>
          ${comps.map((c, i) => _priceRow(c, i)).join('')}
        `).join('')}
      </div>

      <div style="margin-top:10px;font-size:10px;color:var(--td);text-align:right">
        Viso komponentų: ${_pricesData.length} · Redaguok langelius ir spaus "Išsaugoti"
      </div>
    </div>
  `;
}

function _priceRow(c, i) {
  const p = c.pricing || {};
  const isDirty = !!_pricesDirty[c.id];
  const rowBg = isDirty ? 'background:#fff8e1;' : (i % 2 === 1 ? 'background:var(--s2);' : '');

  return `
    <div id="prow-${e(c.id)}" style="display:grid;grid-template-columns:180px 1fr 90px 90px 60px 90px 70px;gap:0;padding:6px 12px;border-bottom:1px solid var(--b1);font-size:11px;align-items:center;${rowBg}">
      <div style="font-weight:600;font-size:10px">${e(c.name)}<br><span style="font-family:'JetBrains Mono',monospace;font-size:9px;color:var(--td)">${e(c.id)}</span></div>
      <div style="font-size:10px;color:var(--td)">${e(c.parent_id||'')}</div>
      <div style="text-align:right">
        <input type="number" min="0" step="0.01" value="${p.part_price||0}"
          style="width:76px;text-align:right;font-family:'JetBrains Mono',monospace"
          data-comp="${e(c.id)}" data-field="part_price" onchange="_priceChange(this)">
      </div>
      <div style="text-align:right">
        <input type="number" min="0" step="0.01" value="${p.install_price||0}"
          style="width:76px;text-align:right;font-family:'JetBrains Mono',monospace"
          data-comp="${e(c.id)}" data-field="install_price" onchange="_priceChange(this)">
      </div>
      <div style="text-align:center">
        <input type="number" min="1" step="1" value="${p.quantity_per_system||1}"
          style="width:48px;text-align:center;font-family:'JetBrains Mono',monospace"
          data-comp="${e(c.id)}" data-field="quantity_per_system" onchange="_priceChange(this)">
      </div>
      <div style="text-align:center">
        <input type="number" min="0" step="1" value="${p.guarantee_months||12}"
          style="width:60px;text-align:center;font-family:'JetBrains Mono',monospace"
          data-comp="${e(c.id)}" data-field="guarantee_months" onchange="_priceChange(this)">
      </div>
      <div style="text-align:center">
        <input type="checkbox" ${p.diy_possible ? 'checked' : ''}
          data-comp="${e(c.id)}" data-field="diy_possible" onchange="_priceChange(this)"
          style="width:16px;height:16px;cursor:pointer">
      </div>
      <div style="text-align:center">
        <select data-comp="${e(c.id)}" data-field="in_package" onchange="_priceChange(this)"
          style="font-size:10px;padding:3px 5px;border:1px solid var(--b1);border-radius:var(--r);background:var(--bg);color:var(--text);width:76px">
          <option value="null" ${c.in_package === null || c.in_package === undefined ? 'selected' : ''}>Auto</option>
          <option value="true" ${c.in_package === true ? 'selected' : ''}>✓ Slepiame</option>
          <option value="false" ${c.in_package === false ? 'selected' : ''}>● Rodome</option>
        </select>
      </div>
    </div>
  `;
}

function _priceChange(el) {
  const compId = el.dataset.comp;
  const field  = el.dataset.field;
  const comp   = _pricesData.find(c => c.id === compId);
  if (!comp) return;

  if (!comp.pricing) comp.pricing = {};

  if (field === 'in_package') {
    const v = el.value;
    comp.in_package = (v === 'null') ? null : (v === 'true');
    _pricesDirty[compId] = true;
    const row = document.getElementById('prow-' + compId);
    if (row) row.style.background = '#fff8e1';
    const btn = document.getElementById('prices-save-btn');
    if (btn) { btn.style.opacity = '1'; btn.style.pointerEvents = 'auto'; btn.textContent = `💾 Išsaugoti pakeitimus (${Object.keys(_pricesDirty).length})`; }
    return;
  }
  if (field === 'diy_possible') {
    comp.pricing[field] = el.checked;
  } else if (field === 'quantity_per_system' || field === 'guarantee_months') {
    comp.pricing[field] = parseInt(el.value) || 1;
  } else {
    comp.pricing[field] = parseFloat(el.value) || 0;
  }

  _pricesDirty[compId] = true;

  const row = document.getElementById('prow-' + compId);
  if (row) row.style.background = '#fff8e1';

  const btn = document.getElementById('prices-save-btn');
  if (btn) {
    btn.style.opacity = '1';
    btn.style.pointerEvents = 'auto';
    btn.textContent = `💾 Išsaugoti pakeitimus (${Object.keys(_pricesDirty).length})`;
  }
}

async function _saveAllPrices() {
  const dirtyIds = Object.keys(_pricesDirty);
  if (!dirtyIds.length) return;

  const btn = document.getElementById('prices-save-btn');
  if (btn) { btn.textContent = '⏳ Saugojama...'; btn.style.opacity = '.6'; btn.style.pointerEvents = 'none'; }

  let ok = 0, fail = 0;
  for (const compId of dirtyIds) {
    const comp = _pricesData.find(c => c.id === compId);
    if (!comp) continue;
    try {
      const r = await fetch('api.php?action=save_component_pricing', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          parent_id:  comp.parent_id,
          comp_id:    comp.id,
          pricing:    comp.pricing,
          models:     comp.models || [],
          in_package: comp.in_package !== undefined ? comp.in_package : null,
        })
      });
      const d = await r.json();
      if (d.ok) {
        ok++;
        delete _pricesDirty[compId];
        const row = document.getElementById('prow-' + compId);
        if (row) row.style.background = '#e8f5e9';
        setTimeout(() => {
          const r2 = document.getElementById('prow-' + compId);
          if (r2) r2.style.background = '';
        }, 2000);
      } else {
        fail++;
        console.error('Klaida:', compId, d.error);
      }
    } catch (err) {
      fail++;
      console.error('Fetch klaida:', compId, err);
    }
  }

  if (btn) {
    if (fail === 0) {
      btn.textContent = `✅ Išsaugota (${ok})`;
      btn.style.opacity = '.4';
      btn.style.pointerEvents = 'none';
      setTimeout(() => { if(btn) { btn.textContent = '💾 Išsaugoti pakeitimus'; } }, 3000);
    } else {
      btn.textContent = `⚠ ${ok} ok, ${fail} klaida`;
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'auto';
    }
  }

  toast(fail === 0 ? `✓ Išsaugota ${ok} komponentų` : `⚠ ${ok} ok, ${fail} klaida`);
}
