function getTagFrequency() {
  const freq={};
  const bump=(t,n=1)=>{if(t)freq[t]=(freq[t]||0)+n;};
  Object.values(KB.objects).forEach(kb=>{
    (kb.tags||[]).forEach(t=>bump(t,2));
    Object.values(kb.failure_modes||{}).forEach(fm=>{
      (fm.symptoms||[]).forEach(t=>bump(t,3));
      (fm.tags||[]).forEach(t=>bump(t,2));
    });
  });
  (KB.tag_relations||[]).forEach(r=>{bump(r.from,1);bump(r.to,1);});
  return freq;
}

function sortByFreq(tags,freq) { return [...tags].sort((a,b)=>(freq[b]||0)-(freq[a]||0)); }

function getAllKnownTags() {
  const all=new Set();
  Object.values(KB.tag_categories||{}).forEach(cat=>(cat.tags||[]).forEach(t=>all.add(t)));
  Object.values(KB.objects).forEach(kb=>{
    (kb.tags||[]).forEach(t=>all.add(t));
    Object.values(kb.failure_modes||{}).forEach(fm=>{
      (fm.symptoms||[]).forEach(t=>all.add(t));
      (fm.tags||[]).forEach(t=>all.add(t));
    });
  });
  return [...all].filter(Boolean);
}

function getAllSyms() {
  const syms=new Set();
  Object.values(KB.objects).forEach(kb=>Object.values(kb.failure_modes||{}).forEach(fm=>(fm.symptoms||[]).forEach(s=>syms.add(s))));
  const cat=KB.tag_categories?.['Simptomai'];
  if(cat) cat.tags.forEach(t=>syms.add(t));
  return [...syms];
}

function renderTagPanel(pid, selTags=[], compact=false) {
  const freq=getTagFrequency();
  const allTags=getAllKnownTags();
  const topTags=sortByFreq(allTags,freq).slice(0,16);
  const allCats=KB.tag_categories||{};

  const catsHtml=[
    topTags.length ? `<div class="tag-cat" style="border-left:3px solid #e65100">
      <div class="tag-cat-lbl">⭐ Dažni</div>
      <div class="tag-opts">${topTags.map(t=>`<div class="topt ${selTags.includes(t)?'sel':''}" onclick="tagToggle('${pid}','${e(t)}')">${e(t)}</div>`).join('')}</div>
    </div>` : '',
    ...Object.entries(allCats).map(([cat,d])=>`
      <div class="tag-cat" style="border-left:3px solid ${d.color||'#ccc'}">
        <div class="tag-cat-lbl" style="color:${d.color}">${cat}</div>
        <div class="tag-opts">${sortByFreq(d.tags||[],freq).map(t=>`<div class="topt ${selTags.includes(t)?'sel':''}" onclick="tagToggle('${pid}','${e(t)}')">${e(t)}</div>`).join('')}</div>
      </div>`)
  ].filter(Boolean);

  return `<div class="tag-panel" id="${pid}">
    <div class="tag-cats">${catsHtml.join('')}</div>
    <div class="tag-selected">${renderChipsHtml(selTags,pid)}</div>
    <input class="tag-inp" placeholder="arba rašyk patį ir Enter…" onkeydown="tagInpKey(event,'${pid}')">
  </div>`;
}

function renderChipsHtml(tags,pid) {
  return tags.map(t=>`<div class="tchip">${e(t)}<span class="x" onclick="tagRemove('${pid}','${e(t)}')">×</span></div>`).join('');
}

function renderChips(pid,tags) {
  const el=document.getElementById(pid); if(!el) return;
  const sc=el.querySelector('.tag-selected');
  if(sc) sc.innerHTML=renderChipsHtml(tags,pid);
  el._tags=tags;
  el.querySelectorAll('.topt').forEach(o=>{
    o.classList.toggle('sel',(tags||[]).includes(o.textContent.trim()));
  });
}

function tagToggle(pid,tag) {
  const el=document.getElementById(pid); if(!el) return;
  if(!el._tags) el._tags=[...el.querySelectorAll('.tchip')].map(c=>c.firstChild?.textContent?.trim()).filter(Boolean);
  if(el._tags.includes(tag)) el._tags=el._tags.filter(t=>t!==tag);
  else el._tags.push(tag);
  renderChips(pid,el._tags);
}

function tagRemove(pid,tag) { tagToggle(pid,tag); }

function tagInpKey(ev,pid) {
  if(ev.key==='Enter'||ev.key===',') {
    ev.preventDefault();
    const val=ev.target.value.trim().replace(/,$/,'');
    if(val) { tagToggle(pid,val); ev.target.value=''; }
  }
}

function getTagsFrom(pid) {
  const el=document.getElementById(pid); if(!el) return [];
  if(el._tags) return el._tags;
  return [...el.querySelectorAll('.tchip')].map(c=>c.firstChild?.textContent?.trim()).filter(Boolean);
}

function learnTagsFromKB() {
  
  const syms=new Set();
  Object.values(KB.objects).forEach(kb=>Object.values(kb.failure_modes||{}).forEach(fm=>(fm.symptoms||[]).forEach(s=>{if(s)syms.add(s);})));
  if(syms.size&&!KB.tag_categories['Simptomai (iš KB)']) KB.tag_categories['Simptomai (iš KB)']={color:'#c62828',tags:[...syms]};
}

function learnSymRelations() { return 0; } 

function renderPct() {
  const el=document.getElementById('pct-content'); if(!el) return;
  let html='';
  Object.keys(KB.objects_meta).forEach(oid=>{
    const kb=KB.objects[oid];
    const fms=Object.values(kb?.failure_modes||{}).filter(f=>f.name);
    if(!fms.length) return;
    if(!KB.percentages[oid]) KB.percentages[oid]={};
    fms.forEach(fm=>{if(!KB.percentages[oid][fm.id]) KB.percentages[oid][fm.id]={base:Math.round(100/fms.length),gvl1:1.0,gvl2:1.0,smel:1.0,mol:1.0,old:1.0};});
    const total=fms.reduce((s,fm)=>s+(parseFloat(KB.percentages[oid][fm.id]?.base)||0),0);
    const okColor=Math.abs(total-100)<1?'var(--pri)':total>105?'var(--red)':'var(--warn)';
    html+=`<div class="pct-obj-card">
      <div class="pct-obj-h">
        <span class="pct-obj-id">${oid}</span>
        <span style="font-size:11px;color:var(--td)">${KB.objects_meta[oid].name}</span>
        <span class="pct-total">Suma: <b style="color:${okColor}">${total.toFixed(1)}%</b> ${Math.abs(total-100)<1?'✓':total>100?'(per daug)':'(per mažai)'}</span>
      </div>
      <div style="background:var(--bg);border-radius:20px;height:6px;overflow:hidden;margin-bottom:12px">
        <div style="height:100%;width:${Math.min(total,120)}%;background:${okColor};border-radius:20px;transition:width .3s"></div>
      </div>
      <div style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr 1fr 1fr;gap:4px;padding:4px 0;border-bottom:1px solid var(--b1);font-size:9px;font-weight:700;color:var(--td);text-align:center;margin-bottom:6px">
        <div style="text-align:left">Gedimas</div>
        <div title="Bazinė tikimybė – %">Bazė %</div>
        <div title="GVL aukštas">🌊↑</div>
        <div title="GVL žemas">💧↓</div>
        <div title="Smėlio gruntas">🟡</div>
        <div title="Molio gruntas">🟤</div>
        <div title="Senas 7m+">⏳</div>
      </div>
      ${fms.map(fm=>{
        const pct=KB.percentages[oid][fm.id]||{base:0};
        const sCol={low:'#4caf50',med:'#ff9800',high:'#f44336',critical:'#e91e63'}[fm.severity]||'#aaa';
        const base=parseFloat(pct.base)||0;
        const envVals=[['gvl1',pct.gvl1||1],['gvl2',pct.gvl2||1],['smel',pct.smel||1],['mol',pct.mol||1],['old',pct.old||1]];
        return `<div style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr 1fr 1fr;gap:4px;align-items:center;padding:5px 0;border-bottom:1px solid var(--b1)">
          <div style="display:flex;align-items:center;gap:5px">
            <div style="width:8px;height:8px;border-radius:50%;background:${sCol};flex-shrink:0"></div>
            <div style="font-size:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${fm.id}">${fm.name||fm.id}</div>
          </div>
          <div style="text-align:center">
            <input type="number" style="width:52px;text-align:center;font-weight:700;font-size:13px;border:1px solid var(--b1);border-radius:4px;padding:2px"
              value="${base}" min="0" max="100" step="1"
              oninput="updPct('${oid}','${fm.id}',this.value)">
          </div>
          ${envVals.map(([k,val])=>{
            const col=val>1.2?'#c62828':val<0.8?'#2e7d32':'#888';
            return `<div style="text-align:center">
              <input type="number" step="0.1" min="0.1" max="10" value="${val}"
                style="width:44px;text-align:center;font-weight:700;font-size:11px;color:${col};border:1px solid ${val!==1?col+'44':'var(--b1)'};border-radius:4px;padding:2px"
                oninput="updPctEnv('${oid}','${fm.id}','${k}',this.value)">
            </div>`;
          }).join('')}
        </div>`;
      }).join('')}
    </div>`;
  });
  el.innerHTML=html||`<div style="text-align:center;padding:40px;color:var(--td)">Nėra gedimų su pavadinimais.</div>`;
}

function updPct(oid,fid,val) {
  if(!KB.percentages[oid]) KB.percentages[oid]={};
  if(!KB.percentages[oid][fid]) KB.percentages[oid][fid]={};
  KB.percentages[oid][fid].base=parseFloat(val)||0;
  markDirty('pct_'+oid);
  renderPct();
}

function updPctEnv(oid,fid,k,val) {
  if(!KB.percentages[oid]) KB.percentages[oid]={};
  if(!KB.percentages[oid][fid]) KB.percentages[oid][fid]={base:0};
  KB.percentages[oid][fid][k]=parseFloat(val)||1.0;
  if(KB.objects[oid]?.failure_modes[fid]) {
    if(!KB.objects[oid].failure_modes[fid].env_modifiers) KB.objects[oid].failure_modes[fid].env_modifiers={};
    KB.objects[oid].failure_modes[fid].env_modifiers[k]={prob_mult:String(val)};
  }
  markDirty('pct_'+oid);
}

function normalizePct() {
  Object.keys(KB.objects_meta).forEach(oid=>{
    const kb=KB.objects[oid];
    const fms=Object.values(kb?.failure_modes||{}).filter(f=>f.name);
    if(!fms.length) return;
    if(!KB.percentages[oid]) KB.percentages[oid]={};
    const total=fms.reduce((s,fm)=>s+(parseFloat(KB.percentages[oid][fm.id]?.base)||0),0);
    if(total===0||Math.abs(total-100)<0.5) return;
    const factor=100/total;
    fms.forEach(fm=>{
      if(!KB.percentages[oid][fm.id]) KB.percentages[oid][fm.id]={base:0};
      KB.percentages[oid][fm.id].base=Math.round(KB.percentages[oid][fm.id].base*factor*10)/10;
    });
  });
  renderPct(); toast('Normalizuota ✓');
}
