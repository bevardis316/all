const TREL_TYPES = {
  'P→G':    {lbl:'Priežastis → Gedimas',     icon:'⏩',col:'#e65100', desc:'Priežastis sukelia gedimą (su laiko tarpu Δt₁)'},
  'G=Ps':   {lbl:'Gedimas = Pasekmė',         icon:'⚡',col:'#c62828', desc:'Gedimas ir pasekmė vyksta kartu'},
  'Ps→S':   {lbl:'Pasekmė → Simptomas',       icon:'👁',col:'#1565c0', desc:'Pasekmė logiškai veda į simptomą (su laiko tarpu Δt₂)'},
  'S↔G':    {lbl:'Simptomas ↔ Gedimas',       icon:'↔',col:'#2e7d32', desc:'Simptomas ir gedimas susiję abipusiai'},
  'sukelia': {lbl:'Sukelia',                   icon:'→',col:'#880e4f', desc:'A tiesiogiai sukelia B'},
  'sustiprina':{lbl:'Sustiprina',             icon:'↑',col:'#00695c', desc:'A padidina B tikimybę'},
  'paneigia': {lbl:'Paneigia',                icon:'✗',col:'#6a1b9a', desc:'A nesuderinamas su B'},
  'susijęs':  {lbl:'Susijęs',                icon:'↔',col:'#8d6e63', desc:'Bendras ryšys'},
};

function getTrelGroups() {
  // 1. Simptomai - iš symptomų kategorijų
  const symCats = {};
  Object.entries(KB.tag_categories||{}).forEach(([cat, d]) => {
    symCats[cat] = { color: d.color||'#1565c0', tags: d.tags||[] };
  });

  // 2. Gedimai - failure mode ID + pavadinimas
  const failures = [];
  Object.entries(KB.objects||{}).forEach(([oid, kb]) => {
    const meta = KB.objects_meta[oid]||{};
    Object.entries(kb.failure_modes||{}).forEach(([fid, fm]) => {
      if(fm.name) failures.push({ id: fid, label: fm.name, obj: meta.name||oid });
    });
  });

  // 3. Laisvų tagų (objektų tagai, ne simptomai)
  const tagSet = new Set();
  Object.values(KB.objects||{}).forEach(kb => {
    (kb.tags||[]).forEach(t => tagSet.add(t));
    Object.values(kb.failure_modes||{}).forEach(fm => {
      (fm.tags||[]).forEach(t => tagSet.add(t));
    });
  });
  // Remove tags already in symCats
  Object.values(symCats).forEach(c => c.tags.forEach(t => tagSet.delete(t)));

  return { symCats, failures, freeTags: [...tagSet].filter(Boolean) };
}

function renderTrelPicker(panelId, inputId) {
  const el = document.getElementById(panelId);
  if(!el) return;
  const { symCats, failures, freeTags } = getTrelGroups();
  const inp = document.getElementById(inputId);

  function pick(val) {
    if(inp) inp.value = val;
    // Highlight selected
    el.querySelectorAll('.tpick-item').forEach(b => {
      b.classList.toggle('tpick-sel', b.dataset.val === val);
    });
  }

  let html = '';

  // Simptomai grupės
  Object.entries(symCats).forEach(([cat, d]) => {
    if(!d.tags.length) return;
    html += '<div class="tpick-group" style="border-left:3px solid '+d.color+';margin-bottom:6px;padding-left:6px">';
    html += '<div class="tpick-lbl" style="color:'+d.color+';font-size:9px;font-weight:700;text-transform:uppercase;margin-bottom:3px">'+cat+'</div>';
    html += '<div class="tpick-row">';
    d.tags.forEach(t => {
      html += '<button class="tpick-item" data-panel="'+panelId+'" data-inp="'+inputId+'" data-val="'+e(t)+'" onclick="trelPick(this)">'+t+'</button>';
    });
    html += '</div></div>';
  });

  // Gedimai
  if(failures.length) {
    html += '<div class="tpick-group" style="border-left:3px solid #c62828;margin-bottom:6px;padding-left:6px">';
    html += '<div class="tpick-lbl" style="color:#c62828;font-size:9px;font-weight:700;text-transform:uppercase;margin-bottom:3px">Gedimai</div>';
    html += '<div class="tpick-row">';
    failures.forEach(f => {
      const label = f.label + ' <span style="opacity:.5;font-size:9px">['+f.obj+']</span>';
      html += '<button class="tpick-item" data-panel="'+panelId+'" data-inp="'+inputId+'" data-val="'+e(f.id)+'" onclick="trelPick(this)" title="'+f.id+'">'+label+'</button>';
    });
    html += '</div></div>';
  }

  // Laisvi tagai
  if(freeTags.length) {
    html += '<div class="tpick-group" style="border-left:3px solid #888;margin-bottom:6px;padding-left:6px">';
    html += '<div class="tpick-lbl" style="color:#888;font-size:9px;font-weight:700;text-transform:uppercase;margin-bottom:3px">Tagai</div>';
    html += '<div class="tpick-row">';
    freeTags.forEach(t => {
      html += '<button class="tpick-item" data-panel="'+panelId+'" data-inp="'+inputId+'" data-val="'+e(t)+'" onclick="trelPick(this)">'+t+'</button>';
    });
    html += '</div></div>';
  }

  el.innerHTML = html;
}

function trelPick(btn) {
  const panelId = btn.dataset.panel;
  const inputId = btn.dataset.inp;
  const val     = btn.dataset.val;
  const inp = document.getElementById(inputId);
  if(inp) inp.value = val;
  const panel = document.getElementById(panelId);
  if(panel) panel.querySelectorAll('.tpick-item').forEach(b => b.classList.toggle('tpick-sel', b===btn));
}

function renderTrel() {
  const s=(document.getElementById('trel-search')?.value||'').toLowerCase();
  const tf=document.getElementById('trel-type-f')?.value||'';
  let rels=[...( KB.tag_relations||[])];
  if(s) rels=rels.filter(r=>r.from.toLowerCase().includes(s)||r.to.toLowerCase().includes(s)||r.note?.toLowerCase().includes(s));
  if(tf) rels=rels.filter(r=>r.type===tf);
  const cnt=document.getElementById('trel-count');
  if(cnt) cnt.textContent=`${rels.length} / ${KB.tag_relations.length} ryšių`;

  // Render grouped pickers
  renderTrelPicker('trel-from-panel','trel-from');
  renderTrelPicker('trel-to-panel','trel-to');

  const list=document.getElementById('trel-list');
  if(list) list.innerHTML=rels.length?rels.map(r=>{
    const td=TREL_TYPES[r.type]||{lbl:r.type,icon:'·',col:'#aaa'};
    return `<div class="trel-causal-row">
      <div style="font-size:11px;font-weight:600">${r.from}</div>
      <div style="text-align:center">
        <div class="trel-type-chip trel-${r.type.replace(/[^a-zA-Z]/g,'')}" style="background:${td.col}18;color:${td.col};border:1px solid ${td.col}44">
          <span>${td.icon}</span><span>${td.lbl}</span>
        </div>
        ${r.dt?`<div class="dt-field" style="margin-top:3px;text-align:center">⏱ ${r.dt}</div>`:''}
      </div>
      <div style="font-size:11px;font-weight:600">${r.to}</div>
      <div style="font-size:10px;color:var(--td);font-style:italic">${r.note||''}</div>
      <button class="rm" onclick="rmTrel('${r.id}')">×</button>
    </div>`;
  }).join(''):`<div style="text-align:center;padding:30px;color:var(--td);font-size:11px">
    <div style="font-size:24px;margin-bottom:8px">⇄</div>
    Nėra ryšių. Spusk "+ Naujas ryšys" viršuje.
  </div>`;
  renderTrelGraph();
}

function renderTrelGraph() {
  const graph=document.getElementById('trel-graph'); if(!graph) return;
  if(!trelViewGraph){
    graph.innerHTML=`<div style="font-size:11px;color:var(--td);padding:12px;background:var(--bg);border-radius:var(--r);text-align:center">
      Spusk „Perjungti vaizdą" norėdamas matyti grafinę vizualizaciją
    </div>`;
    return;
  }
  if(!KB.tag_relations?.length){
    graph.innerHTML=`<div style="text-align:center;padding:30px;color:var(--td);font-size:11px">Nėra ryšių vizualizuoti</div>`;
    return;
  }

  
  const nodes=new Map();
  const getNodeType=(id)=>{
    if(Object.keys(KB.objects_meta).some(oid=>KB.objects[oid]?.failure_modes?.[id])) return 'failure';
    if(Object.keys(KB.objects_meta).includes(id)) return 'object';
    const allSyms=Object.values(KB.objects).flatMap(kb=>Object.values(kb.failure_modes||{}).flatMap(fm=>fm.symptoms||[]));
    if(allSyms.includes(id)) return 'symptom';
    return 'tag';
  };

  KB.tag_relations.forEach(r=>{
    if(!nodes.has(r.from)) nodes.set(r.from,{id:r.from,type:getNodeType(r.from),out:[],inn:[]});
    if(!nodes.has(r.to))   nodes.set(r.to,{id:r.to,type:getNodeType(r.to),out:[],inn:[]});
    nodes.get(r.from).out.push(r);
    nodes.get(r.to).inn.push(r);
  });

  graph.innerHTML=`<div style="display:flex;flex-wrap:wrap;gap:8px;padding:8px">
    ${[...nodes.values()].map(n=>{
      const td=TREL_TYPES;
      return `<div class="trel-vis-node type-${n.type}" onclick="trelNodeInfo('${e(n.id)}')">
        <div>${n.id}</div>
        <div style="font-size:8px;margin-top:2px;opacity:.6">${n.type}</div>
        ${n.out.length?`<div style="font-size:9px;margin-top:4px;border-top:1px solid currentColor;padding-top:3px;opacity:.7">
          ${n.out.map(r=>`→ ${(TREL_TYPES[r.type]?.icon||'·')} ${r.to.substring(0,8)}`).join('<br>')}
        </div>`:''}
      </div>`;
    }).join('')}
  </div>`;
}

function trelNodeInfo(id) {
  const rels=KB.tag_relations.filter(r=>r.from===id||r.to===id);
  if(!rels.length) return;
  const html=rels.map(r=>{
    const td=TREL_TYPES[r.type]||{lbl:r.type,icon:'·',col:'#aaa'};
    const dir=r.from===id?`→ ${td.icon} <strong>${r.to}</strong>`:`<strong>${r.from}</strong> ${td.icon} →`;
    return `<div style="padding:6px 0;border-bottom:1px solid var(--b1);font-size:11px">${dir} <span style="color:${td.col}">[${td.lbl}]</span>${r.dt?` ⏱${r.dt}`:''}</div>`;
  }).join('');
  openModal(`Ryšiai: ${id}`,html,null);
}

function toggleTrelView(){trelViewGraph=!trelViewGraph;renderTrelGraph();}
function addTrel(){const w=document.getElementById('trel-form-wrap');if(w)w.style.display=w.style.display==='none'?'block':'none';}

function saveTrelRow() {
  const from=(document.getElementById('trel-from')?.value||'').trim();
  const type=document.getElementById('trel-type')?.value||'susijęs';
  const to=(document.getElementById('trel-to')?.value||'').trim();
  const note=(document.getElementById('trel-note')?.value||'').trim();
  const dt=(document.getElementById('trel-dt')?.value||'').trim();
  if(!from||!to){toast('Užpildyk "Iš" ir "Į" laukus');return;}
  if(!KB.tag_relations) KB.tag_relations=[];
  KB.tag_relations.push({id:'TR-'+Date.now(),from,type,to,note,dt,created:new Date().toISOString()});
  document.getElementById('trel-form-wrap').style.display='none';
  document.getElementById('trel-from').value='';
  document.getElementById('trel-to').value='';
  document.getElementById('trel-note').value='';
  if(document.getElementById('trel-dt')) document.getElementById('trel-dt').value='';
  markDirty('meta_trel');
  renderTrel();
  toast('Ryšys pridėtas ✓');
}

function rmTrel(id){KB.tag_relations=KB.tag_relations.filter(r=>r.id!==id);markDirty('meta_trel');renderTrel();toast('Ryšys ištrintas');}
function saveTrelFile(){markDirty('meta_trel');flushDirty();toast('Ryšiai saugojami…');}
