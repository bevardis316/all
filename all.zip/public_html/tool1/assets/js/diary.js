function initDiary() {
  const os=document.getElementById('dc-obj');
  if(os) os.innerHTML=Object.keys(KB.objects_meta).map(id=>`<option value="${id}">${id}</option>`).join('');
  const fo=document.getElementById('dc-fobj');
  if(fo) fo.innerHTML=`<option value="">Visi objektai</option>`+Object.keys(KB.objects_meta).map(id=>`<option value="${id}">${id}</option>`).join('');
  dcObjChange(); renderCases();
  const dd=document.getElementById('dc-date'); if(dd) dd.value=new Date().toISOString().split('T')[0];
}

function dcObjChange() {
  const oid=document.getElementById('dc-obj')?.value;
  const sel=document.getElementById('dc-fail'); if(!sel) return;
  const fms=KB.objects[oid]?.failure_modes||{};
  sel.innerHTML=`<option value="">– Pasirinkti –</option>`+Object.values(fms).filter(f=>f.name).map(f=>`<option value="${f.id}">${f.id}: ${f.name}</option>`).join('');
  const sp=document.getElementById('dc-sym-panel');
  if(sp) sp.innerHTML=renderTagPanel('dc-syms',[]);
}

function setM(key,val,btn) {
  dcMeta[key]=val;
  if(btn){const r=btn.closest('.micro');if(r)r.querySelectorAll('.mb').forEach(b=>b.classList.toggle('on',b===btn));}
}

function addCase() {
  const oid=document.getElementById('dc-obj')?.value;
  const fref=document.getElementById('dc-fail')?.value;
  const cid=`CASE-${String(KB.field_cases.length+1).padStart(4,'0')}`;
  const c={id:cid,date:v('dc-date')||new Date().toISOString().split('T')[0],
    object_id:oid,failure_ref:fref,symptoms:getTagsFrom('dc-syms'),
    meta:{gvl:document.getElementById('dc-gvl')?.value||'',...dcMeta},
    diagnosis:v('dc-diag'),resolution:v('dc-res'),lessons:v('dc-less'),
    created:new Date().toISOString()};
  KB.field_cases.push(c);
  if(fref&&KB.objects[oid]?.failure_modes[fref]){
    const fm=KB.objects[oid].failure_modes[fref];
    fm.frequency=(fm.frequency||0)+1;
    if(!fm.meta.first_seen) fm.meta.first_seen=c.date;
    fm.meta.last_seen=c.date;
  }
  KB.timeline_events.push({id:'TL-'+Date.now(),type:'ev-case',date:c.date,object_id:oid,
    text:`Lauko atvejis: ${(c.symptoms||[]).join(', ')||oid}`,meta:c.meta,ref:cid});
  markDirty('case_'+cid);
  markDirty('timeline');
  ui('cases');
  clearDc();
  const newRels=learnSymRelations();
  toast(cid+' išsaugotas ✓'+(newRels>0?' · Auto-ryšiai: +'+newRels:''));
}

function clearDc() {
  ['dc-diag','dc-res','dc-less'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
  dcMeta={};
}

function deleteCase(cid) {
  if(!confirm('Ištrinti '+cid+'?')) return;
  KB.field_cases=KB.field_cases.filter(c=>c.id!==cid);
  KB.timeline_events=KB.timeline_events.filter(e=>e.ref!==cid);
  clearTimeout(_saveTimer); _dirty.clear();
  showSaveInd('Trinamas…','#e65100');
  saveAllFiles();
  ui('cases');
  toast('🗑 '+cid+' ištrinta');
}

function renderCases() {
  const el=document.getElementById('cases-list'); if(!el) return;
  const s=(document.getElementById('dc-search')?.value||'').toLowerCase();
  const fo=document.getElementById('dc-fobj')?.value||'';
  let cases=[...KB.field_cases].reverse();
  if(s) cases=cases.filter(c=>c.object_id.toLowerCase().includes(s)||(c.symptoms||[]).some(sym=>sym.toLowerCase().includes(s))||c.diagnosis.toLowerCase().includes(s));
  if(fo) cases=cases.filter(c=>c.object_id===fo);
  if(!cases.length){el.innerHTML=`<div style="text-align:center;color:var(--td);padding:40px;font-size:12px">Nėra atvejų</div>`;return;}
  el.innerHTML=cases.map(c=>`<div class="dcard">
    <div class="dcard-head">
      <span class="dcard-id">${c.id}</span><span class="dcard-date">${c.date}</span>
      <span class="dcard-obj">${c.object_id}</span>
      ${c.failure_ref?`<span style="font-size:10px;color:var(--warn)">${c.failure_ref}</span>`:''}
      <button class="rm" onclick="deleteCase('${c.id}')" style="margin-left:auto">×</button>
    </div>
    ${c.symptoms?.length?`<div class="dcard-sym">🔍 ${c.symptoms.join(' · ')}</div>`:''}
    ${c.diagnosis?`<div style="font-size:11px;color:var(--td);margin-bottom:4px">→ ${c.diagnosis.substring(0,90)}${c.diagnosis.length>90?'...':''}</div>`:''}
    <div style="display:flex;flex-wrap:wrap;gap:3px">${Object.entries(c.meta||{}).filter(([k,v])=>v).map(([k,v])=>`<span class="dtag">${k}: ${v}</span>`).join('')}</div>
  </div>`).join('');
}

function showSimilarCases(oid, fid, syms) {
  const el=document.getElementById('similar-cases-panel'); if(!el) return;
  const similar=KB.field_cases.filter(c=>{
    if(c.object_id!==oid&&c.failure_ref!==fid) return false;
    if(!syms.length) return c.object_id===oid;
    return (c.symptoms||[]).filter(s=>syms.includes(s)).length>0;
  }).sort((a,b)=>{
    const sa=(a.symptoms||[]).filter(s=>syms.includes(s)).length;
    const sb=(b.symptoms||[]).filter(s=>syms.includes(s)).length;
    return sb-sa;
  }).slice(0,5);
  if(!similar.length){el.style.display='none';return;}
  el.style.display='block';
  el.innerHTML=`<div style="font-size:11px;font-weight:700;color:var(--pri);margin-bottom:6px">📋 Panašūs praeiti atvejai (${similar.length})</div>`+
    similar.map(c=>{
      const overlap=(c.symptoms||[]).filter(s=>syms.includes(s)).length;
      return `<div style="background:var(--s1);border:1px solid var(--b1);border-radius:6px;padding:8px;margin-bottom:4px;cursor:pointer" onclick="fillFromCase('${c.id}')">
        <div style="display:flex;gap:6px;align-items:center">
          <span style="font-family:monospace;font-size:10px;color:var(--pri)">${c.id}</span>
          <span style="font-size:10px;color:var(--td)">${c.date}</span>
          <span style="font-size:10px;background:#e8f5e9;color:#2e7d32;padding:1px 6px;border-radius:10px">${overlap} simpt. sutampa</span>
        </div>
        ${c.diagnosis?`<div style="font-size:10px;color:var(--td);margin-top:3px">→ ${c.diagnosis.substring(0,80)}${c.diagnosis.length>80?'...':''}</div>`:''}
        <div style="font-size:9px;color:#888;margin-top:2px">Spausti → užpildyti iš šio atvejo</div>
      </div>`;
    }).join('');
}

function fillFromCase(cid) {
  const c=KB.field_cases.find(x=>x.id===cid); if(!c) return;
  const diagEl=document.getElementById('dc-diag'); if(diagEl&&c.diagnosis) diagEl.value=c.diagnosis;
  const resEl=document.getElementById('dc-res');   if(resEl&&c.resolution) resEl.value=c.resolution;
  const lessEl=document.getElementById('dc-less'); if(lessEl&&c.lessons) lessEl.value=c.lessons;
  toast('✓ Užpildyta iš '+cid);
}

function logDiagCase(oid, fid) {
  const fm=KB.objects[oid]?.failure_modes[fid];
  gp('d', document.querySelector('[data-p=d]'));
  setTimeout(()=>{
    const os=document.getElementById('dc-obj'); if(os){os.value=oid; dcObjChange();}
    setTimeout(()=>{
      const fs=document.getElementById('dc-fail'); if(fs) fs.value=fid;
      const syms=[...new Set([...diagSel,...(fm?.symptoms||[])])];
      const sp=document.getElementById('dc-sym-panel');
      if(sp){sp._tags=syms; renderChips('dc-syms',syms);}
      const dd=document.getElementById('dc-date'); if(dd) dd.value=new Date().toISOString().split('T')[0];
      const diagEl=document.getElementById('dc-diag'); if(diagEl&&fm) diagEl.value=(fm.diagnosis_steps||[]).join('\n');
      const resEl=document.getElementById('dc-res'); if(resEl&&fm?.resolution) resEl.value=fm.resolution;
      showSimilarCases(oid, fid, syms);
      document.getElementById('dc-date')?.scrollIntoView({behavior:'smooth',block:'center'});
    },150);
  },100);
  toast('✓ Atvejis auto-užpildytas iš diagnostikos');
}

function showSysInfo() {
  const html = `
<div style="font-family:-apple-system,sans-serif;font-size:12px;line-height:1.7;color:#222;max-height:80vh;overflow-y:auto;padding:4px 2px">

<h2 style="margin:0 0 4px;color:#1565c0;font-size:16px">IBNVS v6 – Sistemos dokumentacija</h2>
<div style="font-size:10px;color:#888;margin-bottom:16px">Techninė instrukcija: duomenų struktūra · funkcijų logika · saugojimas · importas</div>

<!-- ═══ KB OBJEKTAS ═══ -->
<details open>
<summary style="cursor:pointer;font-weight:700;color:#1565c0;font-size:13px;padding:4px 0;border-bottom:2px solid #1565c0;margin-bottom:8px">📦 KB – centrinis duomenų objektas</summary>
<pre style="background:#f5f5f5;border-radius:6px;padding:10px;font-size:10px;overflow-x:auto;white-space:pre-wrap">
KB = {
  objects_meta: { BNVI:{id,name,sek,z,custom}, ... }     ← greita navigacija sąraše
  objects: {
    BNVI: {
      name, function, normal_operation,
      normal_signs:[],  tags:[],
      models:[{id,name,price_eur,notes}],                 ← NAUJAS: objekto modeliai
      maintenance_schedule:{interval_months,tasks:[]},    ← NAUJAS: priežiūros intervalas
      env_behavior:{gvl:{gvl1,gvl2,gvl3},soil:{smel,mol},age_effects,reljefas},
      relations:{upstream:[],downstream:[],depends_on:[]},
      exploitation_errors:[{klaida,pasekme,trukme,prevencija}],
      failure_modes:{
        "BNVI-F001": {
          id, object_id, name, severity(low|med|high|critical),
          symptoms:[], tags:[],
          causes:{primary,list:[{name,signs:[],fix,pct,leads_to:[],fix_pattern}]},
          context:{ctx_short,ctx_long,ctx_very_long},
          prevention,
          env_modifiers:{gvl1,gvl2,smel,mol,old:{prob_mult}},
          economics:{self_fix_cost,specialist_cost_avg,user_saved},
          relations:{also_in:[],leads_to:[]},
          meta:{confidence,first_seen,created}
        }
      },
      meta:{confidence,sources,reviewed,updated,version}
    }
  },
  components_meta: { CID:{id,name,parent_id,y_level}, ... }
  components: {
    CID: {
      id, name, parent_id, y_level, function, normal_operation,
      models:[{id,name,price_eur,supplier}],              ← NAUJAS: komponento modeliai
      pricing:{part_price,install_price,                  ← NAUJAS: kainų struktūra
               quantity_per_system,guarantee_months,diy_possible},
      failure_modes:{ ... }  ← ta pati struktūra kaip objektui
    }
  },
  percentages: { BNVI:{ "BNVI-F001":{base,gvl1,gvl2,smel,mol,old} } },
  decision_trees: { "BNVI-F001":{id,object_id,failure_id,root:{...}} },
  tag_categories: { "Kategorija":{color,tags:[]} },
  tag_relations:  [{id,from,type,to,dt}],
  field_cases:    [{id,date,object_id,failure_ref,symptoms,diagnosis,resolution,lessons,meta}],
  timeline_events:[{id,type,date,object_id,text,meta,ref}],
  percentages, decision_trees, _save_log, _cases_index
}
</pre>
</details>

<!-- ═══ FAILŲ STRUKTŪRA ═══ -->
<details>
<summary style="cursor:pointer;font-weight:700;color:#1565c0;font-size:13px;padding:4px 0;border-bottom:2px solid #1565c0;margin-bottom:8px;margin-top:12px">🗂 Failų struktūra serveryje</summary>
<pre style="background:#f5f5f5;border-radius:6px;padding:10px;font-size:10px;overflow-x:auto;white-space:pre-wrap">
ibnvs_data/
├── objects/{OID}/
│   ├── base.json              ← {id,name,sek,z,function,normal_operation,normal_signs,tags,
│   │                               models,maintenance_schedule,meta}
│   ├── env.json               ← {gvl:{gvl1,gvl2,gvl3},soil:{smel,mol},age_effects,reljefas}
│   ├── relations.json         ← {upstream,downstream,depends_on,alternatives}
│   ├── exploitation_errors.json ← [{klaida,pasekme,trukme,prevencija}]
│   ├── failures/
│   │   ├── _index.json
│   │   └── {OID}-F001.json   ← vienas gedimas
│   └── trees/
│       └── {OID}-F001_tree.json ← diagnostikos medis
├── components/{PARENT_ID}/
│   └── {CID}.json            ← {id,name,parent_id,y_level,function,normal_operation,
│                                  models,pricing,failure_modes}
├── meta/
│   ├── objects_index.json    ← greitas indeksas (be duomenų)
│   ├── tag_categories.json
│   ├── tag_relations.json
│   └── system_config.json
├── percentages/{OID}.json    ← {object_id, failures:{FID:{base,gvl1,...}}}
├── cases/2026/{CID}.json
├── timeline/2026.json
└── save_log.json             ← paskutiniai 200 saugojimų
</pre>
</details>

<!-- ═══ SAUGOJIMAS ═══ -->
<details>
<summary style="cursor:pointer;font-weight:700;color:#1565c0;font-size:13px;padding:4px 0;border-bottom:2px solid #1565c0;margin-bottom:8px;margin-top:12px">💾 Saugojimo sistema (markDirty → flushDirty)</summary>
<div style="padding:4px 0">
<table style="width:100%;border-collapse:collapse;font-size:11px">
<tr style="background:#e3f2fd"><th style="padding:5px 8px;text-align:left">markDirty(key)</th><th style="padding:5px 8px;text-align:left">API veiksmas</th><th style="padding:5px 8px;text-align:left">Failas</th></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">obj_{OID}</td><td style="padding:4px 8px">save_object_base</td><td style="padding:4px 8px">objects/{OID}/base.json + env + relations + exploitation_errors</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">fail_{OID}_{FID}</td><td style="padding:4px 8px">save_failure</td><td style="padding:4px 8px">objects/{OID}/failures/{FID}.json</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">tree_{OID}_{FID}</td><td style="padding:4px 8px">save_tree</td><td style="padding:4px 8px">objects/{OID}/trees/{FID}_tree.json</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">pct_{OID}</td><td style="padding:4px 8px">save_percentages</td><td style="padding:4px 8px">percentages/{OID}.json</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">comp_{CID}</td><td style="padding:4px 8px">save_component</td><td style="padding:4px 8px">components/{PARENT}/{CID}.json</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">case_{CID}</td><td style="padding:4px 8px">save_case</td><td style="padding:4px 8px">cases/{year}/{CID}.json</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">meta_tags</td><td style="padding:4px 8px">save_meta</td><td style="padding:4px 8px">meta/tag_categories.json</td></tr>
</table>
<div style="margin-top:8px;font-size:10px;color:#555">⚡ markDirty() → setTimeout(flushDirty, 1800ms) → apiPost() → serveris rašo JSON failus</div>
</div>
</details>

<!-- ═══ IMPORTAS ═══ -->
<details>
<summary style="cursor:pointer;font-weight:700;color:#1565c0;font-size:13px;padding:4px 0;border-bottom:2px solid #1565c0;margin-bottom:8px;margin-top:12px">📥 Importo sistema – 4 šablonų tipai</summary>
<div style="padding:4px 0;display:flex;flex-direction:column;gap:8px">

<div style="border-left:3px solid #1565c0;padding:6px 10px;background:#e3f2fd;border-radius:0 6px 6px 0">
<strong>🏗 obj</strong> – Objektas (<code>schema_type:"obj"</code>)<br>
Pildoma: <code>base</code> (funkcija/veikimas/požymiai/tagai) · <code>models[]</code> · <code>maintenance_schedule</code> · <code>env_behavior</code> · <code>exploitation_errors[]</code> · <code>relations</code> · <code>failures[]</code><br>
Saugo: <code>markDirty('obj_{OID}')</code> + <code>markDirty('fail_{OID}_{FID}')</code> + <code>markDirty('pct_{OID}')</code>
</div>

<div style="border-left:3px solid #7b1fa2;padding:6px 10px;background:#f3e5f5;border-radius:0 6px 6px 0">
<strong>🔧 comp</strong> – Komponentas (<code>schema_type:"comp"</code>)<br>
Pildoma: <code>base</code> · <code>models[]</code> · <code>pricing</code> (part_price/install_price/qty/guarantee/diy) · <code>failures[]</code><br>
Saugo: <code>markDirty('comp_{CID}')</code> + failure/tree dirties
</div>

<div style="border-left:3px solid #c62828;padding:6px 10px;background:#ffebee;border-radius:0 6px 6px 0">
<strong>⚡ fail</strong> – Tik gedimai (<code>schema_type:"fail"</code>)<br>
Pildoma: <code>failures[]</code> → pridedami prie nurodyto <code>target_id</code> (obj arba comp)<br>
FID generuojamas automatiškai: <code>{TARGET}-F{N}</code>. Auto-generuojamas ir decision tree iš causes.list.
</div>

<div style="border-left:3px solid #2e7d32;padding:6px 10px;background:#e8f5e9;border-radius:0 6px 6px 0">
<strong>💰 pricing</strong> – Tik kainos (<code>schema_type:"pricing"</code>)<br>
Pildoma: <code>items[]</code> masyvas su {id, type:"obj"|"comp", models[], pricing/maintenance_schedule}<br>
Batch update – galima atnaujinti kelių objektų/komponentų kainas vienu kartu.
</div>

</div>
</details>

<!-- ═══ ŽINIOS UI ═══ -->
<details>
<summary style="cursor:pointer;font-weight:700;color:#1565c0;font-size:13px;padding:4px 0;border-bottom:2px solid #1565c0;margin-bottom:8px;margin-top:12px">🧠 Žinios skirtukas – pagrindinės funkcijos</summary>
<div style="padding:4px 0">
<table style="width:100%;border-collapse:collapse;font-size:11px">
<tr style="background:#e3f2fd"><th style="padding:5px 8px;text-align:left">Funkcija</th><th style="padding:5px 8px;text-align:left">Ką daro</th></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">renderObjList()</td><td style="padding:4px 8px">Perpiešia kairiąjį objektų/komponentų sąrašą</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">selObj(oid)</td><td style="padding:4px 8px">Pasirenka objektą → renderKTab()</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">selComp(cid)</td><td style="padding:4px 8px">Pasirenka komponentą → renderCompTab()</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">renderKTab()</td><td style="padding:4px 8px">Piešia aktyvų skirtukę (base/failures/env/errors/rels)</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">saveKTab()</td><td style="padding:4px 8px">Perskaito formos reikšmes → rašo į KB.objects[curObj]</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">saveKTabAndSync()</td><td style="padding:4px 8px">saveKTab() + markDirty + flushDirty</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">renderCompTab(cid)</td><td style="padding:4px 8px">Piešia komponento kortelę su kainomis ir gedimais</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">saveCompTab()</td><td style="padding:4px 8px">Išsaugo komponento duomenis (incl. pricing, models)</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">renderFailCard(fid,fm)</td><td style="padding:4px 8px">Vienos gedimo kortelės HTML (sutraukiama/plečiama)</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">addFail()</td><td style="padding:4px 8px">Sukuria naują tuščią gedimą su auto FID</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">saveFail(fid)</td><td style="padding:4px 8px">Perskaito gedimo formos reikšmes → KB</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">genAndShowTree(fid)</td><td style="padding:4px 8px">Iš causes.list automatiškai generuoja TAIP/NE medį</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">renderPct()</td><td style="padding:4px 8px">Tikimybių lentelė su env multiplieriais</td></tr>
<tr style="border-bottom:1px solid #ddd"><td style="padding:4px 8px;font-family:monospace">getCompPriceForFailure(name)</td><td style="padding:4px 8px">Randa komponento kainą pagal gedimo pavadinimą</td></tr>
</table>
</div>
</details>

<!-- ═══ GLOBALŪS KINTAMIEJI ═══ -->
<details>
<summary style="cursor:pointer;font-weight:700;color:#1565c0;font-size:13px;padding:4px 0;border-bottom:2px solid #1565c0;margin-bottom:8px;margin-top:12px">⚙ Globalūs kintamieji</summary>
<pre style="background:#f5f5f5;border-radius:6px;padding:10px;font-size:10px;white-space:pre-wrap">
curObj   – šiuo metu pasirinktas objekto ID (pvz. "BNVI")
curComp  – šiuo metu pasirinktas komponento ID (arba null)
curKTab  – aktyvus Žinios skirtukas: 'base'|'failures'|'env'|'errors'|'rels'
_dirty   – Set() su nesaugotų pakeitimų raktais
_saveTimer – debounce timer ID (1800ms po paskutinio markDirty)
_compOpen  – Set() su atidarytais komponentų mazgais (hierarchija)
_impTplType – aktyvus importo šablono tipas
_impParsed  – paskutinis sėkmingai parsed importo JSON
</pre>
</details>

<!-- ═══ KAINOS IR MODELIAI ═══ -->
<details>
<summary style="cursor:pointer;font-weight:700;color:#1565c0;font-size:13px;padding:4px 0;border-bottom:2px solid #1565c0;margin-bottom:8px;margin-top:12px">💰 Kainų sistema</summary>
<div style="padding:4px 0;font-size:11px">
<p><strong>Objektai</strong> → <code>KB.objects[OID].models[]</code> = [{id:"A", name:"Modelis A", price_eur:100, notes:""}]</p>
<p><strong>Objektai</strong> → <code>KB.objects[OID].maintenance_schedule</code> = {interval_months:6, tasks:["valymas","tikrinimas"]}</p>
<p><strong>Komponentai</strong> → <code>KB.components[CID].models[]</code> = [{id:"A", name:"Grundfos", price_eur:300, supplier:"UAB X"}]</p>
<p><strong>Komponentai</strong> → <code>KB.components[CID].pricing</code> = {part_price:300, install_price:100, quantity_per_system:1, guarantee_months:24, diy_possible:false}</p>
<p>💡 <code>getCompPriceForFailure(failName)</code> – automatiškai randa komponento kainą pagal gedimo pavadinimo atitikmenį (naudojama economics auto-fill)</p>
<p>📍 Ekonomika gedimo kortelėje: <code>fm.economics.user_saved = specialist_cost_avg - self_fix_cost</code></p>
</div>
</details>

<!-- ═══ DIAGNOSTIKA ═══ -->
<details>
<summary style="cursor:pointer;font-weight:700;color:#1565c0;font-size:13px;padding:4px 0;border-bottom:2px solid #1565c0;margin-bottom:8px;margin-top:12px">🔍 Diagnostikos logika (kon/diagnose.php)</summary>
<div style="padding:4px 0;font-size:11px">
<p><strong>1.</strong> Vartotojas pasirenka simptomus → sistema filtruoja gedimus kuriuose yra tie simptomai</p>
<p><strong>2.</strong> Tikimybė skaičiuojama: <code>base% × env_modifier</code> (gvl1/gvl2/smel/mol/old pagal kliento situaciją)</p>
<p><strong>3.</strong> Rikiuojama pagal tikimybę → rodomi top gedimai su causes, fix, economics</p>
<p><strong>4.</strong> Decision tree: TAIP/NE klausimai iš <code>KB.decision_trees[FID]</code></p>
<p><strong>5.</strong> Lauko atvejis (diary) → <code>fm.frequency++</code> → praturtina KB</p>
<p><strong>Aplinkos faktoriai:</strong> gvl1=aukštas GVL, gvl2=žemas GVL, smel=smėlio gruntas, mol=molio gruntas, old=sistema 7m+</p>
</div>
</details>

<div style="margin-top:16px;padding:8px 12px;background:#fff3e0;border-radius:6px;font-size:10px;color:#e65100;border-left:3px solid #ff9800">
⚠ <strong>Taisyklės keičiant kodą:</strong> (1) Visada tikrink ar funkcija neapibrėžta kitur. (2) markDirty() kiekviename įraše. (3) Tušti laukai NEPAKEIČIA esamų duomenų importo metu. (4) _impParseJSON() pašalina "//" komentarus prieš JSON.parse(). (5) saveKTab() visada kviečiamas prieš naviguojant.
</div>
</div>`;

  openModal('📖 IBNVS sistemos dokumentacija', html, null);
}
