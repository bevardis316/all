const IMP_AI_INSTRUCTIONS = {
  obj: `=== IBNVS ŽINIŲ BAZĖS PILDYMO INSTRUKCIJA – OBJEKTAS ===

Tu pildai JSON šabloną nuotekų sistemos objektui (pvz. biologinis valymo įrenginys, siurblinė, drenažas).

TAISYKLĖS:
- Pildyk TIK tuos laukus kurie yra žinomi. Tuščius laukus palik "" arba [].
- NEKEISK laukų pavadinimų (raktų). Tik pildyk reikšmes.
- Visas tekstas lietuvių kalba, trumpai ir tiksliai.
- "object_id" – nekeisti, tai sistemos ID.

LAUKAI:
base.function       = vienas sakinys: ką šis objektas daro sistemoje
base.normal_operation = normalaus veikimo aprašas (2-4 sakiniai)
base.normal_signs   = sąrašas požymių kai viskas gerai (pvz. ["burbuliuoja","nesmirda"])
base.tags           = klasifikacijos žodžiai (pvz. ["biologinis valymas","BNVI"])

models              = įrangos modeliai su kainomis. Kiekvienas: {id:"A", name:"modelio pavadinimas", price_eur:0, notes:""}
maintenance_schedule.interval_months = kas kiek mėnesių reikia techninės priežiūros
maintenance_schedule.tasks = priežiūros užduočių sąrašas (pvz. ["tikrinti dumblo kiekį","plauti filtrą"])

env_behavior        = kaip aplinkos sąlygos veikia šį objektą (lietuviški tekstai)
  gvl1 = kai požeminis vandens lygis AUKŠTAS (problema ar ne?)
  gvl2 = kai požeminis vandens lygis ŽEMAS
  soil.smel = smėlio grunto įtaka
  soil.mol  = molio grunto įtaka
  age_effects = kaip senėjimas veikia (po 7+ metų)

exploitation_errors = TIPINĖS klaidų kurias daro naudotojai. Kiekviena: {klaida, pasekme, trukme, prevencija}

relations = sistemos topologija (kitų objektų ID):
  upstream   = kas yra PRIEŠ šį objektą (nuotekos ateina iš ten)
  downstream = kas yra PO šio objekto (nuotekos eina ten)
  depends_on = nuo ko priklauso šio veikimas

failures = gedimų sąrašas. Kiekvienas gedimas:
  name       = trumpas pavadinimas (pvz. "Orapūtė neveikia")
  severity   = low | med | high | critical
  symptoms   = ką mato/girdi/jaučia KLIENTAS (pvz. ["nėra burbuliukų","nemalonas kvapas"])
  causes.primary = pagrindinė priežastis vienu sakiniu
  causes.list = priežasčių sąrašas. Kiekviena: {name, signs:[], fix, pct(tikimybė 0-100)}
  context.ctx_short     = ką daryti jei gedimas buvo TRUMPAI (val/diena)
  context.ctx_long      = ką daryti jei gedimas ILGAI (savaitė+)
  context.ctx_very_long = ką daryti jei gedimas LABAI ILGAI (mėnuo+)
  prevention = kaip išvengti
  env_modifiers = kaip aplinka veikia šio gedimo tikimybę (1.0=normalu, 2.0=dvigubai dažniau, 0.5=rečiau)
  economics.self_fix_cost      = kiek kainuoja medžiagos jei taiso pats (€)
  economics.specialist_cost_avg = kiek kainuotų specialistas (€)

=== TOLIAU PATEIKIAMAS UŽPILDYTINAS ŠABLONAS ===`,

  comp: `=== IBNVS ŽINIŲ BAZĖS PILDYMO INSTRUKCIJA – KOMPONENTAS ===

Tu pildai JSON šabloną konkretaus komponento ar jo dalies (pvz. siurblys, orapūtė, filtras, jutiklis).

TAISYKLĖS:
- Pildyk TIK žinomus laukus. Tuščius palik "" arba [].
- NEKEISK laukų raktų pavadinimų.
- "component_id" ir "parent_id" – nekeisti.
- Tekstas lietuvių kalba.

LAUKAI:
base.function       = ką šis komponentas daro (1 sakinys)
base.normal_operation = normalus veikimas, kaip atpažinti kad veikia gerai

models = konkretūs šio komponento modeliai/markės rinkoje. Kiekvienas:
  {id:"A", name:"gamintojo modelis", price_eur:0, supplier:"tiekėjas"}

pricing:
  part_price          = komponento kaina (€) – medžiagos/dalis
  install_price       = specialisto darbo kaina keitimui (€)
  quantity_per_system = kiek tokių komponentų tipinėje sistemoje (skaičius)
  guarantee_months    = garantija mėnesiais
  diy_possible        = true jei klientas gali keisti pats, false jei reikia specialisto

failures = komponentui būdingi gedimai. Kiekvienas:
  name       = gedimo pavadinimas
  severity   = low | med | high | critical
  symptoms   = ką mato/girdi klientas
  causes.list = priežastys su sprendimais (name, fix, pct)
  prevention = profilaktika
  economics.self_fix_cost = kaina jei taiso pats
  economics.specialist_cost_avg = specialisto kaina

=== TOLIAU PATEIKIAMAS UŽPILDYTINAS ŠABLONAS ===`,

  fail: `=== IBNVS ŽINIŲ BAZĖS PILDYMO INSTRUKCIJA – GEDIMAI ===

Tu pildai JSON su GEDIMŲ sąrašu. Jie bus pridėti prie nurodyto objekto arba komponento.

TAISYKLĖS:
- "target_id" – nekeisti, tai kur bus pridėti gedimai.
- Galima pateikti kelis gedimus (failures masyvą).
- Tekstas lietuvių kalba.

GEDIMO LAUKAI:
name       = trumpas aiškus pavadinimas (pvz. "Siurblys nesiurbia")
severity   = low (mažas) | med (vidutinis) | high (didelis) | critical (kritinis)
symptoms   = ką KLIENTAS mato/girdi/jaučia. KONKRETŪS požymiai, ne techniniai terminai.
             Pvz: ["vanduo nenusileidžia","girdisi ūžimas","kvapas iš santechnikos"]

causes.primary = pagrindinė priežastis (1 sakinys)
causes.list    = galimos priežastys, kiekviena:
  name  = priežasties apibūdinimas
  signs = požymiai kurie rodo šią priežastį
  fix   = ką konkrečiai daryti (veiksmažodis + objektas)
  pct   = tikimybė % (visi kartu turi sudaryti ~100)
  leads_to = kitų gedimų ID kuriuos sukelia ši priežastis (galima palikti [])

context:
  ctx_short     = ką daryti jei gedimas trumpai (val/diena) – greitas sprendimas
  ctx_long      = ką daryti jei savaitė+ – papildomi žingsniai
  ctx_very_long = ką daryti jei mėnuo+ – gali reikėti daugiau darbų

prevention = kaip išvengti (profilaktiniai veiksmai, intervalai)

env_modifiers = kaip aplinka KEIČIA šio gedimo tikimybę:
  prob_mult: "1.0" = normalu, "1.5" = 50% dažniau, "2.0" = dvigubai, "0.5" = perpus rečiau
  gvl1 = aukštas požeminis vandens lygis
  gvl2 = žemas požeminis vandens lygis
  smel = smėlio gruntas
  mol  = molio gruntas
  old  = sistema senesnė nei 7 metai

economics:
  self_fix_cost       = medžiagų kaina jei taiso pats (€)
  specialist_cost_avg = specialisto iškvietimo kaina (€)
  (user_saved bus apskaičiuota automatiškai)

=== TOLIAU PATEIKIAMAS UŽPILDYTINAS ŠABLONAS ===`,

  pricing: `=== IBNVS ŽINIŲ BAZĖS PILDYMO INSTRUKCIJA – KAINOS IR MODELIAI ===

Tu pildai JSON kainų atnaujinimui. Galima atnaujinti kelis objektus ir komponentus vienu kartu.

TAISYKLĖS:
- "id" – tikslus objekto arba komponento ID iš sistemos. NEKEISTI.
- "type": "obj" = pagrindinis objektas, "comp" = komponentas
- Galima pateikti kelis items[] masyvą.

OBJEKTO (type:"obj") LAUKAI:
models = įrangos modeliai (skirtingos markės/serijos):
  [{id:"A", name:"Gamintojo pavadinimas ir modelis", price_eur:0, notes:"pastabos"}]
  Pvz: [{id:"A", name:"Biotal BIO-5", price_eur:1200, notes:"standartinis"}]

maintenance_schedule:
  interval_months = kas kiek mėnesių būtina techninė priežiūra
  tasks = priežiūros darbų sąrašas

KOMPONENTO (type:"comp") LAUKAI:
models = konkretūs modeliai rinkoje:
  [{id:"A", name:"Grundfos UP 20-14 B PM", price_eur:85, supplier:"Grundfos"}]

pricing:
  part_price          = komponento kaina eurais (medžiaga/dalis)
  install_price       = specialisto darbo kaina keitimui eurais
  quantity_per_system = kiek tokių reikia tipinėje sistemoje
  guarantee_months    = garantija mėnesiais
  diy_possible        = true (galima pačiam) arba false (reikia specialisto)

PAVYZDYS – kaip kalbėti su AI:
"Siurblys Grundfos kainuoja 300€, keitimas specialisto 150€. 
Viena sistema naudoja 1 siurblį. Garantija 24 mėn. Reikia specialisto.
Taip pat orapūtės filtras kainuoja 8€, keičiamas pačiam kas 6 mėn."

=== TOLIAU PATEIKIAMAS UŽPILDYTINAS ŠABLONAS ===`
};

const IMP_TEMPLATES = {
  obj: {
    label: '🏗 Objektas',
    desc:  'Bazė · Aplinka · Eksploatacijos klaidos · Ryšiai · Modeliai/kainos · Gedimai',
    color: '#1565c0',
    targetType: 'obj',
    schema: (oid, name) => ({
      "//": "IBNVS objekto schema. Pildyk tik žinomus laukus. Tuščius palik arba ištrink.",
      "schema_type": "obj",
      "object_id": oid || "OBJEKTO_ID",

      "base": {
        "function": "",
        "normal_operation": "",
        "normal_signs": [],
        "tags": []
      },

      "models": [
        {"id": "A", "name": "", "price_eur": 0, "notes": ""}
      ],

      "maintenance_schedule": {
        "interval_months": 6,
        "tasks": []
      },

      "env_behavior": {
        "gvl": {"gvl1": "", "gvl2": "", "gvl3": ""},
        "soil": {"smel": "", "mol": ""},
        "age_effects": "",
        "reljefas": ""
      },

      "exploitation_errors": [
        {"klaida": "", "pasekme": "", "trukme": "", "prevencija": ""}
      ],

      "relations": {
        "upstream": [],
        "downstream": [],
        "depends_on": []
      },

      "failures": [
        {
          "name": "",
          "severity": "med",
          "symptoms": [],
          "causes": {
            "primary": "",
            "list": [{"name": "", "signs": [], "fix": "", "pct": 0, "leads_to": []}]
          },
          "context": {"ctx_short": "", "ctx_long": "", "ctx_very_long": ""},
          "prevention": "",
          "env_modifiers": {
            "gvl1": {"prob_mult": "1.0"}, "gvl2": {"prob_mult": "1.0"},
            "smel": {"prob_mult": "1.0"}, "mol":  {"prob_mult": "1.0"},
            "old":  {"prob_mult": "1.0"}
          },
          "economics": {"self_fix_cost": 0, "specialist_cost_avg": 120},
          "tags": [],
          "meta": {"confidence": 50}
        }
      ]
    })
  },

  comp: {
    label: '🔧 Komponentas',
    desc:  'Bazė · Modeliai · Kainos (dalies + montavimo) · Gedimai',
    color: '#7b1fa2',
    targetType: 'comp',
    schema: (cid, name, parentId) => ({
      "//": "IBNVS komponento schema.",
      "schema_type": "comp",
      "component_id": cid || "KOMPONENTO_ID",
      "parent_id": parentId || "OBJEKTO_ARBA_KOMPONENTO_ID",

      "base": {
        "name": name || "",
        "function": "",
        "normal_operation": ""
      },

      "models": [
        {"id": "A", "name": "", "price_eur": 0, "supplier": ""}
      ],

      "pricing": {
        "part_price": 0,
        "install_price": 0,
        "quantity_per_system": 1,
        "guarantee_months": 12,
        "diy_possible": true
      },

      "failures": [
        {
          "name": "",
          "severity": "med",
          "symptoms": [],
          "causes": {
            "list": [{"name": "", "fix": "", "pct": 0}]
          },
          "prevention": "",
          "economics": {"self_fix_cost": 0, "specialist_cost_avg": 120},
          "meta": {"confidence": 50}
        }
      ]
    })
  },

  fail: {
    label: '⚡ Tik gedimai',
    desc:  'Prideda naujus gedimus prie esamo objekto arba komponento',
    color: '#c62828',
    targetType: 'any',
    schema: (targetId, name) => ({
      "//": "Tik gedimų schema – pridedami į esamą objektą/komponentą.",
      "schema_type": "fail",
      "target_id": targetId || "OBJEKTO_ARBA_KOMPONENTO_ID",

      "failures": [
        {
          "name": "",
          "severity": "med",
          "symptoms": [],
          "causes": {
            "primary": "",
            "list": [{"name": "", "signs": [], "fix": "", "pct": 0, "leads_to": []}]
          },
          "context": {"ctx_short": "", "ctx_long": "", "ctx_very_long": ""},
          "prevention": "",
          "env_modifiers": {
            "gvl1": {"prob_mult": "1.0"}, "gvl2": {"prob_mult": "1.0"},
            "smel": {"prob_mult": "1.0"}, "mol":  {"prob_mult": "1.0"},
            "old":  {"prob_mult": "1.0"}
          },
          "economics": {"self_fix_cost": 0, "specialist_cost_avg": 120},
          "tags": [],
          "meta": {"confidence": 50}
        }
      ]
    })
  },

  pricing: {
    label: '💰 Kainos / modeliai',
    desc:  'Atnaujina tik kainų ir modelių laukus (objektams ir komponentams)',
    color: '#2e7d32',
    targetType: 'any',
    schema: () => ({
      "//": "Kainų atnaujinimo schema. Įrašyk ID ir kainas.",
      "schema_type": "pricing",
      "items": [
        {
          "id": "OBJEKTO_ARBA_KOMPONENTO_ID",
          "type": "obj",
          "models": [
            {"id": "A", "name": "", "price_eur": 0, "notes": ""}
          ],
          "maintenance_schedule": {"interval_months": 6, "tasks": []}
        },
        {
          "id": "KOMPONENTO_ID",
          "type": "comp",
          "models": [
            {"id": "A", "name": "", "price_eur": 0, "supplier": ""}
          ],
          "pricing": {
            "part_price": 0,
            "install_price": 0,
            "quantity_per_system": 1,
            "guarantee_months": 12,
            "diy_possible": true
          }
        }
      ]
    })
  }
};

let _impTplType = 'obj';
let _impParsed  = null;   
let _impEdits   = {};     

function renderTpls() {
  const wrap = document.getElementById('import-wrap');
  if(!wrap) return;

  wrap.innerHTML = `
  <div style="max-width:1020px;margin:0 auto;display:flex;flex-direction:column;gap:18px">

    <!-- ═══ 1. ŠABLONO TIPAS ═══ -->
    <div class="sec">
      <div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')">
        <div style="display:flex;align-items:center;gap:10px">
          <span style="background:var(--pri);color:#fff;border-radius:50%;width:22px;height:22px;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">1</span>
          <h3 style="margin:0">Pasirink šabloną</h3>
        </div>
        <span class="caret">▾</span>
      </div>
      <div class="sec-b" style="padding:14px">

        <!-- Šablono tipo kortelės -->
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px" id="imp-tpl-cards">
          ${Object.entries(IMP_TEMPLATES).map(([type, tpl]) => `
            <div class="imp-tpl-card ${_impTplType===type?'active':''}" data-type="${type}"
              onclick="impSelectType('${type}')"
              style="cursor:pointer;border:2px solid ${_impTplType===type?tpl.color:'var(--b1)'};border-radius:8px;padding:10px;transition:border-color .15s;background:${_impTplType===type?tpl.color+'11':'var(--bg)'}">
              <div style="font-size:13px;font-weight:700;color:${tpl.color};margin-bottom:4px">${tpl.label}</div>
              <div style="font-size:10px;color:var(--td);line-height:1.4">${tpl.desc}</div>
            </div>`).join('')}
        </div>

        <!-- Taikinio pasirinkimas -->
        <div id="imp-target-row" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
          <div style="flex:1;min-width:200px">
            <div class="lbl" id="imp-target-lbl">Objektas</div>
            <select id="imp-target-sel" onchange="impRefreshSchema()" style="width:100%">
              <option value="">– pasirinkti –</option>
              ${_impTargetOptions()}
            </select>
          </div>
          <button class="btn pri" onclick="impCopySchema()" style="flex-shrink:0">📋 Kopijuoti schemą</button>
        </div>

        <div id="imp-copied" style="display:none;color:#2e7d32;font-size:11px;font-weight:700;margin-top:6px">✅ Nukopijuota į clipboard!</div>

        <div style="margin-top:10px;background:var(--s2);border-radius:var(--r);padding:10px 14px;font-size:10px;color:var(--td);line-height:1.7;border-left:3px solid var(--pri)">
          <strong style="color:var(--fg)">Kaip naudoti:</strong>
          pasirink tipą → pasirink taikinį → <strong>📋 Kopijuoti schemą</strong> → įklijuok į AI + laisvas tekstas → AI grąžins užpildytą JSON → įklijuok žemiau
        </div>

        <!-- Schema preview (sutrumpinta) -->
        <textarea id="imp-schema-prev" rows="4" readonly
          style="font-family:'JetBrains Mono',monospace;font-size:10px;background:var(--s3);border:1px solid var(--b1);border-radius:var(--r);padding:8px;color:var(--td);resize:none;width:100%;margin-top:10px"
          placeholder="← Pasirink tipą ir taikinį – čia atsiras JSON schema"></textarea>
      </div>
    </div>

    <!-- ═══ 2. ĮKLIJUOK AI JSON ═══ -->
    <div class="sec">
      <div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')">
        <div style="display:flex;align-items:center;gap:10px">
          <span style="background:var(--pri);color:#fff;border-radius:50%;width:22px;height:22px;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">2</span>
          <h3 style="margin:0">Įklijuok AI grąžintą JSON</h3>
        </div>
        <span class="caret">▾</span>
      </div>
      <div class="sec-b" style="padding:14px;display:flex;flex-direction:column;gap:10px">
        <textarea id="imp-json" rows="18"
          style="font-family:'JetBrains Mono',monospace;font-size:11px;line-height:1.6;background:var(--s2);border:1px solid var(--b1);border-radius:var(--r);padding:10px;resize:vertical;width:100%"
          placeholder="Čia įklijuok JSON kurį grąžino AI...&#10;&#10;Tušti laukai bus ignoruojami – nepakeis esamų duomenų."
          oninput="impParseAndPreview()"></textarea>

        <div id="imp-parse-err" style="display:none;padding:8px 12px;background:#ffebee;border:1px solid #ef9a9a;border-radius:6px;color:#c62828;font-size:11px"></div>
      </div>
    </div>

    <!-- ═══ 3. PERŽIŪRA IR REDAGAVIMAS ═══ -->
    <div id="imp-preview-sec" style="display:none">
      <div class="sec">
        <div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')">
          <div style="display:flex;align-items:center;gap:10px">
            <span style="background:#ff9800;color:#fff;border-radius:50%;width:22px;height:22px;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex-shrink:0">3</span>
            <h3 style="margin:0">Peržiūra – redaguok prieš importuodamas</h3>
            <span id="imp-stats" style="font-size:11px;color:var(--td)"></span>
          </div>
          <span class="caret">▾</span>
        </div>
        <div class="sec-b" style="padding:14px" id="imp-preview-body"></div>
      </div>

      <div style="display:flex;gap:10px;align-items:center;padding:4px 0">
        <button class="btn pri" id="imp-do-btn" onclick="doImport()">💾 Importuoti į KB</button>
        <button class="btn ghost sm" onclick="impClear()">✕ Išvalyti</button>
        <div id="imp-do-status" style="font-size:11px;color:var(--td)"></div>
      </div>
    </div>

    <!-- ═══ 4. REZULTATAS ═══ -->
    <div id="imp-result" style="display:none"></div>

  </div>`;

  
  _impUpdateTargetOptions();
  if(curObj||curComp) impRefreshSchema();
}

function impSelectType(type) {
  _impTplType = type;
  
  document.querySelectorAll('.imp-tpl-card').forEach(c=>{
    const t = c.dataset.type;
    const col = IMP_TEMPLATES[t].color;
    c.classList.toggle('active', t===type);
    c.style.borderColor = t===type ? col : 'var(--b1)';
    c.style.background  = t===type ? col+'11' : 'var(--bg)';
  });
  _impUpdateTargetOptions();
  impRefreshSchema();
}

function _impTargetOptions() {
  const objOpts = Object.keys(KB.objects_meta).map(id=>
    `<option value="obj::${id}">🏗 ${id} – ${KB.objects_meta[id].name||id}</option>`
  ).join('');
  const compOpts = Object.keys(KB.components_meta||{}).map(cid=>{
    const m=KB.components_meta[cid];
    return `<option value="comp::${cid}">🔧 ${cid} – ${m.name||cid} (↳${m.parent_id})</option>`;
  }).join('');
  return objOpts + (compOpts ? '<option disabled>──────</option>'+compOpts : '');
}

function _impUpdateTargetOptions() {
  const sel = document.getElementById('imp-target-sel');
  const lbl = document.getElementById('imp-target-lbl');
  if(!sel) return;

  const tpl = IMP_TEMPLATES[_impTplType];
  if(lbl) lbl.textContent = tpl.targetType==='comp' ? 'Komponentas' : 'Objektas arba komponentas';

  sel.innerHTML = '<option value="">– pasirinkti –</option>' + _impTargetOptions();

  
  if(tpl.targetType==='comp' && curComp) sel.value='comp::'+curComp;
  else if(tpl.targetType==='obj' && curObj) sel.value='obj::'+curObj;
  else if(curObj) sel.value='obj::'+curObj;
  else if(curComp) sel.value='comp::'+curComp;
}

function impGetCurrentTarget() {
  const sel = document.getElementById('imp-target-sel');
  const val = sel?.value||'';
  if(!val) return {type:null, id:null, name:''};
  const [type, id] = val.split('::');
  const name = type==='obj'
    ? KB.objects_meta[id]?.name||id
    : KB.components_meta[id]?.name||id;
  return {type, id, name};
}

function impRefreshSchema() {
  const {type, id, name} = impGetCurrentTarget();
  const prev = document.getElementById('imp-schema-prev');
  if(!prev) return;

  const tpl = IMP_TEMPLATES[_impTplType];
  let schema;
  if(_impTplType==='obj')     schema = tpl.schema(id||'', name);
  else if(_impTplType==='comp') {
    const parentId = type==='comp' ? KB.components_meta[id]?.parent_id||'' : (id||'');
    schema = tpl.schema(type==='comp'?id:'', name, parentId);
  }
  else if(_impTplType==='fail') schema = tpl.schema(id||'', name);
  else schema = tpl.schema();

  prev.value = JSON.stringify(schema, null, 2);
}

function impCopySchema() {
  const prev = document.getElementById('imp-schema-prev');
  if(!prev?.value.trim()) { toast('⚠ Pirma pasirink šabloną ir taikinį'); return; }
  const instruction = IMP_AI_INSTRUCTIONS[_impTplType] || '';
  const fullText = instruction + '\n\n' + prev.value;
  const show = () => {
    const el=document.getElementById('imp-copied');
    if(el){el.style.display='block';setTimeout(()=>el.style.display='none',2500);}
    toast('📋 Instrukcija + schema nukopijuota!');
  };
  navigator.clipboard.writeText(fullText).then(show).catch(()=>{
    const ta=document.createElement('textarea');
    ta.value=fullText; document.body.appendChild(ta); ta.select();
    document.execCommand('copy'); document.body.removeChild(ta); show();
  });
}

function impParseAndPreview() {
  const raw = document.getElementById('imp-json')?.value?.trim()||'';
  const errEl = document.getElementById('imp-parse-err');
  const prevSec = document.getElementById('imp-preview-sec');

  if(errEl)  { errEl.style.display='none'; errEl.textContent=''; }
  if(prevSec)  prevSec.style.display='none';
  _impParsed = null;

  if(!raw) return;

  let data;
  try { data = _impParseJSON(raw); }
  catch(e) {
    if(errEl){errEl.style.display='block';errEl.textContent='⚠ JSON klaida: '+e.message;}
    return;
  }

  _impParsed = data;

  
  if(data.schema_type && IMP_TEMPLATES[data.schema_type]) {
    _impTplType = data.schema_type;
    impSelectType(_impTplType);
  }

  
  const autoId = data.object_id || data.target_id || data.component_id || null;
  if(autoId) {
    const sel = document.getElementById('imp-target-sel');
    if(sel) {
      const objKey = 'obj::'+autoId;
      const compKey = 'comp::'+autoId;
      if([...sel.options].some(o=>o.value===objKey))  sel.value=objKey;
      else if([...sel.options].some(o=>o.value===compKey)) sel.value=compKey;
    }
  }

  
  _impRenderPreview(data);
  if(prevSec) prevSec.style.display='block';
}

function _impRenderPreview(data) {
  const body = document.getElementById('imp-preview-body');
  const stats = document.getElementById('imp-stats');
  if(!body) return;

  const sections = [];
  const nv = v => v && String(v).trim() && !String(v).startsWith('//');
  let totalFields = 0;

  function addSec(icon, title, color, rows) {
    if(!rows.length) return;
    totalFields += rows.length;
    sections.push({icon, title, color, rows});
  }

  function makeRow(key, label, value, path, isNew) {
    const valStr = Array.isArray(value)
      ? (value.length ? value.join(', ') : '–')
      : (typeof value==='object' && value!==null ? JSON.stringify(value) : String(value||''));
    return {key, label, value: valStr, path, isNew: !!isNew};
  }

  const ttype = data.schema_type || _impTplType;

  
  if(ttype==='obj') {
    const oid = data.object_id||'';
    const kb = KB.objects[oid];
    const rows=[];
    if(nv(data.base?.function))         rows.push(makeRow('base.function','Funkcija',data.base.function,'base',!kb?.function));
    if(nv(data.base?.normal_operation)) rows.push(makeRow('base.normal_operation','Normalus veikimas',data.base.normal_operation,'base',!kb?.normal_operation));
    if(data.base?.normal_signs?.length) rows.push(makeRow('base.normal_signs','Normalūs požymiai',data.base.normal_signs,'base',!kb?.normal_signs?.length));
    if(data.base?.tags?.length)         rows.push(makeRow('base.tags','Tagai',data.base.tags,'base',!kb?.tags?.length));
    if(rows.length) addSec('📦','Bazė','#1565c0',rows);

    const mrows=[];
    if(data.models?.filter(m=>nv(m?.name)||m?.price_eur>0).length)
      mrows.push(makeRow('models','Modeliai', data.models.map(m=>`${m.id||'?'}: ${m.name||''} (${m.price_eur||0}€)`), 'models', !kb?.models?.length));
    if(data.maintenance_schedule?.interval_months)
      mrows.push(makeRow('maint.interval','Priežiūros intervalas', data.maintenance_schedule.interval_months+' mėn.','models',!kb?.maintenance_schedule?.interval_months));
    if(mrows.length) addSec('💰','Kainos / modeliai','#2e7d32',mrows);

    const erows=[];
    const eb=data.env_behavior||{};
    if(nv(eb.gvl?.gvl1)) erows.push(makeRow('env.gvl1','GVL↑',eb.gvl.gvl1,'env',!kb?.env_behavior?.gvl?.gvl1));
    if(nv(eb.gvl?.gvl2)) erows.push(makeRow('env.gvl2','GVL↓',eb.gvl.gvl2,'env',!kb?.env_behavior?.gvl?.gvl2));
    if(nv(eb.soil?.smel)) erows.push(makeRow('env.smel','Smėlis',eb.soil.smel,'env',!kb?.env_behavior?.soil?.smel));
    if(nv(eb.soil?.mol))  erows.push(makeRow('env.mol','Molis',eb.soil.mol,'env',!kb?.env_behavior?.soil?.mol));
    if(nv(eb.age_effects)) erows.push(makeRow('env.age','Senėjimas',eb.age_effects,'env',!kb?.env_behavior?.age_effects));
    if(erows.length) addSec('🌿','Aplinka','#2e7d32',erows);

    const errs=(data.exploitation_errors||[]).filter(e=>nv(e?.klaida));
    if(errs.length) addSec('⚠','Eksploatacijos klaidos','#e65100',
      errs.map((er,i)=>makeRow('err_'+i,er.klaida.slice(0,40),er.pasekme,'errors',true)));

    const rrows=[];
    if(data.relations?.upstream?.length)    rrows.push(makeRow('rel.up','← Prieš šį',data.relations.upstream,'rels',true));
    if(data.relations?.downstream?.length)  rrows.push(makeRow('rel.down','→ Po šio',data.relations.downstream,'rels',true));
    if(rrows.length) addSec('🔗','Ryšiai','#7b1fa2',rrows);

    const fails=(data.failures||[]).filter(f=>nv(f?.name));
    if(fails.length) addSec('🔴','Gedimai','#c62828',
      fails.map((f,i)=>makeRow('fail_'+i,f.name,
        `[${f.severity||'med'}] ${f.symptoms?.length||0} simpt. ${f.causes?.list?.length||0} priežast. ${f.economics?.specialist_cost_avg||0}€`,'failures',true)));
  }

  
  if(ttype==='comp') {
    const cid = data.component_id||'';
    const comp = KB.components[cid];
    const rows=[];
    if(nv(data.base?.function))         rows.push(makeRow('base.function','Funkcija',data.base.function,'base',!comp?.function));
    if(nv(data.base?.normal_operation)) rows.push(makeRow('base.normal_operation','Normalus veikimas',data.base.normal_operation,'base',!comp?.normal_operation));
    if(rows.length) addSec('🔧','Bazė','#7b1fa2',rows);

    const prows=[];
    if(data.models?.filter(m=>nv(m?.name)||m?.price_eur>0).length)
      prows.push(makeRow('models','Modeliai',data.models.map(m=>`${m.id||'?'}: ${m.name||''} (${m.price_eur||0}€)`),'pricing',!comp?.models?.length));
    if(data.pricing?.part_price>0)
      prows.push(makeRow('pricing.part','Dalies kaina',data.pricing.part_price+'€','pricing',!comp?.pricing?.part_price));
    if(data.pricing?.install_price>0)
      prows.push(makeRow('pricing.install','Montavimas',data.pricing.install_price+'€','pricing',!comp?.pricing?.install_price));
    if(prows.length) addSec('💰','Kainos / modeliai','#2e7d32',prows);

    const fails=(data.failures||[]).filter(f=>nv(f?.name));
    if(fails.length) addSec('🔴','Gedimai','#c62828',
      fails.map((f,i)=>makeRow('fail_'+i,f.name,`[${f.severity||'med'}]`,'failures',true)));
  }

  
  if(ttype==='fail') {
    const fails=(data.failures||[]).filter(f=>nv(f?.name));
    addSec('🔴','Gedimai','#c62828',
      fails.map((f,i)=>makeRow('fail_'+i,f.name,
        `[${f.severity||'med'}] ${f.symptoms?.length||0} simpt. ${f.causes?.list?.length||0} priežast.`,'failures',true)));
  }

  
  if(ttype==='pricing') {
    (data.items||[]).forEach((item,i)=>{
      const rows=[];
      if(item.models?.length) rows.push(makeRow('models','Modeliai',item.models.map(m=>`${m.id}: ${m.name||''} ${m.price_eur||0}€`),'pricing',true));
      if(item.pricing?.part_price>0) rows.push(makeRow('part','Dalies kaina',item.pricing.part_price+'€','pricing',true));
      if(item.pricing?.install_price>0) rows.push(makeRow('install','Montavimas',item.pricing.install_price+'€','pricing',true));
      if(item.maintenance_schedule?.interval_months) rows.push(makeRow('maint','Priežiūra',item.maintenance_schedule.interval_months+' mėn.','pricing',true));
      if(rows.length) addSec(item.type==='obj'?'🏗':'🔧', item.id, '#2e7d32', rows);
    });
  }

  if(stats) stats.textContent = `· ${totalFields} laukas (-ai) · ${sections.length} sekcija (-os)`;

  if(!sections.length) {
    body.innerHTML=`<div style="padding:20px;text-align:center;color:var(--td);font-size:11px">⚠ Nerasta jokių pildytų duomenų</div>`;
    document.getElementById('imp-do-btn').disabled=true;
    return;
  }

  const colorsMap={
    '📦Bazė':'#1565c0','🔧Bazė':'#7b1fa2','💰Kainos / modeliai':'#2e7d32',
    '🌿Aplinka':'#2e7d32','⚠Eksploatacijos klaidos':'#e65100',
    '🔗Ryšiai':'#7b1fa2','🔴Gedimai':'#c62828'
  };

  body.innerHTML = sections.map(sec => `
    <div style="margin-bottom:14px">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
        <span style="background:${sec.color};color:#fff;border-radius:4px;padding:2px 8px;font-size:10px;font-weight:700">${sec.icon} ${sec.title}</span>
        <span style="font-size:10px;color:var(--td)">${sec.rows.length} laukas (-ai)</span>
      </div>
      <div style="border:1px solid var(--b1);border-radius:6px;overflow:hidden">
        ${sec.rows.map((row,ri) => `
          <div style="display:grid;grid-template-columns:180px 1fr auto;align-items:center;gap:8px;padding:6px 10px;${ri>0?'border-top:1px solid var(--b1)':''}">
            <div style="font-size:10px;color:var(--td);font-weight:600">${row.label}</div>
            <textarea rows="1" class="imp-edit-field" data-path="${row.path}" data-key="${row.key}"
              style="font-size:11px;line-height:1.4;padding:3px 6px;border:1px solid var(--b1);border-radius:4px;background:${row.isNew?'#f1f8e9':'var(--bg)'};resize:vertical;min-height:26px;width:100%;font-family:inherit"
              oninput="this.style.height='';this.style.height=this.scrollHeight+'px'"
              >${_e(row.value)}</textarea>
            ${row.isNew ? '<span style="font-size:9px;background:#e8f5e9;color:#2e7d32;border-radius:3px;padding:2px 6px;white-space:nowrap;flex-shrink:0">NAUJAS</span>' : '<span></span>'}
          </div>`).join('')}
      </div>
    </div>`).join('');

  
  setTimeout(()=>{
    document.querySelectorAll('.imp-edit-field').forEach(ta=>{
      ta.style.height=''; ta.style.height=ta.scrollHeight+'px';
    });
  },50);

  document.getElementById('imp-do-btn').disabled=false;
}

function _e(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function doImport() {
  if(!_impParsed) return;
  const data = _impParsed;

  
  document.querySelectorAll('.imp-edit-field').forEach(ta => {
    const key = ta.dataset.key;
    if(key) _impEdits[key] = ta.value;
  });

  const {type: ttype, id: tid} = impGetCurrentTarget();
  const schemaType = data.schema_type || _impTplType;
  const log = [];

  const nv = v => v && String(v).trim() && !String(v).startsWith('//');

  
  if(schemaType==='obj') {
    const oid = data.object_id || tid;
    if(!oid||!KB.objects[oid]) { toast('⚠ Objektas nerastas: '+(oid||'?')); return; }
    const kb = KB.objects[oid];

    if(!kb.models) kb.models=[];
    if(!kb.maintenance_schedule) kb.maintenance_schedule={};

    
    if(nv(_impEdits['base.function']||data.base?.function))         { kb.function=_impEdits['base.function']||data.base.function; log.push('funkcija'); }
    if(nv(_impEdits['base.normal_operation']||data.base?.normal_operation)) { kb.normal_operation=_impEdits['base.normal_operation']||data.base.normal_operation; log.push('veikimas'); }
    if(data.base?.normal_signs?.length) { kb.normal_signs=data.base.normal_signs; log.push('požymiai'); }
    if(data.base?.tags?.length)         { kb.tags=data.base.tags; }

    
    if(data.models?.some(m=>nv(m?.name)||m?.price_eur>0)) {
      kb.models = data.models.filter(m=>nv(m?.name)||m?.price_eur>0);
      log.push('modeliai');
    }
    if(data.maintenance_schedule?.interval_months) {
      kb.maintenance_schedule = data.maintenance_schedule;
      log.push('priežiūra');
    }

    
    const eb=data.env_behavior||{};
    if(!kb.env_behavior) kb.env_behavior={gvl:{},soil:{}};
    if(!kb.env_behavior.gvl)  kb.env_behavior.gvl={};
    if(!kb.env_behavior.soil) kb.env_behavior.soil={};
    let envSaved=false;
    if(nv(eb.gvl?.gvl1)){kb.env_behavior.gvl.gvl1=eb.gvl.gvl1;envSaved=true;}
    if(nv(eb.gvl?.gvl2)) kb.env_behavior.gvl.gvl2=eb.gvl.gvl2;
    if(nv(eb.gvl?.gvl3)) kb.env_behavior.gvl.gvl3=eb.gvl.gvl3;
    if(nv(eb.soil?.smel)) kb.env_behavior.soil.smel=eb.soil.smel;
    if(nv(eb.soil?.mol))  kb.env_behavior.soil.mol=eb.soil.mol;
    if(nv(eb.age_effects)) kb.env_behavior.age_effects=eb.age_effects;
    if(nv(eb.reljefas))    kb.env_behavior.reljefas=eb.reljefas;
    if(envSaved) log.push('aplinka');

    
    const errs=(data.exploitation_errors||[]).filter(e=>nv(e?.klaida));
    if(errs.length) {
      if(!kb.exploitation_errors) kb.exploitation_errors=[];
      const exist=new Set(kb.exploitation_errors.map(e=>e.klaida));
      const added=errs.filter(e=>!exist.has(e.klaida));
      kb.exploitation_errors.push(...added);
      if(added.length) log.push('klaidos(+'+added.length+')');
    }

    
    if(!kb.relations) kb.relations={};
    if(data.relations?.upstream?.length)    {kb.relations.upstream=data.relations.upstream;log.push('ryšiai');}
    if(data.relations?.downstream?.length)   kb.relations.downstream=data.relations.downstream;
    if(data.relations?.depends_on?.length)   kb.relations.depends_on=data.relations.depends_on;

    
    const fc = _impAddFailures(data.failures||[], oid, 'obj');
    if(fc) log.push(fc+' gedimas(-ai)');

    if(!kb.meta) kb.meta={};
    kb.meta.updated=new Date().toISOString();
    markDirty('obj_'+oid);
    if(fc) markDirty('pct_'+oid);
    flushDirty();
    curObj=oid; curComp=null;
    renderObjList(); updateCounts(); updateJson();
    _impShowResult(oid, log, 'obj');
  }

  
  else if(schemaType==='comp') {
    const cid = data.component_id || tid;
    if(!cid||!KB.components[cid]) { toast('⚠ Komponentas nerastas: '+(cid||'?')); return; }
    const comp = KB.components[cid];

    if(nv(_impEdits['base.function']||data.base?.function))         {comp.function=_impEdits['base.function']||data.base.function;log.push('funkcija');}
    if(nv(_impEdits['base.normal_operation']||data.base?.normal_operation)) {comp.normal_operation=_impEdits['base.normal_operation']||data.base.normal_operation;log.push('veikimas');}

    if(data.models?.some(m=>nv(m?.name)||m?.price_eur>0)) {
      comp.models=data.models.filter(m=>nv(m?.name)||m?.price_eur>0);
      log.push('modeliai');
    }
    if(data.pricing) {
      comp.pricing = {...(comp.pricing||{}), ...data.pricing};
      log.push('kainos');
    }

    const fc = _impAddFailures(data.failures||[], cid, 'comp');
    if(fc) log.push(fc+' gedimas(-ai)');

    markDirty('comp_'+cid);
    
    if(fc && KB.components[cid]?.failure_modes) {
      Object.keys(KB.components[cid].failure_modes).forEach(fid => markDirty('fail_'+cid+'_'+fid));
    }
    flushDirty();
    curComp=cid; curObj=null;
    renderObjList(); updateCounts(); updateJson();
    _impShowResult(cid, log, 'comp');
  }

  
  else if(schemaType==='fail') {
    const targetId = data.target_id || tid;
    const targetType = ttype || (KB.objects[targetId]?'obj':(KB.components[targetId]?'comp':null));
    if(!targetId||!targetType) { toast('⚠ Taikinys nerastas'); return; }

    const fc = _impAddFailures(data.failures||[], targetId, targetType);
    if(fc) {
      log.push(fc+' gedimas(-ai)');
      markDirty((targetType==='obj'?'obj_':'comp_')+targetId);
      if(targetType==='obj') markDirty('pct_'+targetId);
      flushDirty();
    }
    _impShowResult(targetId, log, targetType);
  }

  
  else if(schemaType==='pricing') {
    (data.items||[]).forEach(item=>{
      if(!item.id) return;
      if(item.type==='obj' && KB.objects[item.id]) {
        const kb=KB.objects[item.id];
        if(item.models?.length) {kb.models=item.models;log.push(item.id+' modeliai');}
        if(item.maintenance_schedule) {kb.maintenance_schedule=item.maintenance_schedule;log.push(item.id+' priežiūra');}
        markDirty('obj_'+item.id);
      } else if(item.type==='comp' && KB.components[item.id]) {
        const comp=KB.components[item.id];
        if(item.models?.length) {comp.models=item.models;log.push(item.id+' modeliai');}
        if(item.pricing) {comp.pricing={...(comp.pricing||{}),...item.pricing};log.push(item.id+' kainos');}
        markDirty('comp_'+item.id);
      }
    });
    flushDirty();
    updateCounts(); renderObjList();
    _impShowResult('', log, 'pricing');
  }

  toast('✅ Importuota: '+log.join(', '));
}

function _impAddFailures(fails, targetId, targetType) {
  const nv = v => v && String(v).trim() && !String(v).startsWith('//');

  const target = targetType==='obj' ? KB.objects[targetId] : KB.components[targetId];
  if(!target) return 0;

  let added = 0;

  for(const f of fails) {
    if(!nv(f?.name)) continue;
    if(!target.failure_modes) target.failure_modes={};
    const fms = target.failure_modes;
    
    const existingNums = Object.keys(fms).map(k => {
      const m = k.match(/-F(\d+)$/); return m ? parseInt(m[1], 10) : 0;
    });
    const n = (existingNums.length ? Math.max(...existingNums) : 0) + 1;
    const fid = `${targetId}-F${String(n).padStart(3,'0')}`;

    const fm = {
      id:fid, object_id:targetId, name:f.name,
      severity:['low','med','high','critical'].includes(f.severity)?f.severity:'med',
      frequency:0, tags:f.tags||[], symptoms:f.symptoms||[],
      causes:{primary:f.causes?.primary||'', list:(f.causes?.list||[]).map(c=>({
        name:c.name||'', signs:c.signs||[], fix:c.fix||'', pct:c.pct||0,
        fix_pattern:c.fix_pattern||'', leads_to:c.leads_to||[]
      }))},
      context:{ctx_short:f.context?.ctx_short||'',ctx_long:f.context?.ctx_long||'',ctx_very_long:f.context?.ctx_very_long||''},
      prevention:f.prevention||'',
      env_modifiers:{
        gvl1:{prob_mult:String(f.env_modifiers?.gvl1?.prob_mult||'1.0')},
        gvl2:{prob_mult:String(f.env_modifiers?.gvl2?.prob_mult||'1.0')},
        smel:{prob_mult:String(f.env_modifiers?.smel?.prob_mult||'1.0')},
        mol: {prob_mult:String(f.env_modifiers?.mol?.prob_mult||'1.0')},
        old: {prob_mult:String(f.env_modifiers?.old?.prob_mult||'1.0')}
      },
      economics:{
        self_fix_cost:f.economics?.self_fix_cost||0,
        specialist_cost_avg:f.economics?.specialist_cost_avg||120,
        user_saved:f.economics?.user_saved||Math.max(0,(f.economics?.specialist_cost_avg||120)-(f.economics?.self_fix_cost||0))
      },
      relations:{also_in:[],leads_to:[]},
      meta:{confidence:f.meta?.confidence||50,first_seen:f.meta?.first_seen||'',created:new Date().toISOString(),import_source:'ai_json'}
    };

    
    const known=new Set(['name','severity','frequency','tags','symptoms','causes','context','prevention','env_modifiers','economics','relations','meta','id','object_id','//','schema_type','target_id','object_id']);
    for(const [k,v] of Object.entries(f)) { if(!known.has(k)&&v!=null) fm[k]=v; }

    fms[fid]=fm;
    markDirty('fail_'+targetId+'_'+fid);

    
    if(targetType==='obj') {
      if(!KB.percentages[targetId]) KB.percentages[targetId]={};
      KB.percentages[targetId][fid]={
        base:Math.max(5,Math.round(100/Object.keys(fms).length)),
        gvl1:parseFloat(fm.env_modifiers.gvl1.prob_mult)||1,
        gvl2:parseFloat(fm.env_modifiers.gvl2.prob_mult)||1,
        smel:parseFloat(fm.env_modifiers.smel.prob_mult)||1,
        mol: parseFloat(fm.env_modifiers.mol.prob_mult)||1,
        old: parseFloat(fm.env_modifiers.old.prob_mult)||1
      };
    }

    
    const causes=fm.causes.list.filter(c=>c.name||c.fix);
    if(causes.length) {
      let uid=0;
      const mkN=(type,text)=>({id:'n'+(uid++),type,text,branches:[],children:[],note:''});
      function bN(ci){
        if(ci>=causes.length) return null;
        const c=causes[ci];
        const fix=mkN('sprendimas','✅ '+(c.fix||c.name));
        const node=mkN('klausimas','Ar '+(c.name||'').toLowerCase()+'?');
        node.branches=['TAIP','NE'];
        node.children=[fix, bN(ci+1)||mkN('sprendimas','📞 Kreiptis į specialistą')];
        return node;
      }
      const root=mkN('start',fm.name||fid);
      root.children=[bN(0)].filter(Boolean);
      KB.decision_trees[fid]={id:fid,object_id:targetId,failure_id:fid,root};
      markDirty('tree_'+targetId+'_'+fid);
    }

    added++;
  }
  return added;
}

function _impShowResult(id, log, type) {
  const rEl=document.getElementById('imp-result');
  if(!rEl) return;
  const name = type==='obj'
    ? KB.objects_meta[id]?.name||id
    : (type==='comp' ? KB.components_meta[id]?.name||id : '');

  rEl.style.display='block';
  rEl.innerHTML=`
    <div style="background:#e8f5e9;border:2px solid #4caf50;border-radius:10px;padding:16px 20px">
      <div style="font-size:14px;font-weight:700;color:#1b5e20;margin-bottom:5px">✅ Importuota sėkmingai</div>
      ${id?`<div style="font-size:11px;color:#388e3c;margin-bottom:4px"><strong>${id}</strong>${name?' – '+name:''}</div>`:''}
      <div style="font-size:11px;color:#2e7d32;margin-bottom:10px">${log.join(' · ')}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${type==='obj'&&id ? `<button class="btn pri sm" onclick="selObj('${id}');gp('k',document.querySelector('[data-p=k]'))">→ Žinios · ${id}</button>` : ''}
        ${type==='comp'&&id ? `<button class="btn pri sm" onclick="selComp('${id}');gp('k',document.querySelector('[data-p=k]'))">→ Žinios · ${id}</button>` : ''}
        <button class="btn ghost sm" onclick="impClear()">📋 Importuoti dar vieną</button>
      </div>
    </div>`;
}

function impClear() {
  const j=document.getElementById('imp-json');
  const r=document.getElementById('imp-result');
  const p=document.getElementById('imp-preview-sec');
  const e=document.getElementById('imp-parse-err');
  if(j) j.value='';
  if(r) r.style.display='none';
  if(p) p.style.display='none';
  if(e) e.style.display='none';
  _impParsed=null; _impEdits={};
}

function _impParseJSON(text) {
  
  const cleaned = text
    .replace(/^\s*"\/\/":\s*"[^"]*",?\s*$/gm, '')
    .replace(/,(\s*[}\]])/g, '$1');
  return JSON.parse(cleaned);
}

// Iš Gedimai skirtuko
function openImportModal() {
  const t=document.querySelector('[data-p="import"]');
  if(t) gp('import',t); else toast('📥 Eikite į Import skirtuką');
}
