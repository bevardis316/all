async function renderUiLabels() {
  const wrap = document.getElementById('ui-wrap');
  if (!wrap) return;
  wrap.innerHTML = '<div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Kraunama...</div>';

  let labels = {};
  try {
    const r = await fetch('api.php?action=load_ui_labels', { credentials: 'include' });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Klaida');
    labels = d.labels || {};
  } catch (e) {
    wrap.innerHTML = '<div style="color:#e53935;padding:20px">⚠ Nepavyko užkrauti: ' + e.message + '</div>';
    return;
  }

  window._uiLabels = JSON.parse(JSON.stringify(labels));
  window._uiLabelsDirty = false;

  wrap.innerHTML = `
    <div style="max-width:900px;margin:0 auto;padding:16px">

      <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;flex-wrap:wrap">
        <div>
          <div style="font-size:16px;font-weight:700;color:var(--pri)">✏️ UI Tekstų redagavimas</div>
          <div style="font-size:11px;color:var(--td);margin-top:2px">
            Keičiate <code>ibnvs_data/meta/ui_labels.json</code> — tekstai atnaujinami realiu laiku
          </div>
        </div>
        <button id="ui-save-btn" class="btn pri" style="margin-left:auto;opacity:.4;pointer-events:none" onclick="saveUiLabels()">
          💾 Išsaugoti pakeitimus
        </button>
      </div>

      ${_uiSection('🏗 3D scenos ašių etiketės', 'axis', labels.axis || {}, {
        '@zempav': 'Žemės paviršius (viršutinis lygis)',
        '@ipgil':  'Įprastas gylis (vidurinis lygis)',
        '@gilu':   'Labai giliai (apatinis lygis)'
      })}

      ${_uiSection('💬 Nurodymai 3D scenoje', 'scene', labels.scene || {}, {
        'select_gvl':    'Tekstas kai dar nepasirinktas GVL',
        'select_first':  'Tekstas kai sistema tuščia',
        'select_system': 'Sistemos pasirinkimo mygtuko tekstas'
      })}

      ${_uiSection('ℹ️ Info blokas — žingsnių tekstai', 'info', labels.info || {}, {
        'gvl':       '① Kai GVL dar nepasirinktas (pirmas ekranas)',
        'gvl_high':  '② Pasirinkus: Aukštas GVL — kodėl infiltracija neveiks',
        'gvl_low':   '② Pasirinkus: Žemas GVL — ką rekomenduoti',
        'gvl_none':  '② Pasirinkus: GVL nėra — puikios sąlygos',
        'soil_sand': '③ Pasirinkus: Smėlis / Žvyras — ką tai lemia',
        'soil_clay': '③ Pasirinkus: Molis / Priemolis — kodėl infiltracija neveiks',
        'depth':     '④ GVL+GT pasirinkti, sistema dar tuščia'
      })}

      ${_uiSection('📋 Meniu etiketės', 'menu', labels.menu || {}, {
        'gvl_label':   'Meniu antraštė — GVL pasirinkimas',
        'soil_label':  'Meniu antraštė — grunto tipas',
        'soil_sand':   'Smėlio grunto mygtuko tekstas',
        'soil_clay':   'Molio grunto mygtuko tekstas',
        'depth_label': 'Gylio pasirinkimo antraštė'
      })}

      ${_uiSection('🔢 Sistemų tipų pavadinimai', 'sys', labels.sys || {}, {
        '1':'Sistema 1','2':'Sistema 2','3':'Sistema 3','4':'Sistema 4',
        '5':'Sistema 5','6':'Sistema 6','7':'Sistema 7','8':'Sistema 8',
        '9':'Sistema 9','10':'Sistema 10','11':'Sistema 11','12':'Sistema 12'
      })}

      ${_uiObjSection(labels.objects || {})}

      ${_uiStyleSection(labels.style || {})}

    </div>
  `;

  wrap.querySelectorAll('[data-ui-key]').forEach(el => {
    el.addEventListener('input', _uiMarkDirty);
    el.addEventListener('change', _uiMarkDirty);
  });
}

function _uiSection(title, group, data, descriptions) {
  const rows = Object.entries(descriptions).map(([key, desc]) => {
    const val = (data[key] !== undefined) ? data[key] : '';
    const isLong = val.length > 80 || desc.includes('Paaiškinimas');
    const inputEl = isLong
      ? `<textarea data-ui-key="${group}.${key}" rows="3" style="width:100%;padding:7px 10px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:11px;font-family:inherit;background:var(--bg);color:var(--text);resize:vertical;line-height:1.5">${_esc(val)}</textarea>`
      : `<input type="text" data-ui-key="${group}.${key}" value="${_esc(val)}" style="width:100%;padding:7px 10px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:11px;font-family:inherit;background:var(--bg);color:var(--text)">`;
    return `
      <div style="margin-bottom:14px">
        <div style="font-size:10px;font-weight:700;color:var(--td);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px">
          ${_esc(key)} <span style="font-weight:400;text-transform:none;letter-spacing:0">— ${_esc(desc)}</span>
        </div>
        ${inputEl}
      </div>`;
  }).join('');

  return `
    <div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);overflow:hidden;margin-bottom:16px">
      <div style="padding:10px 16px;background:var(--s2);border-bottom:1px solid var(--b1);font-size:12px;font-weight:700;color:var(--pri)">
        ${title}
      </div>
      <div style="padding:16px">${rows}</div>
    </div>`;
}

function _uiObjSection(objects) {
  const objIds = Object.keys(objects);
  if (!objIds.length) return '';

  const rows = objIds.map(oid => {
    const obj = objects[oid] || {};
    return `
      <div style="background:var(--bg);border:1px solid var(--b1);border-radius:var(--r);padding:12px;margin-bottom:10px">
        <div style="font-size:11px;font-weight:700;color:var(--pri);margin-bottom:8px;font-family:'JetBrains Mono',monospace">${_esc(oid)}</div>
        <div style="display:grid;grid-template-columns:1fr 1fr 70px;gap:8px">
          <div>
            <div style="font-size:9px;font-weight:700;color:var(--td);text-transform:uppercase;margin-bottom:3px">Pavadinimas (meniu)</div>
            <input type="text" data-ui-key="objects.${oid}.name" value="${_esc(obj.name || '')}"
              style="width:100%;padding:6px 9px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:11px;font-family:inherit;background:var(--s1);color:var(--text)">
          </div>
          <div>
            <div style="font-size:9px;font-weight:700;color:var(--td);text-transform:uppercase;margin-bottom:3px">Aprašymas (info blokas)</div>
            <textarea data-ui-key="objects.${oid}.aprasymas" rows="2"
              style="width:100%;padding:6px 9px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:11px;font-family:inherit;background:var(--s1);color:var(--text);resize:vertical;line-height:1.4">${_esc(obj.aprasymas || '')}</textarea>
          </div>
          <div>
            <div style="font-size:9px;font-weight:700;color:var(--td);text-transform:uppercase;margin-bottom:3px">Trumpinimas</div>
            <input type="text" data-ui-key="objects.${oid}.trumpinimas" value="${_esc(obj.trumpinimas || '')}"
              style="width:100%;padding:6px 9px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:11px;font-family:inherit;background:var(--s1);color:var(--text);text-transform:uppercase"
              maxlength="6">
          </div>
        </div>
      </div>`;
  }).join('');

  return `
    <div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);overflow:hidden;margin-bottom:16px">
      <div style="padding:10px 16px;background:var(--s2);border-bottom:1px solid var(--b1);font-size:12px;font-weight:700;color:var(--pri)">
        🏗 Objektų tekstai (3D scenoje ir meniu)
      </div>
      <div style="padding:16px">${rows}</div>
    </div>`;
}

function _uiStyleSection(data) {
  var fonts = [
    ['inherit',               'Sisteminis (numatytasis)'],
    ["'Inter', sans-serif",   'Inter'],
    ["'Roboto', sans-serif",  'Roboto'],
    ["'Open Sans', sans-serif",'Open Sans'],
    ["'Lato', sans-serif",    'Lato'],
    ["'Nunito', sans-serif",  'Nunito'],
    ["'Georgia', serif",      'Georgia (serif)'],
    ["'Courier New', monospace", 'Courier (monospace)']
  ];

  var current = data.info_font_family || 'inherit';
  var opts = fonts.map(function(f) {
    var sel = current === f[0] ? ' selected' : '';
    return '<option value="' + _esc(f[0]) + '"' + sel + '>' + _esc(f[1]) + '</option>';
  }).join('');

  return `
    <div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);overflow:hidden;margin-bottom:16px">
      <div style="padding:10px 16px;background:var(--s2);border-bottom:1px solid var(--b1);font-size:12px;font-weight:700;color:var(--pri)">
        🎨 Info bloko stilius
      </div>
      <div style="padding:16px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
        <div>
          <div style="font-size:10px;font-weight:700;color:var(--td);text-transform:uppercase;margin-bottom:4px">Šrifto dydis</div>
          <input type="text" data-ui-key="style.info_font_size"
            value="${_esc(data.info_font_size || '13px')}"
            placeholder="pvz. 14px"
            style="width:100%;padding:7px 10px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:11px;font-family:inherit;background:var(--bg);color:var(--text)">
        </div>
        <div>
          <div style="font-size:10px;font-weight:700;color:var(--td);text-transform:uppercase;margin-bottom:4px">Šriftas</div>
          <select data-ui-key="style.info_font_family"
            style="width:100%;padding:7px 10px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:11px;font-family:inherit;background:var(--bg);color:var(--text)">
            ${opts}
          </select>
        </div>
        <div>
          <div style="font-size:10px;font-weight:700;color:var(--td);text-transform:uppercase;margin-bottom:4px">Eilučių tarpas</div>
          <input type="text" data-ui-key="style.info_line_height"
            value="${_esc(data.info_line_height || '1.6')}"
            placeholder="pvz. 1.5"
            style="width:100%;padding:7px 10px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:11px;font-family:inherit;background:var(--bg);color:var(--text)">
        </div>
      </div>
    </div>`;
}


function _uiMarkDirty() {
  window._uiLabelsDirty = true;
  const btn = document.getElementById('ui-save-btn');
  if (btn) { btn.style.opacity = '1'; btn.style.pointerEvents = 'auto'; }
}

async function saveUiLabels() {
  const btn = document.getElementById('ui-save-btn');
  if (btn) { btn.textContent = '⏳ Saugojama...'; btn.style.opacity = '.6'; btn.style.pointerEvents = 'none'; }

  const labels = JSON.parse(JSON.stringify(window._uiLabels));

  document.querySelectorAll('[data-ui-key]').forEach(el => {
    const path = el.getAttribute('data-ui-key').split('.');
    let obj = labels;
    for (let i = 0; i < path.length - 1; i++) {
      if (!obj[path[i]]) obj[path[i]] = {};
      obj = obj[path[i]];
    }
    obj[path[path.length - 1]] = el.value;
  });

  try {
    const r = await fetch('api.php?action=save_ui_labels', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': window._csrfToken || '' },
      body: JSON.stringify({ labels })
    });
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Klaida');

    window._uiLabels = labels;
    window._uiLabelsDirty = false;
    // Atnaujinti versiją localStorage kad kon/ žinotų perkrauti
    try { localStorage.setItem('ui_labels_ver', String(labels.version || Date.now())); } catch(e) {}

    if (btn) {
      btn.textContent = '✅ Išsaugota';
      btn.style.opacity = '.4';
      btn.style.pointerEvents = 'none';
      setTimeout(() => { if (btn) btn.textContent = '💾 Išsaugoti pakeitimus'; }, 3000);
    }
    if (typeof toast === 'function') toast('✓ UI tekstai išsaugoti');

  } catch (e) {
    if (btn) {
      btn.textContent = '⚠ Klaida — bandykite dar kartą';
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'auto';
    }
    if (typeof toast === 'function') toast('⚠ Klaida: ' + e.message);
  }
}

function _esc(s) {
  return (s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
