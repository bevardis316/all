function renderPackages(obj, kb) {
  const packages = kb.packages || [];
  const models = kb.models || [];
  
  const comps = Object.entries(KB.components || {})
    .filter(([cid, c]) => {
      const meta = KB.components_meta[cid];
      const pid = meta?.parent_id || c.parent_id;
      return pid === obj.id;
    })
    .map(([cid, c]) => ({id: cid, name: c.name || cid, models: c.models || []}));

  const pkgRows = packages.map((pkg, pi) => {
    const objMod = models.find(m => m.id === pkg.obj_model_id);
    const compRows = comps.map(comp => {
      const selIdx = pkg.comp_selections?.[comp.id] ?? -1;
      const opts = comp.models.map((m, mi) =>
        `<option value="${mi}" ${selIdx === mi ? 'selected' : ''}>${m.name || '–'}${m.price_eur ? ' · ' + m.price_eur + '€' : ''}</option>`
      ).join('');
      return `<div class="pkg-comp-row">
        <span class="pkg-comp-name">${comp.name}</span>
        <select class="pkg-comp-sel" data-pi="${pi}" data-cid="${comp.id}" onchange="pkgCompChange(${pi},'${comp.id}',this.value)">
          <option value="-1">— nenurodytas —</option>${opts}
        </select>
      </div>`;
    }).join('');

    return `<div class="pkg-card" id="pkg-card-${pi}">
      <div class="pkg-card-head">
        <span class="pkg-num">${pi + 1}</span>
        <input type="text" class="pkg-name-inp" data-pi="${pi}" value="${pkg.name || ''}" placeholder="Paketo pavadinimas" oninput="pkgNameChange(${pi},this.value)" style="flex:1;font-weight:600">
        <button class="rm" onclick="rmPackage(${pi})" title="Ištrinti paketą">×</button>
      </div>
      <div class="pkg-obj-row">
        <span style="font-size:11px;color:var(--td);min-width:100px">Įrenginio modelis:</span>
        <select class="pkg-obj-sel" data-pi="${pi}" onchange="pkgObjModelChange(${pi},this.value)">
          <option value="">— pasirinkite —</option>
          ${models.map(m => `<option value="${m.id}" ${pkg.obj_model_id === m.id ? 'selected' : ''}>${m.name || m.id}${m.price_eur ? ' · ' + m.price_eur + '€' : ''}</option>`).join('')}
        </select>
      </div>
      ${comps.length ? `<div class="pkg-comps-label">Komponentų modeliai:</div>${compRows}` : '<div style="font-size:10px;color:var(--td);padding:4px 0">Šiam objektui komponentų nėra.</div>'}
    </div>`;
  }).join('');

  return `
  <div class="sec">
    <div class="sec-h" onclick="this.closest('.sec').classList.toggle('col')">
      <h3>📦 Komplektai vartotojui</h3>
      <span style="font-size:10px;color:var(--td)">Adminas sudaro komplektus — vartotojas konstruktoriuje renkasi tik iš šių</span>
      <span class="caret">▾</span>
    </div>
    <div class="sec-b">
      <div style="font-size:11px;color:var(--td);margin-bottom:10px;padding:8px;background:var(--s2);border-radius:var(--r);line-height:1.6">
        Kiekvienam komplektui: pasirinkite įrenginio modelį ir kiekvieno komponento modelį.
        Vartotojui konstruktoriuje bus rodomi tik šių komplektų pavadinimai — jis renkasi vieną.
      </div>
      <div id="pkg-list">${pkgRows || '<div style="font-size:11px;color:var(--td);padding:8px 0">Nėra komplektų. Spusk „＋ Komplektas".</div>'}</div>
      <div style="margin-top:10px;display:flex;gap:8px">
        <button class="btn grn sm" onclick="addPackage()">＋ Komplektas</button>
        <button class="btn pri sm" onclick="savePackagesAndSync()">💾 Išsaugoti komplektus</button>
      </div>
    </div>
  </div>`;
}

function addPackage() {
  const kb = KB.objects[curObj]; if (!kb) return;
  if (!kb.packages) kb.packages = [];
  savePackages(); 
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const newId = 'pkg-' + letters[kb.packages.length % 26] + (kb.packages.length >= 26 ? Math.floor(kb.packages.length/26) : '');
  kb.packages.push({id: newId, name: '', obj_model_id: '', comp_selections: {}});
  document.getElementById('pkg-list').innerHTML = renderPackagesInner(kb);
  markDirty('obj_' + curObj);
}

function rmPackage(pi) {
  const kb = KB.objects[curObj]; if (!kb) return;
  savePackages();
  kb.packages.splice(pi, 1);
  document.getElementById('pkg-list').innerHTML = renderPackagesInner(kb);
  markDirty('obj_' + curObj);
}

function pkgNameChange(pi, val) {
  const kb = KB.objects[curObj]; if (!kb?.packages?.[pi]) return;
  kb.packages[pi].name = val;
}
function pkgObjModelChange(pi, val) {
  const kb = KB.objects[curObj]; if (!kb?.packages?.[pi]) return;
  kb.packages[pi].obj_model_id = val;
  markDirty('obj_' + curObj);
}
function pkgCompChange(pi, cid, val) {
  const kb = KB.objects[curObj]; if (!kb?.packages?.[pi]) return;
  if (!kb.packages[pi].comp_selections) kb.packages[pi].comp_selections = {};
  kb.packages[pi].comp_selections[cid] = parseInt(val);
  markDirty('obj_' + curObj);
}

function savePackages() {
  const kb = KB.objects[curObj]; if (!kb) return;
  
  document.querySelectorAll('.pkg-name-inp').forEach(el => {
    const pi = parseInt(el.dataset.pi);
    if (kb.packages?.[pi]) kb.packages[pi].name = el.value.trim();
  });
  document.querySelectorAll('.pkg-obj-sel').forEach(el => {
    const pi = parseInt(el.dataset.pi);
    if (kb.packages?.[pi]) kb.packages[pi].obj_model_id = el.value;
  });
  document.querySelectorAll('.pkg-comp-sel').forEach(el => {
    const pi = parseInt(el.dataset.pi);
    const cid = el.dataset.cid;
    if (kb.packages?.[pi]) {
      if (!kb.packages[pi].comp_selections) kb.packages[pi].comp_selections = {};
      kb.packages[pi].comp_selections[cid] = parseInt(el.value);
    }
  });
}

function savePackagesAndSync() {
  savePackages();
  markDirty('obj_' + curObj);
  flushDirty();
  toast('📦 Komplektai išsaugoti');
}

function renderPackagesInner(kb) {
  const obj = KB.objects_meta[curObj]; if (!obj) return '';
  const packages = kb.packages || [];
  const models = kb.models || [];
  const comps = Object.entries(KB.components || {})
    .filter(([cid]) => {
      const meta = KB.components_meta[cid];
      return (meta?.parent_id || KB.components[cid]?.parent_id) === obj.id;
    })
    .map(([cid, c]) => ({id: cid, name: c.name || cid, models: c.models || []}));

  if (!packages.length) return '<div style="font-size:11px;color:var(--td);padding:8px 0">Nėra komplektų. Spusk „＋ Komplektas".</div>';

  return packages.map((pkg, pi) => {
    const compRows = comps.map(comp => {
      const selIdx = pkg.comp_selections?.[comp.id] ?? -1;
      const opts = comp.models.map((m, mi) =>
        `<option value="${mi}" ${selIdx === mi ? 'selected' : ''}>${m.name || '–'}${m.price_eur ? ' · ' + m.price_eur + '€' : ''}</option>`
      ).join('');
      return `<div class="pkg-comp-row">
        <span class="pkg-comp-name">${comp.name}</span>
        <select class="pkg-comp-sel" data-pi="${pi}" data-cid="${comp.id}" onchange="pkgCompChange(${pi},'${comp.id}',this.value)">
          <option value="-1">— nenurodytas —</option>${opts}
        </select>
      </div>`;
    }).join('');

    return `<div class="pkg-card" id="pkg-card-${pi}">
      <div class="pkg-card-head">
        <span class="pkg-num">${pi + 1}</span>
        <input type="text" class="pkg-name-inp" data-pi="${pi}" value="${pkg.name || ''}" placeholder="Paketo pavadinimas" oninput="pkgNameChange(${pi},this.value)" style="flex:1;font-weight:600">
        <button class="rm" onclick="rmPackage(${pi})" title="Ištrinti">×</button>
      </div>
      <div class="pkg-obj-row">
        <span style="font-size:11px;color:var(--td);min-width:100px">Įrenginio modelis:</span>
        <select class="pkg-obj-sel" data-pi="${pi}" onchange="pkgObjModelChange(${pi},this.value)">
          <option value="">— pasirinkite —</option>
          ${models.map(m => `<option value="${m.id}" ${pkg.obj_model_id === m.id ? 'selected' : ''}>${m.name || m.id}${m.price_eur ? ' · ' + m.price_eur + '€' : ''}</option>`).join('')}
        </select>
      </div>
      ${comps.length ? `<div class="pkg-comps-label">Komponentų modeliai:</div>${compRows}` : ''}
    </div>`;
  }).join('');
}
