let _mapObj = null;
let _mapMarkers = {};
let _pendingData = [];
let _approvedData = [];
let _activeEditId = null;

async function mapPageInit() {
  await Promise.all([mapLoadPending(), mapLoadApproved()]);
  mapRenderPending();
  mapRenderApproved();
  if (window.google && window.google.maps) {
    mapInitGoogleMap();
  }
}

async function mapLoadPending() {
  const d = await apiPost('map_pending', {});
  _pendingData = d.pending || [];
}

async function mapLoadApproved() {
  const d = await apiPost('map_list', {});
  _approvedData = d.entries || [];
}

function mapRenderPending() {
  const el = document.getElementById('mapPendingList');
  if (!el) return;
  if (!_pendingData.length) {
    el.innerHTML = '<div style="color:#888;font-size:13px;padding:16px">Naujų paraiškų nėra</div>';
    return;
  }
  const badge = document.getElementById('mapPendingBadge');
  if (badge) badge.textContent = _pendingData.length;

  el.innerHTML = _pendingData.map(e => `
    <div class="map-card pending" id="pcard_${e.id}">
      <div class="map-card-header">
        <strong>${esc(e.name)}</strong>
        <span class="map-badge new">Nauja</span>
      </div>
      <div class="map-card-body">
        <div>📍 ${esc(e.city)} &nbsp; 📞 ${esc(e.tel)}</div>
        ${e.type ? `<div>🔧 ${esc(e.type)}</div>` : ''}
        ${e.info ? `<div style="color:#6b7280;font-size:12px;margin-top:4px">${esc(e.info)}</div>` : ''}
        <div style="color:#9ca3af;font-size:11px;margin-top:4px">${e.created_at}</div>
      </div>
      <div class="map-card-actions">
        <div class="map-coords-row">

          <input type="number" min="1" max="3650" value="365" placeholder="Dienų" id="pdays_${e.id}" style="width:80px">
          <input type="number" min="0" step="0.01" value="0" placeholder="€" id="peur_${e.id}" style="width:70px">
        </div>
        <div style="margin-top:4px;font-size:11px;color:#9ca3af">Koordinates galite paimti iš Google Maps (dešiniuoju pelės mygtuku → "Kopijuoti koordinates")</div>
        <div style="display:flex;gap:8px;margin-top:8px">
          <button class="map-btn approve" onclick="mapApprove('${e.id}')">✓ Patvirtinti</button>
          <button class="map-btn reject" onclick="mapReject('${e.id}')">✗ Atmesti</button>
        </div>
      </div>
    </div>
  `).join('');
}

function mapRenderApproved() {
  const el = document.getElementById('mapApprovedList');
  if (!el) return;
  if (!_approvedData.length) {
    el.innerHTML = '<div style="color:#888;font-size:13px;padding:16px">Patvirtintų įrašų nėra</div>';
    return;
  }
  const now = Date.now() / 1000;
  el.innerHTML = _approvedData.map(e => {
    const exp = e.expires_at ? new Date(e.expires_at * 1000).toLocaleDateString('lt') : '—';
    const expired = e.expires_at && e.expires_at < now;
    return `
    <div class="map-card approved ${expired ? 'expired' : ''}" id="acard_${e.id}">
      <div class="map-card-header">
        <strong>${esc(e.name)}</strong>
        <span class="map-badge ${expired ? 'exp' : 'ok'}">${expired ? 'Pasibaigė' : 'Aktyvus'}</span>
      </div>
      <div class="map-card-body">
        <div>📍 ${esc(e.city)} &nbsp; 📞 ${esc(e.tel)}</div>
        <div style="font-size:12px;color:#6b7280">🌐 ${e.lat||'?'}, ${e.lng||'?'} &nbsp; ⏰ iki ${exp} &nbsp; 💶 ${e.value_eur||0} €</div>
        ${e.info ? `<div style="color:#6b7280;font-size:12px;margin-top:2px">${esc(e.info)}</div>` : ''}
      </div>
      <div class="map-card-actions" style="display:flex;gap:8px">
        <button class="map-btn edit" onclick="mapOpenEdit('${e.id}')">✎ Redaguoti</button>
        <button class="map-btn reject" onclick="mapDeleteApproved('${e.id}')">✗ Ištrinti</button>
      </div>
    </div>`;
  }).join('');
}

async function mapApprove(id) {
  const days = parseInt(document.getElementById('pdays_' + id)?.value || '365');
  const eur  = parseFloat(document.getElementById('peur_' + id)?.value || '0');

  // Rasti miestą iš pending duomenų
  const entry = _pendingData.find(e => e.id === id);
  const city  = entry?.city || '';

  // Geocoding naršyklėje
  let lat = 0, lng = 0;
  if (city) {
    try {
      const r = await fetch('https://nominatim.openstreetmap.org/search?q='+encodeURIComponent(city+', Lietuva')+'&format=json&limit=1&countrycodes=lt',{headers:{'Accept-Language':'lt'}});
      const d = await r.json();
      if (d.length) { lat=+d[0].lat; lng=+d[0].lon; }
    } catch(e){}
  }

  await apiPost('map_approve', {id, days, value_eur: eur, lat, lng});
  await Promise.all([mapLoadPending(), mapLoadApproved()]);
  mapRenderPending();
  mapRenderApproved();
  mapRefreshMarkers();
}

async function mapReject(id) {
  if (!confirm('Atmesti šią paraišką?')) return;
  await apiPost('map_reject', {id});
  await mapLoadPending();
  mapRenderPending();
}

async function mapDeleteApproved(id) {
  if (!confirm('Ištrinti iš žemėlapio?')) return;
  await apiPost('map_delete', {id});
  await mapLoadApproved();
  mapRenderApproved();
  mapRefreshMarkers();
}

function mapOpenEdit(id) {
  const e = _approvedData.find(x => x.id === id);
  if (!e) return;
  _activeEditId = id;
  document.getElementById('editName').textContent = e.name;

  document.getElementById('editDays').value = e.expires_at ? Math.round((e.expires_at - Date.now()/1000) / 86400) : 365;
  document.getElementById('editEur').value  = e.value_eur || 0;
  document.getElementById('editInfo').value = e.info || '';
  document.getElementById('mapEditModal').style.display = 'flex';
}

function mapCloseEdit() {
  document.getElementById('mapEditModal').style.display = 'none';
  _activeEditId = null;
}

async function mapSaveEdit() {
  if (!_activeEditId) return;

  const days = parseInt(document.getElementById('editDays').value);
  const eur  = parseFloat(document.getElementById('editEur').value);
  const info = document.getElementById('editInfo').value;
  await apiPost('map_update', {id: _activeEditId, days, value_eur: eur, info});
  mapCloseEdit();
  await mapLoadApproved();
  mapRenderApproved();
  mapRefreshMarkers();
}

function mapInitGoogleMap() {
  if (_mapObj) return;
  const container = document.getElementById('adminMapContainer');
  if (!container) return;
  _mapObj = new google.maps.Map(container, {
    center: {lat: 55.17, lng: 23.89},
    zoom: 7,
    mapTypeControl: false,
    streetViewControl: false,
  });
  mapRefreshMarkers();
}

function mapRefreshMarkers() {
  if (!_mapObj) return;
  Object.values(_mapMarkers).forEach(m => m.setMap(null));
  _mapMarkers = {};
  _approvedData.forEach(e => {
    if (!e.lat || !e.lng) return;
    const m = new google.maps.Marker({
      position: {lat: parseFloat(e.lat), lng: parseFloat(e.lng)},
      map: _mapObj,
      title: e.name,
    });
    _mapMarkers[e.id] = m;
  });
}

function esc(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Pridėti naują įrašą tiesiai (be paraiškos) ──────────────────
function mapShowAddNew() {
  const html = `
    <div style="position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center;padding:20px" id="map-add-overlay" onclick="if(event.target.id==='map-add-overlay')mapCloseAddNew()">
      <div style="background:#fff;border-radius:12px;padding:24px;width:100%;max-width:440px;max-height:90vh;overflow-y:auto">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
          <h3 style="font-size:15px;color:#1b5e20">+ Pridėti naują įrašą</h3>
          <button onclick="mapCloseAddNew()" style="background:none;border:none;font-size:20px;cursor:pointer;color:#999">✕</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          <div><label style="font-size:11px;font-weight:700;color:#666;display:block;margin-bottom:4px">VARDAS / ĮMONĖ *</label>
            <input id="an_name" type="text" maxlength="80" style="width:100%;padding:8px 10px;border:1.5px solid #ddd;border-radius:6px;font-size:13px"></div>
          <div><label style="font-size:11px;font-weight:700;color:#666;display:block;margin-bottom:4px">TELEFONAS *</label>
            <input id="an_tel" type="tel" maxlength="20" style="width:100%;padding:8px 10px;border:1.5px solid #ddd;border-radius:6px;font-size:13px"></div>
          <div><label style="font-size:11px;font-weight:700;color:#666;display:block;margin-bottom:4px">MIESTAS *</label>
            <input id="an_city" type="text" maxlength="60" style="width:100%;padding:8px 10px;border:1.5px solid #ddd;border-radius:6px;font-size:13px"></div>
          <div><label style="font-size:11px;font-weight:700;color:#666;display:block;margin-bottom:4px">VEIKLOS SRITIS</label>
            <div id="an_types" style="display:flex;flex-wrap:wrap;gap:8px;margin-top:4px">
              <button type="button" data-val="montavimas" onclick="this.classList.toggle('ton')" style="padding:6px 14px;border:1.5px solid #c8e6c9;border-radius:20px;background:#f9fbe7;color:#1b5e20;font-size:12px;font-weight:600;cursor:pointer;transition:all .15s">Montavimas</button>
              <button type="button" data-val="aptarnavimas" onclick="this.classList.toggle('ton')" style="padding:6px 14px;border:1.5px solid #c8e6c9;border-radius:20px;background:#f9fbe7;color:#1b5e20;font-size:12px;font-weight:600;cursor:pointer;transition:all .15s">Aptarnavimas</button>
              <button type="button" data-val="gamintojas" onclick="this.classList.toggle('ton')" style="padding:6px 14px;border:1.5px solid #c8e6c9;border-radius:20px;background:#f9fbe7;color:#1b5e20;font-size:12px;font-weight:600;cursor:pointer;transition:all .15s">Gamintojas</button>
              <button type="button" data-val="pardavejas" onclick="this.classList.toggle('ton')" style="padding:6px 14px;border:1.5px solid #c8e6c9;border-radius:20px;background:#f9fbe7;color:#1b5e20;font-size:12px;font-weight:600;cursor:pointer;transition:all .15s">Pardavėjas</button>
            </div>
            <style>.ton{background:#1b5e20!important;color:#fff!important;border-color:#1b5e20!important}</style></div>
          <div><label style="font-size:11px;font-weight:700;color:#666;display:block;margin-bottom:4px">APRAŠYMAS</label>
            <textarea id="an_info" maxlength="300" rows="2" style="width:100%;padding:8px 10px;border:1.5px solid #ddd;border-radius:6px;font-size:13px;resize:vertical"></textarea></div>

          <div><label style="font-size:11px;font-weight:700;color:#666;display:block;margin-bottom:4px">GALIOJA (dienų)</label>
            <input id="an_days" type="number" min="1" max="3650" value="365" style="width:100%;padding:8px 10px;border:1.5px solid #ddd;border-radius:6px;font-size:13px"></div>
          <div id="an_err" style="color:#c62828;font-size:12px;display:none"></div>
          <button onclick="mapSubmitAddNew()" style="padding:10px;background:#1b5e20;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;margin-top:4px">✓ Pridėti į žemėlapį</button>
        </div>
      </div>
    </div>`;
  document.body.insertAdjacentHTML('beforeend', html);
}

function mapCloseAddNew() {
  document.getElementById('map-add-overlay')?.remove();
}

async function mapSubmitAddNew() {
  const errEl = document.getElementById('an_err');
  errEl.style.display = 'none';
  const name = document.getElementById('an_name').value.trim();
  const tel  = document.getElementById('an_tel').value.trim();
  const city = document.getElementById('an_city').value.trim();
  const types = Array.from(document.querySelectorAll('#an_types button.ton')).map(b=>b.dataset.val);
  const info = document.getElementById('an_info').value.trim();
  const days = parseInt(document.getElementById('an_days').value) || 365;

  if (!name || !tel || !city) { errEl.textContent = 'Užpildykite privalomus laukus (*)'; errEl.style.display='block'; return; }

  // Geocoding naršyklėje
  let lat = 0, lng = 0;
  try {
    const geo = await fetch('https://nominatim.openstreetmap.org/search?q='+encodeURIComponent(city+', Lietuva')+'&format=json&limit=1&countrycodes=lt',{headers:{'Accept-Language':'lt'}});
    const gd = await geo.json();
    if (gd.length) { lat=+gd[0].lat; lng=+gd[0].lon; }
  } catch(e){}

  if (!lat || !lng) { errEl.textContent='Nepavyko rasti miesto koordinačių. Patikrinkite miesto pavadinimą.'; errEl.style.display='block'; return; }

  try {
    const d = await apiPost('map_add_direct', {name, tel, city, types, type: types[0]||'', info, days, lat, lng});
    if (!d.ok) throw new Error(d.error || 'Klaida');
    mapCloseAddNew();
    await Promise.all([mapLoadPending(), mapLoadApproved()]);
    mapRenderPending();
    mapRenderApproved();
    mapRefreshMarkers();
  } catch(e) {
    errEl.textContent = e.message; errEl.style.display='block';
  }
}
