function getDiagSymsFromKB() {
  const freq={};
  Object.values(KB.objects).forEach(kb=>Object.values(kb.failure_modes||{}).forEach(fm=>{
    (fm.symptoms||[]).forEach(s=>{if(s) freq[s]=(freq[s]||0)+1;});
  }));
  if(!Object.keys(freq).length) return {};
  const catMap={};
  Object.entries(KB.tag_categories||{}).forEach(([cat,data])=>{
    (data.tags||[]).forEach(t=>{if(freq[t]!==undefined) catMap[t]=cat;});
  });
  const result={};
  Object.entries(freq).sort((a,b)=>b[1]-a[1]).forEach(([sym,cnt])=>{
    const cat=catMap[sym]||'Iš žinių bazės';
    if(!result[cat]) result[cat]=[];
    result[cat].push({sym,cnt});
  });
  const sorted={};
  Object.keys(result).filter(k=>k!=='Iš žinių bazės').forEach(k=>sorted[k]=result[k]);
  if(result['Iš žinių bazės']) sorted['Iš žinių bazės']=result['Iš žinių bazės'];
  return sorted;
}

function initDiag() {
  renderDiagSyms();
  const of=document.getElementById('diag-obj-filter');
  if(of) of.innerHTML=`<option value="">Visi objektai</option>`+Object.keys(KB.objects_meta).map(id=>`<option value="${id}">${id} – ${KB.objects_meta[id].name}</option>`).join('');
  const sf=document.getElementById('diag-sys-filter');
  if(sf) sf.innerHTML=`<option value="">Visos sistemos</option>`+TECH.sistemu_tipai.map(t=>`<option value="${t.id}">${t.id}. ${t.grandine.join('→')}</option>`).join('');
  renderDiagSelBar();
}

function renderDiagSyms() {
  const area=document.getElementById('diag-sym-area'); if(!area) return;
  const cats=getDiagSymsFromKB();
  if(!Object.keys(cats).length) {
    area.innerHTML=`<div style="padding:30px;text-align:center;color:var(--td)">
      <div style="font-size:24px;margin-bottom:10px">📋</div>
      <div style="font-size:12px;font-weight:600;margin-bottom:6px">Simptomų dar nėra</div>
      <div style="font-size:11px;line-height:1.6">Pirmiausia užpildyk gedimų korteles:<br>◈ Žinios → objektas → Gedimai → ② Simptomai</div>
    </div>`;
    return;
  }
  area.innerHTML=Object.entries(cats).map(([cat,syms])=>`
    <div class="sym-cat">
      <div class="sym-cat-lbl">${cat} <span style="font-size:9px;opacity:.6">(${syms.length})</span></div>
      <div class="sym-tiles">${syms.map(({sym,cnt})=>`
        <div class="sym-tile ${diagSel.includes(sym)?'sel':''}" onclick="toggleDiagSym('${sym.replace(/'/g,"\\\'")}',this)">
          ${sym}${cnt>1?`<span class="sym-cnt">×${cnt}</span>`:''}
        </div>`).join('')}</div>
    </div>`).join('');
}

function toggleDiagSym(sym, el) {
  if(diagSel.includes(sym)){diagSel=diagSel.filter(s=>s!==sym);if(el)el.classList.remove('sel');}
  else{diagSel.push(sym);if(el)el.classList.add('sel');}
  renderDiagSelBar();
  if(diagSel.length) runDiag();
}

function setDiagEnv(key, val, btn) {
  if(diagEnv[key]===val){diagEnv[key]='';btn.classList.remove('on');}
  else{
    diagEnv[key]=val;
    document.querySelectorAll(`#diag-env .env-btn`).forEach(b=>{if(b.getAttribute('onclick')?.includes(`'${key}'`))b.classList.remove('on');});
    btn.classList.add('on');
  }
  if(diagSel.length) runDiag();
}

function renderDiagSelBar() {
  const chips=document.getElementById('diag-sel-chips'); if(!chips) return;
  if(!diagSel.length){chips.innerHTML=`<span style="opacity:.5;font-size:10px">Nėra – pasirink kairėje</span>`;return;}
  chips.innerHTML=diagSel.map(s=>`<div class="sch">${s}<span onclick="toggleDiagSym('${s.replace(/'/g,"\\'")}',null)" style="opacity:.6;margin-left:3px;cursor:pointer">×</span></div>`).join('');
}

function runDiag() {
  if(!diagSel.length){
    document.getElementById('diag-results').innerHTML=`<div class="diag-no-sel"><div class="ico">🔍</div><h3>Pasirink simptomus</h3><p>Spustelėk simptomus kairėje</p></div>`;
    return;
  }
  const objFilter=document.getElementById('diag-obj-filter')?.value||'';
  const sysFilter=parseInt(document.getElementById('diag-sys-filter')?.value||'0');
  const sysObjs=sysFilter?(TECH.sistemu_tipai.find(t=>t.id===sysFilter)?.grandine||[]):null;
  const results=[];
  Object.keys(KB.objects_meta).forEach(oid=>{
    if(objFilter&&oid!==objFilter) return;
    if(sysObjs&&!sysObjs.includes(oid)) return;
    const kb=KB.objects[oid];
    Object.values(kb?.failure_modes||{}).filter(fm=>fm.name).forEach(fm=>{
      const fmSyms=fm.symptoms||[];
      const hits=diagSel.filter(s=>fmSyms.some(fs=>fs.toLowerCase().includes(s.toLowerCase())||s.toLowerCase().includes(fs.toLowerCase())));
      const misses=fmSyms.filter(fs=>!diagSel.some(s=>s.toLowerCase().includes(fs.toLowerCase())||fs.toLowerCase().includes(s.toLowerCase())));
      if(!hits.length) return;
      let score=Math.round((hits.length/diagSel.length)*100);
      if(fmSyms.length>0) score=Math.round((score+Math.round((hits.length/fmSyms.length)*100))/2);
      const em=fm.env_modifiers||{}; let envMult=1; const envChips=[];
      if(diagEnv.gvl==='gvl-1'&&em.gvl1?.prob_mult){const m=parseFloat(em.gvl1.prob_mult)||1;envMult*=m;if(m!==1)envChips.push({k:'GVL↑',m});}
      if(diagEnv.gvl==='gvl-2'&&em.gvl2?.prob_mult){const m=parseFloat(em.gvl2.prob_mult)||1;envMult*=m;if(m!==1)envChips.push({k:'GVL↓',m});}
      if(diagEnv.soil==='smel'&&em.smel?.prob_mult){const m=parseFloat(em.smel.prob_mult)||1;envMult*=m;if(m!==1)envChips.push({k:'Smėl.',m});}
      if(diagEnv.soil==='mol'&&em.mol?.prob_mult){const m=parseFloat(em.mol.prob_mult)||1;envMult*=m;if(m!==1)envChips.push({k:'Mol.',m});}
      if(diagEnv.age==='old'&&em.old?.prob_mult){const m=parseFloat(em.old.prob_mult)||1;envMult*=m;if(m!==1)envChips.push({k:'7m+',m});}
      const finalScore=Math.min(99,Math.round(score*envMult));
      const pctBase=(KB.percentages[oid]?.[fm.id]?.base||0);
      results.push({oid,fm,hits,misses,score:finalScore,envMult,envChips,pctBase,fmSyms});
    });
  });
  results.sort((a,b)=>b.score-a.score||(b.pctBase-a.pctBase));
  if(!results.length){document.getElementById('diag-results').innerHTML=`<div class="diag-no-sel"><div class="ico">🤔</div><h3>Nerasta atitikmenų</h3><p>Pabandyk pasirinkti daugiau simptomų</p></div>`;return;}
  const sev={low:'#4caf50',med:'#ff9800',high:'#f44336',critical:'#e91e63'};
  document.getElementById('diag-results').innerHTML=results.slice(0,12).map(r=>{
    const ringCol=r.score>70?'#2e7d32':r.score>40?'#ff9800':'#c62828';
    const tree=KB.decision_trees[r.fm.id];
    return `<div class="diag-match">
      <div class="diag-match-head">
        <div class="diag-score-ring" style="border-color:${ringCol};color:${ringCol}">${r.score}%</div>
        <div style="flex:1">
          <div class="diag-obj-path">${r.oid} · <span style="color:${sev[r.fm.severity]||'#aaa'};font-weight:700">${(r.fm.severity||'?').toUpperCase()}</span> · ×${r.fm.frequency||0} atvejų</div>
          <div class="diag-fname">${r.fm.name}</div>
          <div class="diag-sym-match" style="margin-top:4px">
            ${r.hits.map(s=>`<span class="dsym hit">✓ ${s}</span>`).join('')}
            ${r.misses.slice(0,3).map(s=>`<span class="dsym miss">✗ ${s}</span>`).join('')}
          </div>
          ${r.envChips.length?`<div>${r.envChips.map(c=>`<span class="diag-env-chip ${c.m>1?'up':'dn'}">${c.m>1?'↑':'↓'}${c.k} ×${c.m}</span>`).join('')}</div>`:''}
        </div>
        ${r.pctBase?`<div style="text-align:center;padding:0 8px"><div style="font-size:18px;font-weight:700;color:var(--pri)">${r.pctBase}%</div><div style="font-size:9px;color:var(--td)">bazinė tikimybė</div></div>`:''}
      </div>
      <div class="diag-match-body">
        ${r.fm.causes?.primary?`<div class="diag-section"><h4>Pagrindinė priežastis</h4><p>${r.fm.causes.primary}</p></div>`:''}
        ${r.fm.resolution?`<div class="diag-section"><h4>Sprendimas</h4><p>${r.fm.resolution}</p></div>`:''}
        ${r.fm.diagnosis_steps?.length?`<div class="diag-section" style="grid-column:span 2"><h4>Diagnostikos žingsniai</h4><ol class="diag-steps">${r.fm.diagnosis_steps.map(s=>`<li>${s.replace(/^\d+\.\s*/,'')}</li>`).join('')}</ol></div>`:''}
        ${r.fm.prevention?`<div class="diag-section"><h4>Profilaktika</h4><p>${r.fm.prevention}</p></div>`:''}
        ${r.fm.economics?.user_saved>0?`<div class="diag-section" style="grid-column:span 2">
          <div style="background:linear-gradient(135deg,#e8f5e9,#c8e6c9);border:2px solid #4caf50;border-radius:12px;padding:14px 18px;display:flex;align-items:center;gap:16px">
            <div style="font-size:32px">💰</div>
            <div style="flex:1">
              <div style="font-size:11px;font-weight:700;color:#1b5e20;margin-bottom:2px">Problema išspręsta pačiam:</div>
              <div style="font-size:24px;font-weight:900;color:#2e7d32;line-height:1.1">Sutaupyta ~${r.fm.economics.user_saved}€</div>
              <div style="font-size:10px;color:#388e3c;margin-top:3px">
                Specialisto iškvietimas kainuotų ~${r.fm.economics.specialist_cost_avg}€
                ${r.fm.economics.self_fix_cost>0?' · Medžiagos ~'+r.fm.economics.self_fix_cost+'€':''}
              </div>
            </div>
            <div style="text-align:center;padding:8px 14px;background:#fff;border-radius:10px;border:1px solid #a5d6a7">
              <div style="font-size:10px;color:#388e3c;font-weight:600">specialistas</div>
              <div style="font-size:18px;font-weight:800;color:#c62828;text-decoration:line-through">~${r.fm.economics.specialist_cost_avg}€</div>
              <div style="font-size:10px;color:#2e7d32;font-weight:600">pats: ~${r.fm.economics.self_fix_cost}€</div>
            </div>
          </div>
        </div>`:''}
      </div>
      <div style="display:flex;gap:6px;margin-top:10px;padding-top:8px;border-top:1px solid var(--b1)">
        <button class="btn ghost sm" onclick="selObj('${r.oid}');gp('k',document.querySelector('[data-p=k]'))">Žinių kortelė</button>
        ${tree?`<button class="btn sec sm" onclick="openTreeFor('${r.fm.id}','${r.oid}')">⊞ Sprendimų medis</button>`:`<button class="btn ghost sm" onclick="buildTreeFromFail('${r.fm.id}')">⊞ Sukurti medį</button>`}
      </div>
    </div>`;
  }).join('');
}

function openTreeFor(fid, oid) {
  gp('tree',document.querySelector('[data-p=tree]'));
  setTimeout(()=>{
    const os=document.getElementById('tree-obj');if(os){os.value=oid;treeObjChange();}
    setTimeout(()=>{const fs=document.getElementById('tree-fail-sel');if(fs){fs.value=fid;loadTree();}},120);
  },120);
}

function buildTreeFromFail(fid) {
  const kTab=document.querySelector('[data-p="k"]');
  if(kTab) gp('k',kTab);
  setTimeout(()=>{
    const oid=Object.keys(KB.objects).find(o=>KB.objects[o].failure_modes?.[fid])||curObj;
    selObj(oid);
    setTimeout(()=>{
      const btn=document.getElementById('tree-btn-'+fid);
      if(btn){btn.click();btn.scrollIntoView({behavior:'smooth',block:'center'});}
    },300);
  },150);
}
