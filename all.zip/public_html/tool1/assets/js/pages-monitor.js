function _monFmt(n) {
  return n >= 1000 ? (n / 1000).toFixed(1) + 'k' : n;
}

function _monBar(val, max, col) {
  const pct = max > 0 ? Math.min(100, Math.round((val / max) * 100)) : 0;
  col = col || 'var(--pri)';
  return `<div style="background:var(--s3);border-radius:20px;height:8px;overflow:hidden;margin-top:4px">
    <div style="height:100%;width:${pct}%;background:${col};border-radius:20px;transition:width .5s"></div>
  </div>`;
}

function _monStatBox(num, label, col, sub) {
  return `<div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);padding:14px;text-align:center">
    <div style="font-size:28px;font-weight:700;font-family:'JetBrains Mono',monospace;color:${col || 'var(--pri)'};line-height:1">${_monFmt(num)}</div>
    <div style="font-size:9px;color:var(--td);margin-top:4px;text-transform:uppercase;letter-spacing:.5px">${label}</div>
    ${sub ? `<div style="font-size:10px;color:var(--td);margin-top:2px">${sub}</div>` : ''}
  </div>`;
}

function _monSec(title, content) {
  return `<div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);overflow:hidden;margin-bottom:12px">
    <div style="padding:9px 14px;background:var(--s2);border-bottom:1px solid var(--b1);font-size:10px;font-weight:700;color:var(--pri);text-transform:uppercase;letter-spacing:.5px">${title}</div>
    <div style="padding:14px">${content}</div>
  </div>`;
}

async function renderMonitor() {
  const wrap = document.getElementById('monitor-wrap');
  if (!wrap) return;
  wrap.innerHTML = `<div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Kraunama...</div>`;

  let analytics = null;
  try {
    const r = await fetch('api.php?action=load_analytics', { credentials: 'include' });
    const d = await r.json();
    if (d.ok) analytics = d.data;
    else throw new Error(d.err || 'Klaida');
  } catch (e) {
    wrap.innerHTML = `<div style="color:#e53935;padding:20px">⚠ Nepavyko užkrauti: ${e.message}</div>`;
    return;
  }

  wrap.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;align-items:start">
      <div id="mon-col-left"></div>
      <div id="mon-col-right"></div>
    </div>
  `;

  _monRenderAnalytics(analytics);
  _monRenderDiag(analytics);
  _monRenderWorkCounts(analytics);
}

function _monRenderAnalytics(d) {
  const left = document.getElementById('mon-col-left');
  if (!left) return;

  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);

  const byDate = {};
  const byPage = { chat: 0, konstruktorius: 0, diagnostika: 0 };
  let totalDuration = 0, durationCount = 0;

  (d.pageviews || []).forEach(v => {
    const day = v.ts ? v.ts.slice(0, 10) : '';
    if (!byDate[day]) byDate[day] = 0;
    byDate[day]++;
    if (byPage[v.page] !== undefined) byPage[v.page]++;
    else byPage[v.page] = (byPage[v.page] || 0) + 1;
    if (v.duration > 0) { totalDuration += v.duration; durationCount++; }
  });

  const total = d.pageviews?.length || 0;
  const today = byDate[todayStr] || 0;

  let week = 0;
  for (let i = 0; i < 7; i++) {
    const dt = new Date(now); dt.setDate(dt.getDate() - i);
    week += byDate[dt.toISOString().slice(0, 10)] || 0;
  }

  const monthStr = todayStr.slice(0, 7);
  let month = 0;
  Object.entries(byDate).forEach(([k, v]) => { if (k.startsWith(monthStr)) month += v; });

  const avgDur = durationCount > 0 ? Math.round(totalDuration / durationCount) : 0;
  const avgMin = Math.floor(avgDur / 60);
  const avgSec = avgDur % 60;

  const pageLabels = { chat: '💬 Chat', konstruktorius: '⚙ Konstruktorius', diagnostika: '🔍 Diagnostika' };
  const pageColors = { chat: '#1565c0', konstruktorius: 'var(--pri)', diagnostika: '#e65100' };

  const days30 = [];
  let maxViews30 = 0;
  for (let i = 29; i >= 0; i--) {
    const dt = new Date(now); dt.setDate(dt.getDate() - i);
    const key = dt.toISOString().slice(0, 10);
    const val = byDate[key] || 0;
    days30.push({ d: key.slice(5), v: val });
    if (val > maxViews30) maxViews30 = val;
  }

  const chartH = 60;
  const bars = days30.map((d, i) => {
    const h = maxViews30 > 0 ? Math.max(2, Math.round((d.v / maxViews30) * chartH)) : 2;
    const isToday = i === days30.length - 1;
    return `<div title="${d.d}: ${d.v} peržiūrų" style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:${chartH}px;cursor:default">
      <div style="width:90%;background:${isToday ? 'var(--pri)' : 'var(--s3)'};border-radius:2px 2px 0 0;height:${h}px;border:1px solid ${isToday ? 'var(--pri)' : 'var(--b1)'}"></div>
    </div>`;
  }).join('');

  let html = `
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:12px">
      ${_monStatBox(today, 'Šiandien', 'var(--pri)')}
      ${_monStatBox(week, 'Savaitė', '#1565c0')}
      ${_monStatBox(month, 'Mėnuo', '#2e7d32')}
      ${_monStatBox(total, 'Iš viso', 'var(--td)')}
    </div>
  `;

  html += _monSec('📈 Paskutinės 30 dienų', `
    <div style="display:flex;align-items:flex-end;gap:1px;border-bottom:1px solid var(--b1);padding-bottom:4px">
      ${bars}
    </div>
    <div style="display:flex;justify-content:space-between;margin-top:4px;font-size:9px;color:var(--td)">
      <span>${days30[0]?.d}</span><span>Šiandien</span>
    </div>
  `);

  html += _monSec('📊 Įrankių naudojimas', `
    ${Object.entries(byPage).sort((a, b) => b[1] - a[1]).map(([page, cnt]) => {
      const label = pageLabels[page] || page;
      const col = pageColors[page] || 'var(--td)';
      return `<div style="margin-bottom:10px">
        <div style="display:flex;justify-content:space-between;font-size:11px">
          <span style="color:${col};font-weight:600">${label}</span>
          <span style="font-family:'JetBrains Mono',monospace">${cnt}</span>
        </div>
        ${_monBar(cnt, total, col)}
      </div>`;
    }).join('')}
    <div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--b1);font-size:10px;color:var(--td)">
      ⏱ Vidutinė sesijos trukmė: <strong style="color:var(--pri)">${avgMin}m ${avgSec}s</strong>
    </div>
  `);

  const byDevice = {};
  (d.pageviews || []).forEach(v => { byDevice[v.device] = (byDevice[v.device] || 0) + 1; });
  const devLabels = { desktop: '🖥 Desktop', mobile: '📱 Mobile', tablet: '📟 Tablet' };
  const devColors = { desktop: '#1565c0', mobile: '#e65100', tablet: '#6a1b9a' };

  html += _monSec('📱 Įrenginiai', `
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
      ${Object.entries(byDevice).sort((a,b) => b[1]-a[1]).map(([dev, cnt]) =>
        `<div style="text-align:center;padding:10px;background:var(--s2);border-radius:var(--r);border:1px solid var(--b1)">
          <div style="font-size:18px">${(devLabels[dev] || dev).split(' ')[0]}</div>
          <div style="font-size:14px;font-weight:700;color:${devColors[dev] || 'var(--td)'};font-family:'JetBrains Mono',monospace">${cnt}</div>
          <div style="font-size:9px;color:var(--td)">${(devLabels[dev] || dev).split(' ').slice(1).join(' ')}</div>
        </div>`
      ).join('')}
    </div>
  `);

  left.innerHTML = `<div style="font-size:12px;font-weight:700;color:var(--pri);margin-bottom:10px;text-transform:uppercase;letter-spacing:.5px">📊 LANKYTOJŲ STATISTIKA</div>${html}`;
}

function _monRenderDiag(d) {
  const right = document.getElementById('mon-col-right');
  if (!right) return;

  const logs = d.diag_log || [];
  const symCount = {};
  const failCount = {};
  let noMatch = 0;

  logs.forEach(entry => {
    (entry.symptoms || []).forEach(s => { symCount[s] = (symCount[s] || 0) + 1; });
    (entry.results || []).slice(0, 3).forEach(r => {
      const key = r.name || r.fid;
      if (key) failCount[key] = (failCount[key] || 0) + 1;
    });
    if (!entry.found) noMatch++;
  });

  const topSym  = Object.entries(symCount).sort((a, b) => b[1] - a[1]).slice(0, 10);
  const topFail = Object.entries(failCount).sort((a, b) => b[1] - a[1]).slice(0, 10);
  const maxSym  = topSym[0]?.[1] || 1;
  const maxFail = topFail[0]?.[1] || 1;

  let html = `
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px">
      ${_monStatBox(logs.length, 'Iš viso diagnostikų', '#e65100')}
      ${_monStatBox(noMatch, 'Be atsakymo', '#c62828', 'Kur trūksta duomenų')}
      ${_monStatBox(logs.length - noMatch, 'Rasti atitikmens', '#2e7d32')}
    </div>
  `;

  html += _monSec('🔍 TOP 10 simptomų', topSym.length ? `
    ${topSym.map(([sym, cnt]) => `
      <div style="margin-bottom:8px">
        <div style="display:flex;justify-content:space-between;font-size:11px">
          <span style="color:var(--warn);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-right:8px">${sym}</span>
          <span style="font-family:'JetBrains Mono',monospace;font-size:10px">${cnt}×</span>
        </div>
        ${_monBar(cnt, maxSym, 'var(--warn)')}
      </div>`).join('')}
  ` : '<div style="color:var(--td);font-size:11px">Duomenų dar nėra</div>');

  html += _monSec('⚠ TOP 10 gedimų', topFail.length ? `
    ${topFail.map(([fail, cnt]) => `
      <div style="margin-bottom:8px">
        <div style="display:flex;justify-content:space-between;font-size:11px">
          <span style="color:#e65100;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-right:8px">${fail}</span>
          <span style="font-family:'JetBrains Mono',monospace;font-size:10px">${cnt}×</span>
        </div>
        ${_monBar(cnt, maxFail, '#e65100')}
      </div>`).join('')}
  ` : '<div style="color:var(--td);font-size:11px">Duomenų dar nėra</div>');

  right.innerHTML = `<div style="font-size:12px;font-weight:700;color:var(--pri);margin-bottom:10px;text-transform:uppercase;letter-spacing:.5px">🔍 DIAGNOSTIKOS DUOMENYS</div>${html}`;
}

function _monRenderWorkCounts(d) {
  const left = document.getElementById('mon-col-left');
  if (!left) return;

  const log = d.save_log || [];
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);

  let today = 0, week = 0, month = 0;

  log.forEach(entry => {
    const ts = entry.ts ? entry.ts.slice(0, 10) : '';
    const diff = (now - new Date(entry.ts)) / 86400000;
    if (ts === todayStr) today++;
    if (diff < 7) week++;
    if (ts.startsWith(todayStr.slice(0, 7))) month++;
  });

  const workHtml = `
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
      ${_monStatBox(today, 'Šiandien', 'var(--pri)')}
      ${_monStatBox(week, 'Savaitė', '#1565c0')}
      ${_monStatBox(month, 'Mėnuo', '#2e7d32')}
    </div>
  `;

  left.innerHTML += `<div style="font-size:12px;font-weight:700;color:var(--pri);margin-bottom:10px;margin-top:16px;text-transform:uppercase;letter-spacing:.5px">⚙ DARBO STATISTIKA</div>${workHtml}`;
}
