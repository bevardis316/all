function renderTreeDashboard() {
  const el=document.getElementById('tree-dashboard'); if(!el) return;
  const trees=KB.decision_trees||{};
  const tKeys=Object.keys(trees);

  
  const allFails=[];
  Object.entries(KB.objects).forEach(([oid,kb])=>Object.values(kb.failure_modes||{}).filter(f=>f.name).forEach(fm=>{
    const hasTree=!!trees[fm.id];
    const hasDiagTree=(fm.diag_tree||[]).length>0;
    allFails.push({fid:fm.id, oid, name:fm.name, sev:fm.severity, hasTree, hasDiagTree, steps:(fm.diag_tree||[]).length});
  }));

  const withTree=allFails.filter(f=>f.hasTree||f.hasDiagTree);
  const withoutTree=allFails.filter(f=>!f.hasTree&&!f.hasDiagTree);

  el.innerHTML=`
  <!-- STAT BAR -->
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px">
    ${[
      {n:allFails.length, l:'Visi gedimai', col:'var(--pri)'},
      {n:withTree.length, l:'Su diagnostikos medžiu', col:'#2e7d32'},
      {n:withoutTree.length, l:'Be diagnostikos', col:'#c62828'},
      {n:tKeys.length, l:'Išsaugoti standalone medžiai', col:'#1565c0'}
    ].map(s=>`<div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);padding:12px;text-align:center;box-shadow:var(--shadow)">
      <div style="font-size:28px;font-weight:700;font-family:'JetBrains Mono',monospace;color:${s.col};line-height:1">${s.n}</div>
      <div style="font-size:9px;color:var(--td);margin-top:4px;text-transform:uppercase;letter-spacing:.5px">${s.l}</div>
    </div>`).join('')}
  </div>

  <!-- PROGRESO JUOSTA -->
  <div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);padding:14px;margin-bottom:14px">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
      <span style="font-size:11px;font-weight:700">Diagnostikos aprėptis</span>
      <span style="font-size:13px;font-weight:700;color:${withTree.length/Math.max(allFails.length,1)>.7?'#2e7d32':'#e65100'}">${allFails.length?Math.round(withTree.length/allFails.length*100):0}%</span>
    </div>
    <div style="background:var(--s3);border-radius:20px;height:10px;overflow:hidden">
      <div style="height:100%;width:${allFails.length?Math.round(withTree.length/allFails.length*100):0}%;background:linear-gradient(90deg,#2e7d32,#8bc34a);border-radius:20px;transition:width .5s"></div>
    </div>
  </div>

  <!-- GEDIMAI SU MEDŽIU -->
  ${withTree.length?`
  <div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);overflow:hidden;margin-bottom:12px">
    <div style="padding:10px 14px;background:var(--s2);border-bottom:1px solid var(--b1);font-size:11px;font-weight:700;color:#2e7d32">
      ✓ Gedimai su diagnostikos medžiu (${withTree.length})
    </div>
    ${withTree.map(f=>`
    <div style="display:flex;align-items:center;gap:8px;padding:8px 14px;border-bottom:1px solid var(--b1)">
      <span class="sev-badge sev-${f.sev}">${f.sev}</span>
      <span style="font-size:10px;color:var(--td);font-family:'JetBrains Mono',monospace;min-width:100px">${f.fid}</span>
      <span style="font-size:11px;flex:1">${f.name}</span>
      <span style="font-size:9px;color:#2e7d32">${f.steps} žingsniai</span>
      ${f.hasTree?'<span style="font-size:9px;padding:2px 6px;background:#e3f2fd;color:#1565c0;border-radius:20px">standalone</span>':''}
      <button class="btn ghost sm" style="font-size:9px;padding:2px 8px" onclick="openTreeFor('${f.fid}','${f.oid}')">Peržiūrėti →</button>
    </div>`).join('')}
  </div>`:'' }

  <!-- GEDIMAI BE MEDŽIO -->
  ${withoutTree.length?`
  <div style="background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);overflow:hidden">
    <div style="padding:10px 14px;background:var(--s2);border-bottom:1px solid var(--b1);font-size:11px;font-weight:700;color:#c62828">
      ⚠ Gedimai be diagnostikos medžio (${withoutTree.length}) – reikia pildyti
    </div>
    ${withoutTree.map(f=>`
    <div style="display:flex;align-items:center;gap:8px;padding:8px 14px;border-bottom:1px solid var(--b1)">
      <span class="sev-badge sev-${f.sev}">${f.sev}</span>
      <span style="font-size:10px;color:var(--td);font-family:'JetBrains Mono',monospace;min-width:100px">${f.fid}</span>
      <span style="font-size:11px;flex:1">${f.name}</span>
      <button class="btn pri sm" style="font-size:9px;padding:2px 8px" onclick="selObj('${f.oid}');gp('k',document.querySelector('[data-p=k]'));setTimeout(()=>toggleFE('${f.fid}'),300)">+ Diagnostika →</button>
    </div>`).join('')}
  </div>`:''}`;}

function calcAIIQ() {
  const ids=Object.keys(KB.objects_meta);
  const total=ids.length; if(!total) return {iq:0,comps:{},lvl:0};

  
  const failCov=ids.map(id=>Math.min(1,Object.values(KB.objects[id]?.failure_modes||{}).filter(f=>f.name).length/5));
  const failScore=Math.round((failCov.reduce((s,v)=>s+v,0)/total)*25);

  
  let diagTotal=0, diagFilled=0;
  ids.forEach(id=>Object.values(KB.objects[id]?.failure_modes||{}).filter(f=>f.name).forEach(fm=>{
    diagTotal++;
    const steps=fm.diag_tree||[];
    if(steps.length>=2&&steps.every(s=>s.question&&s.yes)) diagFilled++;
    else if(steps.length>=1) diagFilled+=0.5;
  }));
  const diagScore=diagTotal?Math.round((diagFilled/diagTotal)*20):0;

  
  let symTotal=0, symFilled=0;
  ids.forEach(id=>Object.values(KB.objects[id]?.failure_modes||{}).filter(f=>f.name).forEach(fm=>{
    symTotal++;
    if((fm.symptoms||[]).length>=3) symFilled++;
    else if((fm.symptoms||[]).length>=1) symFilled+=0.5;
  }));
  const symScore=symTotal?Math.round((symFilled/symTotal)*15):0;

  
  let envTotal=0, envSet=0;
  ids.forEach(id=>Object.values(KB.objects[id]?.failure_modes||{}).filter(f=>f.name).forEach(fm=>{
    envTotal++;
    const em=fm.env_modifiers||{};
    const nonDefault=Object.values(em).filter(v=>parseFloat(v.prob_mult||1)!==1.0).length;
    if(nonDefault>=2) envSet++;
    else if(nonDefault>=1) envSet+=0.5;
  }));
  const envScore=envTotal?Math.round((envSet/envTotal)*10):0;

  
  const trelCount=KB.tag_relations?.length||0;
  const trelScore=Math.min(10,Math.round(trelCount/3));

  
  const baseScore=Math.round(ids.filter(id=>KB.objects[id]?.function&&KB.objects[id]?.normal_operation).length/total*10);

  
  let causalTotal=0, causalFilled=0;
  ids.forEach(id=>Object.values(KB.objects[id]?.failure_modes||{}).filter(f=>f.name).forEach(fm=>{
    causalTotal++;
    if(fm.causes?.primary&&fm.dt1&&fm.dt2) causalFilled++;
    else if(fm.causes?.primary) causalFilled+=0.5;
  }));
  const causalScore=causalTotal?Math.round((causalFilled/causalTotal)*5):0;

  
  const treeCount=Object.keys(KB.decision_trees||{}).length;
  const treeScore=Math.min(5,treeCount);

  const iq=failScore+diagScore+symScore+envScore+trelScore+baseScore+causalScore+treeScore;
  const lvl=iq>=80?4:iq>=60?3:iq>=40?2:iq>=20?1:0;

  return {
    iq, lvl,
    comps:{
      'Gedimų padengimas':{score:failScore,max:25,col:'#2e7d32'},
      'Diagnostikos medžiai':{score:diagScore,max:20,col:'#1565c0'},
      'Simptomų turtingumas':{score:symScore,max:15,col:'#e65100'},
      'Aplinkos modifikatoriai':{score:envScore,max:10,col:'#8d6e63'},
      'Tagų ryšiai':{score:trelScore,max:10,col:'#6a1b9a'},
      'Objektų bazė':{score:baseScore,max:10,col:'#00695c'},
      'Priežasčių grandinės':{score:causalScore,max:5,col:'#c62828'},
      'Sprendimų medžiai':{score:treeScore,max:5,col:'#1565c0'},
    }
  };
}

function renderStats() {
  const {iq,lvl,comps}=calcAIIQ();
  const iqLabels=['Tuščia KB','Pradinis','Bazinis','Geras','Ekspertas'];
  const iqDescs=[
    'AI beveik nieko nežino apie sistemas',
    'AI žino objektus ir kelis gedimus, bet diagnostika silpna',
    'AI gali diagnozuoti pagrindinius gedimus su paprastais simptomais',
    'AI tinkamai orientuojasi, supranta priežastis ir padarinius',
    'AI konsultuoja kaip patyręs technikas – tiksliai ir išsamiai'
  ];

  let tf=0; const freqs=[];
  const ids=Object.keys(KB.objects_meta);
  ids.forEach(id=>{
    const fms=Object.values(KB.objects[id]?.failure_modes||{}).filter(f=>f.name);
    tf+=fms.length;
    fms.forEach(fm=>freqs.push({id:fm.id,oid:id,lbl:`${id}: ${fm.name.substring(0,14)}`,fr:fm.frequency||0,sev:fm.severity,hasDiag:(fm.diag_tree||[]).length>0,symCount:(fm.symptoms||[]).length,hasCausal:!!(fm.causes?.primary&&fm.dt1)}));
  });
  freqs.sort((a,b)=>b.fr-a.fr);
  const filled=ids.filter(id=>KB.objects[id]?.function).length;
  const pct=Math.round(filled/Math.max(ids.length,1)*100);
  const scol={high:'#f44336',med:'#ff9800',low:'#4caf50',critical:'#e91e63'};

  const el=document.getElementById('stats-wrap'); if(!el) return;
  el.innerHTML=`
  <!-- AI IQ SCORE -->
  <div class="stat-card" style="grid-column:span 3;background:linear-gradient(135deg,var(--s2),var(--s1));border:2px solid var(--b2)">
    <h3>🧠 AI ŽINIŲ BRANDOS INDEKSAS (AI IQ)</h3>
    <div class="iq-gauge-wrap">
      <div>
        <div class="iq-score lvl-${lvl}">${iq}</div>
        <div style="font-size:10px;color:var(--td);margin-top:4px">/ 100 taškų</div>
      </div>
      <div style="flex:1">
        <div class="iq-label">${iqLabels[lvl]}</div>
        <div class="iq-desc">${iqDescs[lvl]}</div>
        <div style="margin-top:10px;background:var(--s3);border-radius:20px;height:8px;overflow:hidden">
          <div style="height:100%;width:${iq}%;background:${lvl>=3?'var(--pri)':lvl>=2?'#ff9800':'#c62828'};border-radius:20px;transition:width .8s ease"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:9px;color:var(--td);margin-top:3px">
          <span>0</span><span>20</span><span>40</span><span>60</span><span>80</span><span>100</span>
        </div>
      </div>
    </div>
    <div>${Object.entries(comps).map(([name,{score,max,col}])=>`
      <div class="iq-comp-row">
        <span class="iq-comp-name">${name}</span>
        <div class="iq-comp-bar-wrap"><div class="iq-comp-bar" style="width:${Math.round(score/max*100)}%;background:${col}"></div></div>
        <span class="iq-comp-val" style="color:${col}">${score}/${max}</span>
      </div>`).join('')}
    </div>
  </div>

  <!-- SKAIČIAI -->
  <div class="stat-card">
    <h3>Gedimų žinių vienetai</h3>
    <div class="bignum">${tf}</div>
    <div class="bigsub">iš ${ids.length} objektų</div>
    <div style="margin-top:10px;font-size:10px;color:var(--td)">Vidutiniškai: ${ids.length?Math.round(tf/ids.length):0} ged./objektas</div>
  </div>
  <div class="stat-card">
    <h3>Diagnostikos aprėptis</h3>
    <div class="bignum">${freqs.filter(f=>f.hasDiag).length}</div>
    <div class="bigsub">iš ${tf} gedimų turi TAIP/NE medį</div>
    <div style="margin-top:8px;background:var(--s3);border-radius:20px;height:6px;overflow:hidden">
      <div style="height:100%;width:${tf?Math.round(freqs.filter(f=>f.hasDiag).length/tf*100):0}%;background:var(--pri);border-radius:20px"></div>
    </div>
  </div>
  <div class="stat-card">
    <h3>KB užpildymas</h3>
    <div class="bignum">${pct}%</div>
    <div class="bigsub">objektų su aprašyta funkcija</div>
    <div style="margin-top:8px;background:var(--s3);border-radius:20px;height:6px;overflow:hidden">
      <div style="height:100%;width:${pct}%;background:var(--acc);border-radius:20px"></div>
    </div>
  </div>

  <!-- DAŽNIAUSI GEDIMAI -->
  <div class="stat-card" style="grid-column:span 3">
    <h3>Dažniausi gedimai (pagal atvejų skaičių)</h3>
    ${freqs.slice(0,8).map(f=>`
      <div class="bar-row">
        <span class="bar-lbl" style="display:flex;align-items:center;gap:4px">
          <span>${f.lbl}</span>
          ${f.hasDiag?'<span title="Turi diagnostikos medį" style="font-size:9px;color:var(--pri)">⊞</span>':''}
          ${f.hasCausal?'<span title="Turi priežasčių grandinę" style="font-size:9px;color:#e65100">⏱</span>':''}
        </span>
        <div class="bar-track"><div class="bar-fill" style="width:${freqs[0]?.fr?Math.round(f.fr/freqs[0].fr*100):0}%;background:${scol[f.sev]||'var(--pri3)'}"></div></div>
        <span class="bar-val">×${f.fr}</span>
      </div>`).join('')||'<div style="color:var(--td);font-size:11px">Nėra duomenų</div>'}
  </div>

  <!-- TAGŲ RYŠIŲ STATISTIKA -->
  <div class="stat-card">
    <h3>Tagų ryšiai</h3>
    <div class="bignum">${KB.tag_relations?.length||0}</div>
    <div class="bigsub">kauzalinių ryšių</div>
    <div style="margin-top:10px">
      ${Object.entries(
        (KB.tag_relations||[]).reduce((acc,r)=>{acc[r.type]=(acc[r.type]||0)+1;return acc;},{})
      ).map(([type,cnt])=>`<div class="iq-comp-row">
        <span class="iq-comp-name">${TREL_TYPES[type]?.lbl||type}</span>
        <span class="iq-comp-val" style="color:${TREL_TYPES[type]?.col||'#888'}">${cnt}</span>
      </div>`).join('')||'<div style="color:var(--td);font-size:11px">Nėra ryšių</div>'}
    </div>
  </div>
  `;
}

function showGuide() {
  const overlay = document.createElement('div');
  overlay.id = 'guide-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px';

  const tabNames = ['Diagnostikos score','AI IQ algoritmas','Tagai ir ryšiai','Tikimybių mechanika','Darbo prioritetai'];
  const tabHtml = tabNames.map((t,i) =>
    '<button onclick="guideTab(' + i + ')" id="gtab-' + i + '" style="padding:10px 16px;font-size:11px;font-weight:600;border:none;background:' + (i===0?'#fff':'transparent') + ';border-bottom:' + (i===0?'2px solid #1e3d2f':'2px solid transparent') + ';margin-bottom:-2px;cursor:pointer;color:' + (i===0?'#1e3d2f':'#666') + '">' + t + '</button>'
  ).join('');

  overlay.innerHTML =
    '<div style="background:#fff;border-radius:14px;width:100%;max-width:820px;max-height:90vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.3)">' +
    '<div style="background:#1e3d2f;color:#fff;padding:16px 20px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0">' +
    '<div><div style="font-size:16px;font-weight:700">📖 IBNVS — kaip veikia sistema (giliai)</div>' +
    '<div style="font-size:10px;opacity:.7;margin-top:2px">Algoritmų mechanika · Tikimybių matematika · Prioritetai</div></div>' +
    '<button onclick="document.getElementById(\'guide-overlay\').remove()" style="background:rgba(255,255,255,.15);border:none;color:#fff;border-radius:8px;padding:6px 12px;cursor:pointer;font-size:13px">✕ Uždaryti</button>' +
    '</div>' +
    '<div style="display:flex;border-bottom:2px solid #e8f5e9;background:#f8fdf9;flex-shrink:0">' + tabHtml + '</div>' +
    '<div style="overflow-y:auto;padding:20px;flex:1" id="guide-content">' + guidePages()[0] + '</div>' +
    '</div>';

  document.body.appendChild(overlay);
  overlay.addEventListener('click', function(e) { if(e.target === overlay) overlay.remove(); });
}

function guideTab(i) {
  document.querySelectorAll('[id^="gtab-"]').forEach((b,j)=>{
    b.style.background = j===i ? '#fff' : 'transparent';
    b.style.borderBottom = j===i ? '2px solid #1e3d2f' : '2px solid transparent';
    b.style.color = j===i ? '#1e3d2f' : '#666';
  });
  document.getElementById('guide-content').innerHTML = guidePages()[i];
}

function guidePages() {
  function box(title, body, color) {
    color = color || '#1e3d2f';
    return '<div style="border:1.5px solid ' + color + '30;border-radius:10px;padding:14px 16px;margin-bottom:14px">' +
           '<div style="font-weight:700;font-size:12px;color:' + color + ';margin-bottom:10px">' + title + '</div>' +
           body + '</div>';
  }
  function p(txt)   { return '<p style="font-size:11px;line-height:1.8;color:#333;margin:0 0 8px">' + txt + '</p>'; }
  function warn(txt){ return '<div style="background:#fff8e1;border-left:3px solid #f9a825;padding:8px 12px;font-size:11px;border-radius:0 6px 6px 0;margin:8px 0;line-height:1.7">⚠ ' + txt + '</div>'; }
  function good(txt){ return '<div style="background:#e8f5e9;border-left:3px solid #2e7d32;padding:8px 12px;font-size:11px;border-radius:0 6px 6px 0;margin:8px 0;line-height:1.7">✅ ' + txt + '</div>'; }
  function bad(txt) { return '<div style="background:#ffebee;border-left:3px solid #c62828;padding:8px 12px;font-size:11px;border-radius:0 6px 6px 0;margin:8px 0;line-height:1.7">❌ ' + txt + '</div>'; }
  function info(txt){ return '<div style="background:#e3f2fd;border-left:3px solid #1565c0;padding:8px 12px;font-size:11px;border-radius:0 6px 6px 0;margin:8px 0;line-height:1.7">ℹ ' + txt + '</div>'; }
  function formula(txt){ return '<div style="background:#1e3d2f;color:#a5d6a7;padding:10px 14px;border-radius:8px;font-family:JetBrains Mono,monospace;font-size:11px;margin:8px 0;line-height:1.9;white-space:pre">' + txt + '</div>'; }
  function ex(rows) {
    return '<table style="width:100%;border-collapse:collapse;font-size:10px;margin-top:8px">' +
      rows.map(function(r,i) {
        var bg = i===0 ? '#1e3d2f' : (i%2 ? '#f8fdf9' : '#fff');
        var tc = i===0 ? '#fff' : 'inherit';
        var bd = i===0 ? '#2e7d32' : '#e8f5e9';
        return '<tr style="background:' + bg + ';color:' + tc + '">' +
          r.map(function(c){ return '<td style="padding:5px 8px;border:1px solid ' + bd + '">' + c + '</td>'; }).join('') +
          '</tr>';
      }).join('') + '</table>';
  }
  function h3(txt){ return '<h3 style="font-size:13px;color:#1e3d2f;margin:0 0 12px">' + txt + '</h3>'; }
  function steps(arr){ return '<ol style="font-size:11px;line-height:2;color:#333;margin:8px 0 0;padding-left:18px">' + arr.map(function(s){ return '<li>' + s + '</li>'; }).join('') + '</ol>'; }

  return [

  
  h3('Žinių bazės pildymo workflow — žingsnis po žingsnio') +

  box('Bendra idėja — kaip sistema auga',
    p('IBNVS žinių bazė auga per <b>import skirtuko workflow</b>. Tu — ekspertas, AI — redaktorius, sistema — sandėlis.') +
    formula(
      'Tu: laisvas tekstas apie gedimą / objektą\n' +
      '  ↓\n' +
      'AI (Claude): užpildo JSON šabloną pagal tavo tekstą\n' +
      '  ↓\n' +
      'Import skirtukas: validuoja, rodo peržiūrą, importuoja\n' +
      '  ↓\n' +
      'Sistema: išsaugo į data/ katalogą, duomenys išlieka po refresh'
    ) +
    good('Duomenų bazė <b>auga</b> — kiekvienas importas sukuria naujus failus. BNVI-F001, BNVI-F002... iki šimtų gedimų.') +
    warn('Jei rašai tiesiog į "Žinios" skirtuko laukus rankiniu būdu — auto-save veikia, bet importas yra greitesnis masiniam pildymui.'),
    '#1565c0'
  ) +

  box('Import workflow — tikslūs žingsniai',
    steps([
      '<b>Import skirtukas</b> → pasirink šablono tipą (🏗 Objektas / 🔧 Komponentas / ⚡ Gedimai / 💰 Kainos)',
      'Pasirink taikinį iš dropdown (pvz. BNVI, FEKSIURB...)',
      '<b>📋 Kopijuoti schemą</b> — nukopijuoja AI instrukciją + tuščią JSON šabloną',
      'Įklijuok į Claude: schema + tavo laisvas tekstas apie tą objektą/gedimą',
      'Claude grąžina užpildytą JSON — nukopijuok atgal į lauką "Įklijuok AI grąžintą JSON"',
      'Sistema rodo <b>peržiūrą</b> — matai ką importuosi, gali redaguoti',
      '<b>💾 Importuoti į KB</b> — duomenys išsaugomi, gedimas gauna unikalų ID (pvz. BNVI-F003)'
    ]) +
    info('Gedimų ID generuojami automatiškai ir <b>niekada nesikartoja</b> net jei trini senus gedimus.'),
    '#2e7d32'
  ) +

  box('4 šablonų tipai — kada kurį naudoti',
    ex([
      ['Šablonas','Kada naudoti','Ką sukuria'],
      ['🏗 Objektas','Pirmas kartas — pildai visą objektą','base + aplinka + ryšiai + gedimai'],
      ['🔧 Komponentas','Siurblys, filtras, orapūtė ir pan.','Atskiras komponentas su kainomis'],
      ['⚡ Tik gedimai','Žinai konkretų gedimą — tiesiog pridedi','Nauji gedimai prie esamo objekto'],
      ['💰 Kainos/modeliai','Atnaujini kainas rinkoje','Kainų update be visa kito'],
    ]) +
    good('Dažniausiai naudosi <b>⚡ Tik gedimai</b> — greičiausias būdas auginti KB po pirminio pildymo.'),
    '#7b1fa2'
  ),

  
  h3('Kaip duomenys saugomi ir kur') +

  box('Failų struktūra serveryje',
    formula(
      'data/\n' +
      '  objects/\n' +
      '    BNVI/\n' +
      '      base.json          ← pavadinimas, funkcija, normalūs požymiai\n' +
      '      env.json           ← aplinkos elgsena (GVL, gruntas, amžius)\n' +
      '      relations.json     ← upstream/downstream ryšiai\n' +
      '      exploitation_errors.json\n' +
      '      failures/\n' +
      '        BNVI-F001.json   ← gedimas #1\n' +
      '        BNVI-F002.json   ← gedimas #2 ... auga iki šimtų\n' +
      '        _index.json      ← greitas sąrašas\n' +
      '      trees/\n' +
      '        BNVI-F001_tree.json  ← sprendimų medis\n' +
      '  components/\n' +
      '    BNVI/\n' +
      '      BNVI-SIURBLYS.json\n' +
      '      BNVI-ORAPUTE.json\n' +
      '  percentages/\n' +
      '    BNVI.json            ← base tikimybės\n' +
      '  meta/\n' +
      '    objects_index.json'
    ) +
    good('Kiekvienas gedimas = atskiras failas. DB <b>auga</b> — senų failų neperrašo, tik prideda naujus.') +
    info('Auto-save veikia per grandinę: pakeitimas → markDirty() → po 1.8s → flushDirty() → API → diskas.'),
    '#1565c0'
  ) +

  box('Ko nereikia daryti rankiniu būdu',
    bad('Nereikia rankiniu būdu redaguoti JSON failų serveryje.') +
    bad('Nereikia paspausti "išsaugoti" po kiekvieno lauko — auto-save veikia automatiškai.') +
    bad('Nereikia importuoti failo iš kompiuterio (nebent darai pilną backup atstatymą).') +
    good('Admin → <b>💾 Išsaugoti viską</b> — naudok kai nori įsitikinti kad viskas serveryje, pvz. prieš atostogaujant.') +
    good('Admin → <b>↓ JSON eksportas</b> — backup į failą, kurį gali laikyti saugiai.'),
    '#e65100'
  ),

  
  h3('Kaip veikia diagnostika — tikslus algoritmas') +

  box('Simptomų atitikimas (pagrindas)',
    p('Pasirinkti simptomai lyginami su kiekvieno gedimo <b>symptoms[]</b> masyvu. Lyginimas dvikryptis:') +
    formula(
      'hits   = kiek pasirinktų simptomų rasta gedimo symptoms[]\n' +
      'score1 = (hits / pasirinkti_viso) × 100\n' +
      'score2 = (hits / gedimo_symptoms_viso) × 100\n' +
      'galutinis = (score1 + score2) / 2'
    ) +
    ex([
      ['Situacija','score1','score2','Galutinis'],
      ['Pasirinkta 3, gedimas turi 2 iš jų, gedimas turi 2 iš viso','67%','100%','83% ✅'],
      ['Pasirinkta 5, gedimas turi 1 iš jų, gedimas turi 4 iš viso','20%','25%','23% ❌'],
      ['Pasirinkta 2, gedimas turi abu, gedimas turi 2 iš viso','100%','100%','100% 🎯'],
    ]) +
    warn('Daugiau pasirinktų simptomų <b>nebūtinai</b> = geresnis rezultatas. Tikslūs 2-3 simptomai geriau nei visi galimi.'),
    '#1565c0'
  ) +

  box('Aplinkos koregavimas',
    p('Simptomų score dauginamas iš aplinkos koeficientų (env_modifiers kiekviename gedime):') +
    formula('finalScore = MIN(99, ROUND(score × gvl_mult × soil_mult × age_mult))') +
    ex([
      ['Aplinka','Gedimo koeficientas','Poveikis score'],
      ['GVL aukštas (gvl-1)','gvl1: "1.5"','× 1.5 → +50%'],
      ['Molis','mol: "1.2"','× 1.2 → +20%'],
      ['Abu kartu','gvl1×mol','× 1.8 → +80%'],
      ['Senesnė 7+ metų','old: "2.0"','× 2.0 → +100%'],
    ]) +
    warn('Koeficientas veikia TIK kai pasirinkta aplinka IR gedimo koeficientas ≠ 1.0. Vengti >2.5 — visi tokie gedimai "susiploja" į 99%, nebelieka diferencijavimo.'),
    '#e65100'
  ),

  
  h3('Tikimybių sistema — trys atskiri lygiai') +

  box('Kas yra kas',
    ex([
      ['Pavadinimas','Kur randasi','Ką daro'],
      ['base %','% skirtukas arba percentages/OBJ.json','Tiebreaker rūšiuojant — kai du gedimai = score, laimi didesnis base'],
      ['causes.pct %','Gedimo priežasčių sąraše','Kiek tikėtina kuri priežastis — tik informacinis'],
      ['env_modifiers','Aplinkos koeficientai kiekviename gedime','Tiesiogiai dauginamas iš diagnostikos score'],
    ]) +
    info('<b>base %</b> veikia tik kaip tiebreaker — diagnostikos score skirtumas net 1% jį "atjungia".') +
    good('<b>Geras principas:</b> vieno objekto visų gedimų base % suma ≈ 100%. Pvz. FEKSIURB: Siurblys=70%, Elektra=20%, Kita=10%.'),
    '#2e7d32'
  ) +

  box('Kaip nustatyti env_modifiers teisingai',
    steps([
      'Pradėk nuo 1.0 visiems koeficientams (neutralus)',
      'Keisk TIK tada kai turi realią patirtį/duomenis',
      'Molio gruntas dažniau kelia problemų filtrui? → mol: "1.3"',
      'Aukštas GVL saugo siurblį nuo perkrovos? → gvl1: "0.7"',
      'Sena sistema dažniau lūžta? → old: "1.5" arba "2.0"',
    ]) +
    bad('old: "3.0" su score=40% → MIN(99, 120) = 99%. Labai aukšti koeficientai naikina diferencijavimą tarp gedimų.'),
    '#7b1fa2'
  ),

  
  h3('AI IQ — kas skaičiuojama ir kaip auginti') +

  box('Visi komponentai su svoriais',
    ex([
      ['Komponentas','Maks','Greičiausias kelias'],
      ['Gedimų padengimas','25pt','Kiekvienam objektui ≥5 gedimai'],
      ['Diagnostikos medžiai','20pt','Kiekvienam gedimui decision_tree ≥2 žingsniai'],
      ['Simptomų turtingumas','15pt','Kiekvienam gedimui ≥3 konkretūs symptoms[]'],
      ['Aplinkos modifikatoriai','10pt','Kiekvienam gedimui ≥2 ne-1.0 koeficientai'],
      ['Tagų ryšiai','10pt','30+ tagų ryšiai ⇄ skirtuke'],
      ['Objektų bazė','10pt','Visi objektai turi function + normal_operation'],
      ['Priežasčių grandinės','5pt','causes.primary + diag_tree šakos'],
      ['Sprendimų medžiai','5pt','Užpildyti decision_trees visiems gedimams'],
    ]) +
    good('Pirmi <b>60 taškų</b> = gedimai + simptomai + medžiai. Tai realus pradinis tikslas.') +
    warn('IQ <b>neskaičiuoja</b>: kainų, modelių, exploitation_errors, ryšių (upstream/downstream). Tai vertinga, bet IQ jų nemato.'),
    '#e65100'
  ) +

  box('Rekomenduojamas pildymo prioritetas',
    steps([
      '<b>⚡ Gedimai</b> — kiekvienam objektui bent 3-5 dažniausiai pasitaikantys',
      '<b>🔴 Simptomai</b> — kiekvienam gedimui 3+ konkrečių, kliento kalba ("ūžia", "nenusileidžia", "smirda")',
      '<b>🌿 Aplinkos koeficientai</b> — tik tie kur tikrai matai skirtumą (gruntas, GVL, amžius)',
      '<b>🔧 Komponentai</b> — siurbliai, filtrai, orapūtės su kainomis',
      '<b>💰 Kainos</b> — specialisto darbas + medžiagos',
      '<b>🔗 Tagų ryšiai</b> — kai bus 20+ gedimų, atsiranda prasmė jungti',
    ]),
    '#2e7d32'
  ),

  ]; 
}

function renderAdmin() {
  const el=document.getElementById('admin-wrap'); if(!el) return;
  const ids=Object.keys(KB.objects_meta);
  const tf=ids.reduce((s,id)=>s+Object.values(KB.objects[id]?.failure_modes||{}).filter(f=>f.name).length,0);
  const {iq,lvl}=calcAIIQ();

  el.innerHTML=`
  <!-- STATUS BAR -->
  <div class="adm-status-bar">
    <div class="adm-status-tile">
      <div class="ast-val">${ids.length}</div><div class="ast-lbl">Objektai</div>
    </div>
    <div class="adm-status-tile">
      <div class="ast-val">${tf}</div><div class="ast-lbl">Gedimai</div>
    </div>
    <div class="adm-status-tile">
      <div class="ast-val">${Object.keys(KB.decision_trees||{}).length}</div><div class="ast-lbl">Medžiai</div>
    </div>
    <div class="adm-status-tile">
      <div class="ast-val">${KB.tag_relations?.length||0}</div><div class="ast-lbl">Ryšiai</div>
    </div>
    <div class="adm-status-tile">
      <div class="ast-val iq-score lvl-${lvl}" style="font-size:22px">${iq}</div><div class="ast-lbl">AI IQ</div>
    </div>
    <div class="adm-status-tile">
      <div class="ast-val">${Object.keys(KB.tag_categories||{}).length}</div><div class="ast-lbl">Tag kategorijos</div>
    </div>
  </div>

  <!-- SEKCIJŲ GRID -->
  <div class="adm-grid">

    <!-- 1. FAILAI IR SAUGOJIMAS -->
    <div class="adm-sec">
      <div class="adm-sec-h">💾 Saugojimas ir eksportas</div>
      <div class="adm-btn-grid">
        <button class="adm-btn pri" onclick="saveAllFiles()">💾 Išsaugoti viską</button>
        <button class="adm-btn sec" onclick="exportFull()">↓ JSON eksportas</button>
        <button class="adm-btn sec" onclick="exportKBForAI()">🤖 AI RAG eksportas</button>
        <button class="adm-btn ghost" onclick="document.getElementById('load-f').click()">↑ Importuoti failą</button>
      </div>
      <input type="file" id="load-f" accept=".json" onchange="loadFile(this)" style="display:none">
      <div class="adm-info">Visi duomenys saugomi serveryje <code>data/</code> kataloge. Auto-save kas 1.8s po pakeitimo.</div>
    </div>

    <!-- 0. ŽINIŲ BAZĖS INSTRUKCIJA -->
    <div class="adm-sec" style="border-color:#1565c0;grid-column:1/-1">
      <div class="adm-sec-h" style="color:#1565c0">📖 Kaip veikia sistema</div>
      <div style="font-size:11px;color:var(--td);margin-bottom:8px">Pilna instrukcija apie taukus, tikimybes, aplinkos modifikatorius ir diagnostikos logiką</div>
      <button class="adm-btn" style="background:#1565c0;color:#fff;width:100%;font-size:12px;padding:10px" onclick="showGuide()">📖 Atidaryti instrukciją</button>
    </div>

    <!-- 2. OBJEKTŲ VALDYMAS -->
    <div class="adm-sec">
      <div class="adm-sec-h">🏗 Objektai
        <button class="btn grn sm" style="margin-left:auto" onclick="showAddObj()">+ Naujas</button>
      </div>
      <div id="admin-obj-list"></div>
    </div>

    <!-- 3. TAGŲ KATEGORIJOS -->
    <div class="adm-sec">
      <div class="adm-sec-h"># Tagų kategorijos
        <button class="btn grn sm" style="margin-left:auto" onclick="addTagCat()">+ Kategorija</button>
        <button class="btn ghost sm" onclick="autoCategorizeTags()">⚡ Auto-grupuoti</button>
      </div>
      <div id="admin-tag-cats"></div>
      <div class="adm-info">Sukurk kategorijas ir priskyrk tagus. „Auto-grupuoti" pasiūlys grupes pagal esamą KB.</div>
    </div>

    <!-- 4. TAGŲ PRISKYRIMAS -->
    <div class="adm-sec" style="grid-column:span 2">
      <div class="adm-sec-h">🏷 Nepriskirti tagai (drag & drop į kategorijas)
        <button class="btn ghost sm" style="margin-left:auto" onclick="renderOrphanTags()">↻ Atnaujinti</button>
      </div>
      <div id="admin-orphan-tags" style="min-height:60px"></div>
      <div class="adm-info">Tagai kurie neįeina į jokią kategoriją. Spusk „+ Kur" norėdamas priskirti.</div>
    </div>

    <!-- 5. DUOMBAZĖS ĮRANKIAI -->
    <div class="adm-sec">
      <div class="adm-sec-h">🔧 KB įrankiai</div>
      <div class="adm-btn-grid">
        <button class="adm-btn warn" onclick="normalizePct()">⚖ Normalizuoti %</button>
        <button class="adm-btn sec" onclick="exportTlJson()">⏱ TL JSON eksportas</button>
        <button class="adm-btn ghost" onclick="loadDemo()">📦 Demo duomenys</button>
        <button class="adm-btn ghost" onclick="rebuildIndexes()">♻ Atnaujinti indeksus</button>
      </div>
    </div>

    <!-- 6. SERVERIO STATUSAS -->
    <div class="adm-sec">
      <div class="adm-sec-h">🖥 Serverio statusas</div>
      <div id="adm-server-status"><div style="font-size:11px;color:var(--td)">Tikrinama...</div></div>
      <div class="adm-btn-grid" style="margin-top:8px">
        <button class="adm-btn ghost" onclick="checkServerStatus()">↻ Patikrinti</button>
        <button class="adm-btn ghost" onclick="window.open('api.php?action=debug','_blank')">API debug</button>
      </div>
    </div>

    <!-- 7. PAVOJINGOS OPERACIJOS -->
    <div class="adm-sec" style="border-color:#c62828">
      <div class="adm-sec-h" style="color:#c62828">⚠ Pavojingos operacijos</div>
      <div class="adm-btn-grid">
        <button class="adm-btn red" onclick="if(confirm('IŠTRINTI VISKĄ? Negrįžtama operacija!'))resetAll()">💣 Reset viskas</button>
        <button class="adm-btn warn" onclick="clearDecisionTrees()">🌿 Išvalyti medžius</button>
        <button class="adm-btn warn" onclick="clearTimeline()">⏱ Išvalyti TL</button>
        <button class="adm-btn warn" onclick="clearTagRelations()">⇄ Išvalyti ryšius</button>
      </div>
    </div>

  </div>`;

  
  const objEl=document.getElementById('admin-obj-list');
  if(objEl) objEl.innerHTML=ids.map(id=>{
    const m=KB.objects_meta[id]; const kb=KB.objects[id];
    const fc=Object.keys(kb?.failure_modes||{}).length;
    const hasBase=!!(kb?.function);
    const hasDiag=Object.values(kb?.failure_modes||{}).some(f=>(f.diag_tree||[]).length>0);
    return `<div style="display:flex;align-items:center;gap:6px;padding:6px 8px;background:var(--bg);border:1px solid var(--b1);border-radius:var(--r);margin-bottom:4px">
      <span style="font-size:9px;font-weight:700;color:var(--pri);font-family:'JetBrains Mono',monospace;min-width:64px">${id}</span>
      <span style="font-size:11px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${m.name}</span>
      <span style="font-size:9px;padding:1px 5px;border-radius:20px;background:${hasBase?'#e8f5e9':'#ffebee'};color:${hasBase?'#2e7d32':'#c62828'}">bazė</span>
      <span style="font-size:9px;padding:1px 5px;border-radius:20px;background:${fc>0?'#e8f5e9':'#ffebee'};color:${fc>0?'#2e7d32':'#c62828'}">${fc}g</span>
      <span style="font-size:9px;padding:1px 5px;border-radius:20px;background:${hasDiag?'#e8f5e9':'#fff3e0'};color:${hasDiag?'#2e7d32':'#e65100'}">diag</span>
      ${m.custom?`<button class="btn red sm" style="padding:2px 6px;font-size:9px" onclick="delObj('${id}')">×</button>`:'<span style="font-size:8px;color:var(--td)">numat.</span>'}
      <button class="btn ghost sm" style="padding:2px 6px;font-size:9px" onclick="selObj('${id}');gp('k',document.querySelector('[data-p=k]'))">→</button>
    </div>`;
  }).join('');

  renderTagCatsEd();
  renderOrphanTags();
  checkServerStatus();
}

function renderOrphanTags() {
  const el=document.getElementById('admin-orphan-tags'); if(!el) return;
  const allInCats=new Set(Object.values(KB.tag_categories||{}).flatMap(c=>c.tags||[]));
  const allUsed=new Set();
  Object.values(KB.objects).forEach(kb=>{
    (kb.tags||[]).forEach(t=>allUsed.add(t));
    Object.values(kb.failure_modes||{}).forEach(fm=>{
      (fm.symptoms||[]).forEach(t=>allUsed.add(t));
      (fm.tags||[]).forEach(t=>allUsed.add(t));
    });
  });
  const orphans=[...allUsed].filter(t=>!allInCats.has(t)).filter(Boolean);
  if(!orphans.length){el.innerHTML='<div style="font-size:11px;color:var(--pri)">✓ Visi tagai priskirti kategorijoms</div>';return;}
  el.innerHTML=orphans.map(t=>`
    <span class="orphan-tag">
      ${e(t)}
      <select class="orphan-cat-sel" onchange="assignTagToCat('${e(t)}',this.value);this.value=''" style="font-size:9px;padding:1px 3px;border:none;background:transparent;cursor:pointer">
        <option value="">+ Kur?</option>
        ${Object.keys(KB.tag_categories||{}).map(cat=>`<option value="${e(cat)}">${cat}</option>`).join('')}
        <option value="__new__">+ Nauja kategorija</option>
      </select>
    </span>`).join('');
}

function assignTagToCat(tag, cat) {
  if(!tag||!cat) return;
  if(cat==='__new__') {
    const name=prompt('Nauja kategorija:'); if(!name) return;
    if(!KB.tag_categories[name]) KB.tag_categories[name]={color:'#'+Math.floor(Math.random()*0xffffff).toString(16).padStart(6,'0'),tags:[]};
    KB.tag_categories[name].tags.push(tag);
  } else {
    if(!KB.tag_categories[cat]) KB.tag_categories[cat]={color:'#888',tags:[]};
    if(!KB.tag_categories[cat].tags.includes(tag)) KB.tag_categories[cat].tags.push(tag);
  }
  markDirty('meta_tags'); flushDirty();
  renderTagCatsEd(); renderOrphanTags();
  toast(`✓ "${tag}" priskirtas`);
}

function autoCategorizeTags() {
  
  const syms=new Set(), fails=new Set(), causes=new Set();
  Object.values(KB.objects).forEach(kb=>Object.values(kb.failure_modes||{}).forEach(fm=>{
    (fm.symptoms||[]).forEach(t=>syms.add(t));
    (fm.tags||[]).forEach(t=>fails.add(t));
    if(fm.causes?.primary) fm.causes.primary.split(' ').filter(w=>w.length>4).forEach(w=>causes.add(w.toLowerCase()));
  }));
  let created=0;
  if(syms.size&&!KB.tag_categories['Simptomai']){KB.tag_categories['Simptomai']={color:'#1565c0',tags:[...syms]};created++;}
  if(fails.size&&!KB.tag_categories['Gedimų tagai']){KB.tag_categories['Gedimų tagai']={color:'#c62828',tags:[...fails]};created++;}

  
  const sysTypes=['orapūt','siurbl','filter','membran','elektr','vandens','kanali'];
  sysTypes.forEach(pat=>{
    const matched=[...syms,...fails].filter(t=>t.toLowerCase().includes(pat));
    if(matched.length>=2) {
      const catName=pat.charAt(0).toUpperCase()+pat.slice(1)+'... sistema';
      if(!KB.tag_categories[catName]){KB.tag_categories[catName]={color:'#'+Math.floor(Math.random()*0x888888+0x444444).toString(16),tags:matched};created++;}
    }
  });

  markDirty('meta_tags'); flushDirty();
  renderTagCatsEd(); renderOrphanTags();
  toast(created?`✓ Sukurtos ${created} kategorijos`:'Kategorijos jau egzistuoja');
}

function checkServerStatus() {
  const el=document.getElementById('adm-server-status'); if(!el) return;
  el.innerHTML='<div style="font-size:10px;color:var(--td)">Tikrinama...</div>';
  apiPost('status',{}).then(r=>{
    const tile=(icon,label,val,color='var(--tx)')=>`
      <div style="background:var(--s1);border:1px solid var(--b1);border-radius:8px;padding:8px 10px;display:flex;flex-direction:column;gap:2px">
        <div style="font-size:9px;color:var(--td)">${icon} ${label}</div>
        <div style="font-size:13px;font-weight:700;color:${color}">${val}</div>
      </div>`;
    el.innerHTML=`
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:8px">
        ${tile('✅','Serveris','Veikia','#2e7d32')}
        ${tile('⚙','API versija', 'v'+r.version)}
        ${tile('🐘','PHP', r.php)}
        ${tile('💾','Duomenų dydis', r.data_size)}
        ${tile('🗂','Objektai', r.objects+' vnt.')}
        ${tile('⚠','Gedimai', r.total_failures+' vnt.')}
        ${tile('📋','Situacijos', r.total_situations+' vnt.')}
        ${tile('🎯','Tikimybių užpildymas', r.pct_coverage, r.pct_coverage==='100%'?'#2e7d32':r.pct_coverage==='0%'?'#c62828':'#e65100')}
        ${tile('💿','Backupai', r.backup_count+' vnt.')}
        ${tile('🕐','Paskutinis backup', r.last_backup)}
        ${tile('✏','Paskutinis išsaugojimas', r.last_saved)}
        ${tile('🗄','Meta indeksas', r.meta_exists?'✓ Yra':'✗ Nėra', r.meta_exists?'#2e7d32':'#c62828')}
      </div>`;
  }).catch(err=>{
    el.innerHTML=`<div style="font-size:10px;color:#c62828">⚠ ${err.message||'Serveris nepasiekiamas'}</div>`;
  });
}

function exportKBForAI() {
  const export_data={
    schema:'ibnvs-rag-v1',
    exported:new Date().toISOString(),
    objects_meta:KB.objects_meta,
    objects:KB.objects,
    decision_trees:KB.decision_trees,
    tag_categories:KB.tag_categories,
    tag_relations:KB.tag_relations,
    percentages:KB.percentages,
    timeline:KB.timeline_events,
    ai_iq:calcAIIQ()
  };
  dl(JSON.stringify(export_data,null,2),'ibnvs_rag_export.json');
  toast('🤖 AI RAG eksportas baigtas ✓');
}

function rebuildIndexes() {
  
  learnTagsFromKB();
  markDirty('meta_tags'); flushDirty();
  renderAdmin(); toast('✓ Indeksai atnaujinti');
}

function clearDecisionTrees() {
  if(!confirm('Išvalyti VISUS sprendimų medžius?')) return;
  KB.decision_trees={}; saveAllFiles(); ui(); toast('Medžiai išvalyti');
}

function clearTimeline() {
  if(!confirm('Išvalyti laiko juostą?')) return;
  KB.timeline_events=[]; markDirty('meta_timeline'); flushDirty(); toast('Laiko juosta išvalyta');
}

function clearTagRelations() {
  if(!confirm('Išvalyti VISUS tagų ryšius?')) return;
  KB.tag_relations=[]; markDirty('meta_trel'); flushDirty(); renderAdmin(); toast('Ryšiai išvalyti');
}

function showAddObj() {
  openModal('Naujas objektas',`
    <div class="row2">
      <div><div class="lbl">ID (didžiosios)</div><input type="text" id="m-oi" placeholder="MANOOBJ"></div>
      <div><div class="lbl">Pavadinimas</div><input type="text" id="m-on" placeholder="Mano objektas"></div>
    </div>
    <div class="lbl">Sektoriai</div>
    <div class="micro">${['A','B','C','D','E'].map(s=>`<button class="mb" onclick="this.classList.toggle('on')" data-s="${s}">${s}</button>`).join('')}</div>
    <div class="lbl">Gylis</div>
    <select id="m-oz"><option value="@ipgil">@ipgil</option><option value="@gilu">@gilu</option><option value="@zempav">@zempav</option><option value="@lbgilu">@lbgilu</option></select>
  `,()=>{
    const id=v('m-oi').toUpperCase().replace(/\W/g,'');
    if(!id){toast('Būtinas ID');return;}
    if(KB.objects_meta[id]){toast('Toks ID jau egzistuoja');return;}
    const sek=[...document.querySelectorAll('#modal-b .mb.on')].map(b=>b.dataset.s);
    KB.objects_meta[id]={id,name:v('m-on')||id,sek:sek.length?sek:['B'],z:v('m-oz'),custom:true};
    KB.objects[id]=emptyObj(id,v('m-on')||id);
    ui(); renderAdmin(); closeModal(); toast(id+' sukurtas ✓');
  });
}

function delObj(id) {
  if(!KB.objects_meta[id]?.custom){toast('Negalima ištrinti numatytojo objekto');return;}
  if(!confirm('Ištrinti '+id+' ir VISUS jo duomenis?')) return;
  delete KB.objects_meta[id]; delete KB.objects[id];
  if(KB.percentages[id]) delete KB.percentages[id];
  Object.keys(KB.decision_trees).forEach(k=>{if(KB.decision_trees[k]?.object_id===id)delete KB.decision_trees[k];});
  if(curObj===id) curObj=Object.keys(KB.objects_meta)[0]||'BNVI';
  clearTimeout(_saveTimer); _dirty.clear();
  showSaveInd('Trinamas…','#e65100');
  apiPost('delete_object',{id}).then(()=>{showSaveInd('🗑 Ištrinta','#2e7d32');toast('🗑 '+id+' ištrinta');}).catch(err=>{showSaveInd('✗ Klaida','#c62828');toast('⚠ '+err.message);});
  ui(); renderAdmin();
}

function resetAll() {
  KB.objects_meta={}; KB.objects={}; KB.field_cases=[]; KB.timeline_events=[]; KB.decision_trees={}; KB.percentages={}; KB.tag_relations=[];
  initObjs(); ui(); renderAdmin(); saveAllFiles(); toast('Reset atliktas');
}

function loadDemo() {
  const kb=KB.objects['BNVI']; if(!kb) return;
  kb.function='Biologiškai valo buitines nuotekas aerobinės fermentacijos būdu';
  kb.normal_operation='Orapūtė nuolat tiekia orą, burbuliuoja, nesmirda, iš sistemos ištekantis vanduo skaidrus';
  kb.normal_signs=['Burbuliuoja','Nesmirda','Vanduo skaidrus'];
  if(!kb.failure_modes['BNVI-F001']){
    kb.failure_modes['BNVI-F001']={
      id:'BNVI-F001', name:'Orapūtė neveikia', severity:'high', frequency:12,
      tags:['elektra'], symptoms:['Neveikia oro padavimas','Kvapas','Putojimas sustojo'],
      causes:{primary:'Elektros gedimas arba sugedusi membrana'},
      dt1:'iš karto', dt2:'3-7 dienos',
      diag_tree:[
        {question:'Ar prie skydelio dega maitinimo indikatorius?', yes:'Elektros tiekimas normalus – problema orapūtėje', yes_status:'next', no_next:2},
        {question:'Ar orapūtė siunčia oro burbuliukus (patikrink vizualiai)?', yes:'Ore kanalas užsikimšęs – patikrink žarnas ir išpūtiklius', yes_status:'fixed', no_next:'specialist'},
        {question:'Ar orapūtė duoda bet kokį garsą (dūzgimą)?', yes:'Membrana sugedusi – pakeisk membraną', yes_status:'fixed', no_next:'specialist'}
      ],
      prevention:'Kas 3 metai keisti membraną, tikrinti žarnas',
      env_modifiers:{gvl1:{prob_mult:'1.5'},gvl2:{prob_mult:'1.0'},smel:{prob_mult:'0.8'},mol:{prob_mult:'1.2'},old:{prob_mult:'2.5'}},
      relations:{}, meta:{confidence:95, first_seen:'2020', created:new Date().toISOString()}
    };
    KB.percentages['BNVI']={'BNVI-F001':{base:35,gvl1:1.5,gvl2:1.0,smel:0.8,mol:1.2,old:2.5}};
  }
  markDirty('obj_BNVI'); flushDirty();
  updateCounts(); renderObjList(); renderKTab(); toast('Demo duomenys įkelti ✓');
}
