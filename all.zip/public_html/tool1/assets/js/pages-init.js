function renderAll() {
  learnTagsFromKB();
  renderObjList(); renderKTab(); updateJson(); updateCounts();
  initDiag();
}

function _applyServerData(data) {
  if (!data) return;

  // Objektai - pildome KB.objects iš serverio base.json duomenų
  if (data.objects) {
    for (const [oid, parts] of Object.entries(data.objects)) {
      const base = parts.base || {};
      if (!KB.objects_meta[oid]) {
        KB.objects_meta[oid] = {
          id: oid,
          name: base.name || oid,
          sek: base.sek || [],
          z: base.z || '',
          custom: base.custom || false,
        };
      }
      if (!KB.objects[oid]) KB.objects[oid] = { failure_modes: {} };
      const kb = KB.objects[oid];
      if (base.name)                 kb.name               = base.name;
      if (base.function)             kb.function           = base.function;
      if (base.normal_operation)     kb.normal_operation   = base.normal_operation;
      if (base.normal_signs)         kb.normal_signs       = base.normal_signs;
      if (base.tags)                 kb.tags               = base.tags;
      if (base.models)               kb.models             = base.models;
      if (base.packages)             kb.packages           = base.packages;
      if (base.maintenance_schedule) kb.maintenance_schedule = base.maintenance_schedule;
      if (base.scene_3d)             kb.scene_3d           = base.scene_3d;
      if (base.meta)                 kb.meta               = base.meta;
      if (parts.env)                 kb.env_behavior       = parts.env;
      if (parts.relations)           kb.relations          = parts.relations;
      if (parts.exploitation_errors) kb.exploitation_errors = parts.exploitation_errors;
    }
  }

  // Gedimai
  if (data.failures) {
    for (const [oid, fms] of Object.entries(data.failures)) {
      if (!KB.objects[oid]) KB.objects[oid] = { failure_modes: {} };
      for (const [fid, fm] of Object.entries(fms)) {
        if (fid === '_index') continue;
        KB.objects[oid].failure_modes[fid] = fm;
      }
    }
  }

  // Komponentai - SVARBU: serveris grąžina { PARENT_ID: { CID: {...} } }
  if (data.components) {
    for (const [parentId, comps] of Object.entries(data.components)) {
      for (const [cid, comp] of Object.entries(comps)) {
        KB.components[cid] = comp;
        KB.components_meta[cid] = {
          id:        cid,
          name:      comp.name || cid,
          parent_id: comp.parent_id || parentId,
          y_level:   comp.y_level || 1,
          active:    comp.active !== false,
          map_x:     comp.map_x ?? null,
          map_y:     comp.map_y ?? null,
          map_z:     comp.map_z ?? null,
        };
      }
    }
  }

  // Medžiai (decision trees)
  if (data.trees) {
    for (const [oid, trees] of Object.entries(data.trees)) {
      for (const [tid, tree] of Object.entries(trees)) {
        KB.decision_trees[tid] = tree;
      }
    }
  }

  // Tikimybės
  if (data.percentages) {
    for (const [oid, pct] of Object.entries(data.percentages)) {
      KB.percentages[oid] = pct;
    }
  }

  // Meta (tag kategorijos, ryšiai)
  if (data.meta) {
    if (data.meta.tag_categories) KB.tag_categories = data.meta.tag_categories;
    if (data.meta.tag_relations)  KB.tag_relations  = data.meta.tag_relations;
  }
}

async function init() {
  showSaveInd('Kraunama iš serverio…', '#e65100');
  const data = await loadFromServer();

  initObjs();
  if (!data) { loadFromLS(); showSaveInd('Serverio nėra – įkelta iš lokalaus', '#ff9800'); }
  else       { _applyServerData(data); showSaveInd('✓ Įkelta iš serverio', '#2e7d32'); }
  renderAll();

  _restoreTab();
}
