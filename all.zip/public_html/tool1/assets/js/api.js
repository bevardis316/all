const API = 'api.php';
const _dirty = new Set();
let _saveTimer = null;

window._csrfToken = '';
fetch(API + '?action=csrf_token').then(r => r.json()).then(d => { window._csrfToken = d.token || ''; }).catch(() => {});

function markDirty(key) {
  _dirty.add(key);
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(flushDirty, 1800);
  showSaveInd('Nesaugota…', '#e65100');
}

async function flushDirty() {
  if (!_dirty.size) return;
  const keys = [..._dirty]; _dirty.clear();
  showSaveInd('Saugojama…', '#e65100');
  const errors = [];

  for (const key of keys) {
    try {
      if (key === 'meta_tags')      await apiPost('save_meta', {file:'tag_categories', data:KB.tag_categories});
      else if (key === 'meta_trel') await apiPost('save_meta', {file:'tag_relations',  data:KB.tag_relations});
      else if (key === 'meta_cfg')  await apiPost('save_meta', {file:'system_config',  data:{version:'6.0',updated:new Date().toISOString()}});
      else if (key.startsWith('obj_')) {
        const oid = key.slice(4);
        const kb = KB.objects[oid]; const meta = KB.objects_meta[oid];
        if (kb && meta) await apiPost('save_object_base', {
          id:oid, name:meta.name, sek:meta.sek, z:meta.z, custom:meta.custom||false,
          base:{id:oid,name:meta.name,sek:meta.sek,z:meta.z,custom:meta.custom||false,function:kb.function||'',normal_operation:kb.normal_operation||'',normal_signs:kb.normal_signs||[],tags:kb.tags||[],models:kb.models||[],packages:kb.packages||[],maintenance_schedule:kb.maintenance_schedule||{},meta:kb.meta||{},scene_3d:kb.scene_3d||{}},
          env:kb.env_behavior||{},
          relations:kb.relations||{},
          exploitation_errors:kb.exploitation_errors||[]
        });
      }
      else if (key.startsWith('fail_')) {
        const [,oid,fid] = key.split('_');
        const fm = KB.objects[oid]?.failure_modes[fid];
        if (fm) await apiPost('save_failure', {...fm, id:fid, object_id:oid});
      }
      else if (key.startsWith('tree_')) {
        const parts = key.split('_'); const oid=parts[1]; const fid=parts.slice(2).join('_');
        const tree = KB.decision_trees[fid];
        if (tree) await apiPost('save_tree', {...tree, object_id:oid, failure_id:fid});
      }
      else if (key.startsWith('pct_')) {
        const oid = key.slice(4);
        const pct = KB.percentages[oid];
        if (pct) await apiPost('save_percentages', {object_id:oid, failures:pct});
      }
      else if (key.startsWith('comp_')) {
        const cid = key.slice(5);
        const comp = KB.components[cid];
        const meta = KB.components_meta[cid];
        if (comp && meta) await apiPost('save_component', {...comp, id:cid, parent_id:comp.parent_id||meta.parent_id||''});
      }
      else if (key.startsWith('case_')) {
        const cid = key.slice(5);
        const c = KB.field_cases.find(x=>x.id===cid);
        if (c) await apiPost('save_case', c);
      }
      else if (key === 'timeline') {
        for (const ev of KB.timeline_events) await apiPost('save_timeline', ev);
      }
    } catch(err) { errors.push(key); _dirty.add(key); }
  }

  if (errors.length) {
    showSaveInd('⚠ '+errors.length+' klaida(os)', '#c62828');
  } else {
    showSaveInd('✓ Išsaugota', '#2e7d32');
  }
  if (typeof renderSaveLog === 'function') renderSaveLog();
}

async function loadFromServer() {
  try {
    showSaveInd('Kraunama…', '#1565c0');
    const r = await fetch(API + '?action=load_all');
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const d = await r.json();
    if (!d.ok) throw new Error(d.error || 'Klaida');
    return d.data;
  } catch(e) {
    showSaveInd('✗ Nepavyko krauti', '#c62828');
    throw e;
  }
}

async function apiPost(action, data) {
  const r = await fetch(API + '?action=' + action, {
    method: 'POST',
    headers: {'Content-Type':'application/json','X-CSRF-Token': window._csrfToken||''},
    body: JSON.stringify(data)
  });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return r.json();
}

function showSaveInd(msg, color) {
  const el = document.getElementById('saveInd');
  if (el) { el.textContent = msg; el.style.color = color; }
}
