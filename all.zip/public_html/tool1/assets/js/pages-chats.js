/**
 * pages-chats.js — Pokalbių peržiūra ir redagavimas
 *
 * Rodo vartotojų pokalbius su AI. Leidžia admin redaguoti AI atsakymą
 * ir išsaugoti kaip patvirtintą pavyzdį (pateks į AI kaip few-shot).
 */

let _chatsData = [];

async function loadChats() {
  const wrap = document.getElementById('chats-list');
  if (!wrap) return;
  wrap.innerHTML = '<div style="color:var(--td);padding:20px;text-align:center">⏳ Kraunama...</div>';

  try {
    const r = await apiPost('load_chats', {});
    _chatsData = r.entries || [];
    _renderChats();
  } catch (e) {
    wrap.innerHTML = '<div style="color:#ef4444;padding:20px">Klaida: ' + e.message + '</div>';
  }
}

function _renderChats() {
  const wrap = document.getElementById('chats-list');
  if (!wrap) return;

  const onlyUnapproved = document.getElementById('chatsShowUnapproved')?.checked;
  let entries = _chatsData;
  if (onlyUnapproved) entries = entries.filter(e => !e.approved);

  const countEl = document.getElementById('chatsCount');
  if (countEl) countEl.textContent = entries.length + ' pokalbių';

  // Badge nav
  const unapprovedCount = _chatsData.filter(e => !e.approved).length;
  const badge = document.getElementById('chatsBadge');
  if (badge) {
    badge.textContent = unapprovedCount;
    badge.style.display = unapprovedCount > 0 ? '' : 'none';
  }

  if (!entries.length) {
    wrap.innerHTML = '<div style="color:var(--td);padding:40px;text-align:center">Pokalbių nėra' + (onlyUnapproved ? ' (visi patikrinti)' : '') + '</div>';
    return;
  }

  wrap.innerHTML = entries.map(e => _chatCard(e)).join('');
}

function _chatCard(e) {
  const approved = e.approved;
  const intentLabel = {
    'KAINA': '💰 Kaina', 'GEDIMAS': '🔴 Gedimas', 'SISTEMOS_PASIRINKIMAS': '🏗 Sistema',
    'SPECIALISTAS': '👤 Specialistas', 'KAS_VEIKIA': '❓ Kaip veikia', 'KITA': '💬 Kita'
  }[e.intent] || e.intent || '?';

  const userHtml  = _esc(e.user || '');
  const aiHtml    = _esc(e.ai || '');
  const cardId    = 'chat-' + e.id;
  const approvedBadge = approved
    ? '<span style="background:#d1fae5;color:#065f46;font-size:10px;padding:2px 7px;border-radius:8px;font-weight:600">✓ patikrinta</span>'
    : '<span style="background:#fef3c7;color:#92400e;font-size:10px;padding:2px 7px;border-radius:8px;font-weight:600">laukia</span>';

  return `
<div id="${cardId}" style="border:1px solid var(--b1);border-radius:10px;margin-bottom:10px;overflow:hidden;background:var(--s1)">
  <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;cursor:pointer;user-select:none"
       onclick="_toggleChat('${e.id}')">
    <span style="font-size:11px;color:var(--td);flex-shrink:0">${intentLabel}</span>
    <span style="flex:1;font-size:13px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"
          title="${userHtml}">${userHtml}</span>
    ${approvedBadge}
    <span style="font-size:12px;color:var(--td)" id="chat-arrow-${e.id}">▼</span>
  </div>
  <div id="chat-body-${e.id}" style="display:none;padding:0 14px 14px">
    <div style="margin-bottom:10px">
      <div style="font-size:11px;font-weight:600;color:var(--td);margin-bottom:4px">KLAUSIMAS</div>
      <div style="background:var(--bg);border-radius:6px;padding:10px;font-size:13px;line-height:1.5;white-space:pre-wrap">${userHtml}</div>
    </div>
    <div style="margin-bottom:12px">
      <div style="font-size:11px;font-weight:600;color:var(--td);margin-bottom:4px">AI ATSAKYMAS <span style="font-weight:400;color:var(--td)">(redaguokite ir išsaugokite)</span></div>
      <textarea id="chat-ta-${e.id}"
        style="width:100%;box-sizing:border-box;min-height:100px;resize:vertical;background:var(--bg);border:1.5px solid var(--b1);border-radius:6px;padding:10px;font-size:13px;line-height:1.5;font-family:inherit;color:var(--text)"
      >${aiHtml}</textarea>
    </div>
    <div style="display:flex;gap:8px">
      <button class="btn pri sm" onclick="_saveChat('${e.id}')">💾 Išsaugoti kaip pavyzdį</button>
      <button class="btn ghost sm" onclick="_toggleChat('${e.id}')">Uždaryti</button>
    </div>
  </div>
</div>`;
}

function _toggleChat(id) {
  const body  = document.getElementById('chat-body-' + id);
  const arrow = document.getElementById('chat-arrow-' + id);
  if (!body) return;
  const open = body.style.display !== 'none';
  body.style.display  = open ? 'none' : '';
  if (arrow) arrow.textContent = open ? '▼' : '▲';
}

async function _saveChat(id) {
  const ta = document.getElementById('chat-ta-' + id);
  if (!ta) return;

  const entry = _chatsData.find(e => e.id === id);
  if (!entry) return;

  const assistant = ta.value.trim();
  if (!assistant) { alert('Atsakymas tuščias'); return; }

  const btn = document.querySelector(`#chat-${id} .btn.pri`);
  if (btn) { btn.disabled = true; btn.textContent = '⏳...'; }

  try {
    await apiPost('save_chat_edit', { id, user: entry.user, assistant });
    // Atnaujinti lokaliai
    entry.approved = true;
    entry.ai       = assistant;
    _renderChats();
  } catch (e) {
    alert('Klaida: ' + e.message);
    if (btn) { btn.disabled = false; btn.textContent = '💾 Išsaugoti kaip pavyzdį'; }
  }
}

function _esc(s) {
  return String(s)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}
