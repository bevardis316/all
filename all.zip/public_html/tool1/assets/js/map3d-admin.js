let _camCalib = null;
let _glbPanelOpen = false;
let _glbSelObj = null;     // gali būti "obj:OID" arba "comp:CID"
let _camCalibSel = null;   // pasirinktas kalibruojamas elementas: "obj:OID" arba "comp:CID"


// ── KAMEROS KALIBRATORIAUS PANELIS ─────────────────────────────────
let _camPanelOpen = false;

// Helper: gauti pasirinkto elemento info
function _adm_getCamSelTarget() {
  // 1) rankiniai pasirinkimas dropdown'e (turi pirmenybę)
  if (_camCalibSel) {
    const [type, id] = _camCalibSel.split(':');
    if (type === 'comp' && KB.components[id]) {
      return { type:'comp', id, name: KB.components[id].name || id, kb: KB.components[id] };
    }
    if (type === 'obj' && KB.objects[id]) {
      return { type:'obj', id, name: KB.objects_meta[id]?.name || id, kb: KB.objects[id] };
    }
  }
  // 2) per scenos pasirinkimą (selComp turi pirmenybę prieš selObj)
  if (_selComp && KB.components[_selComp.id]) {
    return { type:'comp', id:_selComp.id, name: KB.components[_selComp.id].name || _selComp.id, kb: KB.components[_selComp.id] };
  }
  if (_selObj && KB.objects[_selObj]) {
    return { type:'obj', id:_selObj, name: KB.objects_meta[_selObj]?.name || _selObj, kb: KB.objects[_selObj] };
  }
  return null;
}

function _adm_getCamSaved(target) {
  if (!target) return null;
  if (target.type === 'comp') return target.kb.cam_click || null;
  return target.kb.scene_3d?.cam_click || null;
}

function _adm_toggleCamPanel() {
  _camPanelOpen = !_camPanelOpen;
  const existing = document.getElementById('adm-cam-panel');
  if (existing) { existing.remove(); if (!_camPanelOpen) return; }
  if (!_camPanelOpen) return;
  _adm_renderCamPanel();
}

function _adm_renderCamPanel() {
  const area = document.getElementById('map-area');
  if (!area) return;
  const old = document.getElementById('adm-cam-panel');
  if (old) old.remove();

  const orb = _3d?.orb;
  const target = _adm_getCamSelTarget();
  const saved = _adm_getCamSaved(target);

  // Sąrašo užpildymas: visi objektai + visi komponentai
  let opts = '<option value="">— pasirink objektą / komponentą —</option>';
  // Jei kažkas pasirinkta scenoje - pridėti grupę "Pasirinkta scenoje"
  const sceneSel = [];
  if (_selObj) sceneSel.push({type:'obj',id:_selObj,name:KB.objects_meta[_selObj]?.name||_selObj});
  if (_selComp) sceneSel.push({type:'comp',id:_selComp.id,name:KB.components[_selComp.id]?.name||_selComp.id});
  if (sceneSel.length) {
    opts += '<optgroup label="📍 Pasirinkta scenoje">';
    sceneSel.forEach(it => {
      const v = it.type+':'+it.id;
      const sel = (_camCalibSel===v || (!_camCalibSel && target && target.type===it.type && target.id===it.id)) ? ' selected' : '';
      const ico = it.type==='obj' ? '🔵' : '📦';
      opts += '<option value="'+v+'"'+sel+'>'+ico+' '+it.name+'</option>';
    });
    opts += '</optgroup>';
  }
  // Objektai
  opts += '<optgroup label="🔵 Objektai">';
  Object.keys(KB.objects_meta || {}).forEach(id => {
    const n = KB.objects_meta[id]?.name || id;
    const v = 'obj:'+id;
    const sel = _camCalibSel===v ? ' selected' : '';
    const hasCam = KB.objects[id]?.scene_3d?.cam_click ? ' ✓' : '';
    opts += '<option value="'+v+'"'+sel+'>'+n+hasCam+'</option>';
  });
  opts += '</optgroup>';
  // Komponentai
  opts += '<optgroup label="📦 Komponentai">';
  Object.keys(KB.components || {}).sort().forEach(cid => {
    const c = KB.components[cid];
    if (!c) return;
    const n = c.name || cid;
    const par = c.parent_id ? ' ('+c.parent_id+')' : '';
    const v = 'comp:'+cid;
    const sel = _camCalibSel===v ? ' selected' : '';
    const hasCam = c.cam_click ? ' ✓' : '';
    opts += '<option value="'+v+'"'+sel+'>'+n+par+hasCam+'</option>';
  });
  opts += '</optgroup>';

  // Dabartinė kameros pozicija
  const orbHtml = orb
    ? 'r='+orb.r?.toFixed(2)+' θ='+orb.theta?.toFixed(2)+' φ='+orb.phi?.toFixed(2)+'<br>'+
      'tx='+orb.target?.x?.toFixed(2)+' ty='+orb.target?.y?.toFixed(2)+' tz='+orb.target?.z?.toFixed(2)
    : 'Scena nekraunama';

  // Išsaugotos pozicijos statusas
  const savedHtml = saved
    ? '<div style="font-size:10px;color:#2e7d32;margin:4px 0">✓ Išsaugota: r='+saved.r?.toFixed(2)+' θ='+saved.theta?.toFixed(2)+' φ='+saved.phi?.toFixed(2)+'</div>'
    : '<div style="font-size:10px;color:var(--td);margin:4px 0">Išsaugotos pozicijos nėra</div>';

  // Rankiniai input'ai (6 reikšmės)
  const baseVals = saved || (orb ? {r:orb.r,theta:orb.theta,phi:orb.phi,tx:orb.target?.x||0,ty:orb.target?.y||0,tz:orb.target?.z||0} : {r:8,theta:0,phi:1.5,tx:0,ty:0,tz:0});
  const inpStyle = 'width:55px;padding:2px 4px;font-size:11px;border:1px solid var(--b1);border-radius:3px;font-family:monospace';
  const inputsHtml =
    '<div style="display:grid;grid-template-columns:auto 1fr auto auto;gap:4px 6px;align-items:center;margin-top:6px">'+
      '<span style="font-size:10px;color:var(--td)" title="Atstumas nuo taikinio">r</span>'+
      '<input id="cam-inp-r" type="number" step="0.1" value="'+(baseVals.r||0).toFixed(2)+'" style="'+inpStyle+'">'+
      '<button class="cam-btn-step" data-id="r" data-d="-0.5" style="padding:0 6px;font-size:10px;height:20px">−</button>'+
      '<button class="cam-btn-step" data-id="r" data-d="0.5" style="padding:0 6px;font-size:10px;height:20px">+</button>'+

      '<span style="font-size:10px;color:var(--td)" title="Horizontalus kampas (rad)">θ</span>'+
      '<input id="cam-inp-theta" type="number" step="0.05" value="'+(baseVals.theta||0).toFixed(3)+'" style="'+inpStyle+'">'+
      '<button class="cam-btn-step" data-id="theta" data-d="-0.1" style="padding:0 6px;font-size:10px;height:20px">−</button>'+
      '<button class="cam-btn-step" data-id="theta" data-d="0.1" style="padding:0 6px;font-size:10px;height:20px">+</button>'+

      '<span style="font-size:10px;color:var(--td)" title="Vertikalus kampas (rad)">φ</span>'+
      '<input id="cam-inp-phi" type="number" step="0.05" value="'+(baseVals.phi||0).toFixed(3)+'" style="'+inpStyle+'">'+
      '<button class="cam-btn-step" data-id="phi" data-d="-0.1" style="padding:0 6px;font-size:10px;height:20px">−</button>'+
      '<button class="cam-btn-step" data-id="phi" data-d="0.1" style="padding:0 6px;font-size:10px;height:20px">+</button>'+

      '<div style="grid-column:1/-1;height:1px;background:var(--b2);margin:3px 0"></div>'+

      '<span style="font-size:10px;color:var(--td)" title="Taikinio X">tx</span>'+
      '<input id="cam-inp-tx" type="number" step="0.1" value="'+(baseVals.tx||0).toFixed(2)+'" style="'+inpStyle+'">'+
      '<button class="cam-btn-step" data-id="tx" data-d="-0.2" style="padding:0 6px;font-size:10px;height:20px">−</button>'+
      '<button class="cam-btn-step" data-id="tx" data-d="0.2" style="padding:0 6px;font-size:10px;height:20px">+</button>'+

      '<span style="font-size:10px;color:var(--td)" title="Taikinio Y">ty</span>'+
      '<input id="cam-inp-ty" type="number" step="0.1" value="'+(baseVals.ty||0).toFixed(2)+'" style="'+inpStyle+'">'+
      '<button class="cam-btn-step" data-id="ty" data-d="-0.2" style="padding:0 6px;font-size:10px;height:20px">−</button>'+
      '<button class="cam-btn-step" data-id="ty" data-d="0.2" style="padding:0 6px;font-size:10px;height:20px">+</button>'+

      '<span style="font-size:10px;color:var(--td)" title="Taikinio Z">tz</span>'+
      '<input id="cam-inp-tz" type="number" step="0.1" value="'+(baseVals.tz||0).toFixed(2)+'" style="'+inpStyle+'">'+
      '<button class="cam-btn-step" data-id="tz" data-d="-0.2" style="padding:0 6px;font-size:10px;height:20px">−</button>'+
      '<button class="cam-btn-step" data-id="tz" data-d="0.2" style="padding:0 6px;font-size:10px;height:20px">+</button>'+
    '</div>';

  const whatSel = target
    ? (target.type==='comp' ? '📦 ' : '🔵 ') + target.name
    : '— nieko nepasirinkta —';

  const panel = document.createElement('div');
  panel.id = 'adm-cam-panel';
  panel.style.cssText = 'position:absolute;top:44px;right:8px;z-index:40;background:var(--s1);border:1.5px solid var(--b2);border-radius:var(--r2);padding:12px 14px;min-width:280px;max-width:320px;box-shadow:var(--shadow2);font-size:11px;max-height:calc(100vh - 100px);overflow-y:auto';
  panel.innerHTML = `
    <div style="font-weight:700;color:var(--pri);margin-bottom:8px;display:flex;align-items:center;justify-content:space-between">
      📷 Kameros kalibratorius
      <button onclick="_adm_toggleCamPanel()" style="background:none;border:none;cursor:pointer;font-size:14px;color:var(--td);padding:0 2px">✕</button>
    </div>

    <div style="color:var(--td);font-size:10px;margin-bottom:3px">Pasirink objektą / komponentą:</div>
    <select id="cam-calib-sel" style="width:100%;padding:4px 6px;font-size:11px;border:1px solid var(--b1);border-radius:4px;height:26px;margin-bottom:8px">${opts}</select>

    <div style="font-weight:600;margin-bottom:6px;color:var(--text);font-size:11px">${whatSel}</div>

    <div style="color:var(--td);font-size:10px;margin-bottom:2px">Dabartinė kameros pozicija:</div>
    <div style="font-family:monospace;font-size:10px;background:var(--s2);padding:5px 8px;border-radius:var(--r);margin-bottom:4px;line-height:1.5">${orbHtml}</div>
    ${savedHtml}

    <div style="border-top:1px solid var(--b2);margin-top:8px;padding-top:8px">
      <div style="color:var(--td);font-size:10px;margin-bottom:2px">Rankinis valdymas (live):</div>
      ${inputsHtml}
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:10px">
      <button class="btn sm pri" onclick="_adm_saveCamClick()" style="font-size:11px">💾 Išsaugoti</button>
      <button class="btn sm" onclick="_adm_testFlyCam()" style="font-size:11px;background:#e3f2fd;color:#1565c0;border:1px solid #90caf9">▶ Test fly</button>
      <button class="btn sm ghost" onclick="_adm_copyCamLink()" style="font-size:11px">🔗 Kopijuoti nuorodą</button>
      ${saved ? '<button class="btn sm ghost" onclick="_adm_clearCamClick()" style="font-size:11px;color:#c62828;border-color:#c62828">✕ Ištrinti</button>' : '<span></span>'}
    </div>

    ${target ? '' : '<div style="color:#e65100;font-size:10px;margin-top:8px">⚠ Pasirink objektą iš sąrašo arba scenoje</div>'}
  `;
  area.appendChild(panel);

  // Event handlerai
  const selEl = document.getElementById('cam-calib-sel');
  if (selEl) selEl.onchange = () => { _camCalibSel = selEl.value || null; _adm_renderCamPanel(); };

  // Rankinių input'ų live-update
  ['r','theta','phi','tx','ty','tz'].forEach(k => {
    const inp = document.getElementById('cam-inp-'+k);
    if (inp) {
      inp.oninput = () => _adm_applyCamInputs();
      inp.onchange = () => _adm_applyCamInputs();
    }
  });

  // +/- mygtukai
  panel.querySelectorAll('.cam-btn-step').forEach(btn => {
    btn.onclick = () => {
      const id = btn.dataset.id;
      const d = parseFloat(btn.dataset.d);
      const inp = document.getElementById('cam-inp-'+id);
      if (!inp) return;
      const v = parseFloat(inp.value || 0) + d;
      inp.value = v.toFixed(id==='r' || id.startsWith('t') ? 2 : 3);
      _adm_applyCamInputs();
    };
  });
}

// Pritaikyti rankinius input'us prie kameros (live)
function _adm_applyCamInputs() {
  const orb = _3d?.orb;
  const apply = _3d?.applyOrbit;
  if (!orb || !apply) return;
  const r = parseFloat(document.getElementById('cam-inp-r')?.value);
  const th = parseFloat(document.getElementById('cam-inp-theta')?.value);
  const ph = parseFloat(document.getElementById('cam-inp-phi')?.value);
  const tx = parseFloat(document.getElementById('cam-inp-tx')?.value);
  const ty = parseFloat(document.getElementById('cam-inp-ty')?.value);
  const tz = parseFloat(document.getElementById('cam-inp-tz')?.value);
  if (!isNaN(r)) orb.r = r;
  if (!isNaN(th)) orb.theta = th;
  if (!isNaN(ph)) orb.phi = ph;
  if (!isNaN(tx)) orb.target.x = tx;
  if (!isNaN(ty)) orb.target.y = ty;
  if (!isNaN(tz)) orb.target.z = tz;
  apply();
  _userMovedCam = true;
}

// Test fly: animuoja kamerą į išsaugotą poziciją (kaip vartotojui)
function _adm_testFlyCam() {
  const target = _adm_getCamSelTarget();
  const saved = _adm_getCamSaved(target);
  if (!saved) { toast('Nėra išsaugotos pozicijos. Pirma išsaugok.'); return; }
  const orb = _3d?.orb;
  const apply = _3d?.applyOrbit;
  if (!orb || !apply) { toast('Scena nekraunama'); return; }
  if (typeof _camFlyTo === 'function') {
    _camFlyTo(saved, orb, apply);
    _userMovedCam = true;
    toast('▶ Test fly: '+ (target?.name||''));
  } else {
    // fallback - momentinis
    Object.assign(orb, {r:saved.r,theta:saved.theta,phi:saved.phi});
    if (orb.target) {orb.target.x=saved.tx||0; orb.target.y=saved.ty||0; orb.target.z=saved.tz||0;}
    apply();
  }
}

// Nuorodos kopijavimas: /kon/#obj=BNVI arba /kon/#obj=BNVI&comp=AERAT
function _adm_copyCamLink() {
  const target = _adm_getCamSelTarget();
  if (!target) { toast('Pasirink objektą'); return; }
  let url = window.location.origin + '/kon/#';
  if (target.type === 'comp') {
    const parentOid = target.kb.parent_id;
    // raskime root objektą (komponentas gali turėti tarpinę grandinę)
    let rootOid = parentOid;
    while (rootOid && KB.components[rootOid]) {
      rootOid = KB.components[rootOid].parent_id;
    }
    if (rootOid) url += 'obj='+rootOid+'&comp='+target.id;
    else url += 'comp='+target.id;
  } else {
    url += 'obj='+target.id;
  }
  if (navigator.clipboard) {
    navigator.clipboard.writeText(url).then(()=>toast('🔗 Nuoroda nukopijuota: '+url));
  } else {
    prompt('Kopijuok nuorodą:', url);
  }
}

function _adm_saveCamClick() {
  const orb = _3d?.orb;
  if (!orb) { toast('Scena nekraunama'); return; }
  const target = _adm_getCamSelTarget();
  if (!target) { toast('Pasirink objektą arba komponentą'); return; }

  const cam = {
    r:     parseFloat(orb.r.toFixed(3)),
    theta: parseFloat(orb.theta.toFixed(3)),
    phi:   parseFloat(orb.phi.toFixed(3)),
    tx:    parseFloat((orb.target?.x||0).toFixed(3)),
    ty:    parseFloat((orb.target?.y||0).toFixed(3)),
    tz:    parseFloat((orb.target?.z||0).toFixed(3)),
  };

  if (target.type === 'comp') {
    if (!KB.components[target.id]) { toast('Komponentas nerastas'); return; }
    KB.components[target.id].cam_click = cam;
    if (!KB.components_meta[target.id]) KB.components_meta[target.id] = {};
    markDirty('comp_' + target.id);
    if (typeof flushDirty === 'function') flushDirty();
    toast('📷 Kameros pozicija išsaugota: ' + target.name);
  } else {
    if (!KB.objects[target.id]) { toast('Objektas nerastas'); return; }
    if (!KB.objects[target.id].scene_3d) KB.objects[target.id].scene_3d = {};
    KB.objects[target.id].scene_3d.cam_click = cam;
    markDirty('obj_' + target.id);
    if (typeof flushDirty === 'function') flushDirty();
    toast('📷 Kameros pozicija išsaugota: ' + target.name);
  }
  _adm_renderCamPanel();
}

function _adm_clearCamClick() {
  const target = _adm_getCamSelTarget();
  if (!target) return;
  if (target.type === 'comp') {
    if (KB.components[target.id]) {
      delete KB.components[target.id].cam_click;
      markDirty('comp_'+target.id);
      if (typeof flushDirty==='function') flushDirty();
    }
  } else {
    if (KB.objects[target.id]?.scene_3d) {
      delete KB.objects[target.id].scene_3d.cam_click;
      markDirty('obj_'+target.id);
      if (typeof flushDirty==='function') flushDirty();
    }
  }
  toast('Pozicija ištrinta');
  _adm_renderCamPanel();
}
// ───────────────────────────────────────────────────────────────────

function _adm_build3d(canvas) {
  if(_3d){
    if(_3d.orb&&_3d.orb.target&&_userMovedCam)
      _orbSave={r:_3d.orb.r,theta:_3d.orb.theta,phi:_3d.orb.phi,
        tx:_3d.orb.target.x,ty:_3d.orb.target.y,tz:_3d.orb.target.z};
    _3d.stop(); _3d=null;
  }
  _3dSel=null;
  let _cancelled=false;
  const cont=canvas.parentElement;
  let W=cont.clientWidth||900, H=cont.clientHeight||580;
  canvas.width=W; canvas.height=H;
  const _ac=new AbortController(), _sig={signal:_ac.signal};
  const scene=new THREE.Scene(); scene.background=null;
  const camera=new THREE.PerspectiveCamera(42,W/H,0.1,300);
  const renderer=new THREE.WebGLRenderer({canvas,antialias:true,preserveDrawingBuffer:true,alpha:true});
  renderer.setSize(W,H); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
  const _resObs=new ResizeObserver(()=>{
    W=cont.clientWidth||900;H=cont.clientHeight||580;
    canvas.width=W;canvas.height=H;camera.aspect=W/H;camera.updateProjectionMatrix();renderer.setSize(W,H);
  });
  _resObs.observe(cont);
  const _ambLight=new THREE.AmbientLight(0xffffff, (function(){try{var v=parseFloat(localStorage.getItem("adm_amb"));return(v>0?v:1.2);}catch(e){return 1.2;}})());
  scene.add(_ambLight);
  window._admAmbIntensity = _ambLight.intensity;
  window._admAmbLightRef=_ambLight;
  // Atnaujinti input reikšmę
  const _ambInp=document.getElementById('adm-amb-input');
  if(_ambInp) _ambInp.value=_ambLight.intensity.toFixed(1);
  const dl=new THREE.DirectionalLight(0xffffff,0.6); dl.position.set(5,10,15); scene.add(dl);

  const selSys=parseInt(document.getElementById('map-sys')?.value||'0');
  const fullGrandine=TECH.sistemu_tipai.find(t=>t.id===selSys)?.grandine||[];
  const sysObjs=typeof window._konSistemaLength==='number' && window._konSistemaLength>0
    ? fullGrandine.slice(0, window._konSistemaLength)
    : fullGrandine;
  _sysObjsRef=sysObjs;
  const CX=((sysObjs.length-1)/2)*_CELL, CY=1.0*_CELL;

  _drawBackground(scene,CX); _drawAxisLabels(scene,sysObjs,selSys);

  const posMap={};
  sysObjs.forEach((id,idx)=>{posMap[id]=idx;_posMapRef[id]=idx;});

  const objMeshes=[], compMeshes=[];

  // NAM1/NAM2: Y = sekančio objekto Y + 0.5*_CELL
  sysObjs.forEach(id=>{
    const overrideX=posMap[id];
    let pos=_objPos(id,overrideX); if(!pos) return;
    if(id==='NAM1'||id==='NAM2'){
      if(sysObjs.length<2) return;
      const _nextId=sysObjs[1];
      const _nextPos=_objPos(_nextId,posMap[_nextId]);
      const _nextY=_nextPos?_nextPos.y:pos.y;
      pos={x:pos.x,y:_nextY+0.5*_CELL,z:pos.z};
    }
    const kb=KB.objects[id];
    const fms=Object.values(kb?.failure_modes||{}).filter(f=>f.name);
    const hasData=!!(kb?.function||fms.length>0);
    const isSelected=(_selObj===id);
    const col=isSelected?THEME.comp1:(hasData?THEME.obj:THEME.objEmpty);
    const r=0.38;

    const s3d=kb?.scene_3d;
    const _ud={type:'obj',id,overrideX};
    if(s3d?.glb && typeof THREE.GLTFLoader!=='undefined'){
      _admSphere(scene,pos,col,r,_ud,objMeshes,isSelected,s3d);
      THREE.Cache.enabled=true;
      const _glbUrl='/shared/glb/'+s3d.glb+'?v='+(window._glbVer||(window._glbVer=1));
      new THREE.GLTFLoader().load(_glbUrl,gltf=>{
        if(_cancelled) return;
        for(let i=objMeshes.length-1;i>=0;i--){if(objMeshes[i].userData===_ud&&objMeshes[i].geometry?.type==='SphereGeometry'){scene.remove(objMeshes[i]);objMeshes.splice(i,1);}}
        const model=gltf.scene;
        const _r=Math.PI/180;
        const _sx=s3d.scale_x||s3d.scale||1, _sy=s3d.scale_y||s3d.scale||1, _sz=s3d.scale_z||s3d.scale||1;
        model.scale.set(_sx, _sy, _sz);
        model.rotation.set((s3d.rotation_x||0)*_r,(s3d.rotation_y||0)*_r,(s3d.rotation_z||0)*_r);
        model.position.set(pos.x+(s3d.delta_x||0),pos.y+(s3d.delta_y||0),s3d.offset_y||0);
        model.userData=_ud;
        model.traverse(c=>{if(c.isMesh){c.userData=_ud;objMeshes.push(c);}});
        scene.add(model);
      },null,()=>{}); // sferos jau rodomos
    } else { _admSphere(scene,pos,col,r,_ud,objMeshes,isSelected,s3d); }

    const meta=KB.objects_meta[id]||(typeof DEF_OBJS!=='undefined'?DEF_OBJS.find(o=>o.id===id):null);

    const nextId=sysObjs[posMap[id]+1];
    if(nextId){const np=_objPos(nextId,posMap[nextId]);if(np){
      const _ptype=s3d?.pipe_type||'PE';
      const _pcol=_ptype==='PVC'?0x8B4513:_ptype==='PVC_grey'?0x808080:0x1565C0;
      // socket_out: nuo šio objekto, socket_in: į kitą objektą
      // Bazinė pozicija = tinklelio taškas + delta (GLB poslinkis)
      const _bx1=pos.x+(s3d?.delta_x||0),  _by1=pos.y+(s3d?.delta_y||0);
      const _ns3d=KB.objects[nextId]?.scene_3d;
      const _bx2=np.x+(_ns3d?.delta_x||0), _by2=np.y+(_ns3d?.delta_y||0);
      const _fx=s3d?.socket_out ? _bx1+(s3d.socket_out.x||0) : _bx1;
      const _fy=s3d?.socket_out ? _by1+(s3d.socket_out.y||0) : _by1;
      const _tx=_ns3d?.socket_in ? _bx2+(_ns3d.socket_in.x||0) : _bx2;
      const _ty=_ns3d?.socket_in ? _by2+(_ns3d.socket_in.y||0) : _by2;
      _pipe3d(scene,_fx,_fy,0.05,_tx,_ty,0.05,_pcol,0.07);
    }}

    if(_selObj===id){
      if(_viewMode==='step'){
        _showStepComps(scene,compMeshes,id,undefined,undefined,overrideX,1);
      } else if(_viewMode==='expand') _showAllComps(scene,compMeshes,id,undefined,undefined,overrideX);
    }
    if(_viewMode==='all') _showAllComps(scene,compMeshes,id,undefined,undefined,overrideX);
  });

  const orbData=(_userMovedCam&&_orbSave)
    ?{target:new THREE.Vector3(_orbSave.tx,_orbSave.ty,_orbSave.tz),r:_orbSave.r,theta:_orbSave.theta,phi:_orbSave.phi}
    :(_camCalib ? {target:new THREE.Vector3(_camCalib.tx??CX,_camCalib.ty??CY,0),r:_camCalib.r??10,theta:_camCalib.theta??0,phi:_camCalib.phi??(Math.PI/2)} : {target:new THREE.Vector3(CX,CY,0),r:14,theta:0,phi:Math.PI/2});
  const orb=orbData;

  function applyOrbit(){
    const sp=Math.sin(orb.phi),cp=Math.cos(orb.phi),st=Math.sin(orb.theta),ct=Math.cos(orb.theta);
    camera.position.set(orb.target.x+orb.r*sp*st,orb.target.y+orb.r*cp,orb.target.z+orb.r*sp*ct);
    camera.lookAt(orb.target); camera.updateMatrixWorld();
  }
  applyOrbit();

  let drag=false,isPan=false,lastM={x:0,y:0};
  let dragComp=null,compDragging=false;
  const dragPlane=new THREE.Plane(),dragPt=new THREE.Vector3(),dragOff=new THREE.Vector3(),dragOrigPos=new THREE.Vector3();

  function _updateDragPlane(){
    const d=new THREE.Vector3().subVectors(camera.position,orb.target).normalize();
    dragPlane.setFromNormalAndCoplanarPoint(d,dragComp.position);
  }
  function _startDragComp(e){
    if(!_dragMode||e.button!==0) return false;
    const rect=canvas.getBoundingClientRect();
    const mp=new THREE.Vector2(((e.clientX-rect.left)/W)*2-1,-((e.clientY-rect.top)/H)*2+1);
    const ray=new THREE.Raycaster(); ray.setFromCamera(mp,camera);
    const hits=ray.intersectObjects(compMeshes.filter(m=>m.userData?.type==='comp'),true);
    if(hits.length){
      // GLB sub-mesh'ai turi lokalią poziciją — einame iki root scenoje
      let _hit=hits[0].object;
      while(_hit.parent&&_hit.parent!==scene) _hit=_hit.parent;
      dragComp=_hit; compDragging=false;
    }
    else{
      const ohits=ray.intersectObjects(objMeshes,true);
      if(!ohits.length) return false;
      // GLB modeliai turi sub-mesh'us - einame į root grupę
      let _hit=ohits[0].object;
      while(_hit.parent&&_hit.parent.userData&&_hit.parent.userData.type==='obj') _hit=_hit.parent;
      dragComp=_hit; compDragging=false;
    }
    dragOrigPos.copy(dragComp.position); _updateDragPlane();
    ray.ray.intersectPlane(dragPlane,dragPt); dragOff.subVectors(dragComp.position,dragPt);
    canvas.style.cursor='grabbing'; return true;
  }

  const DEAD=3; let _cs={x:0,y:0},_mv=false;

  canvas.addEventListener('mousedown',e=>{
    _cs={x:e.clientX,y:e.clientY};_mv=false;
    if(_startDragComp(e)){e.preventDefault();e.stopPropagation();return;}
    drag=true;isPan=(e.button===0);lastM={x:e.clientX,y:e.clientY};
    canvas.style.cursor='grabbing';e.preventDefault();
  },_sig);
  canvas.addEventListener('contextmenu',e=>e.preventDefault(),_sig);

  function _onMouseUp(){
    if(dragComp&&compDragging){
      _hideAxisLine(scene);
      const ud=dragComp.userData;
      if(ud.type==='obj'){
        const oid=ud.id;
        if(KB.objects[oid]){
          if(!KB.objects[oid].scene_3d) KB.objects[oid].scene_3d={};
          const _bp=_objPos(oid,_posMapRef[oid]);
          KB.objects[oid].scene_3d.delta_x=parseFloat((dragComp.position.x-(_bp?_bp.x:dragComp.position.x)).toFixed(3));
          KB.objects[oid].scene_3d.delta_y=parseFloat((dragComp.position.y-(_bp?_bp.y:dragComp.position.y)).toFixed(3));
          KB.objects[oid].scene_3d.map_z=parseFloat(dragComp.position.z.toFixed(3));
          markDirty('obj_'+oid); if(typeof flushDirty==='function') flushDirty();
          toast('Pozicija: '+(KB.objects_meta[oid]?.name||oid));
        }
      } else {
        const cid=ud.id, comp=KB.components[cid];
        if(comp){
          const ox=ud.objPosX||0,oy=ud.objPosY||0;
          // GLB komponentai: model.position = (cx+delta_x, cy+delta_y, cz)
          // Išsaugome cx = position - delta, kad renderinant GLB nepridėtų delta dar kartą
          const s3d=comp.scene_3d||KB.components[cid]?.scene_3d||{};
          comp.map_x=parseFloat((dragComp.position.x-ox-(s3d.delta_x||0)).toFixed(3));
          comp.map_y=parseFloat((dragComp.position.y-oy-(s3d.delta_y||0)-(s3d.offset_y||0)).toFixed(3));
          comp.map_z=parseFloat(dragComp.position.z.toFixed(3));
          if(!KB.components_meta[cid]) KB.components_meta[cid]={};
          KB.components_meta[cid].map_x=comp.map_x;
          KB.components_meta[cid].map_y=comp.map_y;
          KB.components_meta[cid].map_z=comp.map_z;
          markDirty('comp_'+cid); toast('Pozicija: '+(comp.name||cid));
        }
      }
    }
    dragComp=null;compDragging=false;drag=false;
    canvas.style.cursor=_dragMode?'crosshair':'default';
  }
  document.addEventListener('mouseup',_onMouseUp);

  canvas.addEventListener('mousemove',e=>{
    if(e.buttons&&(Math.abs(e.clientX-_cs.x)>DEAD||Math.abs(e.clientY-_cs.y)>DEAD)) _mv=true;

    if(dragComp){
      const rect=canvas.getBoundingClientRect();
      const mp=new THREE.Vector2(((e.clientX-rect.left)/W)*2-1,-((e.clientY-rect.top)/H)*2+1);
      const ray=new THREE.Raycaster(); ray.setFromCamera(mp,camera);
      if(ray.ray.intersectPlane(dragPlane,dragPt)){
        const nx=dragPt.x+dragOff.x,ny=dragPt.y+dragOff.y,nz=dragPt.z+dragOff.z;
        if(_dragAxis==='x'){dragComp.position.x=nx;dragComp.position.y=dragOrigPos.y;dragComp.position.z=dragOrigPos.z;}
        else if(_dragAxis==='y'){dragComp.position.x=dragOrigPos.x;dragComp.position.y=ny;dragComp.position.z=dragOrigPos.z;}
        else if(_dragAxis==='z'){dragComp.position.x=dragOrigPos.x;dragComp.position.y=dragOrigPos.y;dragComp.position.z=nz;}
        else{dragComp.position.x=nx;dragComp.position.y=ny;dragComp.position.z=nz;}
        compDragging=true;
        _showAxisLine(scene,dragComp);
        const idx=compMeshes.indexOf(dragComp);
        if(idx>=0&&compMeshes[idx+1]?.isSprite)
          compMeshes[idx+1].position.set(dragComp.position.x,dragComp.position.y-0.55,dragComp.position.z);
      }
      return;
    }

    if(!drag){
      const rect=canvas.getBoundingClientRect();
      const mp=new THREE.Vector2(((e.clientX-rect.left)/W)*2-1,-((e.clientY-rect.top)/H)*2+1);
      const ray=new THREE.Raycaster(); ray.setFromCamera(mp,camera);
      if(_dragMode) canvas.style.cursor=ray.intersectObjects(compMeshes.filter(m=>m.userData?.type==='comp')).length?'grab':'crosshair';
      else canvas.style.cursor=ray.intersectObjects(objMeshes).length?'pointer':'default';
      return;
    }

    _userMovedCam=true;
    const dx=e.clientX-lastM.x,dy=e.clientY-lastM.y;
    lastM={x:e.clientX,y:e.clientY};
    if(isPan){
      const right=new THREE.Vector3(),up=new THREE.Vector3();
      camera.matrix.extractBasis(right,up,new THREE.Vector3());
      orb.target.addScaledVector(right,-dx*0.015);
      orb.target.addScaledVector(up,dy*0.015);
    } else {
      orb.theta-=dx*0.008;
      orb.phi=Math.max(0.05,Math.min(Math.PI-0.05,orb.phi+dy*0.008));
    }
    applyOrbit();
  },_sig);

  canvas.addEventListener('wheel',e=>{
    _userMovedCam=true; orb.r=Math.max(4,Math.min(80,orb.r+e.deltaY*0.04));
    applyOrbit(); e.preventDefault();
  },{passive:false,signal:_ac.signal});

  canvas.addEventListener('click',e=>{
    if(_mv) return;
    const rect=canvas.getBoundingClientRect();
    const mp=new THREE.Vector2(((e.clientX-rect.left)/W)*2-1,-((e.clientY-rect.top)/H)*2+1);
    const ray=new THREE.Raycaster(); ray.setFromCamera(mp,camera);

    const objHits=ray.intersectObjects(objMeshes);
    if(objHits.length){
      const d=objHits[0].object.userData;
      if(_selObj===d.id){_selObj=null;_selComp=null;_openedComps=[];_3dSel=null;_panelLevel='obj';_hidePanel();}
      else{_selObj=d.id;_selComp=null;_openedComps=[];_3dSel=d.id;_panelLevel='obj';
        if(!_userMovedCam){orb.theta=_camCalib?.theta??0.25;orb.phi=_camCalib?.phi??1.35;orb.r=(_camCalib?.r??8)*0.8;applyOrbit();_userMovedCam=true;}
      }
      _adm_build3d(canvas);
      if(_selObj) _renderPanel();
      return;
    }

    if(true){
      const compHits=ray.intersectObjects(compMeshes.filter(m=>m.userData?.type==='comp'));
      if(compHits.length){
        const d=compHits[0].object.userData;
        _selComp=d; _panelLevel='comp'; _renderPanel();
        if(_hasChildren(d.id)){
          _openedComps=_openedComps.includes(d.id)
            ? _openedComps.filter(id=>id!==d.id)
            : [..._openedComps,d.id];
          _adm_build3d(canvas);
        }
      }
    }
  },_sig);

  let animId,stopped=false;
  function animate(){if(stopped)return;animId=requestAnimationFrame(animate);renderer.render(scene,camera);}
  animate();

  const DEF_ORB={r:16,theta:0,phi:Math.PI/2,tx:CX,ty:CY};
  _3d={
    stop:()=>{
      _cancelled=true;
      document.removeEventListener('mouseup',_onMouseUp);
      _ac.abort();_resObs.disconnect();
      if(_userMovedCam) _orbSave={r:orb.r,theta:orb.theta,phi:orb.phi,tx:orb.target.x,ty:orb.target.y,tz:orb.target.z};
      stopped=true;cancelAnimationFrame(animId);renderer.dispose();
    },
    orb,applyOrbit,DEF_ORB,
    _compMeshes:compMeshes,
    _removeComps:()=>{compMeshes.forEach(m=>scene.remove(m));compMeshes.length=0;}
  };
}

function _adm_buildEmpty(canvas) {
  if(_3d){_3d.stop();_3d=null;}
  const cont=canvas.parentElement;
  const W=cont.clientWidth||900, H=cont.clientHeight||580;
  canvas.width=W; canvas.height=H;
  const scene=new THREE.Scene(); scene.background=null;
  const camera=new THREE.PerspectiveCamera(42,W/H,0.1,300);
  const renderer=new THREE.WebGLRenderer({canvas,antialias:true,preserveDrawingBuffer:true,alpha:true});
  renderer.setSize(W,H); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
  const CX=2*_CELL; camera.position.set(CX,2,10); camera.lookAt(CX,2,0);
  scene.add(new THREE.AmbientLight(0xffffff,(function(){try{var v=parseFloat(localStorage.getItem("adm_amb"));return(v>0?v:1.2);}catch(e){return 1.2;}})()));
  _drawBackground(scene,2*_CELL); _drawAxisLabels(scene,null,0);
  _txt3d(scene,'Pasirinkite sistemos tipa',CX,2.8*_CELL,0,'#4a9d6f',18);
  let animId,stopped=false;
  function animate(){if(stopped)return;animId=requestAnimationFrame(animate);renderer.render(scene,camera);}
  animate();
  _3d={stop:()=>{stopped=true;cancelAnimationFrame(animId);renderer.dispose();},
    orb:{},applyOrbit:()=>{},DEF_ORB:{},_removeComps:()=>{},_compMeshes:[]};
}

function _adm_renderModeButtons(){
  const mw=document.getElementById('map-comp-mode'); if(!mw) return;
  mw.innerHTML=
    '<span style="font-size:11px;font-weight:600;color:var(--td);margin-right:6px">Rodymas:</span>'+
    [['step','Žingsninis'],['expand','Išklesti'],['all','Visa sistema']].map(([m,l])=>
      '<button class="btn ghost '+(_viewMode===m?'active':'')+'" onclick="setViewMode(\''+m+'\')" style="padding:4px 12px;font-size:11px">'+l+'</button>'
    ).join('')+
    '<button class="btn ghost'+(_dragMode?' active':'')+
    '" onclick="_adm_toggleDragMode()" style="padding:4px 12px;font-size:11px;margin-left:8px"'+
    ' title="Tampymo režimas — vilk komponentus 3D scenoje">&#x21d4; Tampyti</button>';
}

function _adm_toggleDragMode(){
  _dragMode=!_dragMode;_dragAxis=null;
  _adm_renderModeButtons();setDragAxis(null);
  const bar=document.getElementById('drag-axis-bar');
  if(bar) bar.style.display=_dragMode?'flex':'none';
  const canvas=document.getElementById('map-canvas');
  if(canvas) canvas.style.cursor=_dragMode?'crosshair':'default';
  const selSys=parseInt(document.getElementById('map-sys')?.value||'0');
  if(selSys&&canvas) _adm_build3d(canvas);
  if(_dragMode) toast('Tampymo rezimas — pasirink asi ir vilk komponenta');
}

window._build3d = _adm_build3d;
window._buildEmpty = _adm_buildEmpty;
window._renderModeButtons = _adm_renderModeButtons;
window.toggleDragMode = _adm_toggleDragMode;

// Vamzdžio geometrija (vietoj plonos linijos)
function _pipe3d(scene, x1,y1,z1, x2,y2,z2, color, radius) {
  radius = radius || 0.06;
  const start = new THREE.Vector3(x1,y1,z1);
  const end   = new THREE.Vector3(x2,y2,z2);
  const dir   = new THREE.Vector3().subVectors(end, start);
  const len   = dir.length();
  const mid   = new THREE.Vector3().addVectors(start, end).multiplyScalar(0.5);

  const geo = new THREE.CylinderGeometry(radius, radius, len, 8, 1);
  const mat = new THREE.MeshPhongMaterial({color, shininess:40});
  const mesh = new THREE.Mesh(geo, mat);

  // Orientuojame cilindrą nuo start iki end
  mesh.position.copy(mid);
  mesh.quaternion.setFromUnitVectors(
    new THREE.Vector3(0,1,0),
    dir.normalize()
  );
  scene.add(mesh);
  return mesh;
}

function _admSphere(scene,pos,col,r,userData,objMeshes,isSelected,s3d){
  const mx=pos.x+(s3d?.delta_x||0);
  const my=pos.y+(s3d?.delta_y||0);
  const mesh=new THREE.Mesh(
    new THREE.SphereGeometry(r,18,18),
    new THREE.MeshPhongMaterial({color:col,shininess:80,
      emissive:isSelected?THEME.objSelected:0x000000,emissiveIntensity:isSelected?0.25:0})
  );
  mesh.position.set(mx,my,0); mesh.userData=userData;
  scene.add(mesh); objMeshes.push(mesh);
  const aura=new THREE.Mesh(
    new THREE.CircleGeometry(r*(isSelected?2.4:1.7),22),
    new THREE.MeshBasicMaterial({color:col,opacity:isSelected?0.22:0.13,transparent:true,side:THREE.DoubleSide})
  );
  aura.position.set(mx,my,-0.05); scene.add(aura);
}

// ═══════════════════════════════════════════════════════════════════
// GLB IMPORTER - naujas, švarus, veikiantis
// DB schema: scene_3d = { glb, scale, rotation_x, rotation_y, rotation_z,
//                          offset_y, delta_x, delta_y, socket_in, socket_out }
// delta_x/delta_y = poslinkis nuo tinklelio taško (ne absoliutus)
// ═══════════════════════════════════════════════════════════════════


// ── _adm_renderGlbPanel ────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════
// GLB IMPORTER — Blender stiliaus drag-input valdikliai
// Kiekvienas valdiklis: mousedown+drag į šoną = keičia reikšmę realiu laiku
// Dbl-click = įvesti skaičių tiesiogiai
// ═══════════════════════════════════════════════════════════════════


// ── Drag-input stilius ─────────────────────────────────────────────
// Įterpiame CSS vieną kartą
function _glbInjectCSS() {
  if (document.getElementById('glb-drag-style')) return;
  const s = document.createElement('style');
  s.id = 'glb-drag-style';
  s.textContent = `
    .glb-drag {
      display:inline-flex; align-items:center; justify-content:space-between;
      min-width:56px; padding:1px 6px; height:20px;
      background:var(--s1); border:1px solid var(--b1); border-radius:4px;
      font-size:11px; font-weight:600; color:var(--text);
      cursor:ew-resize; user-select:none; position:relative;
      font-family:'JetBrains Mono',monospace;
      transition:border-color .1s, background .1s;
    }
    .glb-drag:hover { border-color:var(--pri); background:var(--s2); }
    .glb-drag.active { border-color:var(--pri); background:#e8f5e9; color:var(--pri); cursor:ew-resize; }
    .glb-drag .glb-drag-lbl {
      font-size:9px; font-weight:700; color:var(--td);
      text-transform:uppercase; letter-spacing:.3px; margin-right:4px;
    }
    .glb-drag .glb-drag-val { flex:1; text-align:right; }
    .glb-drag input.glb-drag-input {
      position:absolute; inset:0; width:100%; border:none;
      background:var(--s1); font:inherit; text-align:center;
      padding:0 4px; border-radius:4px; outline:none;
    }
    .glb-section {
      display:flex; align-items:center; gap:3px;
      padding:2px 6px; background:var(--s2);
      border:1px solid var(--b1); border-radius:5px;
    }
    .glb-section-lbl {
      font-size:9px; font-weight:700; color:var(--td);
      text-transform:uppercase; letter-spacing:.4px; white-space:nowrap;
    }
    .glb-socket { border-color: #a5d6a7 !important; }
    .glb-socket-out { border-color: #ef9a9a !important; }
    #glb-calib-panel { gap:6px; align-items:center; flex-wrap:wrap; }
  `;
  document.head.appendChild(s);
}

// ── Drag-input widget ──────────────────────────────────────────────
// Sukuria drag-input elementą
// label: trumpas tekstas (S, X°, dX...)
// id: DOM id
// val: pradinė reikšmė
// speed: kiek keičiasi per 1px pelės judėjimo
// decimals: kiek skaitmenų po kablelio
// extraClass: papildoma CSS klasė
function _glbMakeDrag(label, id, val, speed, decimals, extraClass) {
  const wrap = document.createElement('div');
  wrap.className = 'glb-drag' + (extraClass ? ' ' + extraClass : '');
  wrap.dataset.id = id;
  wrap.dataset.speed = speed;
  wrap.dataset.decimals = decimals;
  wrap.innerHTML =
    '<span class="glb-drag-lbl">' + label + '</span>' +
    '<span class="glb-drag-val" id="' + id + '-v">' + parseFloat(val).toFixed(decimals) + '</span>';

  // Saugome reikšmę data atribute
  wrap.dataset.value = parseFloat(val);

  // MouseDown — pradedame drag arba dbl-click tikrinimą
  let _dragStartX = 0, _dragStartVal = 0, _dragging = false, _clickCount = 0, _clickTimer = null;

  wrap.addEventListener('mousedown', e => {
    if (e.button !== 0) return;
    e.preventDefault();

    _clickCount++;
    if (_clickCount === 2) {
      // Dbl-click — rodyti input laukelį
      clearTimeout(_clickTimer);
      _clickCount = 0;
      _glbShowInput(wrap, id, decimals);
      return;
    }
    _clickTimer = setTimeout(() => { _clickCount = 0; }, 300);

    _dragStartX  = e.clientX;
    _dragStartVal = parseFloat(wrap.dataset.value);
    _dragging = false;
    wrap.classList.add('active');

    const onMove = e2 => {
      const dx = e2.clientX - _dragStartX;
      if (Math.abs(dx) > 2) _dragging = true;
      if (!_dragging) return;

      const newVal = _dragStartVal + dx * parseFloat(wrap.dataset.speed);
      _glbSetDragVal(wrap, id, newVal, decimals);
      _glbLive();
    };

    const onUp = () => {
      wrap.classList.remove('active');
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };

    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });

  return wrap;
}

// Nustatyti drag reikšmę
function _glbSetDragVal(wrap, id, val, decimals) {
  wrap.dataset.value = val;
  const vEl = wrap.querySelector('.glb-drag-val');
  if (vEl) vEl.textContent = parseFloat(val).toFixed(decimals);
}

// Parodyti inline text input (dbl-click)
function _glbShowInput(wrap, id, decimals) {
  const vEl = wrap.querySelector('.glb-drag-val');
  if (!vEl) return;
  const cur = parseFloat(wrap.dataset.value).toFixed(decimals);
  vEl.style.display = 'none';
  const inp = document.createElement('input');
  inp.className = 'glb-drag-input';
  inp.type = 'number';
  inp.step = Math.pow(10, -decimals);
  inp.value = cur;
  wrap.appendChild(inp);
  inp.focus();
  inp.select();

  const commit = () => {
    const v = parseFloat(inp.value);
    if (!isNaN(v)) {
      _glbSetDragVal(wrap, id, v, decimals);
      _glbLive();
    }
    inp.remove();
    vEl.style.display = '';
  };
  inp.addEventListener('blur', commit);
  inp.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); inp.blur(); }
    if (e.key === 'Escape') { inp.value = cur; inp.blur(); }
  });
}

// Gauti drag reikšmę pagal id
function _glbDragVal(id) {
  const wrap = document.querySelector('[data-id="' + id + '"]');
  return wrap ? parseFloat(wrap.dataset.value) || 0 : 0;
}

// ── Panel render ────────────────────────────────────────────────────
function _adm_toggleGlbPanel() {
  _glbPanelOpen = !_glbPanelOpen;
  _adm_renderModeButtons();
  let panel = document.getElementById('glb-calib-panel');
  if (_glbPanelOpen) {
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'glb-calib-panel';
      panel.style.cssText = 'display:flex;align-items:center;padding:5px 10px;' +
        'background:var(--s2);border-top:1px solid var(--b1);flex-wrap:wrap;gap:5px;font-size:11px';
      const tb = document.getElementById('map-toolbar');
      if (tb && tb.parentNode) tb.parentNode.insertBefore(panel, tb.nextSibling);
    }
    _glbInjectCSS();
    _glbRenderPanel();
    panel.style.display = 'flex';
  } else {
    if (panel) panel.style.display = 'none';
    _glbSelObj = null;
  }
}

// Helper: gauk pasirinkto GLB target (objektas arba komponentas)
// _glbSelObj formatas: "obj:OID" arba "comp:CID" arba senas tiesiog "OID" (objektas)
function _glbGetTarget() {
  let sel = _glbSelObj;
  // Jei nėra rankinio pasirinkimo - imame iš scenos
  if (!sel) {
    if (_selComp) sel = 'comp:'+_selComp.id;
    else if (_selObj) sel = 'obj:'+_selObj;
  }
  if (!sel) return null;
  // Senas formatas - vienas ID = objektas
  if (!sel.includes(':')) sel = 'obj:'+sel;
  const [type, id] = sel.split(':');
  if (type === 'comp' && KB.components[id]) {
    return { type:'comp', id, name: KB.components[id].name||id, kb: KB.components[id], s3d: KB.components[id].scene_3d || {} };
  }
  if (type === 'obj' && KB.objects[id]) {
    return { type:'obj', id, name: KB.objects_meta[id]?.name||id, kb: KB.objects[id], s3d: KB.objects[id].scene_3d || {} };
  }
  return null;
}

// Helper: užtikrina kad target.kb turi scene_3d objektą
function _glbEnsureS3d(target) {
  if (!target) return null;
  if (target.type === 'comp') {
    if (!KB.components[target.id].scene_3d) KB.components[target.id].scene_3d = {};
    return KB.components[target.id].scene_3d;
  } else {
    if (!KB.objects[target.id].scene_3d) KB.objects[target.id].scene_3d = {};
    return KB.objects[target.id].scene_3d;
  }
}

function _glbRenderPanel() {
  const panel = document.getElementById('glb-calib-panel');
  if (!panel) return;
  panel.innerHTML = '';

  const target = _glbGetTarget();
  const s = target ? target.s3d : {};

  const sc  = s.scale      != null ? s.scale      : 1;
  const rx  = s.rotation_x != null ? s.rotation_x : 0;
  const ry  = s.rotation_y != null ? s.rotation_y : 0;
  const rz  = s.rotation_z != null ? s.rotation_z : 0;
  const oy  = s.offset_y   != null ? s.offset_y   : 0;
  const dx  = s.delta_x    != null ? s.delta_x    : 0;
  const dy  = s.delta_y    != null ? s.delta_y    : 0;
  const si  = s.socket_in  || {x:0,y:0,z:0};
  const so  = s.socket_out || {x:0,y:0,z:0};

  // ── Sąrašas: objektai + komponentai ──────────────────────────
  const curVal = _glbSelObj || (target ? target.type+':'+target.id : '');
  let opts = '<option value="">— objektas / komponentas —</option>';
  // Objektai
  opts += '<optgroup label="🔵 Objektai">';
  Object.keys(KB.objects_meta || {}).forEach(id => {
    const n = (KB.objects_meta[id] && KB.objects_meta[id].name) || id;
    const v = 'obj:'+id;
    const has = KB.objects[id]?.scene_3d?.glb ? ' ✓' : '';
    opts += '<option value="' + v + '"' + (v === curVal ? ' selected' : '') + '>' + n + has + '</option>';
  });
  opts += '</optgroup>';
  // Komponentai
  opts += '<optgroup label="📦 Komponentai">';
  Object.keys(KB.components || {}).sort().forEach(cid => {
    const c = KB.components[cid]; if (!c) return;
    const n = c.name || cid;
    const par = c.parent_id ? ' ('+c.parent_id+')' : '';
    const v = 'comp:'+cid;
    const has = c.scene_3d?.glb ? ' ✓' : '';
    opts += '<option value="' + v + '"' + (v === curVal ? ' selected' : '') + '>' + n + par + has + '</option>';
  });
  opts += '</optgroup>';

  const sel = document.createElement('select');
  sel.id = 'glb-obj-sel';
  sel.style.cssText = 'padding:2px 6px;font-size:11px;border:1px solid var(--b1);border-radius:4px;height:22px;min-width:180px';
  sel.innerHTML = opts;
  sel.onchange = () => { _glbSelObj = sel.value || null; _glbRenderPanel(); };
  panel.appendChild(sel);

  const fileInp = document.createElement('input');
  fileInp.id = 'glb-file';
  fileInp.type = 'text';
  fileInp.value = s.glb || '';
  fileInp.placeholder = target?.type==='comp' ? 'aerat.glb' : 'bnvi.glb';
  fileInp.style.cssText = 'width:90px;padding:2px 5px;font-size:11px;border:1px solid var(--b1);border-radius:4px;height:22px';
  panel.appendChild(fileInp);

  // Vamzdžio tipas (TIK objektams - komponentai vamzdžių neturi)
  if (!target || target.type === 'obj') {
    const pipeLabel = document.createElement('span');
    pipeLabel.style.cssText = 'color:var(--td);font-size:10px;margin-left:4px';
    pipeLabel.textContent = 'Vamzdis:';
    panel.appendChild(pipeLabel);
    const pipeSel = document.createElement('select');
    pipeSel.id = 'glb-pipe';
    pipeSel.style.cssText = 'padding:2px 4px;font-size:11px;border:1px solid var(--b1);border-radius:4px;height:22px';
    pipeSel.innerHTML = '<option value="PE">PE (mėlynas)</option><option value="PVC">PVC (rudas)</option><option value="PVC_grey">PVC (pilkas)</option>';
    pipeSel.value = s.pipe_type || 'PE';
    pipeSel.onchange = () => {
      const t = _glbGetTarget(); if (!t || t.type!=='obj') return;
      const s3 = _glbEnsureS3d(t); s3.pipe_type = pipeSel.value; _glbLive();
    };
    panel.appendChild(pipeSel);
  }

  const loadBtn = document.createElement('button');
  loadBtn.title = 'Įkelti GLB į sceną';
  loadBtn.textContent = '▶';
  loadBtn.style.cssText = 'padding:2px 8px;font-size:11px;background:var(--pri);color:#fff;border:none;border-radius:4px;cursor:pointer;height:22px';
  loadBtn.onclick = _glbLoad;
  panel.appendChild(loadBtn);

  // Separator
  const sep = () => {
    const d = document.createElement('div');
    d.style.cssText = 'width:1px;height:18px;background:var(--b1);margin:0 2px';
    return d;
  };

  // ── Scale ──────────────────────────────────────────
  panel.appendChild(sep());
  const scSec = document.createElement('div');
  scSec.className = 'glb-section';
  scSec.appendChild(Object.assign(document.createElement('span'),
    { className: 'glb-section-lbl', textContent: 'Scale' }));
  const sc_x = s.scale_x != null ? s.scale_x : sc;
  const sc_y = s.scale_y != null ? s.scale_y : sc;
  const sc_z = s.scale_z != null ? s.scale_z : sc;
  scSec.appendChild(_glbMakeDrag('XYZ', 'glb-sc',  sc,   0.01, 3));
  scSec.appendChild(_glbMakeDrag('X',   'glb-sc-x', sc_x, 0.01, 3));
  scSec.appendChild(_glbMakeDrag('Y',   'glb-sc-y', sc_y, 0.01, 3));
  scSec.appendChild(_glbMakeDrag('Z',   'glb-sc-z', sc_z, 0.01, 3));
  panel.appendChild(scSec);

  // ── Rotation ───────────────────────────────────────
  panel.appendChild(sep());
  const rotSec = document.createElement('div');
  rotSec.className = 'glb-section';
  rotSec.appendChild(Object.assign(document.createElement('span'),
    { className: 'glb-section-lbl', textContent: 'Rot' }));
  rotSec.appendChild(_glbMakeDrag('X°', 'glb-rx', rx, 0.5, 1));
  rotSec.appendChild(_glbMakeDrag('Y°', 'glb-ry', ry, 0.5, 1));
  rotSec.appendChild(_glbMakeDrag('Z°', 'glb-rz', rz, 0.5, 1));
  panel.appendChild(rotSec);

  // ── Position (delta) ──────────────────────────────
  panel.appendChild(sep());
  const posSec = document.createElement('div');
  posSec.className = 'glb-section';
  posSec.appendChild(Object.assign(document.createElement('span'),
    { className: 'glb-section-lbl', textContent: 'Pos' }));
  posSec.appendChild(_glbMakeDrag('dX', 'glb-dx', dx, 0.01, 3));
  posSec.appendChild(_glbMakeDrag('dY', 'glb-dy', dy, 0.01, 3));
  posSec.appendChild(_glbMakeDrag('↕Y', 'glb-oy', oy, 0.01, 3));
  panel.appendChild(posSec);

  // ── Socket In ─────────────────────────────────────
  panel.appendChild(sep());
  const inSec = document.createElement('div');
  inSec.className = 'glb-section';
  inSec.appendChild(Object.assign(document.createElement('span'),
    { className: 'glb-section-lbl', style: 'color:#2e7d32', textContent: 'In' }));
  inSec.appendChild(_glbMakeDrag('X', 'glb-ix', si.x, 0.01, 3, 'glb-socket'));
  inSec.appendChild(_glbMakeDrag('Y', 'glb-iy', si.y, 0.01, 3, 'glb-socket'));
  inSec.appendChild(_glbMakeDrag('Z', 'glb-iz', si.z, 0.01, 3, 'glb-socket'));
  panel.appendChild(inSec);

  // ── Socket Out ────────────────────────────────────
  const outSec = document.createElement('div');
  outSec.className = 'glb-section';
  outSec.appendChild(Object.assign(document.createElement('span'),
    { className: 'glb-section-lbl', style: 'color:#c62828', textContent: 'Out' }));
  outSec.appendChild(_glbMakeDrag('X', 'glb-ox', so.x, 0.01, 3, 'glb-socket-out'));
  outSec.appendChild(_glbMakeDrag('Y', 'glb-oy2', so.y, 0.01, 3, 'glb-socket-out'));
  outSec.appendChild(_glbMakeDrag('Z', 'glb-oz', so.z, 0.01, 3, 'glb-socket-out'));
  panel.appendChild(outSec);

  // ── Action buttons ────────────────────────────────
  panel.appendChild(sep());

  const mkBtn = (text, title, onclick, bg) => {
    const b = document.createElement('button');
    b.title = title; b.textContent = text; b.onclick = onclick;
    b.style.cssText = 'padding:2px 7px;font-size:11px;background:' + (bg||'var(--s2)') +
      ';color:' + (bg ? '#fff' : 'var(--text)') +
      ';border:1px solid var(--b1);border-radius:4px;cursor:pointer;height:22px';
    return b;
  };
  panel.appendChild(mkBtn('💾 Saugoti', 'Išsaugoti į DB', _glbSave, 'var(--pri)'));
  panel.appendChild(mkBtn('↩', 'Grąžinti poziciją', _glbResetPos));
  panel.appendChild(mkBtn('✕', 'Išvalyti GLB', _glbClear));
}

// ── Live update ────────────────────────────────────────────────────
function _glbLive() {
  const target = _glbGetTarget();
  if (!target) return;
  const s = _glbEnsureS3d(target);

  const _scXYZ = _glbDragVal('glb-sc') || 1;
  s.scale   = _scXYZ;
  s.scale_x = _glbDragVal('glb-sc-x') || _scXYZ;
  s.scale_y = _glbDragVal('glb-sc-y') || _scXYZ;
  s.scale_z = _glbDragVal('glb-sc-z') || _scXYZ;
  s.rotation_x = _glbDragVal('glb-rx');
  s.rotation_y = _glbDragVal('glb-ry');
  s.rotation_z = _glbDragVal('glb-rz');
  s.offset_y   = _glbDragVal('glb-oy');
  s.delta_x    = _glbDragVal('glb-dx');
  s.delta_y    = _glbDragVal('glb-dy');
  if (target.type === 'obj') {
    const _pipeEl = document.getElementById('glb-pipe');
    if (_pipeEl) s.pipe_type = _pipeEl.value;
  }
  s.socket_in  = { x: _glbDragVal('glb-ix'), y: _glbDragVal('glb-iy'), z: _glbDragVal('glb-iz') };
  s.socket_out = { x: _glbDragVal('glb-ox'), y: _glbDragVal('glb-oy2'), z: _glbDragVal('glb-oz') };

  const canvas = document.getElementById('map-canvas');
  if (canvas) _adm_build3d(canvas);
}

// ── GLB Load ───────────────────────────────────────────────────────
function _glbLoad() {
  const target = _glbGetTarget();
  const glb = (document.getElementById('glb-file')?.value || '').trim();
  if (!target || !glb) { toast('Pasirink objektą/komponentą ir GLB failą'); return; }
  const s = _glbEnsureS3d(target);
  s.glb = glb;

  function doLoad() {
    if (typeof THREE.GLTFLoader === 'undefined') {
      const sc = document.createElement('script');
      sc.src = 'https://unpkg.com/three@0.134.0/examples/js/loaders/GLTFLoader.js';
      sc.onload = doLoad;
      document.head.appendChild(sc);
      return;
    }
    const canvas = document.getElementById('map-canvas');
    if (canvas) _adm_build3d(canvas);
    toast('GLB kraunamas…');
  }
  doLoad();
}

// ── GLB Save ───────────────────────────────────────────────────────
function _glbSave() {
  const target = _glbGetTarget();
  if (!target) { toast('Pasirink objektą/komponentą'); return; }
  const s = _glbEnsureS3d(target);

  const glb = (document.getElementById('glb-file')?.value || '').trim();

  Object.assign(s, {
    glb,
    scale:   _glbDragVal('glb-sc')  || 1,
    scale_x: _glbDragVal('glb-sc-x') || _glbDragVal('glb-sc') || 1,
    scale_y: _glbDragVal('glb-sc-y') || _glbDragVal('glb-sc') || 1,
    scale_z: _glbDragVal('glb-sc-z') || _glbDragVal('glb-sc') || 1,
    rotation_x: _glbDragVal('glb-rx'),
    rotation_y: _glbDragVal('glb-ry'),
    rotation_z: _glbDragVal('glb-rz'),
    offset_y:   _glbDragVal('glb-oy'),
    delta_x:    _glbDragVal('glb-dx'),
    delta_y:    _glbDragVal('glb-dy'),
    socket_in:  { x: _glbDragVal('glb-ix'), y: _glbDragVal('glb-iy'), z: _glbDragVal('glb-iz') },
    socket_out: { x: _glbDragVal('glb-ox'), y: _glbDragVal('glb-oy2'), z: _glbDragVal('glb-oz') },
  });
  // pipe_type tik objektams
  if (target.type === 'obj') {
    s.pipe_type = (document.getElementById('glb-pipe')?.value || 'PE');
  }

  if (target.type === 'comp') {
    if (!KB.components_meta[target.id]) KB.components_meta[target.id] = {};
    markDirty('comp_' + target.id);
  } else {
    markDirty('obj_' + target.id);
  }
  if (typeof flushDirty === 'function') flushDirty();
  toast('GLB išsaugota ✓ '+target.name);

  const canvas = document.getElementById('map-canvas');
  if (canvas) _adm_build3d(canvas);
}

// ── GLB Reset Pos ─────────────────────────────────────────────────
function _glbResetPos() {
  const target = _glbGetTarget();
  if (!target) return;
  const s = _glbEnsureS3d(target);
  s.delta_x = 0;
  s.delta_y = 0;
  _glbRenderPanel();
  const canvas = document.getElementById('map-canvas');
  if (canvas) _adm_build3d(canvas);
  toast('Pozicija grąžinta');
}

// ── GLB Clear ─────────────────────────────────────────────────────
function _glbClear() {
  const target = _glbGetTarget();
  if (target) {
    const s = _glbEnsureS3d(target);
    s.glb = '';
  }
  _glbRenderPanel();
  const canvas = document.getElementById('map-canvas');
  if (canvas) _adm_build3d(canvas);
}
