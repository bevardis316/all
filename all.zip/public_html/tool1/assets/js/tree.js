const NC = {
  klausimas: {bg:'#e3f2fd',bd:'#1565c0',tc:'#0d47a1',lbl:'❓ KLAUSIMAS'},
  veiksmas:  {bg:'#fff3e0',bd:'#e65100',tc:'#bf360c',lbl:'🔧 PATIKRINTI'},
  sprendimas:{bg:'#e8f5e9',bd:'#2e7d32',tc:'#1b5e20',lbl:'✅ SPRENDIMAS'},
  nuoroda:   {bg:'#f3e5f5',bd:'#7b1fa2',tc:'#4a148c',lbl:'🔗 EITI Į'},
  start:     {bg:'var(--pri)',bd:'var(--pri)',tc:'#fff',lbl:'▶ PRADŽIA'},
};

const _selN  = {};
const _editN = {};

function dtInit(fid) {
  const oid = curObj;
  if(!KB.decision_trees[fid]) {
    const fm = KB.objects[oid]?.failure_modes?.[fid];
    KB.decision_trees[fid] = {
      id: fid, object_id: oid, failure_id: fid,
      root: {
        id: 'root', type: 'klausimas',
        text: fm?.name ? fm.name + '?' : '',
        branches: [], children: [], note: ''
      }
    };
  }
  dtRender(fid);
  
  _editN[fid] = 'root';
  dtRender(fid);
}

function dtClear(fid) {
  if(!confirm('Išvalyti visą medį?')) return;
  delete KB.decision_trees[fid];
  const el = document.getElementById('diag-tree-'+fid);
  if(el) el.innerHTML = '<div style="text-align:center;padding:20px;color:var(--td);font-size:11px">Medis išvalytas. Spusk „▶ Pradėti medį"</div>';
}

function dtRender(fid) {
  const oid = curObj;
  if(!KB.decision_trees[fid]) return;
  const el = document.getElementById('diag-tree-'+fid);
  if(!el) return;
  el.innerHTML = '';
  const wrap = document.createElement('div');
  wrap.style.cssText = 'display:inline-flex;flex-direction:column;align-items:center;padding:8px 16px 24px';
  el.style.textAlign = 'center';
  el.appendChild(wrap);
  drawNode(KB.decision_trees[fid].root, fid, wrap, null, 0);
}

function renderInlineTree(fid, oid) {
  dtRender(fid);
}

function toggleInlineTree(fid, oid) {
  
  dtInit(fid);
}

function drawNode(node, fid, container, branchLabel, depth) {
  const nc=NC[node.type]||NC.klausimas;
  const isSel=_selN[fid]===node.id;
  const isEd=_editN[fid]===node.id;
  const wrap=document.createElement('div');
  wrap.dataset.nid=node.id;
  wrap.style.cssText='display:inline-flex;flex-direction:column;align-items:center;margin:0 16px;position:relative';
  container.appendChild(wrap);

  if(branchLabel!==null&&branchLabel!==undefined) {
    const iT=branchLabel==='TAIP', iN=branchLabel==='NE';
    const col=iT?'#2e7d32':iN?'#c62828':'#888';
    const bg=iT?'#e8f5e9':iN?'#ffebee':'#f5f5f5';
    const lineV=document.createElement('div');
    lineV.style.cssText=`width:2px;height:20px;background:${col};flex-shrink:0`;
    wrap.appendChild(lineV);
    const lbl=document.createElement('div');
    lbl.style.cssText=`font-size:11px;font-weight:900;padding:3px 16px;border-radius:20px;background:${bg};color:${col};border:2px solid ${col};letter-spacing:.5px;user-select:none`;
    lbl.textContent=iT?'✓ TAIP':iN?'✗ NE':branchLabel;
    wrap.appendChild(lbl);
  }

  const lineDown=document.createElement('div');
  lineDown.style.cssText='width:2px;height:18px;background:#ccc;flex-shrink:0';
  wrap.appendChild(lineDown);

  const box=document.createElement('div');
  const isQ=node.type==='klausimas';
  box.style.cssText=`cursor:pointer;padding:10px 18px;border:2.5px solid ${isSel?'var(--pri)':nc.bd};`+
    `border-radius:${isQ?'10px':'8px'};background:${isSel?'#e8f5e9':(node.type==='start'?nc.bg:'#fff')};`+
    `min-width:140px;max-width:260px;text-align:center;`+
    `box-shadow:${isSel?'0 0 0 3px rgba(46,125,50,.25)':'0 2px 6px rgba(0,0,0,.1)'};transition:box-shadow .12s,border-color .12s;`;

  const labelDiv=document.createElement('div');
  labelDiv.style.cssText=`font-size:8px;font-weight:900;color:${node.type==='start'?'rgba(255,255,255,.8)':nc.tc};letter-spacing:.8px;margin-bottom:3px;text-transform:uppercase`;
  labelDiv.textContent=nc.lbl;
  box.appendChild(labelDiv);

  const textDiv=document.createElement('div');
  textDiv.style.cssText=`font-size:12px;color:${node.type==='start'?'#fff':'#1a1a1a'};line-height:1.4;font-weight:500`;
  textDiv.innerHTML=node.text||`<span style="color:#bbb;font-size:10px;font-style:italic">spusk redaguoti…</span>`;
  box.appendChild(textDiv);

  if(node.note){
    const nd=document.createElement('div');
    nd.style.cssText='font-size:9px;color:#888;margin-top:3px;padding-top:3px;border-top:1px solid #eee';
    nd.textContent='🔧 '+node.note;
    box.appendChild(nd);
  }
  if(node.ref){
    const rd=document.createElement('div');
    rd.style.cssText='font-size:9px;color:var(--pri);margin-top:3px;text-decoration:underline;cursor:pointer;font-weight:600';
    rd.textContent='→ '+node.ref;
    rd.onclick=ev=>{ev.stopPropagation();openRefNode(node.ref);};
    box.appendChild(rd);
  }

  box.onclick=()=>toggleNodeEdit(fid,node.id);
  wrap.appendChild(box);

  if(isEd) {
    const ed = document.createElement('div');
    ed.style.cssText = 'background:#fff;border:2px solid var(--pri);border-radius:10px;padding:12px;margin-top:8px;width:260px;text-align:left;box-shadow:0 4px 16px rgba(0,0,0,.18);z-index:10;position:relative';

    
    const typeRow = document.createElement('div');
    typeRow.style.cssText = 'display:flex;gap:6px;margin-bottom:10px';
    [['klausimas','❓ Klausimas','#1565c0'],['sprendimas','✅ Sprendimas','#2e7d32']].forEach(([t,lbl,col])=>{
      const b = document.createElement('button');
      const active = node.type===t;
      b.style.cssText = `flex:1;padding:6px;border-radius:8px;border:2px solid ${col};background:${active?col:'#fff'};color:${active?'#fff':col};font-size:11px;font-weight:700;cursor:pointer`;
      b.textContent = lbl;
      b.onclick = ev => { ev.stopPropagation(); node.type = t; dtRender(fid); setTimeout(()=>{ _editN[fid]=node.id; dtRender(fid); },10); };
      typeRow.appendChild(b);
    });
    ed.appendChild(typeRow);

    
    const ta = document.createElement('textarea');
    ta.value = node.text||'';
    ta.placeholder = node.type==='klausimas' ? 'pvz. Ar orapūtė skleidžia garsą?' : 'pvz. Orapūtė sudegė — keisti';
    ta.rows = 2;
    ta.style.cssText = 'width:100%;box-sizing:border-box;font-size:12px;margin-bottom:8px;resize:vertical;border-radius:6px;border:1px solid #ddd;padding:6px';
    ta.oninput = () => { node.text = ta.value; };
    ed.appendChild(ta);

    
    if(node.type === 'klausimas') {
      const brRow = document.createElement('div');
      brRow.style.cssText = 'display:flex;gap:6px;margin-bottom:8px';
      [['TAIP','#2e7d32','#e8f5e9'],['NE','#c62828','#ffebee']].forEach(([lbl,col,bg])=>{
        const has = (node.branches||[]).includes(lbl);
        const b = document.createElement('button');
        b.style.cssText = `flex:1;padding:6px;border-radius:8px;border:2px solid ${col};background:${has?col:bg};color:${has?'#fff':col};font-size:12px;font-weight:900;cursor:pointer`;
        b.textContent = has ? `✓ ${lbl} (pridėta)` : `＋ ${lbl}`;
        b.onclick = ev => { ev.stopPropagation(); if(!has) addBranchDirect(fid,node,lbl); else toast('"'+lbl+'" šaka jau yra'); };
        brRow.appendChild(b);
      });
      ed.appendChild(brRow);
    }

    
    const actRow = document.createElement('div');
    actRow.style.cssText = 'display:flex;gap:6px';
    const closeBtn = document.createElement('button');
    closeBtn.className = 'btn pri sm'; closeBtn.style.flex='1'; closeBtn.textContent = '✓ Gerai';
    closeBtn.onclick = ev => { ev.stopPropagation(); node.text=ta.value; _editN[fid]=null; dtRender(fid); };
    const delBtn = document.createElement('button');
    delBtn.className = 'btn red sm'; delBtn.textContent = '🗑';
    delBtn.onclick = ev => { ev.stopPropagation(); deleteNodeDirect(fid,node.id); };
    actRow.appendChild(closeBtn); actRow.appendChild(delBtn);
    ed.appendChild(actRow);

    wrap.appendChild(ed);
    setTimeout(()=>ta.focus(),30);
  }

  if((node.children||[]).length) {
    const conn=document.createElement('div');
    conn.style.cssText='width:2px;height:18px;background:#bbb;flex-shrink:0';
    wrap.appendChild(conn);
    const row=document.createElement('div');
    row.style.cssText='display:flex;align-items:flex-start;justify-content:center;position:relative';
    if(node.children.length>1) {
      const bridge=document.createElement('div');
      bridge.style.cssText='position:absolute;top:0;left:0;right:0;height:2px;background:#ccc;z-index:0;pointer-events:none';
      row.appendChild(bridge);
      setTimeout(()=>{
        const kids=[...row.querySelectorAll(':scope>[data-nid]')];
        if(kids.length>1){
          const first=kids[0].getBoundingClientRect();
          const last=kids[kids.length-1].getBoundingClientRect();
          const rowR=row.getBoundingClientRect();
          bridge.style.left=(first.left-rowR.left+first.width/2)+'px';
          bridge.style.width=((last.left-rowR.left+last.width/2)-(first.left-rowR.left+first.width/2))+'px';
        }
      },30);
    }
    node.children.forEach((ch,ci)=>drawNode(ch,fid,row,(node.branches||[])[ci]||null,depth+1));
    wrap.appendChild(row);
  } else if((node.type==='klausimas'||node.type==='start')&&!isEd&&!node.children?.length) {
    const hint=document.createElement('div');
    hint.style.cssText='display:flex;gap:4px;margin-top:6px;justify-content:center';
    [['TAIP','#2e7d32'],['NE','#c62828']].forEach(([lbl,col])=>{
      const b=document.createElement('button');
      b.style.cssText=`font-size:10px;font-weight:900;padding:3px 12px;border-radius:16px;border:2px dashed ${col};background:#fff;color:${col};cursor:pointer`;
      b.textContent='＋'+lbl;
      b.onclick=ev=>{ev.stopPropagation();addBranchDirect(fid,node,lbl);};
      hint.appendChild(b);
    });
    wrap.appendChild(hint);
  } else if(node.type==='veiksmas'&&!node.children?.length&&!isEd) {
    const hint=document.createElement('div');
    hint.style.cssText='display:flex;gap:3px;margin-top:5px;justify-content:center';
    [['TAIP','#2e7d32'],['NE','#c62828'],['+ MAZGAS','#888']].forEach(([lbl,col])=>{
      const b=document.createElement('button');
      b.style.cssText=`font-size:9px;font-weight:700;padding:2px 8px;border-radius:12px;border:1px dashed ${col};background:#fff;color:${col};cursor:pointer`;
      b.textContent=lbl;
      b.onclick=ev=>{ev.stopPropagation(); addBranchDirect(fid,node,lbl==='+ MAZGAS'?'':lbl);};
      hint.appendChild(b);
    });
    wrap.appendChild(hint);
  }
}

function toggleNodeEdit(fid,nid) {
  _editN[fid]===nid ? _editN[fid]=null : (_editN[fid]=nid, _selN[fid]=nid);
  dtRender(fid);
}

function addBranchDirect(fid,node,label) {
  if(!node.branches) node.branches=[];
  if(label&&node.branches.includes(label)){toast('"'+label+'" šaka jau yra');return;}
  if(label) node.branches.push(label);
  const child={id:'n'+Date.now(),type:'klausimas',text:'',branches:[],children:[],note:''};
  node.children.push(child);
  _editN[fid]=child.id; _selN[fid]=child.id;
  dtRender(fid);
}

function deleteNodeDirect(fid,nid) {
  const tree=KB.decision_trees[fid]; if(!tree) return;
  if(nid==='root'){toast('Negalima ištrinti pirmojo mazgo');return;}
  function rm(n){n.children=(n.children||[]).filter((c,i)=>{
    if(c.id===nid){n.branches=(n.branches||[]).filter((_,j)=>j!==i);return false;}
    rm(c);return true;
  });}
  rm(tree.root);
  _editN[fid]=null; _selN[fid]=null;
  dtRender(fid);
}

function openRefNode(failureId) {
  const oid=Object.keys(KB.objects).find(o=>KB.objects[o].failure_modes?.[failureId]);
  if(!oid){toast('Gedimas nerastas');return;}
  document.querySelectorAll('.ntab').forEach(t=>{if(t.textContent.includes('Žinios'))t.click();});
  setTimeout(()=>{selObj(oid); toast('→ '+failureId);},100);
}

function autoGenTree(fid, oid) {
  const fm=KB.objects[oid||curObj]?.failure_modes?.[fid]; if(!fm) return;
  const syms=fm.symptoms||[]; const steps=fm.diagnosis_steps||[];
  const mkN=(id,type,text)=>({id,type,text,branches:[],children:[],note:''});

  const root=mkN('root','klausimas',syms.length?'Ar pastebimas: '+syms[0]+'?':(fm.name||fid));
  if(syms.length) root.branches=['TAIP','NE'];

  if(syms.length) {
    const sol=mkN('sol0','sprendimas','✅ Tikėtina priežastis: '+(fm.causes?.primary||fm.name));
    const nxt=syms.length>1?mkN('nxt0','klausimas','Ar pastebimas: '+syms[1]+'?'):mkN('no0','veiksmas','Tikrinti kitas galimas priežastis');
    if(syms.length>1) nxt.branches=['TAIP','NE'];
    root.children=[sol,nxt];
    let cur=nxt;
    for(let j=1;j<syms.length;j++){
      const s=mkN('sol'+j,'sprendimas','✅ Tikėtina pagal: '+syms[j]);
      const n=j<syms.length-1?mkN('nxt'+j,'klausimas','Ar pastebimas: '+syms[j+1]+'?'):mkN('done','veiksmas','Nė vienas simptomas – kreiptis į specialistą');
      if(j<syms.length-1) n.branches=['TAIP','NE'];
      cur.children=[s,n]; cur=n;
    }
  } else {
    root.type='klausimas'; root.branches=['TAIP','NE'];
    root.children=[mkN('sol','sprendimas','✅ '+(fm.resolution||'Patvirtinta')),mkN('no','veiksmas','Tikrinti kitas galimas gedimų priežastis')];
  }

  if(steps.length) {
    const stepsNode=mkN('steps','veiksmas','Diagnostikos žingsniai:\n'+steps.join('\n'));
    stepsNode.branches=['TAIP','NE'];
    stepsNode.children=[mkN('fixed','sprendimas','✅ '+(fm.resolution||'Gedimas ištaisytas')),mkN('more','veiksmas','Kreiptis į specialistą')];
    if(root.children[0]) root.children.splice(1,0,stepsNode);
  }

  KB.decision_trees[fid]={id:fid, object_id:oid||curObj, failure_id:fid, root};
  _editN[fid]=null; _selN[fid]='root';
  renderInlineTree(fid,oid||curObj);
  toast('⚡ Medis sugeneruotas iš '+(syms.length||0)+' simptomų');
}

function saveInlineTree(fid,oid) {
  const o=oid||KB.decision_trees[fid]?.object_id||curObj;
  markDirty('tree_'+o+'_'+fid); flushDirty(); toast('💾 Medis išsaugotas');
}

function treeObjChange() {
  const oid=document.getElementById('tree-obj')?.value;
  if(!oid) return;
  const fs=document.getElementById('tree-fail-sel'); if(!fs) return;
  const fms=Object.values(KB.objects[oid]?.failure_modes||{}).filter(f=>f.name);
  fs.innerHTML=`<option value="">-- pasirink gedimą --</option>`+fms.map(fm=>{
    const hasTree=!!(KB.decision_trees[fm.id]||(fm.diag_tree||[]).length);
    return `<option value="${fm.id}">${fm.id} – ${fm.name}${hasTree?' ✓':''}`;
  }).join('');
}

function loadTree() {
  const fid=document.getElementById('tree-fail-sel')?.value;
  const oid=document.getElementById('tree-obj')?.value;
  if(!fid||!oid) return;
  document.getElementById('tree-title').textContent=fid;
  switchTreeTab('view');

  const fm=KB.objects[oid]?.failure_modes?.[fid];

  
  if(fm&&(fm.diag_tree||[]).length&&!KB.decision_trees[fid]) {
    autoGenTree(fid, oid);
  }

  
  _renderTreeIntoCanvas(fid, oid);
}

function _renderTreeIntoCanvas(fid, oid) {
  const render=document.getElementById('tree-render');
  const empty=document.getElementById('tree-empty');
  if(!render) return;

  if(!KB.decision_trees[fid]) {
    
    KB.decision_trees[fid]={
      id:fid, object_id:oid||curObj, failure_id:fid,
      root:{id:'root',type:'klausimas',text:'Pradinis klausimas',branches:['TAIP','NE'],children:[],note:''}
    };
  }

  if(empty) empty.style.display='none';
  render.innerHTML='';
  render.style.cssText='transform-origin:top left;display:inline-block;min-width:100%;padding:20px';

  const wrap=document.createElement('div');
  wrap.style.cssText='display:inline-flex;flex-direction:column;align-items:center;padding:8px 16px 24px';
  render.style.textAlign='center';
  render.appendChild(wrap);
  drawNode(KB.decision_trees[fid].root, fid, wrap, null, 0);
}

function saveTreeFile() {
  const fid=document.getElementById('tree-fail-sel')?.value;
  const oid=document.getElementById('tree-obj')?.value;
  if(!fid) { toast('Pasirink gedimą'); return; }
  saveInlineTree(fid, oid);
}

function autoTreeFromFail() {
  const fid=document.getElementById('tree-fail-sel')?.value;
  const oid=document.getElementById('tree-obj')?.value;
  if(!fid) { toast('Pasirink gedimą'); return; }
  autoGenTree(fid, oid);
  loadTree();
  toast('✓ Medis sugeneruotas');
}

function switchTreeTab(tab) {
  const showDash=tab==='dashboard';
  const d=document.getElementById('tree-tab-dashboard');
  const v=document.getElementById('tree-tab-view');
  const bd=document.getElementById('ttab-dashboard');
  const bv=document.getElementById('ttab-view');
  if(d) d.style.display=showDash?'block':'none';
  if(v) v.style.display=showDash?'none':'flex';
  if(bd) bd.style.fontWeight=showDash?'700':'400';
  if(bv) bv.style.fontWeight=showDash?'400':'700';
  if(showDash) renderTreeDashboard();
}

function initTreePage() {
  const os=document.getElementById('tree-obj'); if(!os) return;
  os.innerHTML=`<option value="">-- pasirink objektą --</option>`+Object.keys(KB.objects_meta).map(id=>`<option value="${id}">${id} – ${KB.objects_meta[id].name}`).join('');
  renderTreeDashboard();

  
  const mini=document.getElementById('tree-coverage-mini');
  if(mini) {
    const all=[],withD=[];
    Object.entries(KB.objects).forEach(([oid,kb])=>Object.values(kb.failure_modes||{}).filter(f=>f.name).forEach(fm=>{
      all.push(fm.id);
      if((fm.diag_tree||[]).length||KB.decision_trees[fm.id]) withD.push(fm.id);
    }));
    mini.innerHTML=`<div style="font-size:18px;font-weight:700;font-family:'JetBrains Mono',monospace;color:var(--pri)">${withD.length}/${all.length}</div>
    <div style="font-size:9px;color:var(--td)">gedimai su diagnostika</div>`;
  }
}
