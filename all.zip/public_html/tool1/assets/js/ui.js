function gp(id, el) {
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.ntab').forEach(t=>t.classList.remove('active'));
  const page = document.getElementById('page-'+id);
  if(!page) { console.error('gp: nėra puslapio page-'+id); return; }
  page.classList.add('active');
  if(el) el.classList.add('active');
  
  history.replaceState(null, '', '#' + id);
  try {
    if(id==='map')    setTimeout(mapPageInit,80);
    
    if(id==='stats')  renderStats();
    if(id==='admin')  { renderStats(); if(typeof switchSATab==='function') switchSATab('admin'); }
    if(id==='import') renderTpls();
    if(id==='pct')    renderPct();
    if(id==='diag')   initDiag();
    if(id==='trel')   renderTrel();
    if(id==='monitor') renderMonitor();
    if(id==='uzsakymai') renderOrders();
    if(id==='kainos')    renderPrices();
  } catch(err) {
    console.error('gp('+id+') render klaida:', err);
  }
}

function _restoreTab() {
  const hash = location.hash.replace('#','');
  const tab = hash ? document.querySelector('.ntab[data-p="'+hash+'"]') : null;
  if(tab) gp(hash, tab);
}

function toast(msg) {
  const t=document.getElementById('toast');
  t.textContent=msg; t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 2200);
}

let _mok = null;
function openModal(title, html, onOk) {
  document.getElementById('modal-t').textContent = title;
  document.getElementById('modal-b').innerHTML = html;
  _mok = onOk;
  document.getElementById('modal').classList.add('open');
}
function modalOk()    { if(_mok) _mok(); }
function closeModal() { document.getElementById('modal').classList.remove('open'); _mok=null; }

function showSaveInd(msg, col) {
  const el = document.getElementById('save-ind'); if(!el) return;
  el.textContent = msg || '✓ Išsaugota';
  el.style.color = col || 'var(--td)';
  el.style.borderColor = col || 'var(--b1)';
  el.classList.add('show');
  if(col !== '#e65100') setTimeout(()=>el.classList.remove('show'), 3000);
}

function updateCounts() {
  let fails = 0;
  Object.keys(KB.objects_meta).forEach(id=>fails+=Object.keys(KB.objects[id]?.failure_modes||{}).length);
  document.getElementById('n-objs').textContent  = Object.keys(KB.objects_meta).length;
  document.getElementById('n-fails').textContent = fails;
  document.getElementById('n-cases').textContent = KB.field_cases.length;
}

function ui(hint) {
  updateCounts();
  updateJson();
  const active = document.querySelector('.page.active')?.id?.replace('page-','');
  if(!active) return;
  if(active==='k')    { renderObjList(); renderKTab(); }
  if(active==='d')    { initDiary(); }
  if(active==='stats') renderStats();
  if(active==='trel')  renderTrel();
  if(active==='pct')   renderPct();
  if(hint==='cases')   renderCases();
  if(hint==='obj')     renderObjList();
  if(hint==='ktab')    renderKTab();
}

function jt(tab, btn) {
  curJTab = tab;
  document.querySelectorAll('.jtab').forEach(t=>t.classList.remove('active'));
  btn.classList.add('active');
  updateJson();
}
function updateJson() {
  const data = curJTab==='obj' ? {[curObj]:KB.objects[curObj]} : KB;
  document.getElementById('json-pre').innerHTML = hlJson(JSON.stringify(data,null,2));
}
function copyJson() {
  const data = curJTab==='obj' ? {[curObj]:KB.objects[curObj]} : KB;
  navigator.clipboard.writeText(JSON.stringify(data,null,2));
  toast('Nukopijuota ✓');
}

function v(id)       { const el=document.getElementById(id); return el?el.value.trim():''; }
function fv(sel,fid) { const el=document.querySelector(`${sel}[data-f="${fid}"]`); return el?el.value.trim():''; }
function fvI(sel,i)  { const el=document.querySelector(`${sel}[data-i="${i}"]`); return el?el.value.trim():''; }
function e(s)        { return (s||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function dl(text, fname) {
  const uri = 'data:application/json;charset=utf-8,' + encodeURIComponent(text);
  const a = document.createElement('a'); a.href=uri; a.download=fname;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
}
function hlJson(j) {
  return j.replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/(\"(\\u[\da-fA-F]{4}|\\[^u]|[^\\"])*\"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?)/g, m=>{
      if(/^"/.test(m)) return /:$/.test(m)?`<span class="jk">${m}</span>`:`<span class="jv">${m}</span>`;
      if(/true|false|null/.test(m)) return `<span class="jb">${m}</span>`;
      return `<span class="jn">${m}</span>`;
    });
}
function appE(id, text) { const el=document.getElementById(id); if(el) el.value=(el.value?el.value+' ':'')+text; }
function autoSave() {}
