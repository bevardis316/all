<?php

require_once __DIR__ . '/api/config.php';
require_once __DIR__ . '/api/auth.php';

require_once dirname(__DIR__) . '/shared/php/domain-reader.php';

$_mapsKey = GOOGLE_MAPS_KEY;

startSecureSession();
if (!isset($_SESSION['ibnvs_auth']) || (time() - ($_SESSION['ibnvs_ts'] ?? 0)) >= SESSION_TTL) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="lt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IBNVS · Žinių Ekosistema v6</title>
<link rel="stylesheet" href="../shared/css/theme.css">
<link rel="stylesheet" href="assets/css/base.css">
<link rel="stylesheet" href="assets/css/layout.css">
<link rel="stylesheet" href="assets/css/forms.css">
<link rel="stylesheet" href="assets/css/components.css">
</head>
<body>

<!-- NAV -->
<div id="nav">
  <div class="nlogo">IBN<span>VS</span></div>
  <div class="ntab active" data-p="k"      onclick="gp('k',this)">◈ Žinios</div>
  <div class="ntab"        data-p="diag"   onclick="gp('diag',this)">🔍 Diagnostika</div>
  <div class="ntab"        data-p="map"    onclick="gp('map',this)">🗺 Žemėlapis <span id="mapPendingBadge" style="display:none;background:#ef4444;color:#fff;border-radius:10px;padding:1px 6px;font-size:11px;margin-left:4px"></span></div>
  <div class="ntab"        data-p="3dmap"  onclick="gp('3dmap',this)">⬡ MAP</div>
  <div class="ntab"        data-p="pct"    onclick="gp('pct',this)">% Procentai</div>
  <div class="ntab"        data-p="trel"   onclick="gp('trel',this)">⇄ Ryšiai+Laikas</div>
  <div class="ntab"        data-p="import" onclick="gp('import',this)">↓ Importas</div>
  <div class="ntab"        data-p="stats"  onclick="gp('stats',this)">▣ Statistika / Admin</div>
  <div class="ntab"        data-p="monitor"    onclick="gp('monitor',this)">📊 Monitoringas</div>
  <div class="ntab"        data-p="uzsakymai" onclick="gp('uzsakymai',this)">🛒 Užsakymai</div>
  <div class="ntab"        data-p="kainos"    onclick="gp('kainos',this)">💰 Kainos</div>
  <div class="ntab"        data-p="ui"       onclick="gp('ui',this);renderUiLabels()">✏️ UI Tekstai</div>
  <div id="nav-r">
    <div class="npill">Obj: <b id="n-objs">0</b></div>
    <div class="npill">Ged: <b id="n-fails">0</b></div>
    <div class="npill">Atv: <b id="n-cases">0</b></div>
    <button class="btn" style="background:#fff;color:var(--pri);border-color:#fff;font-size:10px;font-weight:700" onclick="saveAllFiles()">💾 IŠSAUGOTI VISKĄ</button>
    <button class="btn" style="background:rgba(255,255,255,.15);color:#fff;border-color:rgba(255,255,255,.3);font-size:10px" onclick="exportFull()">↓ EKSPORTAS</button>
    <button class="btn" style="background:rgba(200,50,50,.3);color:#fbb;border-color:rgba(200,50,50,.4);font-size:10px" onclick="doLogout()">⏻ Atsijungti</button>
  </div>
</div>
<div id="save-ind">💾 Išsaugota</div>

<div id="app">

<!-- ══════════ PAGE: KNOWLEDGE ══════════ -->
<div id="page-k" class="page active">
  <div id="obj-sb">
    <div class="sbh">
      <div class="sbh-title">Objektai</div>
      <button class="btn sm ghost" onclick="showAddObj()">+ Naujas</button>
    </div>
    <div id="obj-list"></div>
  </div>
  <div id="k-main">
    <div id="k-tabs">
      <div class="ktab active" onclick="kt('base',this)">Bazė</div>
      <div class="ktab" onclick="kt('failures',this)">Gedimai</div>
      <div class="ktab" onclick="kt('env',this)">Aplinka</div>
      <div class="ktab" onclick="kt('errors',this)">Eksploatacija</div>
      <div class="ktab" onclick="kt('rels',this)">Ryšiai</div>
      <div class="ktab" onclick="kt('packages',this)">📦 Komplektai</div>
    </div>
    <div id="k-content"></div>
  </div>
  <div id="json-side">
    <div class="jsh">
      <div class="jsh-title">JSON</div>
      <div class="jtabs">
        <button class="jtab active" onclick="jt('obj',this)">OBJ</button>
        <button class="jtab" onclick="jt('all',this)">VISKAS</button>
      </div>
    </div>
    <pre id="json-pre"></pre>
    <button class="jcopy" onclick="copyJson()">Kopijuoti JSON</button>
  </div>
</div>

<!-- ══════════ PAGE: DIARY ══════════ -->

<!-- ══════════ PAGE: MAP ══════════ -->
<div id="page-3dmap" class="page">
  <div id="map-toolbar">
    <span style="font-size:12px;font-weight:700;color:var(--pri)">⬡ MAP — Sistemų žemėlapis</span>
    <div style="display:flex;gap:6px;align-items:center">
      <span style="font-size:10px;color:var(--td)">Sistema:</span>
      <select id="map-sys" onchange="renderMapWithLoader()" style="font-size:10px;padding:3px 8px;border:1px solid var(--b1);border-radius:4px;background:var(--s1);max-width:260px">
        <option value="0">— Visi objektai —</option>
      </select>
    </div>
    <div id="map-comp-mode" style="display:flex;align-items:center;gap:4px"></div>
    <div style="margin-left:auto;display:flex;gap:4px;align-items:center">
      <label style="font-size:10px;color:var(--td);white-space:nowrap">☀ Šviesa:</label>
      <input id="adm-amb-input" type="number" value="1.2" min="0" max="3" step="0.1"
        onchange="_adm_setAmbient(this.value)"
        oninput="_adm_setAmbient(this.value)"
        style="width:52px;font-size:10px;padding:2px 5px;border:1px solid var(--b1);border-radius:4px;background:var(--s1);color:var(--text);text-align:center">
      <script>
        (function(){
          var s=parseFloat(localStorage.getItem('adm_amb'));
          if(s>0){ var el=document.getElementById('adm-amb-input'); if(el) el.value=s.toFixed(1); window._admAmbIntensity=s; }
        })();
        function _adm_setAmbient(val){
          val=Math.max(0,Math.min(3,parseFloat(val)||1.2));
          window._admAmbIntensity=val;
          try{ localStorage.setItem('adm_amb',val); }catch(e){}
          if(window._admAmbLightRef) window._admAmbLightRef.intensity=val;
          var inp=document.getElementById('adm-amb-input');
          if(inp&&parseFloat(inp.value)!==val) inp.value=val.toFixed(1);
        }
      </script>
      <button class="btn ghost sm" onclick="_adm_toggleGlbPanel()">&#9650; GLB</button>
      <button class="btn ghost sm" onclick="_adm_refreshGlb()" title="Atnaujinti GLB modelius (išvalyti kešą)">&#8635; GLB</button>
      <button class="btn ghost sm" onclick="_adm_toggleCamPanel()">&#128247; Kamera</button>
      <button class="btn ghost sm" onclick="_adm_toggleGvlPanel()">&#128167; GVL</button>
      <button class="btn ghost sm" onclick="map3dReset()">↺ Reset</button>
    </div>
  </div>
  <!-- Flex wrapper: kaire 3D scena + desine .right panelis.
       map3d.js::_ensurePanel() randa .right ir injektuoja -->
  <div style="flex:1;display:flex;overflow:hidden;min-height:0">
    <div id="map-area" style="flex:1;position:relative;min-width:0">
      <canvas id="map-canvas" style="width:100%;height:100%;display:block;cursor:default"></canvas>
      <div id="map-info-panel"></div>
      <div style="position:absolute;top:10px;right:10px;font-size:9px;color:var(--td);background:var(--s1);padding:6px 10px;border-radius:var(--r);border:1px solid var(--b1);line-height:1.9;pointer-events:none">
        <b style="color:var(--pri)">X</b> Sektorius A→E<br>
        <b style="color:var(--pri)">Y</b> Gylis žemėje<br>
        <span style="color:#888">Klik = komponentai</span>
      </div>
    </div>
    <div class="right" style="width:340px;min-width:280px;max-width:400px;background:var(--s1);border-left:1px solid var(--b1);overflow-y:auto;display:flex;flex-direction:column">
      <div style="padding:12px;color:var(--td);font-size:11px;text-align:center">⬅ Pasirink objektą scenoje</div>
    </div>
  </div>
</div>

<!-- ══════════ PAGE: DIAGNOSTIKA ══════════ -->
<div id="page-diag" class="page">
  <div id="diag-wrap">
    <div id="diag-sym-area">
      <div style="padding:30px;text-align:center;color:var(--td)">
        <div style="font-size:24px;margin-bottom:10px">🔍</div>
        <div style="font-size:12px;font-weight:600;margin-bottom:6px">Kraunama...</div>
      </div>
    </div>
    <div id="diag-env" style="display:flex;gap:10px;padding:10px 14px;background:var(--s2);border:1px solid var(--b1);border-radius:var(--r);margin-bottom:8px;flex-wrap:wrap;align-items:center">
      <div class="env-group">
        <label>GVL:</label>
        <button class="env-btn" onclick="setDiagEnv('gvl','gvl-1',this)">⬆ Aukštas</button>
        <button class="env-btn" onclick="setDiagEnv('gvl','gvl-2',this)">⬇ Žemas</button>
      </div>
      <div class="env-group">
        <label>Gruntas:</label>
        <button class="env-btn" onclick="setDiagEnv('soil','smel',this)">🏖 Smėlis</button>
        <button class="env-btn" onclick="setDiagEnv('soil','mol',this)">🧱 Molis</button>
      </div>
      <div class="env-group">
        <label>Amžius:</label>
        <button class="env-btn" onclick="setDiagEnv('age','old',this)">👴 7m+</button>
      </div>
      <div class="env-group">
        <label>Objektas:</label>
        <select id="diag-obj-filter" onchange="if(diagSel.length)runDiag()" style="width:150px;padding:4px 8px;font-size:11px">
          <option value="">Visi objektai</option>
        </select>
      </div>
      <div class="env-group">
        <label>Sistema:</label>
        <select id="diag-sys-filter" onchange="applyDiagSysFilter()" style="width:150px;padding:4px 8px;font-size:11px">
          <option value="">Visos sistemos</option>
        </select>
      </div>
      <button id="diag-run" onclick="runDiag()">🔍 Diagnozuoti</button>
    </div>
    <div id="diag-sel-bar">
      <span class="sl">Pasirinkti simptomai:</span>
      <div class="sc" id="diag-sel-chips">
        <span style="opacity:.5;font-size:10px">Nėra – pasirink kairėje</span>
      </div>
    </div>
    <div id="diag-results">
      <div class="diag-no-sel">
        <div class="ico">🔍</div>
        <h3>Pasirink simptomus</h3>
        <p>Spustelėk simptomus kairėje, nustatyk aplinkos sąlygas viršuje ir spausk „Diagnozuoti".</p>
      </div>
    </div>
  </div>
</div>

<!-- ══════════ PAGE: TAG RELATIONS + LAIKO GRANDINĖS ══════════ -->
<div id="page-trel" class="page">
  <div id="trel-wrap">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;flex-wrap:wrap">
      <div>
        <div style="font-size:18px;font-weight:700;color:var(--pri)">⇄ Priežasčių ryšiai ir laiko grandinės</div>
        <div style="font-size:11px;color:var(--td);margin-top:2px">Kauzaliniai ryšiai su laiko tarpais — tiesiogiai veikia diagnostikos pasiūlymus ir AI IQ</div>
      </div>
      <button class="btn pri" style="margin-left:auto" onclick="addTrel()">+ Naujas ryšys</button>
      <button class="btn ghost" onclick="saveTrelFile()">💾 Išsaugoti</button>
    </div>
    <div class="admin-sec" id="trel-form-wrap" style="display:none">
      <h3>Naujas kauzalinis ryšys</h3>
      <div style="font-size:11px;color:var(--td);margin-bottom:12px;padding:8px;background:var(--s2);border-radius:var(--r)">
        <strong>P→G</strong> Priežastis→Gedimas · <strong>G=Ps</strong> Gedimas=Pasekmė · <strong>Ps→S</strong> Pasekmė→Simptomas · <strong>S↔G</strong> Simptomas↔Gedimas
      </div>
      <div class="row3">
        <div>
          <div class="lbl">Iš</div>
          <div id="trel-from-panel"></div>
          <input type="text" id="trel-from" placeholder="arba rašyk laisvai…" style="margin-top:4px">
        </div>
        <div>
          <div class="lbl">Ryšio tipas</div>
          <select id="trel-type">
            <option value="P→G">⏩ P→G · Priežastis → Gedimas</option>
            <option value="G=Ps">⚡ G=Ps · Gedimas = Pasekmė</option>
            <option value="Ps→S">👁 Ps→S · Pasekmė → Simptomas</option>
            <option value="S↔G">↔ S↔G · Simptomas ↔ Gedimas</option>
            <option value="sukelia">→ Sukelia</option>
            <option value="sustiprina">↑ Sustiprina</option>
            <option value="paneigia">✗ Paneigia</option>
            <option value="susijęs">↔ Susijęs</option>
          </select>
          <div class="lbl" style="margin-top:8px">Δt laiko tarpas (neprivaloma)</div>
          <input type="text" id="trel-dt" placeholder="pvz. 3 dienos" style="font-family:'JetBrains Mono',monospace">
        </div>
        <div>
          <div class="lbl">Į</div>
          <div id="trel-to-panel"></div>
          <input type="text" id="trel-to" placeholder="arba rašyk laisvai…" style="margin-top:4px">
        </div>
      </div>
      <div class="lbl">Pastaba (neprivaloma)</div>
      <input type="text" id="trel-note" placeholder="pvz. Chemija naikina biologiją per 3 dienas">
      <div class="save-bar">
        <button class="btn pri" onclick="saveTrelRow()">Pridėti ryšį</button>
        <button class="btn ghost" onclick="document.getElementById('trel-form-wrap').style.display='none'">Atšaukti</button>
      </div>
    </div>
    <div style="display:flex;gap:10px;margin-bottom:10px;flex-wrap:wrap">
      <input type="text" id="trel-search" placeholder="Ieškoti ryšių..." style="max-width:220px" oninput="renderTrel()">
      <select id="trel-type-f" onchange="renderTrel()" style="width:200px">
        <option value="">Visi tipai</option>
        <option value="P→G">P→G · Priežastis→Gedimas</option>
        <option value="G=Ps">G=Ps · Gedimas=Pasekmė</option>
        <option value="Ps→S">Ps→S · Pasekmė→Simptomas</option>
        <option value="S↔G">S↔G · Simptomas↔Gedimas</option>
        <option value="sukelia">Sukelia</option>
        <option value="sustiprina">Sustiprina</option>
        <option value="paneigia">Paneigia</option>
        <option value="susijęs">Susijęs</option>
      </select>
      <span id="trel-count" style="font-size:11px;color:var(--td);line-height:32px"></span>
    </div>
    <div class="card" style="margin-bottom:12px">
      <div class="card-h">
        <h3>RYŠIŲ GRAFIKAS</h3>
        <button class="btn ghost sm" onclick="toggleTrelView()">Perjungti vaizdą</button>
      </div>
      <div class="card-body"><div id="trel-graph"></div></div>
    </div>
    <div class="card">
      <div class="card-h"><h3>RYŠIŲ SĄRAŠAS</h3></div>
      <div class="card-body" id="trel-list"></div>
    </div>
  </div>
</div>

<!-- ══════════ PAGE: MONITORINGAS ══════════ -->
<div id="page-monitor" class="page" style="overflow-y:auto;">
  <div id="monitor-wrap" style="padding:16px;max-width:1400px;margin:0 auto">
    <div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Spausk skirtuką kad užkrautų...</div>
  </div>
</div>

<!-- ══════════ ETAPAS 2.3: Trūkstami page div'ai (buvo praleisti) ══════════ -->

<!-- PAGE: PROCENTAI -->
<div id="page-pct" class="page" style="overflow-y:auto;">
  <div id="pct-content" style="padding:16px;max-width:1200px;margin:0 auto">
    <div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Spausk skirtuką kad užkrautų...</div>
  </div>
</div>

<!-- PAGE: IMPORTAS -->
<div id="page-import" class="page" style="overflow-y:auto;">
  <div id="import-wrap" style="padding:16px;max-width:900px;margin:0 auto">
    <div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Spausk skirtuką kad užkrautų...</div>
  </div>
</div>

<!-- PAGE: STATISTIKA / ADMIN (sujungta, Etapas 2.3) -->
<div id="page-stats" class="page" style="overflow-y:auto;">
  <div id="stats-wrap" style="padding:16px;max-width:1400px;margin:0 auto">
    <div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Spausk skirtuką kad užkrautų...</div>
  </div>
</div>

<!-- PAGE: TIMELINE (pages-tl.js) -->
<div id="page-tl" class="page" style="overflow-y:auto;">
  <div id="tl-wrap" style="padding:16px;max-width:1400px;margin:0 auto">
    <div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Spausk skirtuką kad užkrautų...</div>
  </div>
</div>

<!-- PAGE: UŽSAKYMAI (Etapas 4.2) -->
<div id="page-uzsakymai" class="page" style="overflow-y:auto;">
  <div id="orders-wrap" style="padding:16px;max-width:1200px;margin:0 auto">
    <div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Spausk skirtuką kad užkrautų...</div>
  </div>
</div>

<!-- PAGE: KAINOS (Etapas 4.2) -->
<div id="page-kainos" class="page" style="overflow-y:auto;">
  <div id="prices-wrap" style="padding:16px;max-width:1200px;margin:0 auto">
    <div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Spausk skirtuką kad užkrautų...</div>
  </div>
</div>

<div id="page-admin" class="page" style="overflow-y:auto;">
  <div id="admin-wrap" style="padding:16px;max-width:1400px;margin:0 auto"></div>
</div>

<!-- PAGE: UI TEKSTAI -->
<div id="page-ui" class="page" style="overflow-y:auto;">
  <div id="ui-wrap" style="padding:16px;max-width:900px;margin:0 auto">
    <div style="color:var(--td);font-size:12px;padding:20px;text-align:center">⏳ Spausk skirtuką kad užkrautų...</div>
  </div>
</div>

<!-- PAGE: ŽEMĖLAPIS (pages-map.js) -->
<div id="page-map" class="page" style="overflow-y:auto;">
  <div style="padding:16px;max-width:1400px;margin:0 auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
    <h2 style="font-size:16px;font-weight:600;margin:0">🗺 Kontaktų žemėlapis</h2>
    <button class="btn pri sm" onclick="mapShowAddNew()">+ Pridėti naują</button>
  </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">

      <!-- Laukiančios paraiškos -->
      <div>
        <div style="font-size:13px;font-weight:600;color:var(--td);margin-bottom:10px">Laukiančios paraiškos</div>
        <div id="mapPendingList" style="display:flex;flex-direction:column;gap:10px">
          <div style="color:#888;font-size:13px;padding:16px">Kraunama...</div>
        </div>
      </div>

      <!-- Patvirtinti įrašai -->
      <div>
        <div style="font-size:13px;font-weight:600;color:var(--td);margin-bottom:10px">Aktyvūs žemėlapyje</div>
        <div id="mapApprovedList" style="display:flex;flex-direction:column;gap:10px">
          <div style="color:#888;font-size:13px;padding:16px">Kraunama...</div>
        </div>
      </div>
    </div>

    <!-- Mini žemėlapis admin pusėje -->
    <div style="margin-top:20px">
      <div style="font-size:13px;font-weight:600;color:var(--td);margin-bottom:8px">Žemėlapio peržiūra (admin)</div>
      <div id="adminMapContainer" style="width:100%;height:360px;border-radius:10px;border:1px solid var(--b1);background:#e8eaed"></div>
    </div>
  </div>
</div>

<!-- MAP Edit Modal -->
<div id="mapEditModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:2000;align-items:center;justify-content:center">
  <div style="background:var(--s1);border-radius:12px;padding:24px;width:400px;max-width:95vw">
    <div style="font-size:15px;font-weight:600;margin-bottom:16px">Redaguoti: <span id="editName"></span></div>
    <div style="display:flex;flex-direction:column;gap:10px">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <div><label style="font-size:12px;color:var(--td)">Platuma (lat)</label><input id="editLat" type="number" step="0.0001" class="ibnvs-input"></div>
        <div><label style="font-size:12px;color:var(--td)">Ilguma (lng)</label><input id="editLng" type="number" step="0.0001" class="ibnvs-input"></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <div><label style="font-size:12px;color:var(--td)">Rodyti dienų</label><input id="editDays" type="number" min="1" class="ibnvs-input" value="365"></div>
        <div><label style="font-size:12px;color:var(--td)">Vertė (€)</label><input id="editEur" type="number" step="0.01" class="ibnvs-input" value="0"></div>
      </div>
      <div><label style="font-size:12px;color:var(--td)">Trumpa info</label><textarea id="editInfo" style="width:100%;padding:8px;border-radius:6px;border:1.5px solid var(--border);background:var(--bg);color:var(--text);font-size:13px;font-family:inherit;resize:vertical;min-height:60px"></textarea></div>
    </div>
    <div style="display:flex;gap:8px;margin-top:16px">
      <button class="btn pri" onclick="mapSaveEdit()">Išsaugoti</button>
      <button class="btn ghost" onclick="mapCloseEdit()">Atšaukti</button>
    </div>
  </div>
</div>

</div><!-- #app -->

<!-- MODAL -->
<div id="modal"><div id="modal-box">
  <h2 id="modal-t">Modalas</h2>
  <div id="modal-b"></div>
  <div class="save-bar">
    <button class="btn pri" onclick="modalOk()">OK</button>
    <button class="btn ghost" onclick="closeModal()">Uždaryti</button>
  </div>
</div></div>

<div id="toast"></div>

<!-- ================================================================
     JS MODULIAI (tvarka svarbi!)
     ETAPAS 1.1: state.js pakeistas į shared versiją + domain embed
     ================================================================ -->

<!-- 1. Domain duomenys – PHP embed'ina domain.json prieš state.js -->
<script>const _DOMAIN_DATA = <?php echo getDomainPublicJson(); ?>;</script>

<!-- 2. State.js – TECH, DEF_OBJS, KB struktūra, emptyObj/emptyComp -->
<!--    Failas: tool1/assets/js/state.js (atnaujintas su _DOMAIN_DATA logika) -->
<script src="assets/js/state.min.js"></script>
<script src="../shared/js/state-bridge.js"></script>

<!-- 3. Tool1 moduliai (tvarka svarbi) -->
<script src="assets/js/api.min.js"></script>           <!-- fetch, dirty tracking -->
<script src="assets/js/ui.min.js"></script>            <!-- gp(), kt(), toast(), modal() -->
<script src="assets/js/knowledge-core.min.js"></script>   <!-- objektai, gedimai, env, ryšiai -->
<script src="assets/js/knowledge-packages.min.js"></script> <!-- komplektų valdymas -->
<script src="assets/js/knowledge-tags.min.js"></script>   <!-- tagų sistema -->
<script src="assets/js/tree.min.js"></script>          <!-- sprendimų medžiai -->
<script src="assets/js/diary.min.js"></script>         <!-- dienoraštis -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r134/three.min.js"></script>
<script src="../shared/js/map3d-core.min.js"></script>  <!-- 3D engine (shared) ETAPAS 1.2 -->
<script src="assets/js/map3d-admin.min.js"></script>  <!-- Admin overrides: drag, camCalib -->
<script src="assets/js/pages-tl.min.js"></script>      <!-- timeline -->
<script src="assets/js/pages-import.min.js"></script>  <!-- importas -->
<script src="assets/js/pages-stats.min.js"></script>   <!-- statistika/admin -->
<script src="assets/js/pages-diag.min.js"></script>    <!-- diagnostika -->
<script src="assets/js/pages-trel.min.js"></script>    <!-- tag ryšiai + laikas -->
<script src="assets/js/pages-init.min.js"></script>    <!-- init(), renderAll() -->
<script src="assets/js/pages-monitor.min.js"></script> <!-- monitoringas -->
<script src="assets/js/pages-orders.min.js"></script>   <!-- uzsakymai + kainos (Etapas 4.2) -->
<script src="assets/js/pages-ui.js"></script>
<script src="assets/js/pages-map.js"></script>

<style>
.map-card{background:var(--s1);border:1px solid var(--b1);border-radius:10px;padding:14px;font-size:13px}
.map-card.expired{opacity:.6}
.map-card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
.map-card-body{color:var(--td);line-height:1.6}
.map-card-actions{margin-top:10px}
.map-coords-row{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:6px}
.map-coords-row input{padding:5px 8px;border-radius:6px;border:1.5px solid var(--border);background:var(--bg);color:var(--text);font-size:12px}
.map-btn{padding:5px 12px;border-radius:6px;border:none;cursor:pointer;font-size:12px;font-weight:500}
.map-btn.approve{background:#d1fae5;color:#065f46}
.map-btn.reject{background:#fee2e2;color:#991b1b}
.map-btn.edit{background:#dbeafe;color:#1e40af}
.map-badge{font-size:11px;padding:2px 8px;border-radius:10px;font-weight:500}
.map-badge.new{background:#fef3c7;color:#92400e}
.map-badge.ok{background:#d1fae5;color:#065f46}
.map-badge.exp{background:#fee2e2;color:#991b1b}
</style>

<script>
// Atsijungimas
async function doLogout() {
  try { await fetch('api.php?action=logout', {credentials:'include'}); } catch(e) {}
  window.location.href = 'login.php';
}
document.addEventListener('DOMContentLoaded', () => init());
</script>

<?php if ($_mapsKey): ?>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=<?= htmlspecialchars($_mapsKey) ?>&callback=_mapsReady&language=lt&region=LT"></script>
<script>function _mapsReady() { const p=document.getElementById('page-map'); if(p&&p.classList.contains('active')) mapPageInit(); }</script>
<?php endif; ?>

</body>
</html>
