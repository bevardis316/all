<?php

ob_start();

@ini_set('display_errors', '0');
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed = $_SERVER['HTTP_HOST'] ?? '';
if ($origin && parse_url($origin, PHP_URL_HOST) === $allowed) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Access-Control-Allow-Credentials: true');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once __DIR__ . '/api/config.php';
require_once __DIR__ . '/api/helpers.php';
require_once __DIR__ . '/api/paths.php';
require_once __DIR__ . '/api/auth.php';
require_once __DIR__ . '/api/indexes.php';

$action = $_GET['action'] ?? '';

if ($action === 'login') {
    $d = getBody();
    $result = attemptLogin($d['password'] ?? '');
    echo json_encode(array_merge(['ok' => $result['ok']], $result));
    exit;
}
if ($action === 'logout') {
    logout();
    echo json_encode(['ok' => true]);
    exit;
}
if ($action === 'check_auth') {
    startSecureSession();
    $ok = isset($_SESSION['ibnvs_auth']) && (time() - ($_SESSION['ibnvs_ts'] ?? 0)) < SESSION_TTL;
    echo json_encode(['ok' => $ok]);
    exit;
}
if ($action === 'csrf_token') {
    startSecureSession();
    echo json_encode(['ok' => true, 'token' => $_SESSION['csrf_token'] ?? '']);
    exit;
}

checkAuth();
rateLimit();

$csrfToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $csrfToken !== ($_SESSION['csrf_token'] ?? '')) {
    err(403, 'CSRF token klaida');
}

switch ($action) {
    case 'status':
        require __DIR__ . '/api/actions/status.php';
        break;
    case 'load_all':
    case 'load_cases':
        require __DIR__ . '/api/actions/load_all.php';
        break;
    case 'load_analytics':
        require __DIR__ . '/api/actions/load_analytics.php';
        break;
    case 'load_orders':                                          
        require __DIR__ . '/api/actions/load_orders.php';
        break;
    case 'load_components':                                      
        require __DIR__ . '/api/actions/load_components.php';
        break;
    case 'load_object':                                          
        require __DIR__ . '/api/actions/load_object.php';
        break;
    case 'save_component_pricing':                               
        require __DIR__ . '/api/actions/save_component_pricing.php';
        break;
    case 'save_all':
        require __DIR__ . '/api/actions/save_all.php';
        break;
    case 'save_object_base':
    case 'add_object':
    case 'delete_object':
        require __DIR__ . '/api/actions/objects.php';
        break;
    case 'save_scene_3d':
        require __DIR__ . '/api/actions/scene3d.php';
        break;
    case 'save_failure':
    case 'delete_failure':
        require __DIR__ . '/api/actions/failures.php';
        break;
    case 'save_tree':
        require __DIR__ . '/api/actions/trees.php';
        break;
    case 'save_case':
    case 'save_timeline':
    case 'save_percentages':
    case 'save_meta':
        require __DIR__ . '/api/actions/cases.php';
        break;
    case 'save_component':
    case 'delete_component':
        require __DIR__ . '/api/actions/components.php';
        break;
    case 'load_ui_labels':
    case 'save_ui_labels':
        require __DIR__ . '/api/actions/ui_labels.php';
        break;
    case 'init':
        require __DIR__ . '/api/actions/init.php';
        break;
    case 'map_pending':
    case 'map_approve':
    case 'map_reject':
    case 'map_list':
    case 'map_update':
    case 'map_delete':
    case 'map_add_direct':
        require __DIR__ . '/api/actions/map.php';
        break;
    default:
        err(400, "Nežinomas veiksmas: '{$action}'");
}
