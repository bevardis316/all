<?php

function startSecureSession() {
    if (session_status() === PHP_SESSION_NONE) {
        
        session_set_cookie_params([
            'lifetime' => SESSION_TTL,
            'path'     => '/',
            'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'httponly'  => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}

function checkAuth() {
    startSecureSession();

    
    if (
        isset($_SESSION['ibnvs_auth'], $_SESSION['ibnvs_ts']) &&
        (time() - $_SESSION['ibnvs_ts']) < SESSION_TTL
    ) {
        
        $_SESSION['ibnvs_ts'] = time();
        return;
    }

    
    err(401, 'Neprisijungta. Eik į login.php');
}

function attemptLogin($password) {
    $hash = ADMIN_PASSWORD_HASH;
    if (!$hash || $hash === '') {
        
        return ['ok' => false, 'setup' => true, 'hash' => password_hash($password, PASSWORD_DEFAULT)];
    }
    if (password_verify($password, $hash)) {
        startSecureSession();
        session_regenerate_id(true);
        $_SESSION['ibnvs_auth'] = true;
        $_SESSION['ibnvs_ts']   = time();
        return ['ok' => true];
    }
    
    sleep(1);
    return ['ok' => false, 'setup' => false];
}

function logout() {
    startSecureSession();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function rateLimit($max = 120, $win = 60) {
    $f = sys_get_temp_dir() . '/ibnvs_rl_' . md5($_SERVER['REMOTE_ADDR'] ?? 'x') . '.json';
    $now = time();
    $d = ['h' => [], 'b' => 0];
    if (file_exists($f)) {
        $parsed = json_decode(file_get_contents($f), true);
        if (is_array($parsed)) {
            $d['h'] = is_array($parsed['h'] ?? null) ? $parsed['h'] : [];
            $d['b'] = intval($parsed['b'] ?? 0);
        }
    }
    if ($d['b'] > $now) err(429, 'Per daug užklausų. Bandyk po 5 min.');
    $d['h'] = array_values(array_filter($d['h'], fn($t) => $t > $now - $win));
    if (count($d['h']) >= $max) {
        $d['b'] = $now + 300;
        file_put_contents($f, json_encode($d), LOCK_EX);
        err(429, 'Per daug užklausų. 5 min.');
    }
    $d['h'][] = $now;
    file_put_contents($f, json_encode($d), LOCK_EX);
}
