<?php

function metaPath($file)        { return DATA_DIR . "meta/{$file}.json"; }
function objDir($oid)           { return DATA_DIR . "objects/{$oid}/"; }
function objPath($oid, $file)   { return DATA_DIR . "objects/{$oid}/{$file}.json"; }
function failurePath($oid, $fid){ return DATA_DIR . "objects/{$oid}/failures/{$fid}.json"; }
function failureIdx($oid)       { return DATA_DIR . "objects/{$oid}/failures/_index.json"; }
function treePath($oid, $fid)   { return DATA_DIR . "objects/{$oid}/trees/{$fid}_tree.json"; }
function casePath($year, $cid)  { return DATA_DIR . "cases/{$year}/{$cid}.json"; }
function caseIdx()              { return DATA_DIR . "cases/_index.json"; }
function tlPath($year)          { return DATA_DIR . "timeline/{$year}.json"; }
function pctPath($oid)          { return DATA_DIR . "percentages/{$oid}.json"; }
