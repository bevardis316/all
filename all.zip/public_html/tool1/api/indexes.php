<?php

function updateObjectsIndex($oid, $data) {
    $idx = readJson(metaPath('objects_index')) ?? [];
    $idx[$oid] = [
        'name'    => $data['name'] ?? $oid,
        'sek'     => $data['sek'] ?? [],
        'z'       => $data['z'] ?? '',
        'custom'  => $data['custom'] ?? false,
        'updated' => date('c'),
    ];
    writeJson(metaPath('objects_index'), $idx);
}

function updateFailureIndex($oid, $fid, $fm) {
    $idx = readJson(failureIdx($oid)) ?? [];
    $found = false;
    foreach ($idx as &$f) {
        if (($f['id'] ?? '') === $fid) {
            $f = ['id' => $fid, 'name' => $fm['name'] ?? '', 'severity' => $fm['severity'] ?? 'med', 'frequency' => $fm['frequency'] ?? 0, 'updated' => date('c')];
            $found = true;
            break;
        }
    }
    if (!$found) $idx[] = ['id' => $fid, 'name' => $fm['name'] ?? '', 'severity' => $fm['severity'] ?? 'med', 'frequency' => $fm['frequency'] ?? 0, 'created' => date('c')];
    writeJson(failureIdx($oid), $idx);
}

function updateCaseIndex($cid, $data, $year) {
    $idx = readJson(caseIdx()) ?? [];
    $idx[$cid] = [
        'id'          => $cid,
        'date'        => $data['date'] ?? '',
        'object_id'   => $data['object_id'] ?? '',
        'failure_ref' => $data['failure_ref'] ?? '',
        'year'        => $year,
    ];
    writeJson(caseIdx(), $idx);
}

function rebuildCaseIndex($cases) {
    $idx = [];
    foreach ($cases as $c) {
        $cid = safeId($c['id'] ?? '');
        if (!$cid) continue;
        $year = safeYear(substr($c['date'] ?? date('Y-m-d'), 0, 4)) ?: date('Y');
        $idx[$cid] = ['id' => $cid, 'date' => $c['date'] ?? '', 'object_id' => $c['object_id'] ?? '', 'failure_ref' => $c['failure_ref'] ?? '', 'year' => $year];
    }
    writeJson(caseIdx(), $idx);
}
