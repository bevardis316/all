<?php

function err($code, $msg) {
    if (ob_get_level()) ob_clean();
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

function ok($data = []) {
    if (ob_get_level()) ob_clean();
    echo json_encode(array_merge(['ok' => true], $data), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

function safeId($s) {
    return preg_replace('/[^a-zA-Z0-9_\-]/', '', $s);
}

function safeYear($s) {
    return preg_match('/^\d{4}$/', $s) ? $s : '';
}

function ensureDir($path) {
    if (!is_dir($path)) mkdir($path, 0755, true);
    $ha = $path . '/.htaccess';
    if (!file_exists($ha)) file_put_contents($ha, "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
}

function readJson($path) {
    if (!file_exists($path)) return null;
    return json_decode(file_get_contents($path), true);
}

function writeJson($path, $data) {
    ensureDir(dirname($path));
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    return file_put_contents($path, $json, LOCK_EX) !== false;
}

function backupFile($path) {
    if (file_exists($path)) {
        $bak = DATA_DIR . '_backups/' . basename(dirname($path)) . '_' . basename($path, '.json') . '_' . date('Ymd_His') . '.json';
        ensureDir(dirname($bak));
        copy($path, $bak);
    }
}

function getBody() {
    @ini_set('memory_limit', '128M');
    @ini_set('post_max_size', '32M');
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') err(400, 'Tuščias body');
    if (strlen($raw) > MAX_MB * 1024 * 1024) err(413, 'Per didelis: ' . strlen($raw) . ' bytes');
    $d = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) err(400, 'JSON klaida: ' . json_last_error_msg());
    if (!is_array($d)) err(400, 'Blogas JSON tipas');
    return $d;
}

function deleteDirRecursive($dir) {
    if (!is_dir($dir)) return;
    foreach (scandir($dir) as $item) {
        if ($item === '.' || $item === '..') continue;
        $path = $dir . '/' . $item;
        is_dir($path) ? deleteDirRecursive($path) : @unlink($path);
    }
    @rmdir($dir);
}
