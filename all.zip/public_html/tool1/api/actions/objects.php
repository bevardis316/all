<?php

if ($action === 'save_object_base') {
    $body = getBody(); $oid = safeId($body['id'] ?? '');
    if (!$oid) err(400, 'Trūksta objekto ID');
    ensureDir(objDir($oid));
    $parts = ['base', 'env', 'relations', 'exploitation_errors'];
    $saved = [];
    foreach ($parts as $part) {
        if (isset($body[$part])) { writeJson(objPath($oid, $part), $body[$part]); $saved[] = $part; }
    }
    updateObjectsIndex($oid, $body);
    ok(['id' => $oid, 'saved' => $saved, 'path' => "objects/{$oid}/"]);

} elseif ($action === 'load_cases') {
    $year = safeYear($_GET['year'] ?? date('Y'));
    if (!$year) err(400, 'Neteisingi metai');
    $dir = DATA_DIR . "cases/{$year}/";
    $cases = [];
    if (is_dir($dir)) {
        foreach (scandir($dir) as $cf) {
            if (!str_ends_with($cf, '.json')) continue;
            $cd = readJson($dir . $cf);
            if ($cd) $cases[] = $cd;
        }
    }
    usort($cases, fn($a, $b) => strcmp($b['date'] ?? '', $a['date'] ?? ''));
    ok(['cases' => $cases, 'year' => $year, 'count' => count($cases)]);

} elseif ($action === 'add_object') {
    $body = getBody();
    $oid = safeId(strtoupper($body['id'] ?? ''));
    if (!$oid) err(400, 'Trūksta ID');
    ensureDir(objDir($oid));
    ensureDir(DATA_DIR . "objects/{$oid}/failures/");
    ensureDir(DATA_DIR . "objects/{$oid}/trees/");
    $base = ['id' => $oid, 'name' => $body['name'] ?? $oid, 'sek' => $body['sek'] ?? [], 'z' => $body['z'] ?? '@ipgil', 'custom' => true, 'function' => '', 'normal_operation' => '', 'normal_signs' => [], 'tags' => [], 'meta' => ['created' => date('c'), 'confidence' => 0], 'updated' => date('c')];
    writeJson(objPath($oid, 'base'), $base);
    writeJson(failureIdx($oid), []);
    updateObjectsIndex($oid, $base);
    ok(['id' => $oid, 'created' => true]);

} elseif ($action === 'delete_object') {
    $body = getBody();
    $oid = safeId($body['id'] ?? '');
    if (!$oid) err(400, 'Trūksta ID');
    $base = readJson(objPath($oid, 'base'));
    if ($base && !($base['custom'] ?? false)) err(403, 'Negalima ištrinti numatytojo objekto');
    $dir = objDir($oid);
    if (is_dir($dir)) deleteDirRecursive($dir);
    $idx = readJson(metaPath('objects_index')) ?? [];
    unset($idx[$oid]);
    writeJson(metaPath('objects_index'), $idx);
    ok(['deleted' => $oid]);
}
