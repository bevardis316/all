<?php
global $DEF_OBJECTS;
$dirs = [
    DATA_DIR, DATA_DIR . 'meta/', DATA_DIR . 'cases/',
    DATA_DIR . 'timeline/', DATA_DIR . 'percentages/', DATA_DIR . '_backups/',
];
foreach ($DEF_OBJECTS as $oid) {
    $dirs[] = DATA_DIR . "objects/{$oid}/";
    $dirs[] = DATA_DIR . "objects/{$oid}/failures/";
    $dirs[] = DATA_DIR . "objects/{$oid}/trees/";
}
$created = []; $failed = [];
foreach ($dirs as $d) {
    ensureDir($d);
    is_dir($d) ? $created[] = $d : $failed[] = $d;
}
ok(['created' => count($created), 'failed' => $failed, 'data_dir' => DATA_DIR, 'writable' => is_writable(DATA_DIR)]);
