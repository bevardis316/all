<?php
$objects = [];
if (is_dir(DATA_DIR . 'objects/')) {
    foreach (scandir(DATA_DIR . 'objects/') as $d) {
        if ($d === '.' || $d === '..' || $d[0] === '.') continue;
        $fi = readJson(failureIdx($d));
        $fc = is_array($fi) ? count($fi) : 0;
        $objects[$d] = ['failures' => $fc, 'has_tree' => is_dir(DATA_DIR . "objects/{$d}/trees/")];
    }
}
ok([
    'version'      => API_VER,
    'objects'      => count($objects),
    'object_list'  => $objects,
    'meta_exists'  => file_exists(metaPath('objects_index')),
    'cases_index'  => file_exists(caseIdx()),
    'ts'           => time(),
    'php'          => PHP_VERSION,
]);
