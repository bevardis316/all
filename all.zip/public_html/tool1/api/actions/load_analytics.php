<?php

define('ANALYTICS_DIR_M', DATA_DIR . 'analytics/');

$result = [
    'pageviews' => [],
    'diag_log'  => [],
    'save_log'  => [],
    'views'     => [],
];

if (is_dir(ANALYTICS_DIR_M)) {
    $months = [date('Y-m'), date('Y-m', strtotime('-1 month'))];
    foreach ($months as $m) {
        $file = ANALYTICS_DIR_M . $m . '.json';
        if (file_exists($file)) {
            $data = json_decode(file_get_contents($file), true);
            if (is_array($data)) {
                $result['pageviews'] = array_merge($result['pageviews'], $data);
            }
        }
    }
    
    if (count($result['pageviews']) > 2000) {
        $result['pageviews'] = array_slice($result['pageviews'], -2000);
    }

    
    $diagFile = ANALYTICS_DIR_M . 'diag_log.json';
    if (file_exists($diagFile)) {
        $diagData = json_decode(file_get_contents($diagFile), true);
        if (is_array($diagData)) {
            $result['diag_log'] = array_slice($diagData, -1000);
        }
    }
}

$saveLogFile = DATA_DIR . 'save_log.json';
if (file_exists($saveLogFile)) {
    $saveLog = json_decode(file_get_contents($saveLogFile), true);
    if (is_array($saveLog)) {
        $result['save_log'] = array_slice($saveLog, -500);
    }
}

ok(['data' => $result]);
