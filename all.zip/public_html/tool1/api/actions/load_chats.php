<?php
/**
 * tool1/api/actions/load_chats.php
 * Grąžina pokalbių sąrašą iš ibnvs_data/chats/_log.json.
 * Kiekvienas įrašas: {id, ts, intent, user, ai, approved}
 */

define('CHATS_LOG',      DATA_DIR . 'chats/_log.json');
define('CHATS_APPROVED', DATA_DIR . 'chats/qa_approved.json');

// Skaitome $result — api.php siunčia jį kaip atsakymą
$entries = [];

if (file_exists(CHATS_LOG)) {
    $lines = file(CHATS_LOG, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $e = json_decode($line, true);
        if ($e && isset($e['id'])) {
            $entries[] = $e;
        }
    }
}

// Naujausias viršuje
$entries = array_reverse($entries);

// Apribojame iki 500 (rodymui) — seni lieka faile
if (count($entries) > 500) {
    $entries = array_slice($entries, 0, 500);
}

ok(['entries' => $entries, 'total' => count($entries)]);
