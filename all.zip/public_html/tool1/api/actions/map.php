<?php
define('MAP_DATA_DIR_T1', dirname(__DIR__, 4) . '/ibnvs_data/map/');

function t1Geocode(string $city): array {
    $url = 'https://nominatim.openstreetmap.org/search?q=' . urlencode($city . ', Lietuva') .
           '&format=json&limit=1&countrycodes=lt';
    $ctx = stream_context_create(['http'=>['timeout'=>5,'header'=>'User-Agent: manonuotekos.lt/1.0']]);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw) {
        $d = json_decode($raw, true);
        if (!empty($d[0]['lat'])) return [(float)$d[0]['lat'], (float)$d[0]['lon']];
    }
    return [0, 0];
}

function t1MapEnsureDir(): void {
    $dir = MAP_DATA_DIR_T1;
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $ha = $dir . '.htaccess';
    if (!file_exists($ha)) file_put_contents($ha, "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
}

function t1MapLoadPending(): array {
    t1MapEnsureDir();
    $f = MAP_DATA_DIR_T1 . 'pending.json';
    if (!file_exists($f)) return [];
    return json_decode(file_get_contents($f), true) ?: [];
}

function t1MapSavePending(array $data): void {
    t1MapEnsureDir();
    file_put_contents(MAP_DATA_DIR_T1 . 'pending.json', json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
}

function t1MapLoadApproved(): array {
    t1MapEnsureDir();
    $f = MAP_DATA_DIR_T1 . 'entries.json';
    if (!file_exists($f)) return [];
    return json_decode(file_get_contents($f), true) ?: [];
}

function t1MapSaveApproved(array $data): void {
    t1MapEnsureDir();
    file_put_contents(MAP_DATA_DIR_T1 . 'entries.json', json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
}

switch ($action) {

    case 'map_pending':
        $pending = t1MapLoadPending();
        ok(['pending' => array_values($pending)]);
        break;

    case 'map_list':
        $approved = t1MapLoadApproved();
        ok(['entries' => array_values($approved)]);
        break;

    case 'map_approve':
        $d = getBody();
        $id   = $d['id']        ?? '';
        $days = max(1, (int)($d['days'] ?? 365));
        $eur  = (float)($d['value_eur'] ?? 0);
        $lat  = (float)($d['lat'] ?? 0);
        $lng  = (float)($d['lng'] ?? 0);

        if (!$id) err(400, 'Trūksta id');

        $pending = t1MapLoadPending();
        $found = null;
        $newPending = [];
        foreach ($pending as $e) {
            if ($e['id'] === $id) { $found = $e; }
            else { $newPending[] = $e; }
        }
        if (!$found) err(404, 'Paraiška nerasta');

        // Jei naršyklė neatsiuntė koordinačių – bandome iš pending
        if (!$lat || !$lng) {
            $lat = (float)($found['lat'] ?? 0);
            $lng = (float)($found['lng'] ?? 0);
        }

        $found['approved']    = true;
        $found['lat']         = $lat;
        $found['lng']         = $lng;
        $found['expires_at']  = time() + $days * 86400;
        $found['value_eur']   = $eur;
        $found['approved_at'] = date('c');

        $approved = t1MapLoadApproved();
        $approved[] = $found;
        t1MapSaveApproved($approved);
        t1MapSavePending($newPending);

        ok(['id' => $id, 'lat' => $lat, 'lng' => $lng]);
        break;

    case 'map_reject':
        $d = getBody();
        $id = $d['id'] ?? '';
        if (!$id) err(400, 'Trūksta id');
        $pending = t1MapLoadPending();
        $newPending = array_values(array_filter($pending, fn($e) => $e['id'] !== $id));
        t1MapSavePending($newPending);
        ok(['id' => $id]);
        break;

    case 'map_update':
        $d = getBody();
        $id = $d['id'] ?? '';
        if (!$id) err(400, 'Trūksta id');
        $approved = t1MapLoadApproved();
        $found = false;
        foreach ($approved as &$e) {
            if ($e['id'] === $id) {
                if (isset($d['lat']))        $e['lat']        = (float)$d['lat'];
                if (isset($d['lng']))        $e['lng']        = (float)$d['lng'];
                if (isset($d['days']))       $e['expires_at'] = time() + max(1,(int)$d['days']) * 86400;
                if (isset($d['value_eur']))  $e['value_eur']  = (float)$d['value_eur'];
                if (isset($d['type']))       $e['type']       = strip_tags($d['type']);
                if (isset($d['info']))       $e['info']       = mb_substr(strip_tags($d['info']), 0, 300);
                $e['updated_at'] = date('c');
                $found = true;
                break;
            }
        }
        unset($e);
        if (!$found) err(404, 'Įrašas nerastas');
        t1MapSaveApproved($approved);
        ok(['id' => $id]);
        break;

    case 'map_delete':
        $d = getBody();
        $id = $d['id'] ?? '';
        if (!$id) err(400, 'Trūksta id');
        $approved = t1MapLoadApproved();
        $newApproved = array_values(array_filter($approved, fn($e) => $e['id'] !== $id));
        if (count($newApproved) === count($approved)) err(404, 'Įrašas nerastas');
        t1MapSaveApproved($newApproved);
        ok(['id' => $id]);
        break;

    case 'map_add_direct':
        $d = getBody();
        $name = mb_substr(strip_tags($d['name'] ?? ''), 0, 80);
        $tel  = preg_replace('/[^+\d\s\-()\.]/', '', $d['tel'] ?? '');
        $city = mb_substr(strip_tags($d['city'] ?? ''), 0, 60);
        $type  = mb_substr(strip_tags($d['type'] ?? ''), 0, 30);
        $rawTypes = $d['types'] ?? [];
        $types = is_array($rawTypes) ? array_values(array_filter(array_map(fn($t)=>mb_substr(strip_tags($t),0,30), $rawTypes))) : ($type ? [$type] : []);
        $info = mb_substr(strip_tags($d['info'] ?? ''), 0, 300);
        $lat  = (float)($d['lat'] ?? 0);
        $lng  = (float)($d['lng'] ?? 0);
        $days = max(1, (int)($d['days'] ?? 365));

        if (!$name || !$tel || !$city) err(400, 'Trūksta privalomų laukų');
        if (!$lat || !$lng) err(400, 'Trūksta koordinačių');

        $entry = [
            'id'          => uniqid('m_', true),
            'name'        => $name,
            'tel'         => $tel,
            'city'        => $city,
            'type'        => $types[0] ?? '',
            'types'       => $types,
            'info'        => $info,
            'lat'         => $lat,
            'lng'         => $lng,
            'approved'    => true,
            'created_at'  => date('c'),
            'approved_at' => date('c'),
            'expires_at'  => time() + $days * 86400,
            'value_eur'   => 0,
            'ip'          => 'admin',
        ];

        $approved = t1MapLoadApproved();
        $approved[] = $entry;
        t1MapSaveApproved($approved);
        ok(['id' => $entry['id']]);
        break;
}
