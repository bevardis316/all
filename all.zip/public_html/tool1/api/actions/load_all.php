<?php
$result = ['meta'=>[],'objects'=>[],'failures'=>[],'trees'=>[],'cases_index'=>null,'timeline_index'=>[],'percentages'=>[],'components'=>[]];

foreach (['objects_index','tag_categories','tag_relations','system_config'] as $m) {
    $d = readJson(metaPath($m));
    if ($d !== null) $result['meta'][$m] = $d;
}

if (is_dir(DATA_DIR.'objects/')) {
    foreach (scandir(DATA_DIR.'objects/') as $oid) {
        if ($oid==='.'||$oid==='..'||$oid[0]==='.') continue;
        $obj=[];
        foreach (['base','env','relations','exploitation_errors'] as $part) {
            $d=readJson(objPath($oid,$part));
            if ($d!==null) $obj[$part]=$d;
        }
        if (!empty($obj)) $result['objects'][$oid]=$obj;
        $fi=readJson(failureIdx($oid));
        if ($fi) $result['failures'][$oid]['_index']=$fi;
        $fdir=DATA_DIR."objects/{$oid}/failures/";
        if (is_dir($fdir)) {
            foreach (scandir($fdir) as $ff) {
                if ($ff==='_index.json'||!str_ends_with($ff,'.json')) continue;
                $fid=basename($ff,'.json');
                $fd=readJson($fdir.$ff);
                if ($fd) $result['failures'][$oid][$fid]=$fd;
            }
        }
        $tdir=DATA_DIR."objects/{$oid}/trees/";
        if (is_dir($tdir)) {
            foreach (scandir($tdir) as $tf) {
                if (!str_ends_with($tf,'_tree.json')) continue;
                $tid=basename($tf,'_tree.json');
                $td=readJson($tdir.$tf);
                if ($td) $result['trees'][$oid][$tid]=$td;
            }
        }
    }
}

$ci=readJson(caseIdx());
if ($ci) $result['cases_index']=$ci;

for ($y=intval(date('Y'));$y>=intval(date('Y'))-1;$y--) {
    $tl=readJson(tlPath($y));
    if ($tl) $result['timeline_index'][$y]=$tl;
}

if (is_dir(DATA_DIR.'percentages/')) {
    foreach (scandir(DATA_DIR.'percentages/') as $pf) {
        if (!str_ends_with($pf,'.json')) continue;
        $oid=basename($pf,'.json');
        $pd=readJson(DATA_DIR."percentages/{$pf}");
        if ($pd) $result['percentages'][$oid]=$pd;
    }
}

$compBase=DATA_DIR.'components';
if (is_dir($compBase)) {
    foreach (glob($compBase.'/*',GLOB_ONLYDIR)?:[] as $parentDir) {
        $parentId=basename($parentDir);
        foreach (glob($parentDir.'/*.json')?:[] as $compFile) {
            $comp=json_decode(file_get_contents($compFile),true);
            if (!$comp) continue;
            $cid=$comp['id']??basename($compFile,'.json');
            if (!isset($result['components'][$parentId])) $result['components'][$parentId]=[];
            $result['components'][$parentId][$cid]=$comp;
        }
    }
}

ok(['data'=>$result,'ts'=>time()]);
