<?php

$ordersDir = DATA_DIR . 'orders/';
$orders = [];

if (is_dir($ordersDir)) {
    $files = glob($ordersDir . 'UZS-*.json');
    if ($files) {
        foreach ($files as $file) {
            $d = readJson($file);
            if ($d && isset($d['id'])) {
                $orders[] = $d;
            }
        }
        
        usort($orders, fn($a, $b) => strcmp($b['ts'] ?? '', $a['ts'] ?? ''));
    }
}

ok(['orders' => $orders, 'count' => count($orders)]);
