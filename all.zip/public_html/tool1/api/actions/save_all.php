<?php
if (strlen(file_get_contents('php://input')) > MAX_MB * 1024 * 1024) err(413, 'Per didelis');
$kb = getBody();
$saved = [];

ensureDir(DATA_DIR . 'meta/');
if (isset($kb['tag_categories'])) { writeJson(metaPath('tag_categories'), $kb['tag_categories']); $saved[] = 'meta/tag_categories'; }
if (isset($kb['tag_relations']))  { writeJson(metaPath('tag_relations'),  $kb['tag_relations']);  $saved[] = 'meta/tag_relations'; }

if (isset($kb['objects_meta'])) {
    $idx = [];
    foreach ($kb['objects_meta'] as $oid => $meta) {
        $oid = safeId($oid); if (!$oid) continue;
        ensureDir(objDir($oid));
        $kb_obj = $kb['objects'][$oid] ?? [];
        $base = [
            'id' => $oid, 'name' => $meta['name'] ?? $oid, 'sek' => $meta['sek'] ?? [], 'z' => $meta['z'] ?? '', 'custom' => $meta['custom'] ?? false,
            'function' => $kb_obj['function'] ?? '', 'normal_operation' => $kb_obj['normal_operation'] ?? '',
            'normal_signs' => $kb_obj['normal_signs'] ?? [], 'tags' => $kb_obj['tags'] ?? [],
            'models' => $kb_obj['models'] ?? [],
            'packages' => $kb_obj['packages'] ?? [],
            'maintenance_schedule' => $kb_obj['maintenance_schedule'] ?? [],
            'meta' => $kb_obj['meta'] ?? [], 'updated' => date('c'),
        ];
        writeJson(objPath($oid, 'base'), $base);
        if (isset($kb_obj['env_behavior']))        writeJson(objPath($oid, 'env'),                 $kb_obj['env_behavior']);
        if (isset($kb_obj['relations']))           writeJson(objPath($oid, 'relations'),           $kb_obj['relations']);
        if (isset($kb_obj['exploitation_errors'])) writeJson(objPath($oid, 'exploitation_errors'), $kb_obj['exploitation_errors']);

        
        ensureDir(DATA_DIR . "objects/{$oid}/failures/");
        $fidx = [];
        foreach ($kb_obj['failure_modes'] ?? [] as $fid => $fm) {
            $fid = safeId($fid); if (!$fid) continue;
            $fm['id'] = $fid; $fm['object_id'] = $oid;
            writeJson(failurePath($oid, $fid), $fm);
            $fidx[] = ['id' => $fid, 'name' => $fm['name'] ?? '', 'severity' => $fm['severity'] ?? 'med', 'frequency' => $fm['frequency'] ?? 0];
        }
        writeJson(failureIdx($oid), $fidx);

        
        ensureDir(DATA_DIR . "objects/{$oid}/trees/");
        foreach ($kb['decision_trees'] ?? [] as $fid => $tree) {
            if (($tree['object_id'] ?? '') === $oid || strpos($fid, $oid) === 0) {
                writeJson(treePath($oid, safeId($fid)), $tree);
            }
        }

        $idx[$oid] = ['name' => $meta['name'] ?? $oid, 'sek' => $meta['sek'] ?? [], 'z' => $meta['z'] ?? '', 'custom' => $meta['custom'] ?? false, 'failure_count' => count($kb_obj['failure_modes'] ?? [])];
        $saved[] = "objects/{$oid}";
    }
    writeJson(metaPath('objects_index'), $idx);
    $saved[] = 'meta/objects_index';
}

foreach ($kb['field_cases'] ?? [] as $case) {
    $cid = safeId($case['id'] ?? ''); if (!$cid) continue;
    $year = safeYear(substr($case['date'] ?? date('Y-m-d'), 0, 4)) ?: date('Y');
    ensureDir(DATA_DIR . "cases/{$year}/");
    writeJson(casePath($year, $cid), $case);
}
rebuildCaseIndex($kb['field_cases'] ?? []);
$saved[] = 'cases';

$byYear = [];
foreach ($kb['timeline_events'] ?? [] as $ev) {
    $y = safeYear(substr($ev['date'] ?? date('Y-m-d'), 0, 4)) ?: date('Y');
    $byYear[$y][] = $ev;
}
foreach ($byYear as $y => $evs) { writeJson(tlPath($y), $evs); $saved[] = "timeline/{$y}"; }

ensureDir(DATA_DIR . 'percentages/');
foreach ($kb['percentages'] ?? [] as $oid => $pdata) {
    $oid = safeId($oid); if (!$oid) continue;
    writeJson(pctPath($oid), ['object_id' => $oid, 'failures' => $pdata, 'updated' => date('c')]);
    $saved[] = "percentages/{$oid}";
}

$compIdx = [];
foreach ($kb['components'] ?? [] as $cid => $comp) {
    $cid       = safeId($cid); if (!$cid) continue;
    $parent_id = safeId($comp['parent_id'] ?? '');
    if (!$parent_id) continue;
    $dir = DATA_DIR . "components/{$parent_id}/";
    ensureDir($dir);
    $comp['id']        = $cid;
    $comp['parent_id'] = $parent_id;
    $comp['updated']   = date('c');
    writeJson($dir . $cid . '.json', $comp);
    $saved[] = "components/{$parent_id}/{$cid}";
    
    if (!isset($compIdx[$parent_id])) $compIdx[$parent_id] = [];
    $compIdx[$parent_id][$cid] = [
        'id'      => $cid,
        'name'    => $comp['name']    ?? $cid,
        'y_level' => $comp['y_level'] ?? 1,
        'updated' => $comp['updated'],
    ];
}

if (!empty($compIdx)) {
    $idx = readJson(metaPath('objects_index')) ?? [];
    $idx['components'] = $compIdx;
    writeJson(metaPath('objects_index'), $idx);
}

writeJson(metaPath('system_config'), ['version' => API_VER, 'last_save' => date('c'), 'objects' => count($kb['objects_meta'] ?? []), 'schema' => '6.0']);

ok(['saved' => $saved, 'count' => count($saved), 'ts' => time()]);
