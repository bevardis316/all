<?php

if ($action === 'save_case') {
    $body = getBody();
    $cid = safeId($body['id'] ?? ('CASE-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT)));
    $year = safeYear(substr($body['date'] ?? date('Y-m-d'), 0, 4)) ?: date('Y');
    ensureDir(DATA_DIR . "cases/{$year}/");
    $body['id'] = $cid; $body['year'] = $year;
    $body['_meta'] = ['saved' => date('c')];
    writeJson(casePath($year, $cid), $body);
    updateCaseIndex($cid, $body, $year);
    ok(['id' => $cid, 'year' => $year, 'path' => "cases/{$year}/{$cid}.json"]);

} elseif ($action === 'save_timeline') {
    $body = getBody();
    $year = safeYear(substr($body['date'] ?? date('Y-m-d'), 0, 4)) ?: date('Y');
    $eid = safeId($body['id'] ?? ('TL-' . time()));
    $body['id'] = $eid;
    $tl = readJson(tlPath($year)) ?? [];
    $found = false;
    foreach ($tl as &$e) { if (($e['id'] ?? '') === $eid) { $e = $body; $found = true; break; } }
    if (!$found) $tl[] = $body;
    usort($tl, fn($a, $b) => strcmp($a['date'] ?? '', $b['date'] ?? ''));
    writeJson(tlPath($year), $tl);
    ok(['id' => $eid, 'year' => $year]);

} elseif ($action === 'save_percentages') {
    $body = getBody();
    $oid = safeId($body['object_id'] ?? '');
    if (!$oid) err(400, 'Trūksta object_id');
    ensureDir(DATA_DIR . 'percentages/');
    writeJson(pctPath($oid), ['object_id' => $oid, 'failures' => $body['failures'] ?? [], 'updated' => date('c')]);
    ok(['object_id' => $oid, 'path' => "percentages/{$oid}.json"]);

} elseif ($action === 'save_meta') {
    $body = getBody();
    $file = preg_replace('/[^a-z_]/', '', $body['file'] ?? '');
    $allowed = ['tag_categories', 'tag_relations', 'system_config', 'fix_patterns'];
    if (!in_array($file, $allowed)) err(400, 'Neleistinas meta failas');
    ensureDir(DATA_DIR . 'meta/');
    writeJson(metaPath($file), $body['data'] ?? []);
    ok(['file' => $file . '.json']);
}
