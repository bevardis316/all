<?php

$body  = getBody();
$tipas = safeId($body['tipas'] ?? '');
$s3d   = $body['scene_3d'] ?? [];

if (!$tipas) err(400, 'Trūksta tipas');
if (!is_array($s3d)) err(400, 'Neteisingas scene_3d');

// Sanitize
$clean = [
    'glb'        => preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $s3d['glb'] ?? ''),
    'scale'      => (float) ($s3d['scale']      ?? 1.0),
    'rotation_y' => (float) ($s3d['rotation_y'] ?? 0),
    'offset_y'   => (float) ($s3d['offset_y']   ?? 0),
    'socket_in'  => [
        'x' => (float) ($s3d['socket_in']['x']  ?? 0),
        'y' => (float) ($s3d['socket_in']['y']  ?? 0),
        'z' => (float) ($s3d['socket_in']['z']  ?? 0),
    ],
    'socket_out' => [
        'x' => (float) ($s3d['socket_out']['x'] ?? 0),
        'y' => (float) ($s3d['socket_out']['y'] ?? 0),
        'z' => (float) ($s3d['socket_out']['z'] ?? 0),
    ],
];

$path = DATA_DIR . "objects/{$tipas}/base.json";
if (!file_exists($path)) err(404, 'Objektas nerastas');

$base = json_decode(file_get_contents($path), true);
if (!is_array($base)) err(500, 'Sugadintas base.json');

backupFile($path);
$base['scene_3d'] = $clean;
writeJson($path, $base);

ok(['saved' => true]);
