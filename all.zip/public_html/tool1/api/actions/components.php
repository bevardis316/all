<?php

$data = getBody();

function logSave(string $file, string $action, bool $ok, string $note = '') {
    $logFile = DATA_DIR . 'save_log.json';
    $log = [];
    if (is_file($logFile)) {
        $log = json_decode(file_get_contents($logFile), true) ?: [];
    }
    array_unshift($log, [
        'ts'     => date('c'),
        'action' => $action,
        'file'   => $file,
        'ok'     => $ok,
        'note'   => $note,
    ]);
    $log = array_slice($log, 0, 200); 
    file_put_contents($logFile, json_encode($log, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

if ($action === 'save_component') {
    $cid       = safeId($data['id']        ?? '');
    $parent_id = safeId($data['parent_id'] ?? '');

    if (!$cid)       { logSave('', 'save_component', false, 'Trūksta id');        err(400, 'Trūksta id'); }
    if (!$parent_id) { logSave('', 'save_component', false, 'Trūksta parent_id'); err(400, 'Trūksta parent_id'); }

    $dir = DATA_DIR . 'components/' . $parent_id . '/';
    $rel = 'components/' . $parent_id . '/' . $cid . '.json';

    ensureDir($dir);

    $data['id']        = $cid;
    $data['parent_id'] = $parent_id;
    $data['updated']   = date('c');

    if (!writeJson($dir . $cid . '.json', $data)) {
        logSave($rel, 'save_component', false, 'writeJson nepavyko');
        err(500, 'Nepavyko išsaugoti komponento');
    }

    
    $idx = readJson(metaPath('objects_index')) ?? [];
    if (!isset($idx['components']))             $idx['components'] = [];
    if (!isset($idx['components'][$parent_id])) $idx['components'][$parent_id] = [];
    $idx['components'][$parent_id][$cid] = [
        'id'      => $cid,
        'name'    => $data['name']    ?? $cid,
        'y_level' => $data['y_level'] ?? 1,
        'updated' => $data['updated'],
    ];
    writeJson(metaPath('objects_index'), $idx);

    logSave($rel, 'save_component', true, ($data['name'] ?? $cid) . ' → ' . $parent_id);
    ok(['saved' => $cid, 'parent_id' => $parent_id, 'file' => $rel]);
}

if ($action === 'delete_component') {
    $cid       = safeId($data['id']        ?? '');
    $parent_id = safeId($data['parent_id'] ?? '');

    if (!$cid) { logSave('', 'delete_component', false, 'Trūksta id'); err(400, 'Trūksta id'); }

    
    if (!$parent_id) {
        foreach (glob(DATA_DIR . 'components/*', GLOB_ONLYDIR) ?: [] as $d) {
            if (is_file($d . '/' . $cid . '.json')) { $parent_id = basename($d); break; }
        }
    }

    $filePath = DATA_DIR . 'components/' . $parent_id . '/' . $cid . '.json';
    $rel      = 'components/' . $parent_id . '/' . $cid . '.json';

    if (is_file($filePath)) {
        backupFile($filePath);
        unlink($filePath);
        logSave($rel, 'delete_component', true);
    } else {
        logSave($rel, 'delete_component', false, 'Failas nerastas');
    }

    
    $idx = readJson(metaPath('objects_index')) ?? [];
    if (isset($idx['components'][$parent_id][$cid])) {
        unset($idx['components'][$parent_id][$cid]);
        if (empty($idx['components'][$parent_id])) unset($idx['components'][$parent_id]);
        writeJson(metaPath('objects_index'), $idx);
    }

    ok(['deleted' => $cid]);
}
