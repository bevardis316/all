<?php

if ($action === 'save_failure') {
    $body = getBody();
    $oid = safeId($body['object_id'] ?? '');
    $fid = safeId($body['id'] ?? '');
    if (!$oid || !$fid) err(400, 'Trūksta object_id arba id');
    ensureDir(DATA_DIR . "objects/{$oid}/failures/");
    $body['_meta'] = ['saved' => date('c'), 'version' => ($body['_meta']['version'] ?? 0) + 1];
    writeJson(failurePath($oid, $fid), $body);
    updateFailureIndex($oid, $fid, $body);
    ok(['object_id' => $oid, 'failure_id' => $fid, 'path' => "objects/{$oid}/failures/{$fid}.json"]);

} elseif ($action === 'delete_failure') {
    $body = getBody();
    $oid = safeId($body['object_id'] ?? '');
    $fid = safeId($body['id'] ?? '');
    if (!$oid || !$fid) err(400, 'Trūksta laukų');
    $path = failurePath($oid, $fid);
    if (file_exists($path)) { backupFile($path); unlink($path); }
    $idx = readJson(failureIdx($oid)) ?? [];
    $idx = array_values(array_filter($idx, fn($f) => ($f['id'] ?? '') !== $fid));
    writeJson(failureIdx($oid), $idx);
    $tp = treePath($oid, $fid);
    if (file_exists($tp)) unlink($tp);
    ok(['deleted' => $fid]);
}
