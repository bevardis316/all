<?php
/**
 * tool1/api/actions/save_chat_edit.php
 * Išsaugo admin pataisytą Q&A porą į qa_approved.json.
 * Pataisymai automatiškai naudojami kaip few-shot pavyzdžiai AI pokalbyje.
 *
 * POST: { id, user, assistant }
 */

define('CHATS_LOG',      DATA_DIR . 'chats/_log.json');
define('CHATS_APPROVED', DATA_DIR . 'chats/qa_approved.json');

$input     = getBody();
$id        = trim($input['id']        ?? '');
$userMsg   = trim($input['user']      ?? '');
$aiMsg     = trim($input['assistant'] ?? '');

if (!$id || !$userMsg || !$aiMsg) {
    $result = ['ok' => false, 'error' => 'Trūksta laukų'];
    return;
}

// Nuskaitome esamus approved
$approved = ['_comment' => 'Admin pataisyti pokalbiai. Naudojami kaip few-shot pavyzdžiai AI.', 'examples' => []];
if (file_exists(CHATS_APPROVED)) {
    $d = json_decode(file_get_contents(CHATS_APPROVED), true);
    if ($d && isset($d['examples'])) $approved = $d;
}

// Tikriname ar šis id jau yra — atnaujiname arba pridedame
$found = false;
foreach ($approved['examples'] as &$ex) {
    if (($ex['id'] ?? '') === $id) {
        $ex['user']      = $userMsg;
        $ex['assistant'] = $aiMsg;
        $ex['updated']   = date('c');
        $found = true;
        break;
    }
}
unset($ex);

if (!$found) {
    $approved['examples'][] = [
        'id'        => $id,
        'user'      => $userMsg,
        'assistant' => $aiMsg,
        'created'   => date('c'),
    ];
}

// Išsaugome qa_approved.json
file_put_contents(
    CHATS_APPROVED,
    json_encode($approved, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)
);

// Pažymime log'e kaip approved
if (file_exists(CHATS_LOG)) {
    $lines = file(CHATS_LOG, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $updated = [];
    foreach ($lines as $line) {
        $e = json_decode($line, true);
        if ($e && ($e['id'] ?? '') === $id) {
            $e['approved'] = true;
            $e['ai']       = $aiMsg; // atnaujintas atsakymas
        }
        $updated[] = json_encode($e, JSON_UNESCAPED_UNICODE);
    }
    file_put_contents(CHATS_LOG, implode("\n", $updated) . "\n");
}

ok(['id' => $id]);
