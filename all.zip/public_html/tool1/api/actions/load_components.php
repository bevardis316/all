<?php

$compBase = DATA_DIR . 'components';
$components = [];

if (is_dir($compBase)) {
    foreach (glob($compBase . '/*', GLOB_ONLYDIR) ?: [] as $parentDir) {
        $parentId = basename($parentDir);
        foreach (glob($parentDir . '/*.json') ?: [] as $compFile) {
            if (basename($compFile) === '.htaccess') continue;
            $comp = readJson($compFile);
            if (!$comp || !isset($comp['id'])) continue;
            $components[] = [
                'id'           => $comp['id'],
                'name'         => $comp['name']         ?? $comp['id'],
                'parent_id'    => $comp['parent_id']    ?? $parentId,
                'pricing'      => $comp['pricing']      ?? ['part_price'=>0,'install_price'=>0,'quantity_per_system'=>1,'guarantee_months'=>12,'diy_possible'=>true],
                'models'       => $comp['models']       ?? [],
                'in_package'   => $comp['in_package']   ?? null,
                '_file'        => $parentId . '/' . basename($compFile),
            ];
        }
    }
    
    usort($components, fn($a,$b) => ($a['parent_id'].$a['id']) <=> ($b['parent_id'].$b['id']));
}

ok(['components' => $components, 'count' => count($components)]);
