<?php

$oid = safeId($_GET['oid'] ?? '');
if (!$oid) {
    err(400, 'Trūksta objekto ID (oid)');
}

$objDir = DATA_DIR . "objects/{$oid}/";
if (!is_dir($objDir)) {
    err(404, "Objektas '{$oid}' nerastas");
}

$obj = [];
foreach (['base', 'env', 'relations', 'exploitation_errors'] as $part) {
    $d = readJson(objPath($oid, $part));
    if ($d !== null) $obj[$part] = $d;
}

$failureIdx = readJson(failureIdx($oid)) ?? [];
$failures   = ['_index' => $failureIdx];
$fdir       = $objDir . 'failures/';
if (is_dir($fdir)) {
    foreach (scandir($fdir) as $ff) {
        if ($ff === '_index.json' || !str_ends_with($ff, '.json')) continue;
        $fid = basename($ff, '.json');
        $fd  = readJson($fdir . $ff);
        if ($fd) $failures[$fid] = $fd;
    }
}

$trees = [];
$tdir  = $objDir . 'trees/';
if (is_dir($tdir)) {
    foreach (scandir($tdir) as $tf) {
        if (!str_ends_with($tf, '_tree.json')) continue;
        $tid = basename($tf, '_tree.json');
        $td  = readJson($tdir . $tf);
        if ($td) $trees[$tid] = $td;
    }
}

$pct = readJson(pctPath($oid));

ok([
    'oid'         => $oid,
    'object'      => $obj,
    'failures'    => $failures,
    'trees'       => $trees,
    'percentages' => $pct,
]);
