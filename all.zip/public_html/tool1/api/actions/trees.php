<?php

$body = getBody();
$oid = safeId($body['object_id'] ?? '');
$fid = safeId($body['failure_id'] ?? '');
if (!$oid || !$fid) err(400, 'Trūksta object_id arba failure_id');
ensureDir(DATA_DIR . "objects/{$oid}/trees/");
$body['_meta'] = ['saved' => date('c'), 'object_id' => $oid, 'failure_id' => $fid];
writeJson(treePath($oid, $fid), $body);
ok(['object_id' => $oid, 'failure_id' => $fid, 'path' => "objects/{$oid}/trees/{$fid}_tree.json"]);
