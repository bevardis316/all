<?php

$d = getBody();
$parentId = safeId($d['parent_id'] ?? '');
$compId   = safeId($d['comp_id']   ?? '');

if (!$parentId || !$compId) err(400, 'Truksta parent_id arba comp_id');

$filePath = DATA_DIR . "components/{$parentId}/{$compId}.json";
if (!file_exists($filePath)) err(404, "Komponentas nerastas: {$parentId}/{$compId}");

$comp = readJson($filePath);
if (!$comp) err(500, 'Nepavyko perskaityti komponento');

if (array_key_exists('in_package', $d)) {
    $comp['in_package'] = ($d['in_package'] === null) ? null : (bool)$d['in_package'];
}

if (isset($d['pricing']) && is_array($d['pricing'])) {
    $p = $d['pricing'];
    $comp['pricing'] = [
        'part_price'          => max(0, (float)($p['part_price']          ?? $comp['pricing']['part_price']          ?? 0)),
        'install_price'       => max(0, (float)($p['install_price']       ?? $comp['pricing']['install_price']       ?? 0)),
        'quantity_per_system' => max(1, (int)  ($p['quantity_per_system'] ?? $comp['pricing']['quantity_per_system'] ?? 1)),
        'guarantee_months'    => max(0, (int)  ($p['guarantee_months']    ?? $comp['pricing']['guarantee_months']    ?? 12)),
        'diy_possible'        => (bool)($p['diy_possible'] ?? $comp['pricing']['diy_possible'] ?? true),
    ];
}

if (isset($d['models']) && is_array($d['models'])) {
    $comp['models'] = array_values(array_filter($d['models'], fn($m) =>
        is_array($m) && !empty($m['id']) && !empty($m['name'])
    ));
}

$comp['updated'] = date('c');

if (!writeJson($filePath, $comp)) err(500, 'Nepavyko issaugoti');

ok(['saved' => "{$parentId}/{$compId}"]);
