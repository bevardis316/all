<?php

$labelsFile = DATA_DIR . 'meta/ui_labels.json';

if ($action === 'load_ui_labels') {
    if (!file_exists($labelsFile)) {
        ok(['labels' => []]);
        exit;
    }
    $data = json_decode(file_get_contents($labelsFile), true);
    ok(['labels' => is_array($data) ? $data : []]);
    exit;
}

if ($action === 'save_ui_labels') {
    $body = getBody();
    $labels = $body['labels'] ?? null;
    if (!is_array($labels)) {
        err(400, 'Neteisingi duomenys');
    }

    // Išsaugoti esamos versijos _comment ir version
    $existing = [];
    if (file_exists($labelsFile)) {
        $existing = json_decode(file_get_contents($labelsFile), true) ?: [];
    }
    $labels['version']  = ($existing['version'] ?? 0) + 1;
    $labels['_comment'] = $existing['_comment'] ?? 'UI tekstai - keiskite čia, ne domain.json.';

    $json = json_encode($labels, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if (file_put_contents($labelsFile, $json, LOCK_EX) === false) {
        err(500, 'Nepavyko išsaugoti');
    }

    ok(['saved' => true]);
    exit;
}
