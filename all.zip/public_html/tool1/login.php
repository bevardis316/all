<?php
require_once __DIR__ . '/api/config.php';
require_once __DIR__ . '/api/helpers.php';
require_once __DIR__ . '/api/auth.php';

startSecureSession();
if (isset($_SESSION['ibnvs_auth']) && (time() - ($_SESSION['ibnvs_ts'] ?? 0)) < SESSION_TTL) {
    header('Location: index.php');
    exit;
}

$error = '';
$setupHash = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pw = $_POST['password'] ?? '';
    if (!$pw) {
        $error = 'Įvesk slaptažodį.';
    } else {
        $result = attemptLogin($pw);
        if ($result['ok']) {
            header('Location: index.php');
            exit;
        } elseif ($result['setup'] ?? false) {
            $setupHash = $result['hash'];
        } else {
            $error = 'Neteisingas slaptažodis.';
        }
    }
}
?><!DOCTYPE html>
<html lang="lt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IBNVS – Prisijungimas</title>
<link rel="stylesheet" href="../shared/css/theme.css">
<link rel="stylesheet" href="assets/css/login.css">
</head>
<body>
<div class="card">
  <div class="logo">IBNVS v6</div>
  <h1>Prisijungimas</h1>
  <form method="POST" action="login.php">
    <label for="password">Slaptažodis</label>
    <input type="password" id="password" name="password" autofocus autocomplete="current-password">
    <button type="submit">Prisijungti →</button>
  </form>

  <?php if ($error): ?>
    <div class="error">⚠ <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if ($setupHash): ?>
    <div class="setup-box">
      <p><strong>Pirmas paleidimas.</strong> Slaptažodžio hash dar nenurodytas.<br>
      Įrašyk šią eilutę į <code>api/config.php</code>:</p>
      <code onclick="navigator.clipboard.writeText(this.textContent)" title="Spausk kopijuoti">
        define('ADMIN_PASSWORD_HASH', '<?= htmlspecialchars($setupHash) ?>');
      </code>
      <small>↑ Spausk ant kodo — nukopijuos į clipboard. Po įrašymo prisijunk iš naujo.</small>
    </div>
  <?php endif; ?>
</div>
</body>
</html>
