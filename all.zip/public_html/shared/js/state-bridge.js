// Bridge: suderina dvi state.min.js versijas su map3d-core.min.js
// shared/state.min.js  → TECH.st (sutrumpinti raktai: st, g, r)
// tool1/state.min.js   → TECH.sistemu_tipai (pilni raktai)
// map3d-core.min.js    → tikisi TECH.st
// map3d-core.js        → tikisi TECH.sistemu_tipai

if (typeof TECH !== 'undefined') {
  // kon/ atvejis: yra TECH.st, trūksta TECH.sistemu_tipai
  if (TECH.st && !TECH.sistemu_tipai) {
    TECH.sistemu_tipai = TECH.st.map(t => ({
      id: t.id, grandine: t.g, rusis: t.r
    }));
  }
  // tool1/ atvejis: yra TECH.sistemu_tipai, trūksta TECH.st
  if (TECH.sistemu_tipai && !TECH.st) {
    TECH.st = TECH.sistemu_tipai.map(t => ({
      id: t.id, g: t.grandine, r: t.rusis
    }));
  }
}
