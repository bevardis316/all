const THEME = {
  obj:         0x2e7d32,
  objSelected: 0x1565c0,
  objEmpty:    0xaaaaaa,
  comp1:       0x1565c0,
  comp2:       0x7b1fa2,
  comp3:       0x1b5e20,
  comp4:       0x4a148c,
  compLine:    0x2e7d32,
  grid:        0x90EE90,
  bg:          0xf2f8f3,
};

let _3d           = null;
let _3dSel        = null;
let _dragMode     = false;
let _dragAxis     = null;
let _userMovedCam = false;
let _orbSave      = null;
let _sysObjsRef   = [];
let _posMapRef    = {};

let _viewMode    = 'expand';
let _selObj      = null;
let _selComp     = null;
let _openedComps = [];
let _panelLevel  = 'obj';

let _axisLineMesh = null;
let _gridRef      = null;

const _NO_PRICE_OBJS = new Set(['ZEMPAV','SLAIT','NAM1','NAM2']);
const _Z_Y      = { '@zempav':2, '@ipgil':1, '@gilu':0 };
const _CELL     = 2.8;
const _Z_STEP   = 2.4;
const _X_SPREAD = 2.0;

function _objPos(id, overrideX) {
  const meta = KB.objects_meta[id] || (typeof DEF_OBJS!=='undefined' ? DEF_OBJS.find(o=>o.id===id) : null);
  if (!meta) return null;
  const sek = (meta.sek||['B'])[0];
  const z   = meta.z||'@ipgil';
  return {
    x: (overrideX!==undefined ? overrideX : (_SEK_X[sek]!==undefined?_SEK_X[sek]:2)) * _CELL,
    y: (_Z_Y[z]!==undefined?_Z_Y[z]:1) * _CELL,
    z: 0,
  };
}

function _showPkgComps(scene, compMeshes, oid, overrideX) {
  if(oid==='NAM1'||oid==='NAM2') return;
  const objPos=_objPos(oid,overrideX); if(!objPos) return;
  const items=_compChildren(oid);
  if(!items.length) return;

  const kb  = KB.objects[oid]||{};
  const pkgs = kb.packages||[];
  const ap  = window._activePackage;
  const pkg = (ap && ap.oid===oid && pkgs[ap.pkgIdx]) ? pkgs[ap.pkgIdx] : (pkgs[0]||null);
  const compSel = pkg?.comp_selections || {};

  const totalW=(items.length-1)*_X_SPREAD, startX=objPos.x-totalW/2;
  const fromX=objPos.x, fromY=objPos.y;

  items.forEach((comp,i)=>{
    const compId = comp.id || Object.keys(KB.components).find(k=>KB.components[k]===comp) || ('comp_'+i);
    const inPkg = comp.in_package !== false;
    const cz = inPkg ? _Z_STEP * 0.8 : -_Z_STEP * 0.8;
    let cx,cy;
    if(comp.map_x!=null){ cx=objPos.x+comp.map_x; cy=objPos.y+(comp.map_y||0); }
    else { cx=startX+i*_X_SPREAD; cy=fromY; }

    compMeshes.push(_line3d(scene,fromX,fromY,0,cx,cy,cz,
      inPkg?THEME.obj:THEME.objEmpty, inPkg?0.55:0.25));

    const col  = inPkg ? THEME.obj : THEME.objEmpty;
    const userData={type:'comp',id:compId,name:comp.name||compId,oid,cx,cy,cz,overrideX,level:1,objPosX:objPos.x,objPosY:objPos.y};
    _addCompMesh(scene, compMeshes, comp, cx, cy, cz, col, userData, {
      transparent: !inPkg,
      opacity: inPkg ? 1.0 : 0.55
    });

    const label = (inPkg?'\u2713 ':'\u2295 ')+(comp.name||comp.id);
    const sp=_txt3d(scene,label,cx,cy-0.62,cz,inPkg?'#1b5e20':'#999999',12);
    if(sp) compMeshes.push(sp);

    if(_openedComps.includes(comp.id)){
      _showStepComps(scene,compMeshes,oid,comp.id,{cx,cy,cz},overrideX,2);
    }
  });

  if(pkg && pkgs.length > 0){
    const inCount  = items.filter(c=>compSel[c.id]!==undefined).length;
    const outCount = items.length - inCount;
    if(inCount>0||outCount>0){
      _txt3d(scene,
        '\u2713 Komplekte: '+inCount+'  \u2295 Atskirai: '+outCount,
        objPos.x, objPos.y+1.3, 0, '#1b5e20', 12);
    }
  }
}

function _compChildren(parentId) {
  return Object.entries(KB.components||{})
    .filter(([cid,c])=>(KB.components_meta[cid]?.parent_id||c.parent_id)===parentId)
    .map(([cid,c])=>Object.assign(c,{id:c.id||cid}));
}
function _hasChildren(compId) {
  return Object.entries(KB.components||{})
    .some(([cid,c])=>(KB.components_meta[cid]?.parent_id||c.parent_id)===compId);
}

function _txt3d(scene, text, x, y, z, color, size) {
  const cv=document.createElement('canvas'); cv.width=256; cv.height=64;
  const ctx=cv.getContext('2d');
  ctx.font='bold '+(size||16)+'px Inter,Arial,sans-serif';
  ctx.fillStyle=color||'#333'; ctx.textAlign='center';
  ctx.fillText(text.substring(0,22),128,42);
  const sp=new THREE.Sprite(new THREE.SpriteMaterial({
    map:new THREE.CanvasTexture(cv), transparent:true, depthWrite:false
  }));
  sp.position.set(x,y,z); sp.scale.set(3.2,0.64,1); scene.add(sp); return sp;
}

function _line3d(scene, x1,y1,z1, x2,y2,z2, color, opacity) {
  const line=new THREE.Line(
    new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(x1,y1,z1),new THREE.Vector3(x2,y2,z2)]),
    new THREE.LineBasicMaterial({color, opacity:opacity||0.5, transparent:true})
  );
  scene.add(line); return line;
}

function _drawGrid(scene) {
  const COLS=5, ROWS=3, pts=[];
  for(let y=0;y<ROWS;y++) pts.push(0,y*_CELL,0,(COLS-1)*_CELL,y*_CELL,0);
  for(let x=0;x<COLS;x++) pts.push(x*_CELL,0,0,x*_CELL,(ROWS-1)*_CELL,0);
  const geo=new THREE.BufferGeometry();
  geo.setAttribute('position',new THREE.Float32BufferAttribute(pts,3));
  const _gl=new THREE.LineSegments(geo,new THREE.LineBasicMaterial({color:THEME.grid,opacity:0.18,transparent:true}));
  scene.add(_gl); return _gl;
}


// Vamzdžio geometrija (vietoj plonos linijos)
function _pipe3d(scene, x1,y1,z1, x2,y2,z2, color, radius) {
  radius = radius || 0.06;
  const start = new THREE.Vector3(x1,y1,z1);
  const end   = new THREE.Vector3(x2,y2,z2);
  const dir   = new THREE.Vector3().subVectors(end, start);
  const len   = dir.length();
  const mid   = new THREE.Vector3().addVectors(start, end).multiplyScalar(0.5);

  const geo = new THREE.CylinderGeometry(radius, radius, len, 8, 1);
  const mat = new THREE.MeshPhongMaterial({color, shininess:40});
  const mesh = new THREE.Mesh(geo, mat);

  // Orientuojame cilindrą nuo start iki end
  mesh.position.copy(mid);
  mesh.quaternion.setFromUnitVectors(
    new THREE.Vector3(0,1,0),
    dir.normalize()
  );
  scene.add(mesh);
  return mesh;
}


function _drawBackground(scene, cx, bg) {
  const W = (6-1)*_CELL, H = (3-1)*_CELL;
  let _bgMesh = null;
  const _bgUrl = (bg || '/shared/img/background.png') + '?v=' + (localStorage.getItem('glb_ver')||'1');
  const _loadBg = function(url) {
    new THREE.TextureLoader().load(url, function(tex) {
      _bgMesh = new THREE.Mesh(
        new THREE.PlaneGeometry(W, H),
        new THREE.MeshBasicMaterial({
          map:tex, transparent:true, opacity:0.80,
          side:THREE.DoubleSide, depthWrite:false
        })
      );
      _bgMesh.position.set(2.5*_CELL, H/2, -0.01);
      _bgMesh.renderOrder = 0;
      scene.add(_bgMesh);
    }, undefined, function() {
      // Fallback: jei failas nerastas - grįžti į default
      if (url !== '/shared/img/background.png') _loadBg('/shared/img/background.png');
    });
  };
  _loadBg(_bgUrl);
  // Grąžiname getter funkciją - mesh gali būti dar nekrautas
  return { getMesh: () => _bgMesh };
}

function _drawAxisLabels(scene, sysObjs, selSys) {
  [['Žemės paviršius','@zempav'],['Įprastas gylis','@ipgil'],['Labai giliai','@gilu']].forEach(([lbl,key])=>{
    if(_Z_Y[key]!==undefined) _txt3d(scene,lbl,-1.6,_Z_Y[key]*_CELL+(key==='@zempav'?-0.65:0.12),0,'#6a5f31',18);
  });
}

function _showAxisLine(scene, mesh) {
  _hideAxisLine(scene);
  if(!_dragAxis) return;
  const p=mesh.position;
  const ext=20;
  const col = _dragAxis==='x'?0xff2020 : _dragAxis==='y'?0x00cc44 : 0x2080ff;
  let pts;
  if(_dragAxis==='x') pts=[new THREE.Vector3(-ext,p.y,p.z),new THREE.Vector3(ext,p.y,p.z)];
  else if(_dragAxis==='y') pts=[new THREE.Vector3(p.x,-ext,p.z),new THREE.Vector3(p.x,ext,p.z)];
  else pts=[new THREE.Vector3(p.x,p.y,-ext),new THREE.Vector3(p.x,p.y,ext)];
  _axisLineMesh=new THREE.Line(
    new THREE.BufferGeometry().setFromPoints(pts),
    new THREE.LineBasicMaterial({color:col,opacity:0.7,transparent:true})
  );
  scene.add(_axisLineMesh);
}

function _hideAxisLine(scene) {
  if(_axisLineMesh){ scene.remove(_axisLineMesh); _axisLineMesh=null; }
}

function _showComponents(scene, compMeshes, oid, parentCompId, parentPos, overrideX, level) {
  level=level||1; if(oid==='NAM1'||oid==='NAM2') return;
  const objPos=_objPos(oid,overrideX); if(!objPos) return;
  const items=_compChildren(parentCompId||oid);
  if(!items.length) return;
  const fromX=parentPos?parentPos.cx:objPos.x, fromY=parentPos?parentPos.cy:objPos.y, fromZ=parentPos?parentPos.cz:0;
  const compZ=fromZ-_Z_STEP, totalW=(items.length-1)*_X_SPREAD, startX=fromX-totalW/2;
  items.forEach((comp,i)=>{
    let cx,cy,cz;
    if(comp.map_x!=null&&comp.map_z!=null){ cx=objPos.x+comp.map_x; cy=objPos.y+(comp.map_y||0); cz=comp.map_z; }
    else { cx=startX+i*_X_SPREAD; cy=fromY; cz=compZ; }
    compMeshes.push(_line3d(scene,fromX,fromY,fromZ,cx,cy,cz,THEME.obj,0.45));
    const userData={type:'comp',id:comp.id,name:comp.name||comp.id,oid,cx,cy,cz,overrideX,level,objPosX:objPos.x,objPosY:objPos.y};
    const _col = level===1?THEME.comp1:THEME.comp2;
    _addCompMesh(scene, compMeshes, comp, cx, cy, cz, _col, userData);
    const sp=_txt3d(scene,comp.name||comp.id,cx,cy-0.55,cz,level===1?'#1565c0':'#7b1fa2',13);
    if(sp) compMeshes.push(sp);
  });
}

function _showStepComps(scene, compMeshes, oid, parentCompId, parentPos, overrideX, level) {
  level=level||1; if(oid==='NAM1'||oid==='NAM2') return;
  const objPos=_objPos(oid,overrideX); if(!objPos) return;
  const items=_compChildren(parentCompId||oid);
  if(!items.length) return;
  const fromX=parentPos?parentPos.cx:objPos.x, fromY=parentPos?parentPos.cy:objPos.y, fromZ=parentPos?parentPos.cz:0;
  const compZ=fromZ-_Z_STEP, totalW=(items.length-1)*_X_SPREAD, startX=fromX-totalW/2;
  const levelCol=[THEME.comp1,THEME.comp2,THEME.comp3,THEME.comp4];
  const levelTxt=['#1565c0','#7b1fa2','#1b5e20','#4a148c'];
  const col=levelCol[Math.min(level-1,3)];
  const txtCol=levelTxt[Math.min(level-1,3)];
  items.forEach((comp,i)=>{
    let cx,cy,cz;
    if(comp.map_x!=null&&comp.map_z!=null){ cx=objPos.x+comp.map_x; cy=objPos.y+(comp.map_y||0); cz=comp.map_z; }
    else { cx=startX+i*_X_SPREAD; cy=fromY; cz=compZ; }
    compMeshes.push(_line3d(scene,fromX,fromY,fromZ,cx,cy,cz,THEME.obj,0.45));
    const userData={type:'comp',id:comp.id,name:comp.name||comp.id,oid,cx,cy,cz,overrideX,level,objPosX:objPos.x,objPosY:objPos.y};
    _addCompMesh(scene, compMeshes, comp, cx, cy, cz, col, userData);
    const sp=_txt3d(scene,comp.name||comp.id,cx,cy-0.55,cz,txtCol,13);
    if(sp) compMeshes.push(sp);
    if(_openedComps.includes(comp.id)){
      _showStepComps(scene,compMeshes,oid,comp.id,{cx,cy,cz},overrideX,level+1);
    }
  });
}

function _showAllComps(scene, compMeshes, oid, parentCompId, parentPos, overrideX, level) {
  level=level||1; if(oid==='NAM1'||oid==='NAM2') return;
  const objPos=_objPos(oid,overrideX); if(!objPos) return;
  const items=_compChildren(parentCompId||oid);
  if(!items.length) return;
  const fromX=parentPos?parentPos.cx:objPos.x, fromY=parentPos?parentPos.cy:objPos.y, fromZ=parentPos?parentPos.cz:0;
  const compZ=fromZ-_Z_STEP, totalW=(items.length-1)*_X_SPREAD, startX=fromX-totalW/2;
  items.forEach((comp,i)=>{
    let cx,cy,cz;
    if(comp.map_x!=null&&comp.map_z!=null){ cx=objPos.x+comp.map_x; cy=objPos.y+(comp.map_y||0); cz=comp.map_z; }
    else { cx=startX+i*_X_SPREAD; cy=fromY; cz=compZ; }
    compMeshes.push(_line3d(scene,fromX,fromY,fromZ,cx,cy,cz,THEME.obj,0.45));
    const userData={type:'comp',id:comp.id,name:comp.name||comp.id,oid,cx,cy,cz,overrideX,level,objPosX:objPos.x,objPosY:objPos.y};
    const _col = level===1?THEME.comp1:THEME.comp2;
    _addCompMesh(scene, compMeshes, comp, cx, cy, cz, _col, userData);
    const sp=_txt3d(scene,comp.name||comp.id,cx,cy-0.55,cz,level===1?'#1565c0':'#7b1fa2',13);
    if(sp) compMeshes.push(sp);
    _showAllComps(scene,compMeshes,oid,comp.id,{cx,cy,cz},overrideX,level+1);
  });
}

function _panelEl() { return document.getElementById('map-side-panel'); }

function _hidePanel() {
  const p=_panelEl(); if(p){p.style.display='none';p.innerHTML='';}
  document.body.classList.remove('msp-panel-open');
  const _r=document.querySelector('.right'); if(_r) _r.style.display='';
}

function _renderPanel() {
  if(!_selObj){_hidePanel();return;}
  _panelLevel==='comp'&&_selComp ? _renderPanelComp() : (_panelLevel='obj',_renderPanelObj());
}

function _renderPanelCompList(items, depth) {
  const dotCols=['#1565c0','#7b1fa2','#1b5e20','#4a148c'];
  const isAdmin = typeof saveAllFiles === 'function';
  return items.map(c=>{
    const isSeparate = c.in_package === false;
    if(isSeparate && !isAdmin) return '';
    const hasSub=_hasChildren(c.id);
    const isOpen=_openedComps.includes(c.id);
    const dotColor = isSeparate ? '#bbb' : dotCols[Math.min(depth,3)];
    const dot='<span class="msp-dot" style="background:'+dotColor+'"></span>';
    const indent=depth>0?'style="padding-left:'+(8+depth*14)+'px"':'';
    const separateBadge = (isAdmin && isSeparate)
      ? '<span style="font-size:9px;color:#999;margin-left:4px">atskirai</span>' : '';
    const subHtml=isOpen
      ? '<div id="msp-sub-'+c.id+'">'+_renderPanelCompList(_compChildren(c.id), depth+1)+'</div>'
      : '<div id="msp-sub-'+c.id+'" style="display:none"></div>';
    return '<div id="msp-row-'+c.id+'" class="msp-comp-row" '+indent+' onclick="mapClickComp(\''+c.id+'\')">'+
      dot+
      '<span class="msp-comp-name">'+(c.name||c.id)+'</span>'+
      separateBadge+
      (hasSub?'<span class="msp-expand-btn" data-tog="'+c.id+'" onclick="event.stopPropagation();mapToggleSub(\''+c.id+'\')">'+
        (isOpen?'&#9662;':'&#9658;')+'</span>':'')+
    '</div>'+subHtml;
  }).join('');
}

function _renderPanelSys(sysId) {
  const sys=TECH.sistemu_tipai.find(t=>t.id===sysId);
  if(!sys) return;
  const sysObjs=sys.grandine||[];

  let totalObjs=0, totalParts=0, totalInstall=0, totalComps=0;
  const objRows=sysObjs
    .filter(oid=>!_NO_PRICE_OBJS.has(oid))
    .map(oid=>{
    const meta=KB.objects_meta[oid]||{};
    const kb=KB.objects[oid]||{};
    const objModels=kb.models||[];
    const objPrice=objModels[0]?.price_eur||0;
    totalObjs+=objPrice;
    const comps=_buildCompTree(oid,oid);
    function sumTree(nodes){nodes.forEach(n=>{
      if(n.in_package===false){
        const p=n.pricing||{};
        const qty=p.quantity_per_system||1;
        const unitPrice=(n.models&&n.models[0]?.price_eur)||p.part_price||0;
        totalParts+=unitPrice*qty;
        totalInstall+=(p.install_price||0)*qty;
        totalComps++;
      } else {
        totalComps++;
      }
      sumTree(n.children||[]);
    });}
    sumTree(comps);
    const hasData=!!(kb.function||Object.values(kb.failure_modes||{}).some(f=>f.name));
    return {oid, name:meta.name||oid, descr:kb.function||'', hasData, compCount:comps.length, objPrice};
  });

  const grandTotal=totalObjs+totalParts+totalInstall;
  const priceBlock=grandTotal?
    '<div class="msp-sys-price">'+
      (totalObjs?'<div class="msp-sys-price-row"><span>Įrenginiai</span><b>~'+totalObjs+' €</b></div>':'')+
      (totalParts?'<div class="msp-sys-price-row"><span>Medžiagos / dalys</span><b>~'+totalParts+' €</b></div>':'')+
      (totalInstall?'<div class="msp-sys-price-row"><span>Montavimo darbai</span><b>~'+totalInstall+' €</b></div>':'')+
      '<div class="msp-sys-price-row msp-sys-total"><span>Viso apytiksliai</span><b>~'+grandTotal+' €</b></div>'+
    '</div>' : '';

  const objListHtml=objRows.map(r=>
    '<div class="msp-comp-row" onclick="mapSysClickObj(\''+r.oid+'\')">'+
      '<span class="msp-dot" style="background:'+(r.hasData?'#2e7d32':'#bbb')+'"></span>'+
      '<span class="msp-comp-name">'+r.name+'</span>'+
      (r.objPrice?'<span style="font-size:11px;font-weight:700;color:var(--pri)">'+r.objPrice+' €</span>':'')+
      '<span class="msp-arrow-r">&#8250;</span>'+
    '</div>'
  ).join('');

  const p=_panelEl(); if(!p) return;
  p.innerHTML=
    '<div class="msp-head">'+
      '<div class="msp-sys-label">Sistema</div>'+
      '<div class="msp-obj-name">'+(sys.pavadinimas||('Sistema #'+sysId))+'</div>'+
      '<button class="msp-close" onclick="_hidePanel()">&#215;</button>'+
    '</div>'+
    '<div class="msp-body">'+
      '<div class="msp-sys-meta">'+
        '<span>'+sysObjs.length+' objektai</span>'+
        (totalComps?'<span>'+totalComps+' komponentai</span>':'')+
      '</div>'+
      priceBlock+
      '<div class="msp-section-title msp-mt">Objektai sistemoje</div>'+
      '<div class="msp-comp-list">'+objListHtml+'</div>'+
      '<div class="msp-divider msp-mt"></div>'+
      '<button class="msp-action msp-action-buy" style="margin-top:4px" onclick="mapShowShoppingList(\'sys\')">&#128722; Pirkimo sarasas (visa sistema)</button>'+
    '</div>';
  p.style.display='flex';
  document.body.classList.add('msp-panel-open');
  const _r=document.querySelector('.right'); if(_r) _r.style.display='flex';
}

function mapSysClickObj(oid){
  _selObj=oid; _selComp=null; _openedComps=[]; _panelLevel='obj';
  _renderPanel();
  const canvas=document.getElementById('map-canvas');
  const selSys=parseInt(document.getElementById('map-sys')?.value||'0');
  if(canvas&&selSys) _build3d(canvas);
  // Kamera → cam_click jei nustatyta
  const _oCam=KB.objects[oid]?.scene_3d?.cam_click;
  if(_oCam&&_3d?.orb&&_3d?.applyOrbit) _camFlyTo(_oCam,_3d.orb,_3d.applyOrbit);
}

function _renderPanelObj() {
  const id=_selObj;
  const meta=KB.objects_meta[id]||(typeof DEF_OBJS!=='undefined'?DEF_OBJS.find(o=>o.id===id):null)||{};
  const kb=KB.objects[id]||{};
  const name=meta.name||id;
  const descr=kb.function||'';
  const models=kb.models||[];
  const pkgs=kb.packages||[];
  const comps=_compChildren(id);

  const isAdmin = typeof saveAllFiles === 'function'; 
  const activePkgIdx=(window._activePackage?.oid===id)?window._activePackage.pkgIdx:0;
  const pkgsHtml=(isAdmin && pkgs.length>0)
    ?'<div class="msp-section-title msp-mt">&#128230; Komplektai</div>'+
      '<div class="msp-pkg-btns">'+
      pkgs.map((p,i)=>{
        const m=models.find(m=>m.id===p.obj_model_id);
        const sub=m?m.name||p.obj_model_id:'';
        const isAct=i===activePkgIdx;
        return '<button class="msp-pkg-btn'+(isAct?' active':'')
          +'" onclick="mapSelectPkg(\''+id+'\','+i+')">'+
          (p.name||('Variantas '+(i+1)))+
          (sub?'<span class="msp-pkg-sub">'+sub+'</span>':'')+
          '</button>';
      }).join('')+
      '</div>'+
      '<div class="msp-pkg-legend">'+
        '<span style="color:#2e7d32;font-weight:700">\u2713 Komplekte</span> = Z+ &nbsp;'+
        '<span style="color:#999">\u2295 Atskirai</span> = Z-'+
      '</div>'
    :'';

  const modelsHtml=models.length
    ?'<div class="msp-section-title msp-mt">Modeliai</div>'+
      '<div class="msp-models">'+
      models.map(m=>'<div class="msp-model-row">'+
        '<span class="msp-model-name">'+(m.name||m.id)+'</span>'+
        (m.price_eur?'<span class="msp-price">'+m.price_eur+' \u20ac</span>':'')+
        (m.notes?'<span class="msp-notes">'+m.notes+'</span>':'')+
      '</div>').join('')+
      '</div>':'';

  const compsHtml=comps.length
    ?_renderPanelCompList(comps,0)
    :'<div class="msp-empty">Komponentu nera</div>';

  const p=_panelEl(); if(!p) return;
  const body=p.querySelector('.msp-body');
  const prevScroll=body?.scrollTop||0;
  p.innerHTML=
    '<div class="msp-header">'+
      '<span class="msp-title">'+name+'</span>'+
      '<button class="msp-close" onclick="mapPanelClose()">\xd7</button>'+
    '</div>'+
    '<div class="msp-body">'+
      (descr?'<div class="msp-text msp-mb">'+descr+'</div>':'<div class="msp-empty-sm">Aprasymo nera</div>')+
      '<div class="msp-inline-btns">'+
        '<button class="msp-ibtn" onclick="mapBtnAtrodo(\''+id+'\',\'obj\')">&#128444; Kaip atrodo</button>'+
        '<button class="msp-ibtn" onclick="mapBtnMontuoti(\''+id+'\',\'obj\')">&#128295; Kaip montuoti</button>'+
        '<button class="msp-ibtn" onclick="mapBtnPirkti(\''+id+'\',\'obj\')">&#128222; Kur pirkti?</button>'+
      '</div>'+
      pkgsHtml+
      modelsHtml+
      '<div class="msp-section-title msp-mt">Komponentai</div>'+
      '<div class="msp-comp-list">'+compsHtml+'</div>'+
      '<div class="msp-divider msp-mt"></div>'+
      '<button class="msp-action msp-action-buy" onclick="mapShowShoppingList(\'obj\')">&#128722; Pirkimo sarasas (objektas)</button>'+
      '<button class="msp-action msp-action-buy" style="margin-top:4px" onclick="mapShowShoppingList(\'sys\')">&#128722; Pirkimo sarasas (sistema)</button>'+
    '</div>';
  p.style.display='flex';
  document.body.classList.add('msp-panel-open');
  const _r=document.querySelector('.right'); if(_r) _r.style.display='flex';
  if(prevScroll) requestAnimationFrame(()=>{ const b=p.querySelector('.msp-body'); if(b) b.scrollTop=prevScroll; });
  // Kamera → cam_click objektui, tx/ty/tz = dabartinė objekto pozicija
  // Objektui kameros nekeičiame - vartotojas pats naršo
}

function _renderPanelComp() {
  const cd=_selComp;
  const comp=KB.components[cd.id]||{};
  const name=comp.name||cd.id;
  const descr=comp.description||comp.aprasymas||'';
  const pricing=comp.pricing||{};
  const models=comp.models||[];
  const subComps=_compChildren(cd.id);

  const parentName=(()=>{
    if(cd.level>1){ const par=KB.components[comp.parent_id]; return par?(par.name||comp.parent_id):comp.parent_id; }
    const m=KB.objects_meta[cd.oid]||{}; return m.name||cd.oid;
  })();

  const priceHtml=(pricing.part_price||pricing.install_price)?
    '<div class="msp-price-box">'+
      (pricing.part_price?'<div class="msp-price-row"><span>Dalies kaina</span><b>'+pricing.part_price+' €</b></div>':'')+
      (pricing.install_price?'<div class="msp-price-row"><span>Montavimas</span><b>'+pricing.install_price+' €</b></div>':'')+
      (pricing.quantity_per_system>1?'<div class="msp-price-row"><span>Kiekis</span><b>'+pricing.quantity_per_system+' vnt.</b></div>':'')+
      (pricing.diy_possible===false?'<div class="msp-diy-no">Reikia specialisto</div>':'<div class="msp-diy-yes">Galima montuoti pačiam</div>')+
    '</div>' : '';

  const modelsHtml=models.length?
    '<div class="msp-section-title msp-mt">Modeliai / tiekėjai</div>'+
    '<div class="msp-models">'+
    models.map(m=>'<div class="msp-model-row">'+
      '<span class="msp-model-name">'+(m.name||'–')+'</span>'+
      (m.supplier?'<span class="msp-supplier">'+m.supplier+'</span>':'')+
      (m.price_eur?'<span class="msp-price">'+m.price_eur+' €</span>':'')+
    '</div>').join('')+
    '</div>':'';

  const subHtml=subComps.length?
    '<div class="msp-section-title msp-mt">Sudedamosios dalys</div>'+
    '<div class="msp-comp-list">'+
    subComps.map(s=>'<div class="msp-comp-row" onclick="mapClickComp(\''+s.id+'\')">'+
      '<span class="msp-dot msp-dot-l2"></span>'+
      '<span class="msp-comp-name">'+(s.name||s.id)+'</span>'+
      '<span class="msp-arrow-r">&#8250;</span>'+
    '</div>').join('')+
    '</div>':'';

  const p=_panelEl(); if(!p) return;
  const prevScrollC=p.querySelector('.msp-body')?.scrollTop||0;
  p.innerHTML=
    '<div class="msp-header">'+
      '<button class="msp-back" onclick="mapPanelBack()">&#8592; '+parentName+'</button>'+
      '<button class="msp-close" onclick="mapPanelClose()">&#215;</button>'+
    '</div>'+
    '<div class="msp-title-bar"><span class="msp-title">'+name+'</span></div>'+
    '<div class="msp-body">'+
      (descr?'<div class="msp-text msp-mb">'+descr+'</div>':'<div class="msp-empty-sm">Aprašymo nėra</div>')+
      '<div class="msp-inline-btns">'+
        '<button class="msp-ibtn" onclick="mapBtnAtrodo(\''+cd.id+'\',\'comp\')">&#128444; Kaip atrodo</button>'+
        '<button class="msp-ibtn" onclick="mapBtnMontuoti(\''+cd.id+'\',\'comp\')">&#128295; Kaip montuoti</button>'+
        '<button class="msp-ibtn" onclick="mapBtnPirkti(\''+cd.id+'\',\'comp\')">&#128222; Kur pirkti?</button>'+
      '</div>'+
      priceHtml+modelsHtml+subHtml+
    '</div>';
  p.style.display='flex';
  document.body.classList.add('msp-panel-open');
  const _r=document.querySelector('.right'); if(_r) _r.style.display='flex';
  if(prevScrollC) requestAnimationFrame(()=>{ const b=p.querySelector('.msp-body'); if(b) b.scrollTop=prevScrollC; });
  // Kamera → cam_click komponentui, tx/ty/tz = dabartinė komp. pozicija
  const _cCamComp=KB.components[_selComp?.id]?.cam_click;
  if(_3d?.orb&&_3d?.applyOrbit&&typeof _camFlyTo==='function'&&_selComp){
    // userData.cx/cy/cz visada teisingi (tinklelio koordinatės, BEZ delta)
    // GLB komponentai: scene pozicija = cx + delta_x, bet orbit target = cx (centras)
    const _cs3d = KB.components[_selComp.id]?.scene_3d || {};
    const _ctx = (_selComp.cx ?? 0) + (_cs3d.delta_x || 0);
    const _cty = (_selComp.cy ?? 0) + (_cs3d.delta_y || 0);
    const _ctz = (_selComp.cz ?? 0);
    if(_cCamComp){
      _camFlyTo({r:_cCamComp.r, theta:_cCamComp.theta, phi:_cCamComp.phi,
                 tx:_ctx, ty:_cty, tz:_ctz}, _3d.orb, _3d.applyOrbit);
    } else {
      _camFlyTo({r:2, theta:_3d.orb.theta, phi:1.2,
                 tx:_ctx, ty:_cty, tz:_ctz}, _3d.orb, _3d.applyOrbit);
    }
    _userMovedCam=true;
  }
}

function mapClickComp(compId) {
  const m=_findCompMesh(compId);
  if(m) {
    _selComp=m.userData; _panelLevel='comp'; _renderPanel();
    const _cCam = KB.components[compId]?.cam_click;
    if (_cCam && _3d?.orb && _3d?.applyOrbit && typeof _camFlyTo === 'function') {
      _camFlyTo(_cCam, _3d.orb, _3d.applyOrbit);
      _userMovedCam = true;
    }
    return;
  }
  const comp=KB.components[compId]; if(!comp) return;
  let oid=_selObj, pid=comp.parent_id, level=2;
  while(pid&&KB.components[pid]){ pid=KB.components[pid].parent_id; level++; }
  _selComp={id:compId,name:comp.name||compId,oid:oid||_selObj,level,
    objPosX:0,objPosY:0,cx:0,cy:0,cz:0};
  _panelLevel='comp'; _renderPanel();
  const _cCam = KB.components[compId]?.cam_click;
  if (_cCam && _3d?.orb && _3d?.applyOrbit && typeof _camFlyTo === 'function') {
    _camFlyTo(_cCam, _3d.orb, _3d.applyOrbit);
    _userMovedCam = true;
  }
}

function mapToggleSub(compId) {
  const isOpen=_openedComps.includes(compId);
  if(isOpen) {
    _openedComps=_openedComps.filter(id=>id!==compId);
    const subEl=document.getElementById('msp-sub-'+compId);
    const btn=document.querySelector('[data-tog="'+compId+'"]');
    if(subEl) subEl.style.display='none';
    if(btn) btn.innerHTML='&#9658;';
  } else {
    _openedComps=[..._openedComps,compId];
    const subEl=document.getElementById('msp-sub-'+compId);
    if(subEl && subEl.children.length===0) {
      const parentRow=document.getElementById('msp-row-'+compId);
      const depth=parentRow
        ? Math.round((parseInt(parentRow.style.paddingLeft)||8)/14)
        : 1;
      subEl.innerHTML=_renderPanelCompList(_compChildren(compId), depth+1);
    }
    if(subEl) subEl.style.display='block';
    const btn=document.querySelector('[data-tog="'+compId+'"]');
    if(btn) btn.innerHTML='&#9662;';
  }
}

function mapPanelBack() {
  if(_panelLevel!=='comp') return;
  const comp=KB.components[_selComp?.id];
  if(comp&&comp.parent_id&&KB.components[comp.parent_id]) {
    const pm=_findCompMesh(comp.parent_id);
    _selComp=pm?pm.userData:{id:comp.parent_id,name:KB.components[comp.parent_id].name||comp.parent_id,oid:_selObj,level:1,objPosX:0,objPosY:0,cx:0,cy:0,cz:0};
    _renderPanel();
    const _pCam=KB.components[comp.parent_id]?.cam_click;
    if(_pCam&&_3d?.orb&&_3d?.applyOrbit&&typeof _camFlyTo==='function'){
      _camFlyTo(_pCam,_3d.orb,_3d.applyOrbit); _userMovedCam=true;
    }
    return;
  }
  _selComp=null; _panelLevel='obj'; _renderPanel();
  const _oBkCam=KB.objects[_selObj]?.scene_3d?.cam_click;
  if(_oBkCam&&_3d?.orb&&_3d?.applyOrbit&&typeof _camFlyTo==='function'){
    _camFlyTo(_oBkCam,_3d.orb,_3d.applyOrbit); _userMovedCam=true;
  }
}

function mapPanelClose() {
  _selObj=null;_selComp=null;_openedComps=[];_3dSel=null;_panelLevel='obj';
  _hidePanel();
  const canvas=document.getElementById('map-canvas');
  const selSys=parseInt(document.getElementById('map-sys')?.value||'0');
  if(canvas&&selSys) _build3d(canvas);
}

function mapSelectPkg(oid, pkgIdx) {
  window._activePackage = {oid, pkgIdx};
  const canvas = document.getElementById('map-canvas');
  if(canvas) _build3d(canvas);
  _renderPanel();
}

function _findCompMesh(compId) {
  return _3d?._compMeshes?.find(m=>m.userData&&m.userData.id===compId&&m.userData.type==='comp')||null;
}

function mapShowShoppingList(scope) {
  let roots=[];
  if(scope==='obj'&&_selObj) roots=[_selObj];
  else roots=[..._sysObjsRef];
  if(!roots.length){toast('Nera sistemos');return;}

  roots=roots.filter(oid=>!_NO_PRICE_OBJS.has(oid));
  if(!roots.length){toast('Komponentu nerasta');return;}

  window._shopRoots=roots;
  window._shopSelections={};

  const isAdmin = typeof saveAllFiles === 'function';

  const needPick=roots.filter(oid=>{
    const kb=KB.objects[oid]||{};
    if(isAdmin) return (kb.packages||[]).length>0 || (kb.models||[]).length>1;
    return (kb.models||[]).length>1;
  });

  roots.filter(oid=>!needPick.includes(oid)).forEach(oid=>{
    const kb=KB.objects[oid]||{};
    const hasPkg=(kb.packages||[]).length>0;
    window._shopSelections[oid]=hasPkg && isAdmin
      ? {type:'pkg',idx:0}
      : {auto:true};
  });

  if(needPick.length>0){
    _showShoppingStep1(needPick, isAdmin);
  } else {
    _openShopModal('Pirkimo sąrašas','<div id="sl-result-wrap"></div>');
    _renderShoppingResult();
  }
}

function _showShoppingStep1(needPick, isAdmin){
  const selHTML=needPick.map(oid=>{
    const kb=KB.objects[oid]||{};
    const meta=KB.objects_meta[oid]||{};
    const pkgs=kb.packages||[];
    const models=kb.models||[];

    let opts='';
    if(isAdmin && pkgs.length>0){
      opts=pkgs.map((p,i)=>{
        const m=models.find(m=>m.id===p.obj_model_id);
        const sub=m?m.name||p.obj_model_id:'';
        return '<button class="sl-pkg-btn" onclick="shopSelectPkg(\''+oid+'\',\'pkg\','+i+',this)">'+
          (p.name||('Variantas '+(i+1)))+
          (sub?'<span class="sl-pkg-sub">'+sub+'</span>':'')+
          '</button>';
      }).join('');
    } else {
      opts=models.map((m,i)=>{
        return '<button class="sl-pkg-btn" onclick="shopSelectPkg(\''+oid+'\',\'model\','+i+',this)">'+
          (m.name||('Modelis '+(i+1)))+
          (m.price_eur?'<span class="sl-pkg-sub">'+m.price_eur+' €</span>':'')+
          '</button>';
      }).join('');
    }

    return '<div class="sl-step-obj">'+
      '<div class="sl-step-obj-name">'+(meta.name||oid)+'</div>'+
      '<div class="sl-pkg-btns">'+opts+'</div>'+
      '</div>';
  }).join('');

  const _body=
    '<div class="sl-step-wrap">'+
    '<div class="sl-step-title">Pasirinkite modelį:</div>'+
    selHTML+
    '</div><div id="sl-result-wrap"></div>';
  _openShopModal('Pirkimo sąrašas', _body);
}

function _openShopModal(title, body){
  if(window.innerWidth <= 768){
    // Mobiliame: rodyti tiesiai map-side-panel viduje, ne kaip atskirą modalą
    const p = _panelEl();
    if(p){
      p.innerHTML =
        '<div class="msp-head">' +
          '<button class="msp-back" onclick="_renderPanel()">&#8592; Atgal</button>' +
          '<div class="msp-obj-name">' + title + '</div>' +
          '<button class="msp-close" onclick="_hidePanel()">&#x2715;</button>' +
        '</div>' +
        '<div class="msp-body">' + body + '</div>';
      p.style.display = 'flex';
      document.body.classList.add('msp-panel-open');
      const _rs=document.querySelector('.right'); if(_rs) _rs.style.display='flex';
      return;
    }
  }
  openModal(title, body, null);
  const sb=document.querySelector('#modal-box > div:last-child');
  if(sb) sb.style.display='none';
}

function _shopClose(){
  if(window.innerWidth<=768){ _hidePanel(); }
  else { closeModal(); }
}

function shopSelectPkg(oid,type,idx,btn){
  if(type==='pkg'){
    window._shopSelections[oid]={type:'pkg',idx};
  } else {
    window._shopSelections[oid]={type:'model',idx};
  }
  btn.closest('.sl-pkg-btns').querySelectorAll('.sl-pkg-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const isAdmin = typeof saveAllFiles === 'function';
  const needPick=window._shopRoots.filter(o=>{
    const kb=KB.objects[o]||{};
    if(isAdmin) return (kb.packages||[]).length>0||(kb.models||[]).length>1;
    return (kb.models||[]).length>1;
  });
  if(needPick.every(o=>window._shopSelections[o]!==undefined)) _renderShoppingResult();
}

function _renderShoppingResult(){
  const roots=window._shopRoots;
  const sels=window._shopSelections;
  let grand=0;

  function _resolveSel(oid){
    const kb=KB.objects[oid]||{};
    const sel=sels[oid]||{};
    if(sel.type==='pkg'){
      const pkg=(kb.packages||[])[sel.idx];
      return {pkg, modelId: pkg?.obj_model_id||null};
    } else if(sel.type==='model'){
      const m=(kb.models||[])[sel.idx];
      const autoPkg=(kb.packages||[])[0]||null;
      return {pkg:autoPkg, modelId: m?.id||null};
    } else {
      const autoPkg=(kb.packages||[])[0]||null;
      return {pkg:autoPkg, modelId: (kb.models||[])[0]?.id||null};
    }
  }

  const listHtml=roots.map(oid=>{
    const kb=KB.objects[oid]||{};
    const meta=KB.objects_meta[oid]||{};
    const {pkg,modelId}=_resolveSel(oid);

    const m=modelId?(kb.models||[]).find(m=>m.id===modelId):(kb.models||[])[0];
    const objPrice=m?.price_eur||0;
    const objModelLabel=m?.name||'';
    grand+=objPrice;

    const compRows=_buildCompRowsForPkg(oid,pkg);
    compRows.forEach(r=>{grand+=r.price;}); 

    const compHtml=compRows.map(r=>{
      const priceHtml = r.includedInPrice
        ? '<span style="font-size:10px;color:#2e7d32;margin-left:4px">&#10003; įeina į kainą</span>'
        : (r.price ? '<span class="sl-price">'+r.price+(r.qty>1?' ×'+r.qty:'')+' \u20ac</span>' : '');
      return '<div class="sl-row sl-depth-0">'+
        '<div class="sl-row-main">'+
          '<span class="sl-bullet" style="color:'+(r.includedInPrice?'#2e7d32':'#e65100')+'">&#9679;</span>'+
          '<span class="sl-name">'+r.name+'</span>'+
          priceHtml+
        '</div>'+
        (r.modelName||r.supplier?'<div class="sl-supplier">'+(r.modelName||'')+
          (r.supplier&&r.modelName?' · ':'')+
          (r.supplier||'')+'</div>':'')+
      '</div>';
    }).join('');

    return '<div class="sl-obj-block">'+
      '<div class="sl-obj-head">'+
        '<span class="sl-obj-title">'+(meta.name||oid)+'</span>'+
        (objPrice?'<span class="sl-price">'+objPrice+' \u20ac</span>':'')+
      '</div>'+
      (objModelLabel?'<div class="sl-supplier">'+objModelLabel+'</div>':'')+
      (compRows.length?'<div class="sl-comps-label">Sudėtis (&#10003; įeina į kainą · &#9679; perkama atskirai):</div>'+compHtml:'')+
      '</div>';
  }).join('');

  document.getElementById('sl-result-wrap').innerHTML=
    '<div class="sl-wrap" style="margin-top:12px">'+listHtml+'</div>'+
    '<div class="sl-total"><span class="sl-grand">Viso: <b>~'+grand+' \u20ac</b></span></div>'+
    '<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">'+
      '<button class="btn sm pri" onclick="mapDownloadInvoice()">&#8681; Atsisiusti sarasa</button>'+
      '<button class="btn sm" onclick="mapShowOrderForm()" style="background:#e8f5e9;color:#2e7d32;border-color:#a5d6a7">&#128222; Uzsisakyti is musu</button>'+
      '<button class="btn sm" onclick="_shopClose()" style="background:var(--s2)">Uzdaryti</button>'+
    '</div>';

  window._lastShoppingGrand=grand;
}

function _buildCompRowsForPkg(oid,pkg){
  const rows=[];
  Object.entries(KB.components||{})
    .filter(([cid])=>(KB.components_meta[cid]?.parent_id||KB.components[cid]?.parent_id)===oid)
    .forEach(([cid,c])=>{
      const isSeparate = c.in_package === false;
      const idx=pkg?.comp_selections?.[cid]??-1;
      const models=c.models||[];
      const sel=idx>=0?models[idx]:models[0];
      const qty=c.pricing?.quantity_per_system||1;

      const price = isSeparate ? (sel?.price_eur||c.pricing?.part_price||0)*qty : 0;

      rows.push({
        name:      c.name||cid,
        modelName: sel?.name||'',
        supplier:  sel?.supplier||'',
        price,
        qty,
        inPkg:     !isSeparate,
        includedInPrice: !isSeparate,
      });
      _buildCompRowsForPkg(cid,pkg).forEach(r=>rows.push(r));
    });
  return rows;
}

function _showShoppingFull(roots){
  let grand=0;
  const listHtml=roots.map(oid=>{
    const kb=KB.objects[oid]||{};
    const meta=KB.objects_meta[oid]||{};
    const m=(kb.models||[])[0];
    const objPrice=m?.price_eur||0;
    grand+=objPrice;
    const children=_buildCompTree(oid,oid);
    function sumC(ns){ns.forEach(n=>{
      if(n.in_package!==false){sumC(n.children||[]);return;}
      grand+=(n.models?.[0]?.price_eur||n.pricing?.part_price||0)*(n.pricing?.quantity_per_system||1);
      sumC(n.children||[]);
    });}
    sumC(children);
    return '<div class="sl-obj-block">'+
      '<div class="sl-obj-head">'+
        '<span class="sl-obj-title">'+(meta.name||oid)+'</span>'+
        (objPrice?'<span class="sl-price">'+objPrice+' \u20ac</span>':'')+
      '</div>'+
      (m?.name?'<div class="sl-supplier">'+m.name+(m.notes?' · '+m.notes:'')+'</div>':'')+
      (children.length?'<div class="sl-comps-label">Sud\u0117tis (\u2713 \u012feina \u012f kain\u0105 \u00b7 \u25cf perkama atskirai):</div>'+_renderTreeRows(children,0):'')+
      '</div>';
  }).join('');

  const _body=
    '<div class="sl-wrap">'+listHtml+'</div>'+
    '<div class="sl-total"><span class="sl-grand">Viso: <b>~'+grand+' \u20ac</b></span></div>'+
    '<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">'+
      '<button class="btn sm pri" onclick="mapDownloadInvoice()">&#8681; Atsisi\u0173sti s\u0105ra\u0161\u0105</button>'+
      '<button class="btn sm" onclick="mapShowOrderForm()" style="background:#e8f5e9;color:#2e7d32;border-color:#a5d6a7">&#128222; U\u017esisakyti i\u0161 m\u016bs\u0173</button>'+
      '<button class="btn sm" onclick="_shopClose()" style="background:var(--s2)">U\u017edaryti</button>'+
    '</div>';
  openModal('Pirkimo s\u0105ra\u0161as', _body, null);
  const sb=document.querySelector('#modal-box > div:last-child');
  if(sb) sb.style.display='none';

  window._shopRoots=roots;
  window._shopSelections={};
  window._lastShoppingGrand=grand;
}

function _buildCompTree(oid,parentId,level){
  level=level||1;
  return Object.entries(KB.components||{})
    .filter(([cid])=>(KB.components_meta[cid]?.parent_id||KB.components[cid]?.parent_id)===parentId)
    .map(([cid,c])=>({
      id:cid,name:c.name||cid,level,
      in_package: c.in_package,   
      pricing:c.pricing||{},models:c.models||[],
      children:_buildCompTree(oid,cid,level+1)
    }));
}

function _renderTreeRows(nodes,depth){
  return nodes.map(n=>{
    const m=n.models?.[0];
    const qty=n.pricing?.quantity_per_system||1;
    const unitPrice=m?.price_eur||n.pricing?.part_price||0;
    const total=unitPrice*qty;
    const isSeparate = n.in_package===false;
    const priceHtml = isSeparate
      ? (total?'<span class="sl-price">'+total+(qty>1?' ×'+qty:'')+' \u20ac</span>':'')
      : '<span style="font-size:10px;color:#2e7d32;margin-left:4px">&#10003; \u012feina \u012f kain\u0105</span>';
    const bulletColor = isSeparate ? '#e65100' : '#2e7d32';
    return '<div class="sl-row sl-depth-'+Math.min(depth,3)+'">'+
      '<div class="sl-row-main">'+
        '<span class="sl-bullet" style="color:'+bulletColor+'">'+(depth===0?'&#9679;':'&#9675;')+'</span>'+
        '<span class="sl-name">'+n.name+'</span>'+
        priceHtml+
      '</div>'+
      (m?'<div class="sl-supplier">'+(m.name||'')+(m.supplier?' · '+m.supplier:'')+'</div>':'')+
      (n.children.length?_renderTreeRows(n.children,depth+1):'')+
    '</div>';
  }).join('');
}

function mapDownloadInvoice(){
  const roots=window._shopRoots;
  const sels=window._shopSelections||{};
  if(!roots||!roots.length) return;

  const date=new Date().toLocaleDateString('lt-LT');
  const nr='SAR-'+Date.now().toString().slice(-6);
  let grand=0;

  const rowsHtml=roots.map(oid=>{
    const kb=KB.objects[oid]||{};
    const meta=KB.objects_meta[oid]||{};
    const sel=sels[oid]||{};
    let pkg=null, modelId=null;
    if(sel.type==='pkg'){
      pkg=(kb.packages||[])[sel.idx];
      modelId=pkg?.obj_model_id||null;
    } else if(sel.type==='model'){
      modelId=(kb.models||[])[sel.idx]?.id||null;
    } else {
      modelId=(kb.models||[])[0]?.id||null;
    }

    const m=modelId?(kb.models||[]).find(m=>m.id===modelId):(kb.models||[])[0];
    const objPrice=m?.price_eur||0;
    const objLabel=[m?.name,m?.notes].filter(Boolean).join(' · ');
    grand+=objPrice;

    const compRows=_buildCompRowsForPkg(oid,pkg);
    compRows.forEach(r=>{grand+=r.price;});

    const objRow='<tr style="background:#f0f0f0">'+
      '<td style="font-weight:700">'+(meta.name||oid)+'</td>'+
      '<td style="text-align:center">1</td>'+
      '<td style="font-size:10px;color:#555">'+(objLabel||'-')+'</td>'+
      '<td style="text-align:right;font-weight:700">'+(objPrice?objPrice+' €':'-')+'</td>'+
      '</tr>';

    const compHtml=compRows.length
      ?compRows.map(r=>
        '<tr>'+
          '<td style="padding-left:16px;color:#333">'+r.name+'</td>'+
          '<td style="text-align:center">'+r.qty+'</td>'+
          '<td style="font-size:10px;color:#555">'+([r.modelName,r.supplier].filter(Boolean).join(' · ')||'-')+'</td>'+
          '<td style="text-align:right">'+(r.price?r.price+' €':'-')+'</td>'+
        '</tr>'
      ).join('')
      :'';

    return objRow+compHtml+'<tr><td colspan="4" style="padding:3px 0;border:none"></td></tr>';
  }).join('');

  const html='<!DOCTYPE html><html lang="lt"><head><meta charset="UTF-8">'+
    '<title>Pirkimo sarasas '+nr+'</title>'+
    '<style>'+
      '*{margin:0;padding:0;box-sizing:border-box}'+
      'body{font-family:Arial,sans-serif;font-size:12px;color:#000;padding:28px}'+
      'h1{font-size:17px;font-weight:700;margin-bottom:3px}'+
      '.meta{color:#555;font-size:10px;margin-bottom:18px}'+
      'table{width:100%;border-collapse:collapse;margin-top:10px}'+
      'th{background:#333;color:#fff;padding:6px 8px;text-align:left;font-size:11px}'+
      'td{padding:5px 8px;border-bottom:1px solid #ccc;vertical-align:top}'+
      '.tf td{border-top:2px solid #000;font-weight:700;font-size:13px;padding-top:8px}'+
      '@media print{body{padding:12px}}'+
    '</style></head><body>'+
    '<h1>Pirkimo sarasas</h1>'+
    '<div class="meta">'+nr+' &nbsp;|&nbsp; '+date+' &nbsp;|&nbsp; IBNVS sistema</div>'+
    '<table>'+
      '<thead><tr>'+
        '<th>Objektas / Komponentas</th>'+
        '<th style="width:50px">Kiek.</th>'+
        '<th style="width:160px">Modelis / Tiekejas</th>'+
        '<th style="width:80px;text-align:right">Kaina</th>'+
      '</tr></thead>'+
      '<tbody>'+rowsHtml+'</tbody>'+
      '<tfoot><tr class="tf">'+
        '<td colspan="3">VISO (apytiksliai)</td>'+
        '<td style="text-align:right">'+grand+' €</td>'+
      '</tr></tfoot>'+
    '</table>'+
    '<p style="margin-top:14px;font-size:9px;color:#777">Kainos orientacines. Sugeneruota: IBNVS</p>'+
    '</body></html>';

  const w=window.open('','_blank','width=780,height=680');
  if(!w){toast('Narsykle blokavo langa -- leisk popup');return;}
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(()=>w.print(),350);
}

function mapShowOrderForm(){
  const grand = window._lastShoppingGrand || 0;
  const grandStr = grand > 0 ? '~' + grand + ' \u20ac' : '';

  const roots = window._shopRoots || [];
  const sels  = window._shopSelections || {};
  let sarasLines = [];
  roots.forEach(oid => {
    const kb   = KB.objects[oid] || {};
    const meta = KB.objects_meta[oid] || {};
    const sel  = sels[oid] || {};
    let modelLabel = '';
    if (sel.type === 'pkg') {
      const pkg = (kb.packages||[])[sel.idx];
      const m   = (kb.models||[]).find(m => m.id === pkg?.obj_model_id);
      modelLabel = pkg?.name || (m?.name ? m.name : '');
    } else if (sel.type === 'model') {
      const m = (kb.models||[])[sel.idx];
      modelLabel = m?.name || '';
    } else {
      const m = (kb.models||[])[0];
      modelLabel = m?.name || '';
    }
    const price = (() => {
      const m2 = modelLabel ? (kb.models||[]).find(m=>m.name===modelLabel) : (kb.models||[])[0];
      return m2?.price_eur ? m2.price_eur + ' \u20ac' : '';
    })();
    sarasLines.push('<b>'+(meta.name||oid)+'</b>'+(modelLabel?' &mdash; '+modelLabel:'')+(price?' ('+price+')':''));
    _buildCompRowsForPkg(oid, sel.type==='pkg'?(kb.packages||[])[sel.idx]:null)
      .forEach(r => sarasLines.push('&nbsp;&nbsp;&#8226; '+r.name+(r.modelName?' &mdash; '+r.modelName:'')+(r.price?' ('+r.price+' \u20ac)':'')));
  });
  const sarasHtml = sarasLines.join('<br>');

  const ordItems = [];
  roots.forEach(oid => {
    const kb  = KB.objects[oid] || {};
    const sel = sels[oid] || {};
    let modelId = null;
    if (sel.type === 'pkg') {
      const pkg = (kb.packages||[])[sel.idx];
      modelId = pkg?.obj_model_id || null;
    } else if (sel.type === 'model') {
      modelId = (kb.models||[])[sel.idx]?.id || null;
    } else {
      modelId = (kb.models||[])[0]?.id || null;
    }
    ordItems.push({ type: 'obj', id: oid, model_id: modelId });
    Object.entries(KB.components || {})
      .filter(([cid]) => (KB.components_meta[cid]?.parent_id || KB.components[cid]?.parent_id) === oid)
      .forEach(([cid, c]) => {
        if (c.in_package === false) {
          const pkg = sel.type === 'pkg' ? (kb.packages||[])[sel.idx] : null;
          const idx = pkg?.comp_selections?.[cid] ?? -1;
          const mId = idx >= 0 ? (c.models||[])[idx]?.id : (c.models||[])[0]?.id || null;
          ordItems.push({ type: 'comp', id: cid, parent_id: oid, model_id: mId });
        }
      });
  });
  const itemsEncoded = encodeURIComponent(JSON.stringify(ordItems));

  const body =
    '<div id="ord-wrap" style="display:flex;flex-direction:column;gap:10px;margin-top:4px">' +
    (grandStr ? '<div style="font-size:13px;font-weight:700;color:var(--pri);margin-bottom:2px">Pirkimo suma: '+grandStr+'</div>' : '') +
    '<div style="font-size:11px;color:var(--td);margin-bottom:4px">Palikite kontaktus — susisieksime per 1 darbo dieną ir aptarsime detalias kainas bei montavimą.</div>' +
    '<div><label style="font-size:10px;font-weight:600;color:var(--td);display:block;margin-bottom:3px">Vardas *</label>' +
      '<input id="ord-name" type="text" placeholder="Jūsų vardas" style="width:100%;padding:7px 10px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:12px;font-family:inherit;background:var(--bg)"></div>' +
    '<div><label style="font-size:10px;font-weight:600;color:var(--td);display:block;margin-bottom:3px">Telefonas</label>' +
      '<input id="ord-tel" type="tel" placeholder="+370 600 00000" style="width:100%;padding:7px 10px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:12px;font-family:inherit;background:var(--bg)"></div>' +
    '<div><label style="font-size:10px;font-weight:600;color:var(--td);display:block;margin-bottom:3px">El. paštas</label>' +
      '<input id="ord-email" type="email" placeholder="jusu@email.lt" style="width:100%;padding:7px 10px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:12px;font-family:inherit;background:var(--bg)"></div>' +
    '<div><label style="font-size:10px;font-weight:600;color:var(--td);display:block;margin-bottom:3px">Žinutė (neprivaloma)</label>' +
      '<textarea id="ord-msg" rows="2" placeholder="Sklypo vieta, klausimai..." style="width:100%;padding:7px 10px;border:1.5px solid var(--b1);border-radius:var(--r);font-size:12px;font-family:inherit;background:var(--bg);resize:vertical"></textarea></div>' +
    '<div id="ord-err" style="color:#c62828;font-size:11px;display:none"></div>' +
    '<div style="display:flex;gap:8px;margin-top:4px">' +
      '<button class="btn pri" id="ord-send-btn" onclick="mapSendOrder(\''+encodeURIComponent(sarasHtml)+'\','+grand+',\''+itemsEncoded+'\')" style="flex:1">&#128222; Siusti uzsakyma</button>' +
      '<button class="btn ghost" onclick="closeModal()">Atšaukti</button>' +
    '</div></div>';

  openModal('Užsakymas iš konstruktoriaus', body, null);
}

function mapSendOrder(sarasEncoded, grand, itemsEncoded){
  const name  = (document.getElementById('ord-name')?.value  || '').trim();
  const tel   = (document.getElementById('ord-tel')?.value   || '').trim();
  const email = (document.getElementById('ord-email')?.value || '').trim();
  const msg   = (document.getElementById('ord-msg')?.value   || '').trim();
  const errEl = document.getElementById('ord-err');
  const btn   = document.getElementById('ord-send-btn');

  if (!name)        { errEl.textContent='Įveskite vardą'; errEl.style.display=''; return; }
  if (!tel && !email){ errEl.textContent='Įveskite telefoną arba el. paštą'; errEl.style.display=''; return; }
  errEl.style.display='none';

  btn.disabled=true; btn.textContent='Siunčiama...';

  const sarasHtml = decodeURIComponent(sarasEncoded);
  let items = [];
  try { items = JSON.parse(decodeURIComponent(itemsEncoded || '%5B%5D')); } catch(e) {}

  const orderUrl = (typeof API_URL !== 'undefined' ? API_URL : './api.php').replace('api.php','order.php');

  fetch(orderUrl, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({
      vardas:      name,
      tel:         tel,
      email:       email,
      zinute:      msg,
      saraso_html: sarasHtml,
      grand_total: grand,
      items:       items,  
    })
  })
  .then(r => r.json())
  .then(d => {
    if (d.ok) {
      document.getElementById('ord-wrap').innerHTML =
        '<div style="text-align:center;padding:20px 0">' +
        '<div style="font-size:32px;margin-bottom:10px">&#9989;</div>' +
        '<div style="font-size:14px;font-weight:700;color:var(--pri);margin-bottom:6px">Užsakymas gautas!</div>' +
        '<div style="font-size:12px;color:var(--td);margin-bottom:4px">'+d.msg+'</div>' +
        '<div style="font-size:10px;color:var(--td)">Užsakymo nr.: <b>'+(d.nr||'')+'</b></div>' +
        '<button class="btn ghost sm" onclick="closeModal()" style="margin-top:14px">Uždaryti</button>' +
        '</div>';
    } else {
      btn.disabled=false; btn.textContent='\u260E Siusti uzsakyma';
      errEl.textContent = d.err || 'Klaida. Bandykite dar kartą.';
      errEl.style.display='';
    }
  })
  .catch(() => {
    btn.disabled=false; btn.textContent='\u260E Siusti uzsakyma';
    errEl.textContent='Ryšio klaida. Patikrinkite interneto ryšį.';
    errEl.style.display='';
  });
}

function mapBtnAtrodo(id,type) {
  openModal('Kaip atrodo',(type==='obj'?(KB.objects_meta[id]?.name||id):(KB.components[id]?.name||id)),
    '<div style="text-align:center;padding:30px 20px;color:var(--td)">'+
    '<div style="font-size:48px;margin-bottom:12px">&#128444;</div>'+
    '<div style="font-size:13px;margin-bottom:6px;font-weight:600">Foto / video</div>'+
    '<div style="font-size:11px">Turinys bus pridetas prie sio elemento</div></div>',null);
}
function mapBtnMontuoti(id,type) {
  openModal('Kaip montuoti',(type==='obj'?(KB.objects_meta[id]?.name||id):(KB.components[id]?.name||id)),
    '<div style="text-align:center;padding:30px 20px;color:var(--td)">'+
    '<div style="font-size:48px;margin-bottom:12px">&#128295;</div>'+
    '<div style="font-size:13px;margin-bottom:6px;font-weight:600">Montavimo instrukcija</div>'+
    '<div style="font-size:11px">Tekstas ir video bus pridetas</div></div>',null);
}
function mapBtnPirkti(id,type) {
  const comp=type==='comp'?KB.components[id]:null;
  const models=(comp?.models||[]).filter(m=>m.supplier||m.price_eur);
  const bodyHtml=models.length?
    '<div style="padding:12px">'+
    models.map(m=>'<div style="display:flex;align-items:center;gap:10px;padding:8px;border:1px solid var(--b1);border-radius:var(--r);margin-bottom:6px">'+
      '<div style="flex:1"><div style="font-weight:600;font-size:12px">'+(m.name||'Modelis')+'</div>'+
      (m.supplier?'<div style="font-size:11px;color:var(--td)">'+m.supplier+'</div>':'')+
      '</div>'+
      (m.price_eur?'<div style="font-weight:700;color:var(--pri)">'+m.price_eur+' €</div>':'')+
    '</div>').join('')+
    '</div>':
    '<div style="text-align:center;padding:30px 20px;color:var(--td)">'+
    '<div style="font-size:48px;margin-bottom:12px">&#128222;</div>'+
    '<div style="font-size:11px">Tiekėjų sarasas bus pridetas</div></div>';
  openModal('Kur pirkti: '+(comp?.name||id),bodyHtml,null);
}

function _buildEmpty(canvas) {
  if(_3d){_3d.stop();_3d=null;}
  const cont=canvas.parentElement;
  const W=cont.clientWidth||900, H=cont.clientHeight||580;
  canvas.width=W; canvas.height=H;
  const scene=new THREE.Scene(); scene.background=null;
  const camera=new THREE.PerspectiveCamera(42,W/H,0.1,300);
  const renderer=new THREE.WebGLRenderer({canvas,antialias:true,preserveDrawingBuffer:true,alpha:true});
  renderer.setSize(W,H); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
  const CX=2*_CELL; camera.position.set(CX,2,10); camera.lookAt(CX,2,0);
  scene.add(new THREE.AmbientLight(0xffffff,(function(){try{var v=parseFloat(localStorage.getItem("adm_amb"));return(v>0?v:2.5);}catch(e){return 2.5;}})())); scene.add(new THREE.HemisphereLight(0xffffff,0x8898aa,1.0));
  _drawBackground(scene,2*_CELL); _drawAxisLabels(scene,null,0);
  _txt3d(scene,'Pasirinkite sistemos tipa',CX,2.8*_CELL,0,'#4a9d6f',18);
  let animId,stopped=false;
  function animate(){if(stopped)return;animId=requestAnimationFrame(animate);renderer.render(scene,camera);}
  animate();
  _3d={stop:()=>{stopped=true;cancelAnimationFrame(animId);renderer.dispose();},
    orb:{},applyOrbit:()=>{},DEF_ORB:{},_removeComps:()=>{},_compMeshes:[]};
}

function _addSphere(scene, pos, col, r, userData, objMeshes, isSelected, s3d) {
  const mx = pos.x + (s3d?.delta_x||0);
  const my = pos.y + (s3d?.delta_y||0);
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(r,18,18),
    new THREE.MeshPhongMaterial({color:col,shininess:80,
      emissive:isSelected?0x0d3a80:0x000000,emissiveIntensity:isSelected?0.25:0})
  );
  mesh.position.set(mx,my,0); mesh.userData=userData;
  scene.add(mesh); objMeshes.push(mesh);
}

function _addCompMesh(scene, compMeshes, comp, cx, cy, cz, col, userData, opts) {
  opts = opts || {};
  const _opacity = opts.opacity != null ? opts.opacity : 1.0;
  const _transparent = opts.transparent || false;
  const s3d = comp.scene_3d || KB.components[userData && userData.id]?.scene_3d;

  if (s3d?.glb && typeof THREE.GLTFLoader !== 'undefined') {
    const placeholder = new THREE.Mesh(
      new THREE.BoxGeometry(0.5,0.5,0.5),
      new THREE.MeshPhongMaterial({color:col,shininess:70,transparent:_transparent,opacity:_opacity})
    );
    placeholder.position.set(cx,cy,cz);
    placeholder.userData = userData;
    scene.add(placeholder); compMeshes.push(placeholder);

    THREE.Cache.enabled = false;
    const loader = new THREE.GLTFLoader();
    const _glbUrl = '/shared/glb/' + s3d.glb + '?v=' + (window._glbVer||(window._glbVer=localStorage.getItem('glb_ver')||'1'));
    loader.load(_glbUrl, gltf => {
      const idx = compMeshes.indexOf(placeholder);
      if (idx >= 0) {
        scene.remove(placeholder);
        compMeshes.splice(idx, 1);
      }
      const model = gltf.scene;
      const _sx = s3d.scale_x || s3d.scale || 1;
      const _sy = s3d.scale_y || s3d.scale || 1;
      const _sz = s3d.scale_z || s3d.scale || 1;
      model.scale.set(_sx, _sy, _sz);
      model.rotation.set(
        (s3d.rotation_x||0)*Math.PI/180,
        (s3d.rotation_y||0)*Math.PI/180,
        (s3d.rotation_z||0)*Math.PI/180
      );
      model.position.set(
        cx + (s3d.delta_x||0),
        cy + (s3d.delta_y||0) + (s3d.offset_y||0),
        cz
      );
      model.userData = userData;
      model.traverse(c => { if(c.isMesh) { c.userData = userData; compMeshes.push(c); } });
      scene.add(model);
    }, null, () => {});
    return placeholder;
  }

  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.5,0.5,0.5),
    new THREE.MeshPhongMaterial({color:col,shininess:70,transparent:_transparent,opacity:_opacity})
  );
  mesh.position.set(cx,cy,cz);
  mesh.userData = userData;
  scene.add(mesh); compMeshes.push(mesh);
  return mesh;
}


// Randa objekto/komponento 3D poziciją iš compMeshes/objMeshes
function _getEntityPos(id, type) {
  if (!_3d) return null;
  const meshes = type === 'obj' ? (_3d._objMeshes || []) : (_3d._compMeshes || []);
  const mesh = meshes.find(m => m.userData && m.userData.id === id && m.userData.type === type);
  if (mesh) {
    const pos = new THREE.Vector3();
    mesh.getWorldPosition(pos);
    return pos;
  }
  // Fallback: iš userData.cx/cy/cz
  const comp = _3d._compMeshes && _3d._compMeshes.find(m => m.userData && m.userData.id === id);
  if (comp && comp.userData.cx !== undefined) {
    return new THREE.Vector3(comp.userData.cx, comp.userData.cy, comp.userData.cz || 0);
  }
  return null;
}

// Sklandžiai animuoja kamerą į cam_click poziciją per ~500ms
function _camFlyTo(cam, orb, applyOrbit) {
  if (!cam || !orb || !applyOrbit) return;
  const _dur = 500; // ms
  const _start = performance.now();
  const _from = {
    r:     orb.r,
    theta: orb.theta,
    phi:   orb.phi,
    tx:    orb.target.x,
    ty:    orb.target.y,
    tz:    orb.target.z,
  };
  function _ease(t) { return t<0.5 ? 2*t*t : -1+(4-2*t)*t; } // ease in-out
  function _tick() {
    const _t = Math.min(1, (performance.now()-_start)/_dur);
    const _e = _ease(_t);
    orb.r     = _from.r     + (_e * (cam.r     - _from.r));
    orb.theta = _from.theta + (_e * (cam.theta - _from.theta));
    orb.phi   = _from.phi   + (_e * (cam.phi   - _from.phi));
    orb.target.x = _from.tx + (_e * ((cam.tx||0) - _from.tx));
    orb.target.y = _from.ty + (_e * ((cam.ty||0) - _from.ty));
    orb.target.z = _from.tz + (_e * ((cam.tz||0) - _from.tz));
    applyOrbit();
    if (_t < 1) requestAnimationFrame(_tick);
  }
  requestAnimationFrame(_tick);
}


function _build3d(canvas) {
  if(_3d){
    if(_3d.orb&&_3d.orb.target&&_userMovedCam)
      _orbSave={r:_3d.orb.r,theta:_3d.orb.theta,phi:_3d.orb.phi,
        tx:_3d.orb.target.x,ty:_3d.orb.target.y,tz:_3d.orb.target.z};
    _3d.stop(); _3d=null;
  }
  _3dSel=null;
  const cont=canvas.parentElement;
  let W=cont.clientWidth||900, H=cont.clientHeight||580;
  canvas.width=W; canvas.height=H;
  const _ac=new AbortController(), _sig={signal:_ac.signal};
  const scene=new THREE.Scene(); scene.background=null;
  const camera=new THREE.PerspectiveCamera(42,W/H,0.1,300);
  const renderer=new THREE.WebGLRenderer({canvas,antialias:true,preserveDrawingBuffer:true,alpha:true});
  renderer.setSize(W,H); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
  // Teisingos spalvos PBR medžiagoms (kaip Blender)
  renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  // Aplinkos šviesa PBR medžiagoms - procedūrinė neutrali aplinka
  (function(){
    try {
      const _pmrem = new THREE.PMREMGenerator(renderer);
      _pmrem.compileEquirectangularShader();
      // Sukuriame neutralią aplinką iš DataTexture
      const _size = 64;
      const _data = new Uint8Array(_size * _size * 4);
      for(let i=0; i<_size*_size; i++){
        const y = Math.floor(i/_size)/_size; // 0=apačia, 1=viršus
        // Gradientas: apačia pilka (#667), viršus balta (#fff)
        const r = Math.round(100 + y*155);
        const g = Math.round(110 + y*145);
        const b = Math.round(120 + y*135);
        _data[i*4]=r; _data[i*4+1]=g; _data[i*4+2]=b; _data[i*4+3]=255;
      }
      const _envTex = new THREE.DataTexture(_data, _size, _size, THREE.RGBAFormat);
      _envTex.needsUpdate = true;
      const _rt = _pmrem.fromEquirectangular(_envTex);
      scene.environment = _rt.texture;
      _envTex.dispose(); _pmrem.dispose();
    } catch(e) { console.warn('Environment setup failed:', e); }
  })();
  const _resObs=new ResizeObserver(()=>{
    W=cont.clientWidth||900;H=cont.clientHeight||580;
    canvas.width=W;canvas.height=H;camera.aspect=W/H;camera.updateProjectionMatrix();renderer.setSize(W,H);
  });
  _resObs.observe(cont);
  // Šviesos - su environment map užtenka mažesnės intensyvumos
  scene.add(new THREE.AmbientLight(0xffffff, 1.5));
  scene.add(new THREE.HemisphereLight(0xffffff, 0x667788, 1.2));
  const dl=new THREE.DirectionalLight(0xffffff, 0.8); dl.position.set(5,10,15); scene.add(dl);
  const dl2=new THREE.DirectionalLight(0xffffff, 0.4); dl2.position.set(-5,-2,8); scene.add(dl2);
  const _headLight=new THREE.PointLight(0xffffff,1.0,0); scene.add(_headLight);
  const selSys=parseInt(document.getElementById('map-sys')?.value||'0');
  const fullGrandine=TECH.sistemu_tipai.find(t=>t.id===selSys)?.grandine||[];
  const sysObjs=typeof window._konSistemaLength==='number' && window._konSistemaLength>0
    ? fullGrandine.slice(0, window._konSistemaLength)
    : fullGrandine;
  _sysObjsRef=sysObjs;
  const CX=((sysObjs.length-1)/2)*_CELL, CY=1.0*_CELL;

  const _bgImg = sysObjs.includes('SLAIT') ? '/shared/img/backgrounds/background_slait.png' : sysObjs.includes('INFKAUB') ? '/shared/img/backgrounds/background_kaub.png' : null;
  const _bgRef = _drawBackground(scene,CX,_bgImg); _drawAxisLabels(scene,sysObjs,selSys);

  const posMap={};
  sysObjs.forEach((id,idx)=>{posMap[id]=idx;_posMapRef[id]=idx;});

  const objMeshes=[], compMeshes=[];

  sysObjs.forEach(id=>{
    const overrideX=posMap[id];
    let pos=_objPos(id,overrideX); if(!pos) return;
    // NAM1/NAM2: Y = sekančio objekto Y + 0.5*_CELL
    if(id==='NAM1'||id==='NAM2'){
      if(sysObjs.length<2) return;
      const _nid=sysObjs[1];
      const _np=_objPos(_nid,posMap[_nid]);
      pos={x:pos.x,y:(_np?_np.y:pos.y)+0.5*_CELL,z:pos.z};
    }
    const kb=KB.objects[id];
    const fms=Object.values(kb?.failure_modes||{}).filter(f=>f.name);
    const hasData=!!(kb?.function||fms.length>0);
    const isSelected=(_selObj===id);
    const col=isSelected?THEME.comp1:(hasData?THEME.obj:THEME.objEmpty);
    const r=['ZEMPAV','SLAIT','NAM1','NAM2'].includes(id)?0.02:0.38;

    const s3d = KB.objects[id]?.scene_3d;
    const userData = {type:'obj',id,overrideX};

    if (s3d?.glb && typeof THREE.GLTFLoader !== 'undefined') {
      // Spheres-first: iš karto rodome sferą, GLB tyliai pakeičia ją kai pakraunamas
      const _placeholder = _addSphere(scene, pos, col, r, userData, objMeshes, isSelected, s3d);
      THREE.Cache.enabled = false;
      const loader = new THREE.GLTFLoader();
      const _glbUrl = '/shared/glb/' + s3d.glb + '?v=' + (window._glbVer||(window._glbVer=localStorage.getItem('glb_ver')||'1'));
      loader.load(_glbUrl, gltf => {
        // Pašalinti placeholder sferą ir aurą
        for (let i = objMeshes.length - 1; i >= 0; i--) {
          if (objMeshes[i].userData === userData && (objMeshes[i].geometry?.type === 'SphereGeometry' || objMeshes[i].geometry?.type === 'CircleGeometry')) {
            scene.remove(objMeshes[i]);
            objMeshes.splice(i, 1);
          }
        }
        const model = gltf.scene;
        const _sx=s3d.scale_x||s3d.scale||1, _sy=s3d.scale_y||s3d.scale||1, _sz=s3d.scale_z||s3d.scale||1;
        model.scale.set(_sx, _sy, _sz);
        model.rotation.set(
          (s3d.rotation_x||0)*Math.PI/180,
          (s3d.rotation_y||0)*Math.PI/180,
          (s3d.rotation_z||0)*Math.PI/180
        );
        model.position.set(
          pos.x + (s3d.delta_x||0),
          pos.y + (s3d.delta_y||0) + (s3d.offset_y||0),
          0
        );
        model.userData = userData;
        model.traverse(c => {
          if(c.isMesh) {
            c.userData = userData;
            objMeshes.push(c);
            if(c.material){
              const mats = Array.isArray(c.material) ? c.material : [c.material];
              mats.forEach(mat => {
                // Metalness sumažiname - juodos metalinės paviršios absorbuoja šviesą
                if(mat.metalness !== undefined) mat.metalness = Math.min(mat.metalness, 0.3);
                // Roughness padidinamas - blizgūs paviršiai atrodo tamsiai
                if(mat.roughness !== undefined) mat.roughness = Math.max(mat.roughness, 0.55);
                // Tamsios spalvos gauna emissive
                const col = mat.color;
                if(col && col.r*0.299 + col.g*0.587 + col.b*0.114 < 0.18){
                  mat.emissive = new THREE.Color(0x303030);
                  mat.emissiveIntensity = 1.0;
                }
              });
            }
          }
        });
        scene.add(model);
      }, null, () => {
        // Klaida - sferos jau rodomos, nieko daryti nereikia
      });
    } else {
      // Default sphere
      _addSphere(scene, pos, col, r, userData, objMeshes, isSelected, s3d);
    }

    const meta=KB.objects_meta[id]||(typeof DEF_OBJS!=='undefined'?DEF_OBJS.find(o=>o.id===id):null);

    const nextId=sysObjs[posMap[id]+1];
    if(nextId){
      const np=_objPos(nextId,posMap[nextId]);
      if(np){
        // Use socket points if available
        const ns3d = KB.objects[nextId]?.scene_3d;
        const _bx1=pos.x+(s3d?.delta_x||0),   _by1=pos.y+(s3d?.delta_y||0);
        const _bx2=np.x+(ns3d?.delta_x||0),    _by2=np.y+(ns3d?.delta_y||0);
        const fromPt = s3d?.socket_out ? {x:_bx1+(s3d.socket_out.x||0), y:_by1+(s3d.socket_out.y||0)} : {x:_bx1,y:_by1};
        const toPt   = ns3d?.socket_in  ? {x:_bx2+(ns3d.socket_in.x||0),  y:_by2+(ns3d.socket_in.y||0)}  : {x:_bx2,y:_by2};
        const _ptype = s3d?.pipe_type || 'PE';
        const _pcol  = _ptype==='PVC' ? 0x8B4513 : _ptype==='PVC_grey' ? 0x808080 : 0x1565C0;
        const _prad = _ptype==='PVC' ? 0.09 : _ptype==='PVC_grey' ? 0.06 : 0.03;
        _pipe3d(scene,fromPt.x,fromPt.y,0.05,toPt.x,toPt.y,0.05,_pcol,_prad);
      }
    }

    if(_selObj===id){
      const isAdmin3d = typeof saveAllFiles === 'function';
      if(!isAdmin3d || _viewMode==='expand'){
        _showAllComps(scene,compMeshes,id,undefined,undefined,overrideX);
      } else if(_viewMode==='step'){
        _showPkgComps(scene,compMeshes,id,overrideX);
      }
    }
    if(_viewMode==='all') _showAllComps(scene,compMeshes,id,undefined,undefined,overrideX);
  });

  const orbData=(_userMovedCam&&_orbSave)
    ?{target:new THREE.Vector3(_orbSave.tx,_orbSave.ty,_orbSave.tz),r:_orbSave.r,theta:_orbSave.theta,phi:_orbSave.phi}
    :{target:new THREE.Vector3(CX,CY,0),r:9.5,theta:0,phi:Math.PI/2};
  const orb=orbData;

  function applyOrbit(){
    const sp=Math.sin(orb.phi),cp=Math.cos(orb.phi),st=Math.sin(orb.theta),ct=Math.cos(orb.theta);
    camera.position.set(orb.target.x+orb.r*sp*st,orb.target.y+orb.r*cp,orb.target.z+orb.r*sp*ct);
    camera.lookAt(orb.target); camera.updateMatrixWorld();
      if (typeof _headLight !== 'undefined') _headLight.position.copy(camera.position);
  }
  applyOrbit();

  let drag=false,isPan=false,lastM={x:0,y:0};
  let dragComp=null,compDragging=false;
  const dragPlane=new THREE.Plane(),dragPt=new THREE.Vector3(),dragOff=new THREE.Vector3(),dragOrigPos=new THREE.Vector3();

  function _updateDragPlane(){
    const d=new THREE.Vector3().subVectors(camera.position,orb.target).normalize();
    dragPlane.setFromNormalAndCoplanarPoint(d,dragComp.position);
  }
  function _startDragComp(e){
    if(!_dragMode||e.button!==0) return false;
    const rect=canvas.getBoundingClientRect();
    const mp=new THREE.Vector2(((e.clientX-rect.left)/W)*2-1,-((e.clientY-rect.top)/H)*2+1);
    const ray=new THREE.Raycaster(); ray.setFromCamera(mp,camera);
    const hits=ray.intersectObjects(compMeshes.filter(m=>m.userData?.type==='comp'));
    if(!hits.length) return false;
    dragComp=hits[0].object; compDragging=false;
    dragOrigPos.copy(dragComp.position); _updateDragPlane();
    ray.ray.intersectPlane(dragPlane,dragPt); dragOff.subVectors(dragComp.position,dragPt);
    canvas.style.cursor='grabbing'; return true;
  }

  const DEAD=3; let _cs={x:0,y:0},_mv=false;

  canvas.addEventListener('mousedown',e=>{
    _cs={x:e.clientX,y:e.clientY};_mv=false;
    if(_startDragComp(e)){e.preventDefault();e.stopPropagation();return;}
    drag=true;isPan=(e.button===0);lastM={x:e.clientX,y:e.clientY};
    canvas.style.cursor='grabbing';e.preventDefault();
  },_sig);
  canvas.addEventListener('contextmenu',e=>e.preventDefault(),_sig);

  document.addEventListener('mouseup',()=>{
    if(dragComp&&compDragging){
      _hideAxisLine(scene);
      const cid=dragComp.userData.id, comp=KB.components[cid];
      if(comp){
        const ox=dragComp.userData.objPosX||0,oy=dragComp.userData.objPosY||0;
        comp.map_x=parseFloat((dragComp.position.x-ox).toFixed(3));
        comp.map_y=parseFloat((dragComp.position.y-oy).toFixed(3));
        comp.map_z=parseFloat(dragComp.position.z.toFixed(3));
        if(!KB.components_meta[cid]) KB.components_meta[cid]={};
        KB.components_meta[cid].map_x=comp.map_x;
        KB.components_meta[cid].map_y=comp.map_y;
        KB.components_meta[cid].map_z=comp.map_z;
        markDirty('comp_'+cid); toast('Pozicija issaugota: '+(comp.name||cid));
      }
    }
    dragComp=null;compDragging=false;drag=false;
    canvas.style.cursor=_dragMode?'crosshair':'default';
  },{signal:_ac.signal});

  canvas.addEventListener('mousemove',e=>{
    if(e.buttons&&(Math.abs(e.clientX-_cs.x)>DEAD||Math.abs(e.clientY-_cs.y)>DEAD)) _mv=true;

    if(dragComp){
      const rect=canvas.getBoundingClientRect();
      const mp=new THREE.Vector2(((e.clientX-rect.left)/W)*2-1,-((e.clientY-rect.top)/H)*2+1);
      const ray=new THREE.Raycaster(); ray.setFromCamera(mp,camera);
      if(ray.ray.intersectPlane(dragPlane,dragPt)){
        const nx=dragPt.x+dragOff.x,ny=dragPt.y+dragOff.y,nz=dragPt.z+dragOff.z;
        if(_dragAxis==='x'){dragComp.position.x=nx;dragComp.position.y=dragOrigPos.y;dragComp.position.z=dragOrigPos.z;}
        else if(_dragAxis==='y'){dragComp.position.x=dragOrigPos.x;dragComp.position.y=ny;dragComp.position.z=dragOrigPos.z;}
        else if(_dragAxis==='z'){dragComp.position.x=dragOrigPos.x;dragComp.position.y=dragOrigPos.y;dragComp.position.z=nz;}
        else{dragComp.position.x=nx;dragComp.position.y=ny;dragComp.position.z=nz;}
        compDragging=true;
        _showAxisLine(scene,dragComp);
        const idx=compMeshes.indexOf(dragComp);
        if(idx>=0&&compMeshes[idx+1]?.isSprite)
          compMeshes[idx+1].position.set(dragComp.position.x,dragComp.position.y-0.55,dragComp.position.z);
      }
      return;
    }

    if(!drag){
      const rect=canvas.getBoundingClientRect();
      const mp=new THREE.Vector2(((e.clientX-rect.left)/W)*2-1,-((e.clientY-rect.top)/H)*2+1);
      const ray=new THREE.Raycaster(); ray.setFromCamera(mp,camera);
      if(_dragMode) canvas.style.cursor=ray.intersectObjects(compMeshes.filter(m=>m.userData?.type==='comp')).length?'grab':'crosshair';
      else canvas.style.cursor=ray.intersectObjects(objMeshes).length?'pointer':'default';
      return;
    }

    _userMovedCam=true;
    const dx=e.clientX-lastM.x,dy=e.clientY-lastM.y;
    lastM={x:e.clientX,y:e.clientY};
    if(isPan){
      const right=new THREE.Vector3(),up=new THREE.Vector3();
      camera.matrix.extractBasis(right,up,new THREE.Vector3());
      orb.target.addScaledVector(right,-dx*0.015);
      orb.target.addScaledVector(up,dy*0.015);
    } else {
      orb.theta-=dx*0.008;
      orb.phi=Math.max(0.05,Math.min(Math.PI-0.05,orb.phi+dy*0.008));
    }
    applyOrbit();
  },_sig);

  canvas.addEventListener('wheel',e=>{
    _userMovedCam=true; orb.r=Math.max(0.05,Math.min(80,orb.r+e.deltaY*0.02));
    applyOrbit(); e.preventDefault();
  },{passive:false,signal:_ac.signal});

  
  // ── TOUCH GESTAI (mobilūs) ──────────────────────────────────────
  let _t1 = null, _t2 = null, _tDist0 = 0, _tOrb0 = {};

  function _tPos(e) {
    const r = canvas.getBoundingClientRect();
    return Array.from(e.touches).map(t => ({
      x: t.clientX - r.left,
      y: t.clientY - r.top
    }));
  }

  function _tDist(pts) {
    const dx = pts[1].x - pts[0].x, dy = pts[1].y - pts[0].y;
    return Math.sqrt(dx*dx + dy*dy);
  }

  let _tMoved = false;

  canvas.addEventListener('touchstart', e => {
    e.preventDefault();
    const pts = _tPos(e);
    if (e.touches.length === 1) {
      _t1 = pts[0]; _t2 = null; _tMoved = false;
    } else if (e.touches.length === 2) {
      _t1 = pts[0]; _t2 = pts[1];
      _tDist0 = _tDist(pts);
      _tOrb0  = { r: orb.r, theta: orb.theta, phi: orb.phi };
    }
    _userMovedCam = true;
  }, { passive: false, signal: _ac.signal });

  canvas.addEventListener('touchmove', e => {
    e.preventDefault();
    const pts = _tPos(e);

    if (e.touches.length === 1 && _t1) {
      const dx = pts[0].x - _t1.x;
      const dy = pts[0].y - _t1.y;
      if (!_tMoved && (Math.abs(dx) > 4 || Math.abs(dy) > 4)) _tMoved = true;
      if (_tMoved) {
        orb.theta -= dx * 0.008;
        orb.phi    = Math.max(0.05, Math.min(Math.PI - 0.05, orb.phi + dy * 0.008));
        applyOrbit();
        _userMovedCam = true;
      }
      _t1 = pts[0];
    } else if (e.touches.length === 2 && _t2) {
      _tMoved = true;
      const dist = _tDist(pts);
      orb.r = Math.max(0.05, Math.min(80, _tOrb0.r * (_tDist0 / Math.max(dist, 1))));
      applyOrbit();
      _userMovedCam = true;
    }
  }, { passive: false, signal: _ac.signal });

  canvas.addEventListener('touchend', e => {
    if (e.touches.length === 0) {
      if (!_tMoved && _t1) {
        const rect2 = canvas.getBoundingClientRect();
        const mp = new THREE.Vector2(
          (_t1.x / rect2.width)  * 2 - 1,
          -(_t1.y / rect2.height) * 2 + 1
        );
        const ray = new THREE.Raycaster(); ray.setFromCamera(mp, camera);
        const objHits = ray.intersectObjects(objMeshes);
        if (objHits.length) {
          const d = objHits[0].object.userData;
          if (_selObj === d.id) { _selObj = null; _selComp = null; _openedComps = []; _3dSel = null; _panelLevel = 'obj'; _hidePanel(); }
          else { _selObj = d.id; _selComp = null; _openedComps = []; _3dSel = d.id; _panelLevel = 'obj'; }
          _build3d(canvas);
          if (_selObj) _renderPanel();
        }
      }
      _t1 = null; _t2 = null;
    } else if (e.touches.length === 1) { _t2 = null; _t1 = _tPos(e)[0]; }
  }, { passive: false, signal: _ac.signal });
  // ────────────────────────────────────────────────────────────────

canvas.addEventListener('click',e=>{
    if(_mv) return;
    const rect=canvas.getBoundingClientRect();
    const mp=new THREE.Vector2(((e.clientX-rect.left)/W)*2-1,-((e.clientY-rect.top)/H)*2+1);
    const ray=new THREE.Raycaster(); ray.setFromCamera(mp,camera);

    const objHits=ray.intersectObjects(objMeshes);
    if(objHits.length){
      const d=objHits[0].object.userData;
      if(_selObj===d.id){_selObj=null;_selComp=null;_openedComps=[];_3dSel=null;_panelLevel='obj';_hidePanel();}
      else{_selObj=d.id;_selComp=null;_openedComps=[];_3dSel=d.id;_panelLevel='obj';
        const _oCam=KB.objects[d.id]?.scene_3d?.cam_click;
        if(_oCam){ _camFlyTo(_oCam,orb,applyOrbit); _userMovedCam=true; }
        else if(!_userMovedCam){orb.theta=1.20;orb.phi=1.35;orb.r=8;applyOrbit();_userMovedCam=true;}
      }
      _build3d(canvas);
      if(_selObj) _renderPanel();
      return;
    }

    if(true){  
      const compHits=ray.intersectObjects(compMeshes.filter(m=>m.userData?.type==='comp'));
      if(compHits.length){
        const d=compHits[0].object.userData;
        _selComp=d; _panelLevel='comp'; _renderPanel();
        const _cCam=KB.components[d.id]?.cam_click;
        if(_cCam){ _camFlyTo(_cCam,orb,applyOrbit); _userMovedCam=true; }
        if(_hasChildren(d.id)){
          _openedComps=_openedComps.includes(d.id)
            ? _openedComps.filter(id=>id!==d.id)
            : [..._openedComps,d.id];
          _build3d(canvas);
        }
      }
    }
  },_sig);

  let animId,stopped=false;
  function animate(){
    if(stopped)return;
    animId=requestAnimationFrame(animate);
    // Fonas blunka kai kamera sukama į šoną (pagal theta kampą)
    const _bgMesh=_bgRef.getMesh();
    let _bgOpNow=0;
    if(_bgMesh){
      const _t=((orb.theta%(Math.PI*2))+Math.PI*2)%(Math.PI*2);
      const _rs=Math.abs(Math.sin(_t));const _rp=Math.abs(orb.phi-Math.PI/2)/(Math.PI/2);const _f=Math.max(_rs,_rp);
      _bgOpNow=0.95*Math.max(0,1-_f*6);
      _bgMesh.material.opacity=_bgOpNow;
    }
    const _fadeR=_bgOpNow/0.95;
    const _gvlM=scene.getObjectByName('_gvlWater'); if(_gvlM) _gvlM.material.opacity=0.32*_fadeR;
    if(_gridRef){const _gOp=_fadeR<0.15?Math.max(0,(1-_fadeR*6.67)*0.35):0;_gridRef.material.opacity=window._gridVisible===false?0:_gOp;}
        renderer.render(scene,camera);
  }
  animate();

  const DEF_ORB={r:10,theta:0,phi:Math.PI/2,tx:CX,ty:CY};
  _3d={
    stop:()=>{
      _ac.abort();_resObs.disconnect();
      if(_userMovedCam) _orbSave={r:orb.r,theta:orb.theta,phi:orb.phi,tx:orb.target.x,ty:orb.target.y,tz:orb.target.z};
      stopped=true;cancelAnimationFrame(animId);renderer.dispose();
    },
    orb,applyOrbit,DEF_ORB,
    _compMeshes:compMeshes,
    _objMeshes:objMeshes,
    _removeComps:()=>{compMeshes.forEach(m=>scene.remove(m));compMeshes.length=0;},
    bgRef:_bgRef,renderer,scene,camera
  };
}

function renderMap(){
  const sel=document.getElementById('map-sys');
  if(sel&&sel.options.length===1){
    TECH.sistemu_tipai.forEach(t=>{
      const opt=document.createElement('option');
      opt.value=t.id; opt.textContent=t.id+'. '+t.grandine.join(' -> ');
      sel.appendChild(opt);
    });
  }
  const mw=document.getElementById('map-comp-mode');
  if(mw&&!mw.dataset.init){mw.dataset.init='1';_renderModeButtons();}
  _ensurePanel();_ensureDragAxisBar();_injectCSS();
  _selObj=null;_selComp=null;_openedComps=[];_3dSel=null;_panelLevel='obj';
  _hidePanel();
  const selSys=parseInt(sel?.value||'0');
  const canvas=document.getElementById('map-canvas'); if(!canvas) return;
  const afterBuild=()=>{
    if(selSys) _renderPanelSys(selSys);
    else _hidePanel();
  };
  if(typeof THREE==='undefined'){
    const sc=document.createElement('script');
    sc.src='https://cdnjs.cloudflare.com/ajax/libs/three.js/r134/three.min.js';
    sc.onload=()=>{
      // Load GLTFLoader then build scene
      const gl=document.createElement('script');
      gl.src='https://unpkg.com/three@0.134.0/examples/js/loaders/GLTFLoader.js';
      gl.onload=()=>{ selSys?_build3d(canvas):_buildEmpty(canvas); afterBuild(); };
      gl.onerror=()=>{ selSys?_build3d(canvas):_buildEmpty(canvas); afterBuild(); };
      document.head.appendChild(gl);
    };
    document.head.appendChild(sc);
  } else {
    // THREE loaded, ensure GLTFLoader too
    if(typeof THREE.GLTFLoader==='undefined'){
      const gl=document.createElement('script');
      gl.src='https://unpkg.com/three@0.134.0/examples/js/loaders/GLTFLoader.js';
      gl.onload=()=>{ selSys?_build3d(canvas):_buildEmpty(canvas); afterBuild(); };
      gl.onerror=()=>{ selSys?_build3d(canvas):_buildEmpty(canvas); afterBuild(); };
      document.head.appendChild(gl);
    } else { selSys?_build3d(canvas):_buildEmpty(canvas); afterBuild(); }
  }
}

function _renderModeButtons(){
  const mw=document.getElementById('map-comp-mode'); if(!mw) return;
  const isAdmin = typeof saveAllFiles === 'function';
  if(!isAdmin){
    mw.innerHTML='<button class="btn ghost" onclick="_toggleGrid()" style="padding:4px 12px;font-size:11px;opacity:'+(window._gridVisible===false?'0.4':'1')+'">&#9783; Tinklelis</button>';
    return;
  }
  mw.innerHTML=
    '<span style="font-size:11px;font-weight:600;color:var(--td);margin-right:6px">Rodymas:</span>'+
    [['step','Žingsninis'],['expand','Išklesti'],['all','Visa sistema']].map(([m,l])=>
      '<button class="btn ghost '+(_viewMode===m?'active':'')+'" onclick="setViewMode(''+m+'')" style="padding:4px 12px;font-size:11px">'+l+'</button>'
    ).join('')+
    '<button class="btn ghost" onclick="_toggleGrid()" style="padding:4px 12px;font-size:11px;margin-left:8px;opacity:'+(window._gridVisible===false?'0.4':'1')+'">&#9783; Tinklelis</button>';
}
function _toggleGrid(){
  window._gridVisible = (window._gridVisible === false) ? true : false;
  _renderModeButtons();
}

function _ensurePanel(){
  if(document.getElementById('map-side-panel')) return;
  const r=document.querySelector('.right'); if(!r) return;
  const p=document.createElement('div'); p.id='map-side-panel';
  p.style.cssText='display:none;flex-direction:column;overflow:hidden;width:100%;height:100%;';
  r.innerHTML='';
  r.appendChild(p);
}

function _ensureDragAxisBar(){
  if(document.getElementById('drag-axis-bar')) return;
  const a=document.getElementById('map-area'); if(!a) return;
  const bar=document.createElement('div'); bar.id='drag-axis-bar';
  bar.style.cssText='display:none;position:absolute;bottom:44px;left:50%;transform:translateX(-50%);background:var(--s1);border:1px solid var(--b1);border-radius:var(--r2);padding:5px 10px;align-items:center;gap:6px;z-index:30;box-shadow:var(--shadow2);';
  bar.innerHTML='<span style="font-size:10px;color:var(--td);white-space:nowrap">Tampymo asis:</span>'+
    [['free','Laisvas',null],['x','X','x'],['y','Y','y'],['z','Z','z']].map(([k,l,v])=>
      '<button id="dax-'+k+'" onclick="setDragAxis('+(v?'\''+v+'\'':'null')+')" style="padding:3px 11px;font-size:11px;font-weight:700;border-radius:var(--r);border:1.5px solid '+(k==='free'?'var(--pri)':'var(--b1)')+';background:'+(k==='free'?'var(--pri)':'var(--s2)')+';color:'+(k==='free'?'#fff':'var(--text)')+';cursor:pointer;font-family:inherit">'+l+'</button>'
    ).join('');
  a.appendChild(bar);
}

function _injectCSS(){
  if(document.getElementById('msp-style')) return;
  const s=document.createElement('style'); s.id='msp-style';
  s.textContent=`
    #map-side-panel{font-family:'Inter',sans-serif;font-size:12px;color:var(--text)}
    .msp-head{padding:12px 14px 10px;background:var(--s2);border-bottom:1px solid var(--b1);flex-shrink:0;position:relative;padding-right:36px}
    .msp-back{background:none;border:none;color:var(--acc);font-size:11px;cursor:pointer;padding:0;font-family:inherit;font-weight:600;margin-bottom:6px;display:flex;align-items:center;gap:3px}
    .msp-back:hover{text-decoration:underline}
    .msp-obj-name{font-size:13px;font-weight:700;color:var(--pri);line-height:1.3}
    .msp-admin-link{display:inline-flex;align-items:center;gap:4px;margin-top:6px;font-size:10px;color:var(--acc);background:none;border:1px solid var(--b2);border-radius:var(--r);padding:2px 8px;cursor:pointer;font-family:inherit}
    .msp-admin-link:hover{background:var(--s3)}
    .msp-close{position:absolute;top:10px;right:10px;background:none;border:none;font-size:18px;color:var(--td);cursor:pointer;padding:0 4px;border-radius:var(--r);line-height:1}
    .msp-close:hover{background:var(--s3);color:var(--text)}
    .msp-body{flex:1;overflow-y:auto;padding:12px}
    .msp-mb{margin-bottom:10px}.msp-mt{margin-top:12px}
    .msp-section-title{font-size:10px;font-weight:700;color:var(--td);text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px}
    .msp-text{font-size:11px;color:var(--text);line-height:1.55}
    .msp-empty-sm{font-size:11px;color:var(--td);font-style:italic;margin-bottom:10px}
    .msp-models{display:flex;flex-direction:column;gap:3px;margin-bottom:2px}
    .msp-model-row{display:flex;align-items:center;gap:6px;padding:5px 8px;background:var(--s2);border-radius:var(--r);font-size:11px}
    .msp-model-name{flex:1;font-weight:500}
    .msp-supplier{font-size:10px;color:var(--td)}
    .msp-price{font-weight:700;color:var(--pri);white-space:nowrap}
    .msp-notes{font-size:10px;color:var(--td)}
    .msp-pkg-btns{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:6px}
    .msp-pkg-btn{padding:5px 10px;border-radius:var(--r);border:1.5px solid var(--b1);background:var(--s1);font-size:11px;font-weight:600;cursor:pointer;color:var(--td);font-family:inherit;display:flex;flex-direction:column;align-items:flex-start;gap:1px;transition:all .12s}
    .msp-pkg-btn:hover{border-color:var(--pri3);color:var(--text)}
    .msp-pkg-btn.active{border-color:var(--pri);background:var(--s2);color:var(--pri)}
    .msp-pkg-sub{font-size:9px;font-weight:400;color:var(--td)}
    .msp-pkg-legend{font-size:10px;color:var(--td);padding:3px 0 4px;margin-bottom:2px}
    .msp-price-box{background:var(--s2);border-radius:var(--r);padding:8px 10px;margin:8px 0}
    .msp-price-row{display:flex;justify-content:space-between;font-size:11px;padding:2px 0}
    .msp-price-row b{color:var(--pri)}
    .msp-diy-yes{font-size:10px;color:#2e7d32;margin-top:4px;font-weight:600}
    .msp-diy-no{font-size:10px;color:var(--warn);margin-top:4px;font-weight:600}
    .msp-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
    .msp-dot-l1{background:#1565c0}.msp-dot-l2{background:#7b1fa2}
    .msp-comp-list{display:flex;flex-direction:column;gap:2px}
    .msp-comp-row{display:flex;align-items:center;gap:7px;padding:7px 8px;border-radius:var(--r);cursor:pointer;transition:background .1s;font-size:11px}
    .msp-comp-row:hover{background:var(--s2)}
    .msp-comp-name{flex:1;color:var(--text)}
    .msp-expand-btn{color:var(--td);font-size:11px;padding:2px 5px;border-radius:3px}
    .msp-expand-btn:hover{background:var(--s3)}
    .msp-arrow-r{color:var(--td);font-size:14px}
    .msp-sub-list{padding-left:20px;display:flex;flex-direction:column;gap:1px;margin-bottom:4px}
    .msp-sub-item{display:flex;align-items:center;gap:5px;padding:5px 6px;font-size:11px;color:var(--text);border-radius:var(--r);cursor:pointer}
    .msp-sub-item:hover{background:var(--s2)}
    .msp-tree-line{color:var(--b2);font-size:13px;flex-shrink:0}
    .msp-btns{padding:10px 12px;border-top:1px solid var(--b1);display:flex;flex-direction:column;gap:5px;flex-shrink:0}
    .msp-divider{height:1px;background:var(--b1);margin:3px 0}
    .msp-action{padding:7px 10px;background:var(--s2);border:1px solid var(--b1);border-radius:var(--r);font-size:11px;font-weight:600;color:var(--pri);cursor:pointer;text-align:left;transition:all .12s;font-family:'Inter',sans-serif}
    .msp-action:hover{background:var(--s3);border-color:var(--b2)}
    .msp-action-buy{color:var(--warn);background:rgba(230,81,0,.06);border-color:rgba(230,81,0,.2)}
    .msp-action-buy:hover{background:rgba(230,81,0,.12)}
    .msp-sys-label{font-size:10px;font-weight:700;color:var(--td);text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px}
    .msp-sys-meta{display:flex;gap:12px;font-size:11px;color:var(--td);margin-bottom:10px}
    .msp-sys-price{background:var(--s2);border-radius:var(--r);padding:10px 12px;margin-bottom:4px}
    .msp-sys-price-row{display:flex;justify-content:space-between;font-size:11px;padding:3px 0;border-bottom:1px solid var(--b1)}
    .msp-sys-price-row:last-child{border-bottom:none}
    .msp-sys-price-row b{color:var(--pri)}
    .msp-sys-total{margin-top:4px;padding-top:6px!important;border-top:2px solid var(--b1)!important;border-bottom:none!important}
    .msp-sys-total b{font-size:13px!important}
    .msp-ibtn{padding:7px 10px;background:var(--s2);border:1px solid var(--b1);border-radius:var(--r);font-size:11px;font-weight:600;color:var(--pri);cursor:pointer;text-align:left;transition:all .12s;font-family:'Inter',sans-serif}
    .msp-ibtn:hover{background:var(--s3);border-color:var(--b2)}
    
    .sl-wrap{max-height:55vh;overflow-y:auto}
    .sl-obj-block{margin-bottom:16px}
    .sl-obj-head{display:flex;align-items:center;justify-content:space-between;padding:8px 0 4px;border-bottom:2px solid var(--pri)}
    .sl-obj-title{font-size:13px;font-weight:700;color:var(--pri)}
    .sl-comps-label{font-size:10px;color:var(--td);text-transform:uppercase;letter-spacing:.4px;margin:8px 0 4px;padding-left:4px}
    .sl-row{padding:4px 0}
    .sl-depth-0{padding-left:0}
    .sl-depth-1{padding-left:16px}
    .sl-depth-2{padding-left:30px}
    .sl-depth-3{padding-left:44px}
    .sl-row-main{display:flex;align-items:center;gap:7px;padding:4px 6px;border-radius:var(--r)}
    .sl-row-main:hover{background:var(--s2)}
    .sl-bullet{font-size:8px;color:var(--b2);flex-shrink:0}
    .sl-depth-0 .sl-bullet{color:var(--pri);font-size:9px}
    .sl-name{flex:1;font-size:12px;color:var(--text)}
    .sl-depth-0 .sl-name{font-weight:600}
    .sl-price{font-size:11px;font-weight:700;color:var(--pri);white-space:nowrap}
    .sl-spec{font-size:10px;color:var(--warn);background:rgba(230,81,0,.08);border-radius:10px;padding:1px 6px;white-space:nowrap}
    .sl-supplier{font-size:10px;color:var(--td);padding-left:24px;margin-top:-2px}
    .sl-models{padding-left:24px;margin-top:2px;display:flex;flex-wrap:wrap;gap:3px}
    .sl-model-tag{font-size:10px;color:var(--td);background:var(--s2);border:1px solid var(--b1);border-radius:10px;padding:1px 7px}
    .sl-total{display:flex;gap:16px;padding:10px 0 4px;border-top:2px solid var(--b1);margin-top:8px;flex-wrap:wrap;align-items:center}
    .sl-total span{font-size:12px;color:var(--text)}
    .sl-total b{color:var(--pri)}
    .sl-grand{font-size:13px!important;font-weight:700;color:var(--pri)!important;margin-left:auto;background:var(--s2);padding:4px 12px;border-radius:var(--r);border:1px solid var(--b1)}
    .sl-picks{display:flex;flex-direction:column;gap:8px;max-height:55vh;overflow-y:auto}
    .sl-pick-row{display:flex;align-items:center;gap:10px;padding:8px;background:var(--s2);border-radius:var(--r);border:1px solid var(--b1)}
    .sl-pick-name{flex:1;font-size:12px;font-weight:600;color:var(--text)}
    .sl-pick-sel{font-size:11px;padding:4px 6px;border:1px solid var(--b1);border-radius:var(--r);background:var(--s1);color:var(--text);font-family:inherit;max-width:220px}
  `;
  document.head.appendChild(s);
}

function setDragAxis(axis){
  _dragAxis=axis;
  const active=axis===null?'free':axis;
  ['free','x','y','z'].forEach(k=>{
    const btn=document.getElementById('dax-'+k); if(!btn) return;
    const on=k===active;
    btn.style.background=on?'var(--pri)':'var(--s2)';
    btn.style.color=on?'#fff':'var(--text)';
    btn.style.borderColor=on?'var(--pri)':'var(--b1)';
  });
}

function setViewMode(mode){
  _viewMode=mode;_openedComps=[];_renderModeButtons();
  const canvas=document.getElementById('map-canvas');
  const selSys=parseInt(document.getElementById('map-sys')?.value||'0');
  if(!canvas||!selSys) return;
  _build3d(canvas); if(_selObj) _renderPanel();
}

function toggleDragMode(){
  _dragMode=!_dragMode;_dragAxis=null;
  _renderModeButtons();setDragAxis(null);
  const bar=document.getElementById('drag-axis-bar');
  if(bar) bar.style.display=_dragMode?'flex':'none';
  const canvas=document.getElementById('map-canvas');
  if(canvas) canvas.style.cursor=_dragMode?'crosshair':'default';
  const selSys=parseInt(document.getElementById('map-sys')?.value||'0');
  if(selSys&&canvas) _build3d(canvas);
  if(_dragMode) toast('Tampymo rezimas — pasirink asi ir vilk komponenta');
}

function map3dReset(){
  _userMovedCam=false;_orbSave=null;
  if(!_3d||!_3d.DEF_ORB.r) return;
  const d=_3d.DEF_ORB;
  _3d.orb.r=d.r;_3d.orb.theta=d.theta;_3d.orb.phi=d.phi;
  _3d.orb.target.set(d.tx,d.ty,0);_3d.applyOrbit();
}

function mapReset()    { map3dReset(); }

function renderMapWithLoader(){
  const selSys=parseInt(document.getElementById('map-sys')?.value||'0');
  if(!selSys){ renderMap(); return; } // jei "visi objektai" - be loader'io

  // Sukurti overlay ant canvas
  const area=document.getElementById('map-area');
  if(!area) { renderMap(); return; }

  // Pašalinti seną overlay jei buvo
  const _old=document.getElementById('map-load-overlay');
  if(_old) _old.remove();

  const ov=document.createElement('div');
  ov.id='map-load-overlay';
  ov.style.cssText='position:absolute;inset:0;z-index:50;display:flex;flex-direction:column;align-items:center;justify-content:center;background:var(--bg,#f2f8f3);pointer-events:none;';
  ov.innerHTML=
    '<div style="font-family:inherit;font-size:28px;font-weight:800;letter-spacing:2px;color:var(--pri,#2e7d32);margin-bottom:16px">IBN<span style="color:var(--acc,#4a9d6f)">VS</span></div>'+
    '<div style="display:flex;gap:6px;margin-bottom:14px">'+
      '<div class="mlo-dot" style="width:8px;height:8px;border-radius:50%;background:var(--pri,#2e7d32);animation:mloBounce 1.1s ease-in-out infinite;animation-delay:0s"></div>'+
      '<div class="mlo-dot" style="width:8px;height:8px;border-radius:50%;background:var(--pri,#2e7d32);animation:mloBounce 1.1s ease-in-out infinite;animation-delay:0.18s"></div>'+
      '<div class="mlo-dot" style="width:8px;height:8px;border-radius:50%;background:var(--pri,#2e7d32);animation:mloBounce 1.1s ease-in-out infinite;animation-delay:0.36s"></div>'+
    '</div>'+
    '<div style="font-size:11px;color:var(--td,#888);font-weight:500">Kraunama sistema…</div>';

  // Pridėti CSS animaciją vieną kartą
  if(!document.getElementById('mlo-style')){
    const st=document.createElement('style'); st.id='mlo-style';
    st.textContent='@keyframes mloBounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-10px)}}';
    document.head.appendChild(st);
  }

  area.appendChild(ov);

  // Kviesti renderMap() iš karto - scena kraunasi fone
  renderMap();

  // Po 5s paslėpti overlay
  setTimeout(()=>{
    const o=document.getElementById('map-load-overlay');
    if(o){ o.style.transition='opacity 0.4s'; o.style.opacity='0'; setTimeout(()=>o.remove(),400); }
  }, 5000);
}

function mapZ(d)       { if(_3d&&_3d.orb.r){_3d.orb.r=Math.max(0.05,Math.min(80,_3d.orb.r-d*20));_3d.applyOrbit();} }
function mapHover()    {}
function mapHoverEnd() {}
function mapNodeDrag() {}
function mapClick()    {}
function showMtt()     {}
function hideMtt()     {}
function _drawMap()    {}
function _startForce() {}
