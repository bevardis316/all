const _DOMAIN = (
  typeof _DOMAIN_DATA !== 'undefined' &&
  _DOMAIN_DATA !== null &&
  typeof _DOMAIN_DATA === 'object' &&
  !Array.isArray(_DOMAIN_DATA) &&
  _DOMAIN_DATA.sistemu_tipai
) ? _DOMAIN_DATA : null;

const TECH = {
  sistemu_tipai: _DOMAIN ? _DOMAIN.sistemu_tipai : [
    {id:1,  grandine:["NAM1","BNVI","MEGSUL","INFSUL"],                        rusis:"@geoinf"},
    {id:2,  grandine:["NAM1","BNVI","MEGSUL","SLAIT"],                         rusis:"@geopav"},
    {id:3,  grandine:["NAM1","BNVI","DRENSIURB","ZEMPAV"],                     rusis:"@geopav"},
    {id:4,  grandine:["NAM1","BNVI","DRENSIURB","INFLAUK"],                    rusis:"@geoinf"},
    {id:5,  grandine:["NAM1","BNVI","DRENSIURB","INFKAUB"],                    rusis:"@geoinf"},
    {id:6,  grandine:["NAM2","FEKSIURB","BNVI","MEGSUL","INFSUL"],             rusis:"@geoinf"},
    {id:7,  grandine:["NAM1","UZDTALP"],                                       rusis:"@geouzd"},
    {id:8,  grandine:["NAM2","FEKSIURB","UZDTALP"],                            rusis:"@geouzd"},
    {id:9,  grandine:["NAM2","FEKSIURB","BNVI","MEGSUL","SLAIT"],              rusis:"@geopav"},
    {id:10, grandine:["NAM2","FEKSIURB","BNVI","DRENSIURB","ZEMPAV"],          rusis:"@geopav"},
    {id:11, grandine:["NAM2","FEKSIURB","BNVI","DRENSIURB","INFLAUK"],         rusis:"@geoinf"},
    {id:12, grandine:["NAM2","FEKSIURB","BNVI","DRENSIURB","INFKAUB"],         rusis:"@geoinf"},
  ],

  z_lygiai: _DOMAIN ? _DOMAIN.z_lygiai : {
    "@zempav": {pav:"Žemės paviršius (0m)",         obj:["ZEMPAV","INFKAUB"]},
    "@ipgil":  {pav:"Įprastas gylis (0.3–1.4m)",    obj:["NAM1","NAM2","BNVI","INFSUL","INFLAUK","DRENSIURB","SLAIT","UZDTALP","MEGSUL"]},
    "@gilu":   {pav:"Gilu (1.5–2.4m)",              obj:["FEKSIURB"]},
    "@lbgilu": {pav:"Labai gilu (2.4m+)",            obj:[]},
  },

  sektoriai: _DOMAIN ? _DOMAIN.sektoriai : {
    "A":"Nuotekų šaltinis","B":"Po A","C":"Po B","D":"Po C","E":"Galutinis taškas"
  },

  in_out: _DOMAIN ? _DOMAIN.in_out : {
    NAM1:      {in:null,                          out:["PVC110","PVC160"]},
    NAM2:      {in:null,                          out:["PVC110","PVC160"]},
    BNVI:      {in:["PE50","PVC110","PVC160"],    out:["PVC110","PVC160"]},
    FEKSIURB:  {in:["PVC110","PVC160"],           out:["PE50"]},
    DRENSIURB: {in:["PVC110","PVC160"],           out:["PE32"]},
    INFSUL:    {in:["PVC110","PVC160"],           out:null},
    UZDTALP:   {in:["PE50","PVC110","PVC160"],    out:null},
    INFKAUB:   {in:["PE32"],                      out:null},
    ZEMPAV:    {in:["PE32"],                      out:null},
    SLAIT:     {in:["PVC110","PVC160"],           out:null},
    INFLAUK:   {in:["PE32"],                      out:null},
    MEGSUL:    {in:["PVC110","PVC160"],           out:["PVC110","PVC160"]},
  },

  gvl_blokuoja: _DOMAIN ? _DOMAIN.gvl_blokuoja : {
    "gvl-1":[1,4,6,11],"gvl-2":[1,6],"gvl-3":[]
  },

  grunto_grupes: _DOMAIN ? _DOMAIN.grunto_grupes : {
    "@smel":["Smėlis","Žvyras","Priesmėlis"],"@mol":["Molis","Priemolis"]
  },

  

  
  autoTags(oid) {
    const tags=[];
    
    for(const [zt,d] of Object.entries(this.z_lygiai)) if(d.obj.includes(oid)) tags.push(zt);
    
    const sek=DEF_OBJS.find(o=>o.id===oid)?.sek||[];
    sek.forEach(s=>tags.push('@sek'+s));
    
    const tipai=this.sistemu_tipai.filter(t=>t.grandine.includes(oid)).map(t=>t.rusis);
    [...new Set(tipai)].forEach(t=>tags.push(t));
    
    const io=this.in_out[oid];
    if(io){
      (io.in||[]).forEach(v=>tags.push('@in-'+v.toLowerCase()));
      (io.out||[]).forEach(v=>tags.push('@out-'+v.toLowerCase()));
    }
    return [...new Set(tags)];
  },

  
  relations(oid) {
    const up=new Set(), down=new Set();
    this.sistemu_tipai.forEach(t=>{
      const i=t.grandine.indexOf(oid);
      if(i>0) up.add(t.grandine[i-1]);
      if(i>=0&&i<t.grandine.length-1) down.add(t.grandine[i+1]);
    });
    return {upstream:[...up].filter(x=>x!==oid), downstream:[...down].filter(x=>x!==oid)};
  },

  
  leistinos_sistemos(gvl) {
    const blok=this.gvl_blokuoja[gvl]||[];
    return this.sistemu_tipai.filter(t=>!blok.includes(t.id));
  }
};

const DEF_OBJS = _DOMAIN
  ? Object.entries(_DOMAIN.objektai).map(([id, o]) => ({id, name:o.name, sek:o.sek, z:o.z}))
  : [
    {id:"NAM1",      name:"Namas (įprastas gylis)",     sek:["A"],         z:"@ipgil"},
    {id:"NAM2",      name:"Namas (gilus gylis 1.6m+)",  sek:["A"],         z:"@gilu"},
    {id:"BNVI",      name:"Biol. nuotekų valymo įr.",   sek:["B","C"],     z:"@ipgil"},
    {id:"FEKSIURB",  name:"Fekalinis siurblys",          sek:["B"],         z:"@gilu"},
    {id:"DRENSIURB", name:"Drenažo siurblys",            sek:["C","D"],     z:"@ipgil"},
    {id:"MEGSUL",    name:"Mėginių ėmimo šulinys",      sek:["C","D"],     z:"@ipgil"},
    {id:"UZDTALP",   name:"Uždara talpykla",             sek:["B","C","D"], z:"@ipgil"},
    {id:"INFSUL",    name:"Infiltracinis šulinys",       sek:["C","D","E"], z:"@ipgil"},
    {id:"INFKAUB",   name:"Infiltracinis kauptuvas",     sek:["D","E"],     z:"@zempav"},
    {id:"INFLAUK",   name:"Infiltracinis laukas",        sek:["D","E"],     z:"@ipgil"},
    {id:"ZEMPAV",    name:"Žemės paviršius",             sek:["D","E"],     z:"@zempav"},
    {id:"SLAIT",     name:"Šlaitas / nuokalnė",          sek:["C","D","E"], z:"@ipgil"},
  ];

const DEF_TAG_CATS = {};

let KB = {
  schema:"6.0", created:new Date().toISOString(), updated:"",
  objects_meta:{}, objects:{},
  components_meta:{}, components:{},
  field_cases:[], timeline_events:[],
  decision_trees:{},
  tag_categories:{},
  tag_relations:[],
  percentages:{}
};

let curObj="BNVI", curKTab="base", curJTab="obj";
let curComp=null;
let mapSc=1, mapX=0, mapY=0, mapDrag=false, mapLast=null;
let pendImp=null, dcMeta={};
let diagSel=[], diagEnv={gvl:'',soil:'',age:''};
let trelViewGraph=false;

function emptyObj(id, name) {
  return {
    id, name,
    meta:{confidence:0, sources:[], reviewed:false, created:new Date().toISOString(), updated:"", version:1},
    tags:[], function:"", normal_operation:"", normal_signs:[],
    failure_modes:{},
    exploitation_errors:[],
    env_behavior:{gvl:{gvl1:"",gvl2:"",gvl3:""},soil:{smel:"",mol:""},age_effects:"",reljefas:"",vamzdziai_in:[],vamzdziai_out:[]},
    relations:{upstream:[],downstream:[],alternatives:[],depends_on:[]}
  };
}

function emptyComp(id, name, parent_id, y_level) {
  return {
    id, name,
    parent_id: parent_id || '',
    y_level: y_level || 1,
    meta:{confidence:0, sources:[], reviewed:false, created:new Date().toISOString(), updated:"", version:1},
    tags:[], function:"", normal_operation:"", normal_signs:[],
    failure_modes:{},
    exploitation_errors:[],
    env_behavior:{gvl:{gvl1:"",gvl2:"",gvl3:""},soil:{smel:"",mol:""},age_effects:"",reljefas:"",vamzdziai_in:[],vamzdziai_out:[]},
    relations:{upstream:[],downstream:[],alternatives:[],depends_on:[]}
  };
}

function initObjs() {
  DEF_OBJS.forEach(o => {
    if(!KB.objects_meta[o.id]) KB.objects_meta[o.id] = {...o, custom:false};
    if(!KB.objects[o.id]) {
      const obj = emptyObj(o.id, o.name);
      
      obj.tags = TECH.autoTags(o.id);
      
      const rel = TECH.relations(o.id);
      obj.relations.upstream   = rel.upstream;
      obj.relations.downstream = rel.downstream;
      
      const io = TECH.in_out[o.id];
      if(io) {
        obj.env_behavior.vamzdziai_in  = io.in  || [];
        obj.env_behavior.vamzdziai_out = io.out || [];
      }
      KB.objects[o.id] = obj;
    }
  });
}
