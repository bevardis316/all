<?php

$_domainCache = null;

function getDomain() {
    global $_domainCache;
    
    if ($_domainCache !== null) return $_domainCache;

    
    if (!defined('DATA_DIR')) return null;

    $path = DATA_DIR . 'meta/domain.json';
    if (!file_exists($path)) return null;

    $raw = file_get_contents($path);
    if ($raw === false) return null;

    $data = json_decode($raw, true);
    
    if (!is_array($data)) return null;

    $_domainCache = $data;
    return $data;
}

function getKonDomain() {
    $d = getDomain();
    
    return ($d && isset($d['kon'])) ? $d['kon'] : $d;
}

function getDomainJson() {
    $d = getDomain();
    if ($d === null) return 'null';
    return json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function getDomainPublicJson() {
    $full = getDomain();
    if ($full === null) return 'null';

    // Abbreviated keys to match state.min.js expectations
    $ob = [];
    foreach ($full['objektai'] ?? [] as $id => $o) {
        $ob[$id] = [
            'n'  => $o['name']  ?? '',
            'sk' => $o['sek']   ?? [],
            'z'  => $o['z']     ?? '',
        ];
    }

    $zl = [];
    foreach ($full['z_lygiai'] ?? [] as $k => $v) {
        $zl[$k] = [
            'pv' => $v['pav'] ?? '',
            'ob' => $v['obj'] ?? [],
        ];
    }

    $st = [];
    foreach ($full['sistemu_tipai'] ?? [] as $t) {
        $st[] = [
            'id'       => $t['id'],
            'g'        => $t['grandine'] ?? [],
            'r'        => $t['rusis'] ?? '',
            'grandine' => $t['grandine'] ?? [],
            'rusis'    => $t['rusis'] ?? '',
        ];
    }

    $public = [
        'st' => $st,
        'ob' => $ob,
        'zl' => $zl,
        'se' => $full['sektoriai']     ?? [],
        'io' => $full['in_out']        ?? [],
        'gb' => $full['gvl_blokuoja']  ?? [],
        'gg' => $full['grunto_grupes'] ?? [],
    ];
    return json_encode($public, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
