<?php
require_once dirname(__DIR__, 3) . '/private/bootstrap.php';
