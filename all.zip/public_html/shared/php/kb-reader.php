<?php

if (!defined('DATA_DIR')) {
    throw new RuntimeException('DATA_DIR turi būti apibrėžtas prieš įtraukiant kb-reader.php');
}

function loadDomain() {
    $path = DATA_DIR . 'meta/domain.json';
    if (!file_exists($path)) return null;
    $data = json_decode(file_get_contents($path), true);
    return is_array($data) ? $data : null;
}

function kbReadJson($path) {
    if (!file_exists($path)) return null;
    $data = json_decode(file_get_contents($path), true);
    return is_array($data) ? $data : null;
}

function kbMetaPath($file)         { return DATA_DIR . "meta/{$file}.json"; }
function kbObjDir($oid)            { return DATA_DIR . "objects/{$oid}/"; }
function kbObjPath($oid, $file)    { return DATA_DIR . "objects/{$oid}/{$file}.json"; }
function kbFailurePath($oid, $fid) { return DATA_DIR . "objects/{$oid}/failures/{$fid}.json"; }
function kbFailureIdx($oid)        { return DATA_DIR . "objects/{$oid}/failures/_index.json"; }
function kbCompDir($parentId)      { return DATA_DIR . "components/{$parentId}/"; }

function kbLoadAll() {
    $domain = loadDomain();
    $defObjects = $domain
        ? array_keys($domain['objektai'])
        : ['NAM1','NAM2','BNVI','FEKSIURB','DRENSIURB','MEGSUL','UZDTALP','INFSUL','INFKAUB','INFLAUK','ZEMPAV','SLAIT'];

    $result = [
        'objects_meta'    => [],
        'objects'         => [],
        'components'      => [],
        'components_meta' => [],
    ];

    foreach ($defObjects as $oid) {
        $base = kbReadJson(kbObjPath($oid, 'base'));
        if (!$base) continue;

        $result['objects_meta'][$oid] = [
            'id'     => $oid,
            'name'   => $base['name'] ?? $oid,
            'sek'    => $base['sek']  ?? [],
            'z'      => $base['z']    ?? '',
            'custom' => $base['custom'] ?? false,
        ];

        $obj = [
            'name'                 => $base['name'] ?? $oid,
            'function'             => $base['function'] ?? '',
            'normal_operation'     => $base['normal_operation'] ?? '',
            'normal_signs'         => $base['normal_signs'] ?? [],
            'tags'                 => $base['tags'] ?? [],
            'models'               => $base['models'] ?? [],
            'packages'             => $base['packages'] ?? [],
            'maintenance_schedule' => $base['maintenance_schedule'] ?? [],
            'failure_modes'        => [],
            'scene_3d'             => $base['scene_3d'] ?? null,
        ];

        $env = kbReadJson(kbObjPath($oid, 'env'));
        if ($env) $obj['env_behavior'] = $env;

        $rels = kbReadJson(kbObjPath($oid, 'relations'));
        if ($rels) $obj['relations'] = $rels;

        $fdir = DATA_DIR . "objects/{$oid}/failures/";
        if (is_dir($fdir)) {
            foreach (glob($fdir . '*.json') ?: [] as $ff) {
                if (str_ends_with($ff, '_index.json')) continue;
                $fid = basename($ff, '.json');
                $fd  = kbReadJson($ff);
                if ($fd) $obj['failure_modes'][$fid] = $fd;
            }
        }

        $result['objects'][$oid] = $obj;
    }

    $compBase = DATA_DIR . 'components';
    if (is_dir($compBase)) {
        foreach (glob($compBase . '/*', GLOB_ONLYDIR) ?: [] as $parentDir) {
            $parentId = basename($parentDir);
            foreach (glob($parentDir . '/*.json') ?: [] as $compFile) {
                $comp = kbReadJson($compFile);
                if (!$comp) continue;
                $cid = $comp['id'] ?? basename($compFile, '.json');
                $realParent = $comp['parent_id'] ?? $parentId;
                $result['components'][$cid]      = $comp;
                $result['components_meta'][$cid] = [
                    'id'        => $cid,
                    'name'      => $comp['name'] ?? $cid,
                    'parent_id' => $realParent,
                    'y_level'   => $comp['y_level'] ?? 1,
                    'active'    => $comp['active'] ?? true, 
                ];
            }
        }
    }

    return $result;
}

function kbLoadPublic() {
    $full = kbLoadAll();
    $result = [
        'objects_meta'    => $full['objects_meta'],
        'objects'         => [],
        'components'      => [],
        'components_meta' => $full['components_meta'],
    ];

    foreach ($full['objects'] as $oid => $obj) {
        $result['objects'][$oid] = [
            'name'           => $obj['name'],
            'models'         => $obj['models'],
            'packages'       => $obj['packages'],
            'normal_signs'   => $obj['normal_signs'],
            'failure_modes'  => _filterFailuresPublic($obj['failure_modes'] ?? []),
            'scene_3d'       => $obj['scene_3d'] ?? null,
        ];
    }

    foreach ($full['components'] as $cid => $comp) {
        if (isset($comp['active']) && $comp['active'] === false) continue; 
        $result['components'][$cid] = [
            'id'         => $comp['id'],
            'name'       => $comp['name'],
            'parent_id'  => $comp['parent_id'],
            'y_level'    => $comp['y_level'] ?? 1,
            'in_package' => $comp['in_package'] ?? true,
            'map_x'      => $comp['map_x'] ?? null,
            'map_y'      => $comp['map_y'] ?? null,
            'map_z'      => $comp['map_z'] ?? null,
            'models'     => $comp['models'] ?? [],
            'pricing'    => $comp['pricing'] ?? null,
            'scene_3d'   => $comp['scene_3d'] ?? null,
        ];
    }

    return $result;
}

function _filterFailuresPublic($failures) {
    $result = [];
    foreach ($failures as $fid => $fm) {
        $result[$fid] = [
            'id'       => $fm['id'] ?? $fid,
            'name'     => $fm['name'] ?? '',
            'severity' => $fm['severity'] ?? '',
            'symptoms' => $fm['symptoms'] ?? [],
            'causes'   => ['primary' => $fm['causes']['primary'] ?? ''],
            'resolution' => $fm['resolution'] ?? '',
            'prevention' => $fm['prevention'] ?? '',
            'economics'  => $fm['economics'] ?? null,
            'diagnosis_steps' => $fm['diagnosis_steps'] ?? [],
        ];
    }
    return $result;
}
