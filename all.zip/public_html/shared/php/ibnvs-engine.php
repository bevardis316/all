<?php

if (!class_exists('IBNVS')) {

class IBNVS {

  
  private static $_d = null;

  private static function d() {
    if (self::$_d !== null) return self::$_d;
    $path = DATA_DIR . 'meta/domain.json';
    if (!file_exists($path)) {
      error_log('IBNVS: domain.json nerastas: ' . $path);
      self::$_d = [];
      return self::$_d;
    }
    $raw = file_get_contents($path);
    self::$_d = json_decode($raw, true) ?: [];
    return self::$_d;
  }

  

  private static function sistemosTipai() {
    $tipai = [];
    foreach (self::d()['sistemu_tipai'] ?? [] as $t) {
      $tipai[] = $t['grandine'];
    }
    return $tipai;
  }

  private static function objektuSektoriai($oid) {
    return self::d()['objektai'][$oid]['sek'] ?? ['B'];
  }

  private static function objektuGylis($oid) {
    $obj = self::d()['objektai'][$oid] ?? null;
    if ($obj && isset($obj['gylis'])) return (string)$obj['gylis'];
    $z = $obj['z'] ?? '@ipgil';
    return ['@zempav' => '0', '@ipgil' => '-1', '@gilu' => '-2', '@lbgilu' => '-3'][$z] ?? '-1';
  }

  private static function sektoriai() {
    return array_keys(self::d()['sektoriai'] ?? ['A'=>'','B'=>'','C'=>'','D'=>'','E'=>'']);
  }

  

  public static function gvlLeidzia($kandidatas, $sistema, $gvl, $gruntas) {
    $d = self::d();
    $blokNr = array_merge(
      $d['gvl_blokuoja'][$gvl] ?? [],
      ($gvl === 'gvl-3' && $gruntas === 'mol') ? ($d['mol_blokuoja'] ?? []) : []
    );
    if (empty($blokNr)) return true;

    $visi = self::sistemosTipai();
    $blokuojamos = array_map(fn($nr) => $visi[$nr - 1] ?? [], $blokNr);
    $kelias = array_merge($sistema, [$kandidatas]);

    return (bool) array_filter($visi, function($s) use ($kelias, $blokuojamos) {
      if (count($kelias) > count($s)) return false;
      for ($i = 0; $i < count($kelias); $i++) {
        if ($s[$i] !== $kelias[$i]) return false;
      }
      foreach ($blokuojamos as $b) {
        if (count($b) === count($s) && $b === $s) return false;
      }
      return true;
    });
  }

  public static function getGalimiObjektai($sistema, $gvl = null, $gruntas = null) {
    if (empty($sistema)) {
      $kandidatai = ['NAM1', 'NAM2'];
    } else {
      $galimi = [];
      foreach (self::sistemosTipai() as $tipas) {
        if (count($tipas) > count($sistema)) {
          $match = true;
          for ($i = 0; $i < count($sistema); $i++) {
            if ($tipas[$i] !== $sistema[$i]) { $match = false; break; }
          }
          if ($match) $galimi[] = $tipas[count($sistema)];
        }
      }
      $kandidatai = array_unique($galimi);
    }
    if ($gvl) {
      $kandidatai = array_values(array_filter($kandidatai,
        fn($k) => self::gvlLeidzia($k, $sistema, $gvl, $gruntas)
      ));
    }
    return $kandidatai;
  }

  

  public static function pridetiObjekta($sistema, $naujasTipas, $dabartinisSektorius) {
    $d = self::d();

    $galimisektoriai = self::objektuSektoriai($naujasTipas);
    $gylis           = self::objektuGylis($naujasTipas);
    $koordinates     = self::_koordinates($sistema, $naujasTipas, $d);

    $sektoriai  = self::sektoriai();
    $sektorius  = in_array($dabartinisSektorius, $galimisektoriai)
                    ? $dabartinisSektorius
                    : $galimisektoriai[0];

    $vamzdis = null;
    if (!empty($sistema)) {
      $paskutinis = end($sistema);
      $jungRaktas = $paskutinis . '->' . $naujasTipas;
      $vamzdis    = $d['vamzdziu_tipai'][$jungRaktas] ?? 'PVC';
    }

    $objektas = [
      'tipas'       => $naujasTipas,
      'sektorius'   => $sektorius,
      'gylis'       => $gylis,
      'x'           => $koordinates['x'],
      'y'           => $koordinates['y'],
      'vamzdis'     => $vamzdis,
      'jungtys'     => $d['jungtys'][$naujasTipas]   ?? null,
      'aprasymas'   => $d['aprasymai'][$naujasTipas] ?? $naujasTipas,
      'trumpinimas' => $d['objektai'][$naujasTipas]['trumpinimas'] ?? $naujasTipas,
      'infoTekstas' => $d['aprasymai'][$naujasTipas] ?? '',
    ];

    $sektoriusIndex  = array_search($sektorius, $sektoriai);
    $naujasSektorius = ($sektoriusIndex !== false && $sektoriusIndex < count($sektoriai) - 1)
      ? $sektoriai[$sektoriusIndex + 1]
      : $sektorius;

    return ['objektas' => $objektas, 'naujasSektorius' => $naujasSektorius];
  }

  

  private static function _koordinates($sistema, $naujasTipas, $d) {
    $koord = $d['koordinates'] ?? [];

    if (!empty($sistema)) {
      $pilnaSeka = implode('->', $sistema) . '->' . $naujasTipas;
      if (isset($koord[$pilnaSeka])) return $koord[$pilnaSeka];
      $trumpaSeka = end($sistema) . '->' . $naujasTipas;
      if (isset($koord[$trumpaSeka])) return $koord[$trumpaSeka];
    } else {
      if (isset($koord[$naujasTipas])) return $koord[$naujasTipas];
    }

    $obj = $d['objektai'][$naujasTipas] ?? null;
    if ($obj && isset($obj['x'])) return ['x' => $obj['x'], 'y' => $obj['y']];

    $fallback = [
      'NAM1'     => ['x' => 0.0286, 'y' => 0.3527],
      'NAM2'     => ['x' => 0.0292, 'y' => 0.7982],
      'FEKSIURB' => ['x' => 0.1860, 'y' => 0.5937],
      'BNVI'     => ['x' => 0.3889, 'y' => 0.4571],
      'MEGSUL'   => ['x' => 0.5097, 'y' => 0.3857],
      'DRENSIURB'=> ['x' => 0.5531, 'y' => 0.4514],
    ];
    return $fallback[$naujasTipas] ?? ['x' => 0.5, 'y' => 0.5];
  }

  public static function aprasymas($oid) {
    return self::d()['aprasymai'][$oid] ?? $oid;
  }
}

}
