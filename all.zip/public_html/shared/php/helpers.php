<?php

function apiErr($code, $msg) {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

function apiOk($data = []) {
    echo json_encode(array_merge(['ok' => true], $data), JSON_UNESCAPED_UNICODE);
}

function safeId($s) {
    return preg_replace('/[^a-zA-Z0-9_\-]/', '', $s ?? '');
}

function apiHeaders() {
    header('Content-Type: application/json; charset=utf-8');
    $origin  = $_SERVER['HTTP_ORIGIN'] ?? '';
    $allowed = $_SERVER['HTTP_HOST']   ?? '';
    if ($origin && parse_url($origin, PHP_URL_HOST) === $allowed) {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Access-Control-Allow-Credentials: true');
    }
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
}

function requirePost() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        apiErr(405, 'Tik POST');
    }
}

function getBody() {
    $raw = file_get_contents('php://input');
    if (!$raw) apiErr(400, 'Tuščias body');
    $d = json_decode($raw, true);
    if (!is_array($d)) apiErr(400, 'Blogas JSON');
    return $d;
}

function rateLimit($max = 30, $periodMin = 1, $prefix = 'pub') {
    $ip  = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $key = sys_get_temp_dir() . '/rl_' . $prefix . '_' . md5($ip) . '.json';
    $now = time();
    $win = $periodMin * 60;

    $d = ['hits' => [], 'blocked_until' => 0];
    if (file_exists($key)) {
        $p = json_decode(file_get_contents($key), true);
        if (is_array($p)) $d = $p;
    }

    if ($d['blocked_until'] > $now) {
        apiErr(429, 'Per daug užklausų. Bandykite vėliau.');
    }

    $d['hits'] = array_values(array_filter($d['hits'], fn($t) => $t > $now - $win));

    if (count($d['hits']) >= $max) {
        $d['blocked_until'] = $now + 60;
        file_put_contents($key, json_encode($d), LOCK_EX);
        apiErr(429, 'Per daug užklausų. Bandykite po minutės.');
    }

    $d['hits'][] = $now;
    file_put_contents($key, json_encode($d), LOCK_EX);
}
