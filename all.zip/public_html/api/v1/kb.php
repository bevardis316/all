<?php
session_name('ibnvs_gate');
session_start();
if (empty($_SESSION['ibnvs_auth'])) {
    http_response_code(403);
    echo json_encode(['ok'=>false,'error'=>'Unauthorized']);
    exit;
}
require dirname(__DIR__, 3) . '/private/api/kb.php';
