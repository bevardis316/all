<?php
// Laikinas diagnostikos failas — po patikrinimo IŠTRINKITE
// Atidarykite naršyklėje: jusu-svetaine.lt/api/test_ai.php

require_once dirname(__DIR__, 2) . '/private/bootstrap.php';

header('Content-Type: text/plain; charset=utf-8');

echo "=== IBNVS AI Diagnostika ===\n\n";

// 1. Konstantos
echo "1. ANTHROPIC_KEY: " . (ANTHROPIC_KEY ? 'NUSTATYTAS (' . substr(ANTHROPIC_KEY, 0, 12) . '...)' : '⛔ TUSCIAS - .env faile nera ANTHROPIC_KEY') . "\n";
echo "   ANTHROPIC_MODEL: " . ANTHROPIC_MODEL . "\n";
echo "   OPENAI_KEY: " . (OPENAI_KEY ? 'NUSTATYTAS' : '⛔ TUSCIAS') . "\n\n";

if (!ANTHROPIC_KEY) {
    echo "⛔ SUSTABDYTA: ANTHROPIC_KEY nenustatytas.\n";
    echo "   Patikrinkite .env faila - turi buti eilute: ANTHROPIC_KEY=sk-ant-...\n";
    exit;
}

// 2. Curl test — ar serveris pasiekia Anthropic
echo "2. Jungimasis prie api.anthropic.com...\n";
$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'x-api-key: ' . ANTHROPIC_KEY,
        'anthropic-version: 2023-06-01',
    ],
    CURLOPT_POSTFIELDS => json_encode([
        'model'      => ANTHROPIC_MODEL,
        'max_tokens' => 30,
        'system'     => 'Tu esi testas. Atsakyk vienu zodziu.',
        'messages'   => [['role' => 'user', 'content' => 'Labas']],
    ]),
    CURLOPT_TIMEOUT => 20,
]);
$resp     = curl_exec($ch);
$curlErr  = curl_error($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($curlErr) {
    echo "   ⛔ CURL KLAIDA: " . $curlErr . "\n";
    echo "   Priezastis: serveris negali jungtis prie api.anthropic.com\n";
    echo "   Sprendimas: kreipkites i hostingo palaikyma - reikia leisti HTTPS isejima i api.anthropic.com\n";
    exit;
}

echo "   HTTP kodas: " . $httpCode . "\n";

$data = json_decode($resp, true);
if ($httpCode === 401) {
    echo "   ⛔ NETEISINGAS API RAKTAS (401)\n";
    echo "   Patikrinkite ANTHROPIC_KEY reiksme .env faile\n";
    exit;
}
if ($httpCode === 403) {
    echo "   ⛔ PRIEIGA UZDRAUSTA (403) - raktas galioja bet neturi teisiu\n";
    exit;
}
if (!empty($data['error'])) {
    echo "   ⛔ Anthropic klaida: " . json_encode($data['error'], JSON_UNESCAPED_UNICODE) . "\n";
    exit;
}

$text = $data['content'][0]['text'] ?? null;
if ($text) {
    echo "   ✅ VEIKIA! Atsakymas: \"" . $text . "\"\n\n";
    echo "=== Viskas gerai. Chat'as turi veikti. ===\n";
} else {
    echo "   ⚠️ Neigrastas atsakymas. Raw response:\n" . substr($resp, 0, 300) . "\n";
}
