<?php
/**
 * public_html/api/v1/chat-eval.php
 *
 * Proxy admin'o diagnostikos endpoint'ui. Reikalauja admin sesijos
 * (tos pačios, kuria atveriamas /tool1/ ir kitos saugomos vietos).
 */

session_name('ibnvs_gate');
session_set_cookie_params([
    'lifetime' => 28800,
    'path'     => '/',
    'secure'   => true,
    'httponly' => true,
    'samesite' => 'Strict',
]);
session_start();

if (empty($_SESSION['ibnvs_auth'])) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'Tik admin\'ui (prisijunkite per /gate.php)'], JSON_UNESCAPED_UNICODE);
    exit;
}

require dirname(__DIR__, 3) . '/private/api/chat/_eval.php';
