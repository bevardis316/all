<?php
// Grąžina komponentų scene_3d duomenis (glb, scale, rotation ir t.t.)
// Naudojamas konstruktoriaus KB loader'io

session_name('ibnvs_gate');
session_start();
if (empty($_SESSION['ibnvs_auth'])) {
    http_response_code(403);
    echo json_encode(['ok'=>false,'error'=>'Unauthorized']);
    exit;
}
require_once dirname(__DIR__, 3) . '/private/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

$result = [];

$compBase = DATA_DIR . 'components';
if (is_dir($compBase)) {
    foreach (glob($compBase . '/*', GLOB_ONLYDIR) ?: [] as $parentDir) {
        foreach (glob($parentDir . '/*.json') ?: [] as $compFile) {
            $comp = json_decode(file_get_contents($compFile), true);
            if (!$comp) continue;
            $cid = $comp['id'] ?? basename($compFile, '.json');
            if (!empty($comp['scene_3d'])) {
                $result[$cid] = $comp['scene_3d'];
            }
        }
    }
}

echo json_encode(['ok' => true, 'scene3d' => $result]);
