<?php require dirname(__DIR__, 3) . '/private/api/symptoms.php';
