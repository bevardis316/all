<?php
require_once dirname(__DIR__, 2) . '/private/bootstrap.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

apiHeaders();
requirePost();

$ip  = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$now = time();
rateLimit(5, 10, 'order');

$body = json_decode(file_get_contents('php://input'), true);
if (!$body) { http_response_code(400); echo json_encode(['ok'=>false,'err'=>'Neteisingi duomenys']); exit; }
$vardas    = trim($body['vardas']    ?? '');
$tel       = trim($body['tel']       ?? '');
$emailFrom = trim($body['email']     ?? '');
$zinute    = trim($body['zinute']    ?? '');
$sarasHtml = strip_tags($body['saraso_html'] ?? '', '<ul><li><strong><br>');
$grandClient = (float)($body['grand_total'] ?? 0);

$items        = $body['items'] ?? [];
$grand        = $grandClient; 
$priceWarning = null;         

if (!empty($items) && is_array($items)) {
    $dataDir = DATA_DIR;
    $calculated = 0.0;

    foreach ($items as $item) {
        if (!is_array($item)) continue;
        $type     = $item['type']      ?? '';
        $id       = preg_replace('/[^a-zA-Z0-9_\-]/', '', $item['id']      ?? '');
        $parentId = preg_replace('/[^a-zA-Z0-9_\-]/', '', $item['parent_id'] ?? '');
        $modelId  = preg_replace('/[^a-zA-Z0-9_\-]/', '', $item['model_id'] ?? '');

        if ($type === 'obj' && $id) {
            
            $baseFile = $dataDir . "objects/{$id}/base.json";
            if (file_exists($baseFile)) {
                $base = json_decode(file_get_contents($baseFile), true);
                $models = $base['models'] ?? [];
                $price = 0;
                if ($modelId) {
                    foreach ($models as $m) {
                        if (($m['id'] ?? '') === $modelId) { $price = (float)($m['price_eur'] ?? 0); break; }
                    }
                }
                if (!$price && !empty($models)) $price = (float)($models[0]['price_eur'] ?? 0);
                $calculated += $price;
            }
        } elseif ($type === 'comp' && $id && $parentId) {
            
            $compFile = $dataDir . "components/{$parentId}/{$id}.json";
            if (file_exists($compFile)) {
                $comp = json_decode(file_get_contents($compFile), true);
                $models  = $comp['models']  ?? [];
                $pricing = $comp['pricing'] ?? [];
                $qty     = max(1, (int)($pricing['quantity_per_system'] ?? 1));
                $price   = 0;
                if ($modelId) {
                    foreach ($models as $m) {
                        if (($m['id'] ?? '') === $modelId) { $price = (float)($m['price_eur'] ?? 0); break; }
                    }
                }
                if (!$price) $price = (float)($pricing['part_price'] ?? 0);
                $calculated += $price * $qty;
            }
        }
    }

    
    $grand = $calculated;

    
    if ($grandClient > 0 && $calculated > 0) {
        $diff = abs($grandClient - $calculated) / max($grandClient, $calculated);
        if ($diff > 0.05) {
            $priceWarning = [
                'klientas'      => $grandClient,
                'serveris'      => $calculated,
                'skirtumas_pct' => round($diff * 100),
            ];
        }
    }
} elseif ($grandClient > 0) {
    
    $grand = $grandClient;
}

if (!$vardas) { echo json_encode(['ok'=>false,'err'=>'Iveskite varda']); exit; }
if (!$tel && !$emailFrom) { echo json_encode(['ok'=>false,'err'=>'Iveskite telefona arba el. pasta']); exit; }
if ($emailFrom && !filter_var($emailFrom, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['ok'=>false,'err'=>'Neteisingas el. pasto formatas']); exit;
}

$v  = fn($s) => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
$nr   = 'UZS-' . strtoupper(substr(md5($now.$ip), 0, 6));
$date = date('Y-m-d H:i', $now);

$adminEmail = ADMIN_EMAIL;

$grandFmt   = $grand > 0 ? '~' . number_format($grand, 0, '.', ' ') . ' EUR' : 'nenurodytas';
$telHtml    = $tel       ? '<div class="field"><label>Telefonas</label><div class="val">'.$v($tel).'</div></div>' : '';
$emailHtml2 = $emailFrom ? '<div class="field"><label>El. pastas</label><div class="val">'.$v($emailFrom).'</div></div>' : '';
$zinuteHtml = $zinute    ? '<div class="field"><label>Zinute</label><div class="val">'.$v($zinute).'</div></div>' : '';

$css = 'body{font-family:Arial,sans-serif;font-size:13px;color:#1b2e1b;padding:0;margin:0}'
     . '.wrap{max-width:620px;margin:20px auto;background:#fff;border-radius:8px;overflow:hidden}'
     . '.hdr{background:#2e7d32;color:#fff;padding:18px 24px}'
     . '.hdr h1{font-size:17px;margin:0 0 3px}'
     . '.hdr small{opacity:.7;font-size:11px}'
     . '.body{padding:20px 24px}'
     . '.field{margin-bottom:10px}'
     . '.field label{font-size:10px;font-weight:700;color:#5a7a5a;text-transform:uppercase;letter-spacing:.06em;display:block;margin-bottom:2px}'
     . '.field .val{font-size:13px;font-weight:600}'
     . 'hr{border:none;border-top:1px solid #c8e6c9;margin:16px 0}'
     . '.sarasas{background:#f0f7f0;border-radius:6px;padding:14px;margin-top:12px;font-size:12px}'
     . '.total{font-size:15px;font-weight:700;color:#2e7d32;margin-top:10px}'
     . '.ftr{background:#e8f5e9;padding:10px 24px;font-size:10px;color:#5a7a5a;text-align:center}';

$html = '<!DOCTYPE html><html lang="lt"><head><meta charset="UTF-8"><style>'.$css.'</style></head><body>'
      . '<div class="wrap">'
      .   '<div class="hdr"><h1>Naujas uzsakymas — IBNVS konstruktorius</h1><small>'.$nr.' | '.$date.'</small></div>'
      .   '<div class="body">'
      .     '<div class="field"><label>Vardas</label><div class="val">'.$v($vardas).'</div></div>'
      .     $telHtml . $emailHtml2 . $zinuteHtml
      .     '<hr>'
      .     '<div style="font-size:11px;font-weight:700;color:#5a7a5a;text-transform:uppercase;margin-bottom:8px">Pirkimo sarasas</div>'
      .     '<div class="sarasas">'.$sarasHtml.'</div>'
      .     '<div class="total">Viso: '.$grandFmt.'</div>'
      .   '</div>'
      .   '<div class="ftr">IBNVS Konstruktorius | manonuotekos.lt | IP: '.htmlspecialchars($ip, ENT_QUOTES).'</div>'
      . '</div></body></html>';

$subject = '=?UTF-8?B?'.base64_encode('Uzsakymas '.$nr.' — '.$vardas).'?=';
$headers = "MIME-Version: 1.0\r\n"
         . "Content-Type: text/html; charset=UTF-8\r\n"
         . "From: IBNVS <noreply@manonuotekos.lt>\r\n"
         . "Reply-To: " . ($emailFrom ?: $adminEmail) . "\r\n"
         . "X-Mailer: IBNVS-Order/1.0";

$sent = mail($adminEmail, $subject, $html, $headers);

$ordersDir = DATA_DIR . 'orders/';
if (!is_dir($ordersDir)) @mkdir($ordersDir, 0755, true);
if (is_dir($ordersDir)) {
    file_put_contents(
        $ordersDir . $nr . '.json',
        json_encode([
            'id'   => $nr, 'ts' => date('c', $now),
            'vardas' => $vardas, 'tel' => $tel, 'email' => $emailFrom,
            'zinute' => $zinute, 'grand' => $grand, 'grand_klientas' => $grandClient,
            'price_warning' => $priceWarning, 'ip' => $ip, 'mail_sent' => $sent,
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
        LOCK_EX
    );
}

echo json_encode(['ok'=>true, 'nr'=>$nr, 'msg'=>'Uzsakymas gautas! Susisieksime per 1 darbo diena.']);
