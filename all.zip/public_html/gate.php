<?php

session_name('ibnvs_gate');
session_set_cookie_params([
    'lifetime' => 28800,
    'path'     => '/',
    'secure'   => true,
    'httponly' => true,
    'samesite' => 'Strict',
]);
session_start();

require_once dirname(__DIR__) . '/private/bootstrap.php';

$error = '';
$hash  = ADMIN_PASSWORD_HASH;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pw   = $_POST['password'] ?? '';
    $dest = $_POST['dest']     ?? '/';
    if (!preg_match('/^\/[a-zA-Z0-9\/_\-\.]*$/', $dest)) $dest = '/';
    if ($hash && password_verify($pw, $hash)) {
        $_SESSION['ibnvs_auth'] = true;
        $_SESSION['ibnvs_time'] = time();
        $_SESSION['ibnvs_ts']   = time(); 
        header('Location: ' . $dest);
        exit;
    } else {
        $error = 'Neteisingas slaptažodis.';
    }
}

if (!empty($_SESSION['ibnvs_auth'])) { header('Location: /'); exit; }

$dest = '/';
$raw  = $_GET['dest'] ?? '/';
if (preg_match('/^\/[a-zA-Z0-9\/_\-\.]*$/', $raw)) $dest = $raw;


if (empty($_SESSION['gate_tracked'])) {
    $_SESSION['gate_tracked'] = true;
    $ua     = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $device = 'desktop';
    if (preg_match('/Mobile|Android|iPhone/i', $ua)) $device = 'mobile';
    elseif (preg_match('/iPad|Tablet/i', $ua))        $device = 'tablet';

    $browser = 'other';
    if (str_contains($ua,'Chrome') && !str_contains($ua,'Edg')) $browser = 'chrome';
    elseif (str_contains($ua,'Firefox'))                         $browser = 'firefox';
    elseif (str_contains($ua,'Safari') && !str_contains($ua,'Chrome')) $browser = 'safari';
    elseif (str_contains($ua,'Edg'))                             $browser = 'edge';

    $entry = [
        'ts'      => date('c'),
        'page'    => 'landing',
        'device'  => $device,
        'browser' => $browser,
        'duration'=> 0,
    ];
    if (!is_dir(ANALYTICS_DIR)) @mkdir(ANALYTICS_DIR, 0755, true);
    $file = ANALYTICS_DIR . date('Y-m') . '.json';
    $data = file_exists($file) ? (json_decode(file_get_contents($file), true) ?? []) : [];
    $data[] = $entry;
    if (count($data) > 5000) $data = array_slice($data, -5000);
    @file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE), LOCK_EX);
}
?>
<!doctype html>
<html lang="lt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Virtualus Konsultantas</title>
  <link rel="stylesheet" href="index.css" />
  <style>
    
    body {
      background-image: url('home.jpg') !important;
      background-size: cover !important;
      background-position: center center !important;
      background-attachment: scroll !important; 
    }
    
    .container {
      padding-bottom: 20px !important;
    }

    
    .action-button { cursor: pointer; }

    
    #gate-overlay {
      position: fixed;
      inset: 0;
      z-index: 50;
      cursor: default;
    }

    
    #gate-drawer {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 200;
      background: rgba(8, 8, 8, 0.92);
      backdrop-filter: blur(18px);
      -webkit-backdrop-filter: blur(18px);
      border-top: 1px solid rgba(255,255,255,0.1);
      border-radius: 20px 20px 0 0;
      padding: 24px 24px 32px;
      transform: translateY(100%);
      transition: transform 0.35s cubic-bezier(0.32, 0.72, 0, 1);
    }

    #gate-drawer.open {
      transform: translateY(0);
    }

    
    .drawer-handle {
      width: 40px;
      height: 4px;
      background: rgba(255,255,255,0.25);
      border-radius: 2px;
      margin: 0 auto 20px;
    }

    .drawer-title {
      font-size: 0.78rem;
      font-weight: 700;
      color: #22c55e;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      text-align: center;
      margin-bottom: 16px;
      animation: blink-green 1.3s ease-in-out infinite;
    }

    @keyframes blink-green {
      0%, 100% { opacity: 1; text-shadow: 0 0 10px rgba(34,197,94,0.9); }
      50%       { opacity: 0.2; text-shadow: none; }
    }

    .drawer-form {
      display: flex;
      gap: 10px;
      align-items: center;
    }

    .drawer-input-wrap {
      position: relative;
      flex: 1;
    }

    .drawer-input-wrap input {
      width: 100%;
      padding: 12px 40px 12px 14px;
      border: 1.5px solid rgba(255,255,255,0.15);
      border-radius: 10px;
      background: rgba(255,255,255,0.08);
      color: #fff;
      font-size: 1rem;
      outline: none;
      transition: border-color 0.2s, background 0.2s;
    }

    .drawer-input-wrap input::placeholder { color: rgba(255,255,255,0.35); }

    .drawer-input-wrap input:focus {
      border-color: #22c55e;
      background: rgba(255,255,255,0.12);
    }

    .toggle-pw {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      cursor: pointer;
      color: rgba(255,255,255,0.35);
      font-size: 1rem;
      padding: 0;
      line-height: 1;
      transition: color 0.15s;
    }
    .toggle-pw:hover { color: rgba(255,255,255,0.75); }

    .drawer-btn {
      padding: 12px 22px;
      background: #22c55e;
      color: #fff;
      border: none;
      border-radius: 10px;
      font-size: 0.95rem;
      font-weight: 700;
      cursor: pointer;
      white-space: nowrap;
      transition: background 0.2s, transform 0.1s;
      flex-shrink: 0;
    }
    .drawer-btn:hover  { background: #16a34a; }
    .drawer-btn:active { transform: scale(0.96); }

    .drawer-error {
      margin-top: 10px;
      font-size: 0.82rem;
      color: #f87171;
      text-align: center;
    }

    
    #gate-hint {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      z-index: 100;
      background: rgba(8,8,8,0.75);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      border-top: 1px solid rgba(255,255,255,0.07);
      height: 42px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: background 0.2s;
    }
    #gate-hint:hover { background: rgba(8,8,8,0.92); }

    #gate-hint span {
      font-size: 0.78rem;
      font-weight: 700;
      color: #22c55e;
      letter-spacing: 0.05em;
      animation: blink-green 1.3s ease-in-out infinite;
    }

    
    #lightbox {
      display: none;
      position: fixed;
      inset: 0;
      z-index: 300;
      background: rgba(0,0,0,0.92);
      align-items: center;
      justify-content: center;
      cursor: zoom-out;
      padding: 20px;
    }
    #lightbox.open { display: flex; }

    #lb-img {
      max-width: 92vw;
      max-height: 88vh;
      width: auto;
      height: auto;
      border-radius: 10px;
      box-shadow: 0 8px 60px rgba(0,0,0,0.8);
      display: block;
      object-fit: contain;
      cursor: default;
      animation: lb-in 0.2s ease;
    }

    @keyframes lb-in {
      from { opacity:0; transform:scale(0.94); }
      to   { opacity:1; transform:scale(1); }
    }

    .lb-close {
      position: fixed;
      top: 16px; right: 20px;
      font-size: 2rem;
      color: rgba(255,255,255,0.7);
      cursor: pointer;
      background: rgba(0,0,0,0.4);
      border: none;
      border-radius: 50%;
      width: 40px; height: 40px;
      display: flex; align-items: center; justify-content: center;
      z-index: 301;
      transition: color 0.15s, background 0.15s;
      line-height: 1;
    }
    .lb-close:hover { color: #fff; background: rgba(0,0,0,0.7); }
  </style>
</head>

<body>

  
  <div class="container">
    <header>
      <p>
        Dauguma problemų kyla ne dėl įrangos, o dėl to, kad niekas aiškiai nepaaiškino, kaip ja naudotis.
IBNVS – vieta, kur viskas pateikta suprantamai: kaip veikia, kaip sutaisyti, kur bei už kiek viską įsigyti. 
Viskas vienoje vietoje. Visiškai nemokamai. Nuolat tobulinama.
      </p>
    </header>

    <div class="chat-wrapper">
      <div class="messages" id="messages"></div>
      <form class="input-form" id="chatForm" onsubmit="interceptAction(event)">
        <input id="input" type="text" placeholder="Klauskite..." autocomplete="off" />
        <button type="submit">➤</button>
      </form>
    </div>

    <div class="buttons-wrapper">
      <div class="action-item">
        <span class="button-header">Konstruktorius</span>
        <button
          class="action-button"
          style="background-image: url('pav1.png')"
          onclick="interceptAction(event, 'kon/index.php')"
        ></button>
        <span class="button-description">Planuojate montuoti patys? Čia – mano rekomendacijos, kaip tai daryti, ir tikslius medžiagų kiekius su kainomis.</span>
      </div>

      <div class="action-item">
        <span class="button-header">Gedimų diagnostika</span>
        <button
          class="action-button"
          style="background-image: url('testui.jpg')"
          onclick="interceptAction(event, 'diag/diagnose.php')"
        ></button>
        <span class="button-description">Kažkas neveikia? Nurodykite simptomus, kuriuos matote, girdite, jaučiate, o aš pamėginsiu jums padėti.</span>
      </div>

      <div class="action-item">
        <span class="button-header">Kontaktų bazė</span>
        <button
          class="action-button"
          style="background-image: url('verslui.jpg')"
          onclick="interceptAction(event, 'map/')"
        ></button>
        <span class="button-description">Neieškokite meistrų už 300 km. Čia matysite, kur jie įisikūrę – kad žinotumėte, kurie meistrai ištiesu yra šalia jūsų.</span>
      </div>
    </div>
  </div>

  

  
  <div id="gate-hint" onclick="openDrawer()">
    <span>⬤ &nbsp;Naudojimasis galimas tik pakviestiems dalyviams</span>
  </div>

  
  <div id="gate-drawer">
    <div class="drawer-handle"></div>
    <div class="drawer-title">⬤ &nbsp;Kolkas tik pakviestiems dalyviams</div>

    <form class="drawer-form" method="POST" action="/gate.php" autocomplete="off">
      <input type="hidden" name="dest" value="<?= htmlspecialchars($dest) ?>">
      <div class="drawer-input-wrap">
        <input
          type="password"
          id="password"
          name="password"
          placeholder="Slaptažodis…"
          autocomplete="current-password"
          required
        >
        <button type="button" class="toggle-pw" onclick="togglePw()">👁</button>
      </div>
      <button type="submit" class="drawer-btn">Įeiti →</button>
    </form>

    <?php if ($error): ?>
      <div class="drawer-error">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
  </div>

  
  <div id="lightbox" onclick="closeLightbox()">
    <button class="lb-close" onclick="closeLightbox()">✕</button>
    <button id="lb-prev" onclick="event.stopPropagation();lbNav(-1)" style="display:none;position:fixed;left:16px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,0.5);border:none;color:#fff;font-size:2rem;width:48px;height:48px;border-radius:50%;cursor:pointer;align-items:center;justify-content:center;z-index:302">‹</button>
    <img id="lb-img" src="" alt="" onclick="event.stopPropagation()">
    <button id="lb-next" onclick="event.stopPropagation();lbNav(1)" style="display:none;position:fixed;right:16px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,0.5);border:none;color:#fff;font-size:2rem;width:48px;height:48px;border-radius:50%;cursor:pointer;align-items:center;justify-content:center;z-index:302">›</button>
    <div id="lb-dots" style="position:fixed;bottom:24px;left:0;right:0;text-align:center;z-index:302;display:none"></div>
  </div>

  <script>
  
  function interceptAction(e, dest) {
    e.preventDefault();
    if (dest) {
      document.querySelector('input[name="dest"]').value = '/' + dest;
    }
    openDrawer();
  }

  function openDrawer() {
    document.getElementById('gate-drawer').classList.add('open');
    setTimeout(function() {
      document.getElementById('password').focus();
    }, 350);
  }

  
  document.addEventListener('click', function(e) {
    var drawer = document.getElementById('gate-drawer');
    var hint   = document.getElementById('gate-hint');
    if (drawer.classList.contains('open') &&
        !drawer.contains(e.target) &&
        !hint.contains(e.target)) {
      drawer.classList.remove('open');
    }
  });

  function togglePw() {
    var f = document.getElementById('password');
    f.type = f.type === 'password' ? 'text' : 'password';
  }

  
  // Galerijos nuotraukos – kiekvienam mygtukui masyvas failų
  var lbImages = [
    ['kon1.jpg', 'kon2.jpg', 'kon3.jpg', 'kon4.jpg', 'kon5.jpg', 'kon6.jpg'],  // Konstruktorius
    ['diag1.jpg', 'diag2.jpg'],                                                  // Diagnostika
    ['map1.jpg', 'map2.jpg']                                                     // Žemėlapis
  ];
  var _lb = {set: 0, idx: 0};

  function openLightbox(setIndex) {
    _lb = {set: setIndex, idx: 0};
    _lbRender();
    document.getElementById('lightbox').classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function _lbRender() {
    var imgs = lbImages[_lb.set];
    var idx  = _lb.idx;
    var img  = document.getElementById('lb-img');
    img.src  = imgs[idx];
    img.style.animation = 'none';
    img.offsetHeight;
    img.style.animation = 'lb-in 0.2s ease';
    // Rodyklės
    document.getElementById('lb-prev').style.display = idx > 0 ? 'flex' : 'none';
    document.getElementById('lb-next').style.display = idx < imgs.length - 1 ? 'flex' : 'none';
    // Taškeliai
    var dots = document.getElementById('lb-dots');
    if (imgs.length > 1) {
      dots.innerHTML = imgs.map(function(_, i) {
        return '<span onclick="event.stopPropagation();_lbGo(' + i + ')" style="display:inline-block;width:8px;height:8px;border-radius:50%;margin:0 4px;cursor:pointer;background:' + (i === idx ? '#fff' : 'rgba(255,255,255,0.35)') + '"></span>';
      }).join('');
      dots.style.display = 'block';
    } else {
      dots.style.display = 'none';
    }
  }

  function lbNav(dir) {
    var imgs = lbImages[_lb.set];
    var next = _lb.idx + dir;
    if (next >= 0 && next < imgs.length) { _lb.idx = next; _lbRender(); }
  }

  function _lbGo(idx) {
    _lb.idx = idx; _lbRender();
  }

  function closeLightbox() {
    document.getElementById('lightbox').classList.remove('open');
    document.body.style.overflow = '';
  }

  document.querySelectorAll('.action-button').forEach(function(btn, i) {
    btn.addEventListener('click', function(e) {
      e.stopPropagation();
      openLightbox(i);
    });
  });

  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      closeLightbox();
      document.getElementById('gate-drawer').classList.remove('open');
    }
    if (e.key === 'ArrowRight') lbNav(1);
    if (e.key === 'ArrowLeft')  lbNav(-1);
  });

  
  <?php if ($error): ?>
  window.addEventListener('DOMContentLoaded', function() { openDrawer(); });
  <?php endif; ?>
  </script>
<!-- FOOTER + MODAL -->
<div id="ibnvs-footer" style="text-align:center;padding:18px 16px 16px;font-size:0.72rem;color:rgb(0, 0, 0);border-top:1px solid rgba(255,255,255,0.08);margin-top:auto;margin-bottom:50px">
  © 2026 IBNVS. Visos teisės saugomos. &nbsp;·&nbsp;
  <a href="#" onclick="ibnvsModal('salygos');return false;" style="color:rgb(0, 0, 0);text-decoration:underline;text-underline-offset:3px">Naudojimo sąlygos</a>
  &nbsp;·&nbsp;
  <a href="#" onclick="ibnvsModal('privatumas');return false;" style="color:rgb(0, 0, 0);text-decoration:underline;text-underline-offset:3px">Privatumo politika</a>
  &nbsp;·&nbsp;
  <a href="#" onclick="ibnvsModal('atsakomybe');return false;" style="color:rgb(0, 0, 0);text-decoration:underline;text-underline-offset:3px">Atsakomybės atsisakymas</a>
</div>

<div id="ibnvs-modal-overlay" onclick="ibnvsModalClose()" style="display:none;position:fixed;inset:0;z-index:9000;background:rgba(0,0,0,0.6);backdrop-filter:blur(4px);align-items:center;justify-content:center;padding:20px">
  <div onclick="event.stopPropagation()" style="background:#fff;border-radius:16px;max-width:680px;width:100%;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,0.3)">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 22px 14px;border-bottom:1px solid #eee;flex-shrink:0">
      <div id="ibnvs-modal-title" style="font-size:1rem;font-weight:700;color:#1b5e20"></div>
      <button onclick="ibnvsModalClose()" style="background:none;border:none;font-size:1.4rem;cursor:pointer;color:#999;line-height:1;padding:0">✕</button>
    </div>
    <div id="ibnvs-modal-body" style="overflow-y:auto;padding:20px 22px;font-size:0.82rem;line-height:1.7;color:#333"></div>
  </div>
</div>

<script>
var _ibnvsDocs = {
  salygos: {
    title: 'Naudojimo sąlygos',
    html: '<h3 style="color:#1b5e20;margin:0 0 8px">1. Bendroji informacija</h3><p>IBNVS (manonuotekos.lt) – asmeninė informacinė svetainė, sukurta remiantis praktine patirtimi nuotekų valymo ir nusodinimo sistemų srityje. Tikslas – nemokamai dalintis žiniomis su visais norinčiais.</p><h3 style="color:#1b5e20;margin:16px 0 8px">2. Informacinio pobūdžio turinys</h3><p>Visa pateikta informacija – skaičiavimai, rekomendacijos, diagnostikos išvados – yra <b>asmeninė autoriaus nuomonė</b>, pagrįsta praktine patirtimi. Tai nėra oficialus inžinerinis projektas ar juridiškai įpareigojantis dokumentas.</p><h3 style="color:#1b5e20;margin:16px 0 8px">3. Atsakomybės ribojimas</h3><p>IBNVS autorius neprisiima atsakomybės dėl nuostolių, atsiradusių naudojantis svetainės informacija, neteisingai įrengtos sistemos pasekmių ar trečiųjų šalių paslaugų kokybės. Kainos ir techniniai duomenys pateikiami orientaciniai.</p><h3 style="color:#1b5e20;margin:16px 0 8px">4. Intelektinė nuosavybė</h3><p>Programinis kodas, 3D modeliai, tekstai ir duomenų bazė yra IBNVS autoriaus intelektinė nuosavybė. Draudžiama kopijuoti ar naudoti komerciniais tikslais be raštiško sutikimo.</p><h3 style="color:#1b5e20;margin:16px 0 8px">5. Žemėlapio registracija</h3><p>Žemėlapyje registruodamiesi specialistai patvirtina, kad pateikia teisingą informaciją ir sutinka būti viešai matomi. IBNVS negarantuoja jų paslaugų kokybės ir gali pašalinti įrašą be įspėjimo.</p><p style="margin-top:16px;color:#888;font-size:0.78rem">© 2026 IBNVS · manonuotekos.lt</p>'
  },
  privatumas: {
    title: 'Privatumo politika',
    html: '<h3 style="color:#1b5e20;margin:0 0 8px">Kokie duomenys renkami</h3><p>Svetainė renka anoniminius lankymosi statistikos duomenis: apsilankymo laikas, trukmė, įrenginio tipas, naršyklė. Šie duomenys nesiejami su jūsų asmeniu.</p><p style="margin-top:10px">Žemėlapyje savanoriškai registruodamiesi pateikiate: vardą / įmonės pavadinimą, telefono numerį, miestą. Šie duomenys yra <b>viešai matomi</b> svetainėje.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Ko nerenkame</h3><p>IBNVS nerenka el. pašto adresų, mokėjimo duomenų, asmens kodų ar tikslios geografinės vietos.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Slapukai</h3><p>Naudojamas tik vienas techninis sesijos slapukas, būtinas svetainės veikimui. Reklaminiai slapukai nenaudojami.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Jūsų teisės</h3><p>Turite teisę prašyti ištaisyti ar ištrinti savo duomenis iš žemėlapio. Duomenys neparduodami ir neperduodami trečiosioms šalims.</p><p style="margin-top:16px;color:#888;font-size:0.78rem">© 2026 IBNVS · manonuotekos.lt</p>'
  },
  atsakomybe: {
    title: 'Atsakomybės atsisakymas',
    html: '<p>IBNVS – vieno žmogaus sukurta informacinė svetainė. Autorius turi daugiametę praktinę patirtį nuotekų valymo sistemų srityje ir nori ja <b>nemokamai dalintis</b> su visais.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Apie pateikiamą informaciją</h3><p>Konstruktoriaus skaičiavimai, diagnostikos rekomendacijos ir kainos yra <b>orientaciniai</b>. Kiekvienas objektas yra skirtingas. Prieš pradėdami darbus – konsultuokitės su specialistu, patikrinkite norminius reikalavimus ir kainas tiesiogiai pas tiekėjus.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Apie žemėlapio specialistus</h3><p>Žemėlapyje rodomi specialistai savanoriškai pateikė savo kontaktus. IBNVS netikrina jų kvalifikacijos ir neatsako už jų darbų kokybę.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Baigiamasis žodis</h3><p>Ši svetainė sukurta iš noro padėti. Jei informacija netinka – tiesiog ja nesinaudokite. Naudodamiesi svetaine patvirtinate, kad suprantate jos informacinį pobūdį ir prisiimate atsakomybę už savo sprendimus.</p><p style="margin-top:16px;color:#888;font-size:0.78rem">© 2026 IBNVS · manonuotekos.lt</p>'
  }
};
function ibnvsModal(doc) {
  var d = _ibnvsDocs[doc]; if (!d) return;
  document.getElementById('ibnvs-modal-title').textContent = d.title;
  document.getElementById('ibnvs-modal-body').innerHTML = d.html;
  document.getElementById('ibnvs-modal-overlay').style.display = 'flex';
  document.body.style.overflow = 'hidden';
}
function ibnvsModalClose() {
  document.getElementById('ibnvs-modal-overlay').style.display = 'none';
  document.body.style.overflow = '';
}
document.addEventListener('keydown', function(e) { if (e.key === 'Escape') ibnvsModalClose(); });
</script>

</body>
</html>
