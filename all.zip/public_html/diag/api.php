<?php
// Ši byla skirta tik atgaliniam suderinamumui.
// Visa logika yra private/api/ - pasiekiama per /api/v1/
// diagnose.js siunčia užklausas į /api/v1/{action} - teisingai.

http_response_code(404);
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => false, 'error' => 'Naudokite /api/v1/ endpoint\'us'], JSON_UNESCAPED_UNICODE);
