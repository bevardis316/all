<?php
require_once dirname(__DIR__, 2) . '/private/bootstrap.php';
if (!OPENAI_KEY) { http_response_code(500); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['error' => 'Konfigūracijos klaida: API raktas nerastas (.env)']); exit; }
