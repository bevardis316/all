<?php require_once dirname(__DIR__, 2) . "/private/auth_check.php"; ?>
<!DOCTYPE html>
<html lang="lt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Nuotekų sistemos diagnostika | manonuotekos.lt</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="diagnose.css">
</head>
<body>
<div id="app">
  <div id="hdr">
    <div id="hdr-logo">🌿 Nuotekų sistemos diagnostika <small>Pasirinkite simptomus</small></div>
    <button id="hdr-btn" onclick="document.getElementById('contact-bar').scrollIntoView()">📞 Susisiekti</button>
  </div>
  <div id="wrap">

    <!-- KAIRĖ: simptomų pasirinkimas -->
    <div id="left">
      <div id="left-top">
        <h2>🔍 Gedimų diagnostika</h2>
        <p>Pasirinkite simptomus žemiau — sistema automatiškai pateiks geriausius atitikmenis.</p>
      </div>
      <div id="search-wrap">
        <input id="sym-search" type="text" placeholder="🔍 Ieškoti simptomo..." oninput="flt(this.value)">
      </div>
      <div id="sym-area">
        <div style="padding:30px;text-align:center;color:var(--td);font-size:11px">
          <div style="font-size:28px;margin-bottom:8px">⏳</div>Kraunama...
        </div>
      </div>
    </div>

    <!-- DEŠINĖ: rezultatai -->
    <div id="right">
      <div id="tab-diag">
        <div id="env-bar">
          <div class="eg"><label>GVL:</label>
            <button class="eb" data-g="gvl" data-v="gvl-1" onclick="senv(this)">🌊 Aukštas</button>
            <button class="eb" data-g="gvl" data-v="gvl-2" onclick="senv(this)">💧 Žemas</button>
            <button class="eb" data-g="gvl" data-v="gvl-3" onclick="senv(this)">🏙 Nėra</button>
          </div>
          <div class="eg"><label>Gruntas:</label>
            <button class="eb" data-g="soil" data-v="smel" onclick="senv(this)">🟡 Smėlis</button>
            <button class="eb" data-g="soil" data-v="mol"  onclick="senv(this)">🟤 Molis</button>
          </div>
          <div class="eg"><label>Amžius:</label>
            <button class="eb" data-g="age" data-v="new" onclick="senv(this)">&lt;3m</button>
            <button class="eb" data-g="age" data-v="mid" onclick="senv(this)">3-7m</button>
            <button class="eb" data-g="age" data-v="old" onclick="senv(this)">7m+</button>
          </div>
          <div class="eg"><label>Objektas:</label>
            <select id="obj-sel" onchange="if(diagSel.length)runDiag()"><option value="">Visi</option></select>
          </div>
          <button id="run-btn" onclick="runDiag()">🔍 Diagnozuoti</button>
        </div>
        <div id="sel-bar">
          <span class="sl">Pasirinkti simptomai:</span>
          <div class="sc" id="chips"><span style="opacity:.5;font-size:10px">Nėra - pasirink kaireje</span></div>
        </div>
        <div id="ai-box">
          <div id="ai-head">
            <div id="ai-ico">🤖</div>
            <div id="ai-title">AI Diagnostikos asistentas</div>
            <div id="ai-status"></div>
          </div>
          <div id="ai-text"></div>
        </div>
        <div id="results">
          <div class="no-sel">
            <div class="ico">🔍</div>
            <h3>Pasirink simptomus</h3>
            <p>Spustelkite simptomus kairėje — sistema iš karto pateiks galimus gedimus.</p>
          </div>
        </div>
        <div id="contact-bar">
          <h3>📞 Reikia pagalbos? Susisiekite su specialistu</h3>
          <div class="cr">
            <input id="c-n" type="text"  placeholder="Vardas">
            <input id="c-p" type="tel"   placeholder="Tel. numeris">
            <input id="c-e" type="email" placeholder="El. paštas">
            <input id="c-m" type="text"  placeholder="Trumpai aprašykite problemą...">
            <button id="c-send" onclick="sendContact()">Siųsti →</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="comp-popup" onclick="if(event.target===this)closePopup()">
  <div id="comp-modal">
    <div id="comp-modal-head">
      <div id="comp-modal-ico">🔧</div>
      <div id="comp-modal-titles">
        <div id="comp-modal-id"></div>
        <div id="comp-modal-name"></div>
        <div id="comp-modal-parent"></div>
      </div>
      <div id="comp-modal-close" onclick="closePopup()">✕</div>
    </div>
    <div id="comp-modal-body"></div>
    <div id="comp-modal-btns">
      <button class="comp-action-btn cab-info"   onclick="showCompTab('info')"  ><span class="cab-ico">ℹ️</span>Info</button>
      <button class="comp-action-btn cab-repair" onclick="showCompTab('repair')"><span class="cab-ico">🔧</span>Kaip remontuoti</button>
      <button class="comp-action-btn cab-buy"    onclick="showCompTab('buy')"   ><span class="cab-ico">🛒</span>Kur pirkti</button>
    </div>
  </div>
</div>

<script src="js/diagnose.min.js"></script>
<!-- FOOTER + MODAL -->
<div id="ibnvs-footer" style="text-align:center;padding:18px 16px 24px;font-size:0.72rem;color:rgba(150,150,150,0.8);border-top:1px solid rgba(0,0,0,0.07);margin-top:auto">
  © 2026 IBNVS. Visos teisės saugomos. &nbsp;·&nbsp;
  <a href="#" onclick="ibnvsModal('salygos');return false;" style="color:inherit;text-decoration:underline;text-underline-offset:3px">Naudojimo sąlygos</a>
  &nbsp;·&nbsp;
  <a href="#" onclick="ibnvsModal('privatumas');return false;" style="color:inherit;text-decoration:underline;text-underline-offset:3px">Privatumo politika</a>
  &nbsp;·&nbsp;
  <a href="#" onclick="ibnvsModal('atsakomybe');return false;" style="color:inherit;text-decoration:underline;text-underline-offset:3px">Atsakomybės atsisakymas</a>
</div>

<div id="ibnvs-modal-overlay" onclick="ibnvsModalClose()" style="display:none;position:fixed;inset:0;z-index:9000;background:rgba(0,0,0,0.6);backdrop-filter:blur(4px);align-items:center;justify-content:center;padding:20px">
  <div onclick="event.stopPropagation()" style="background:#fff;border-radius:16px;max-width:680px;width:100%;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,0.3)">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 22px 14px;border-bottom:1px solid #eee;flex-shrink:0">
      <div id="ibnvs-modal-title" style="font-size:1rem;font-weight:700;color:#1b5e20"></div>
      <button onclick="ibnvsModalClose()" style="background:none;border:none;font-size:1.4rem;cursor:pointer;color:#999;line-height:1;padding:0">✕</button>
    </div>
    <div id="ibnvs-modal-body" style="overflow-y:auto;padding:20px 22px;font-size:0.82rem;line-height:1.7;color:#333"></div>
  </div>
</div>

<script>
var _ibnvsDocs = {
  salygos: {
    title: 'Naudojimo sąlygos',
    html: '<h3 style="color:#1b5e20;margin:0 0 8px">1. Bendroji informacija</h3><p>IBNVS (manonuotekos.lt) – asmeninė informacinė svetainė, sukurta remiantis praktine patirtimi nuotekų valymo ir nusodinimo sistemų srityje. Tikslas – nemokamai dalintis žiniomis su visais norinčiais.</p><h3 style="color:#1b5e20;margin:16px 0 8px">2. Informacinio pobūdžio turinys</h3><p>Visa pateikta informacija – skaičiavimai, rekomendacijos, diagnostikos išvados – yra <b>asmeninė autoriaus nuomonė</b>, pagrįsta praktine patirtimi. Tai nėra oficialus inžinerinis projektas ar juridiškai įpareigojantis dokumentas.</p><h3 style="color:#1b5e20;margin:16px 0 8px">3. Atsakomybės ribojimas</h3><p>IBNVS autorius neprisiima atsakomybės dėl nuostolių, atsiradusių naudojantis svetainės informacija, neteisingai įrengtos sistemos pasekmių ar trečiųjų šalių paslaugų kokybės. Kainos ir techniniai duomenys pateikiami orientaciniai.</p><h3 style="color:#1b5e20;margin:16px 0 8px">4. Intelektinė nuosavybė</h3><p>Programinis kodas, 3D modeliai, tekstai ir duomenų bazė yra IBNVS autoriaus intelektinė nuosavybė. Draudžiama kopijuoti ar naudoti komerciniais tikslais be raštiško sutikimo.</p><h3 style="color:#1b5e20;margin:16px 0 8px">5. Žemėlapio registracija</h3><p>Žemėlapyje registruodamiesi specialistai patvirtina, kad pateikia teisingą informaciją ir sutinka būti viešai matomi. IBNVS negarantuoja jų paslaugų kokybės ir gali pašalinti įrašą be įspėjimo.</p><p style="margin-top:16px;color:#888;font-size:0.78rem">© 2026 IBNVS · manonuotekos.lt</p>'
  },
  privatumas: {
    title: 'Privatumo politika',
    html: '<h3 style="color:#1b5e20;margin:0 0 8px">Kokie duomenys renkami</h3><p>Svetainė renka anoniminius lankymosi statistikos duomenis: apsilankymo laikas, trukmė, įrenginio tipas, naršyklė. Šie duomenys nesiejami su jūsų asmeniu.</p><p style="margin-top:10px">Žemėlapyje savanoriškai registruodamiesi pateikiate: vardą / įmonės pavadinimą, telefono numerį, miestą. Šie duomenys yra <b>viešai matomi</b> svetainėje.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Ko nerenkame</h3><p>IBNVS nerenka el. pašto adresų, mokėjimo duomenų, asmens kodų ar tikslios geografinės vietos.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Slapukai</h3><p>Naudojamas tik vienas techninis sesijos slapukas, būtinas svetainės veikimui. Reklaminiai slapukai nenaudojami.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Jūsų teisės</h3><p>Turite teisę prašyti ištaisyti ar ištrinti savo duomenis iš žemėlapio. Duomenys neparduodami ir neperduodami trečiosioms šalims.</p><p style="margin-top:16px;color:#888;font-size:0.78rem">© 2026 IBNVS · manonuotekos.lt</p>'
  },
  atsakomybe: {
    title: 'Atsakomybės atsisakymas',
    html: '<p>IBNVS – vieno žmogaus sukurta informacinė svetainė. Autorius turi daugiametę praktinę patirtį nuotekų valymo sistemų srityje ir nori ja <b>nemokamai dalintis</b> su visais.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Apie pateikiamą informaciją</h3><p>Konstruktoriaus skaičiavimai, diagnostikos rekomendacijos ir kainos yra <b>orientaciniai</b>. Kiekvienas objektas yra skirtingas. Prieš pradėdami darbus – konsultuokitės su specialistu, patikrinkite norminius reikalavimus ir kainas tiesiogiai pas tiekėjus.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Apie žemėlapio specialistus</h3><p>Žemėlapyje rodomi specialistai savanoriškai pateikė savo kontaktus. IBNVS netikrina jų kvalifikacijos ir neatsako už jų darbų kokybę.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Baigiamasis žodis</h3><p>Ši svetainė sukurta iš noro padėti. Jei informacija netinka – tiesiog ja nesinaudokite. Naudodamiesi svetaine patvirtinate, kad suprantate jos informacinį pobūdį ir prisiimate atsakomybę už savo sprendimus.</p><p style="margin-top:16px;color:#888;font-size:0.78rem">© 2026 IBNVS · manonuotekos.lt</p>'
  }
};
function ibnvsModal(doc) {
  var d = _ibnvsDocs[doc]; if (!d) return;
  document.getElementById('ibnvs-modal-title').textContent = d.title;
  document.getElementById('ibnvs-modal-body').innerHTML = d.html;
  document.getElementById('ibnvs-modal-overlay').style.display = 'flex';
  document.body.style.overflow = 'hidden';
}
function ibnvsModalClose() {
  document.getElementById('ibnvs-modal-overlay').style.display = 'none';
  document.body.style.overflow = '';
}
document.addEventListener('keydown', function(e) { if (e.key === 'Escape') ibnvsModalClose(); });
</script>

</body>
</html>
