var diagSel, diagEnv, lastAIText;
var konData   = null;
var curCompId = null;
var API_BASE  = '/api/v1';

(function(){
  diagSel = []; diagEnv = {}; lastAIText = '';
  loadSymptoms();
  loadTree();
})();

function loadSymptoms() {
  post({action:'symptoms'}, function(data) {
    if (!data || !data.ok) return;
    var sel = document.getElementById('obj-sel');
    (data.objects || []).forEach(function(oid) {
      var o = document.createElement('option');
      o.value = o.textContent = oid;
      sel.appendChild(o);
    });
    var area   = document.getElementById('sym-area');
    var groups = data.groups || {};
    var keys   = Object.keys(groups);
    if (!keys.length) {
      area.innerHTML = '<div style="padding:30px;text-align:center;color:var(--td);font-size:11px"><div style="font-size:28px;margin-bottom:8px">📋</div>Simptomų dar nėra. Pirmiausia užpildyk IBNVS įrankyje.</div>';
      return;
    }
    var catMap = {
      '👃 Kvapai':          ['kvap','smell','odor','dvok','sieros','amoniak','puvimo','rūgš'],
      '🔊 Garsai':          ['gars','sound','triukšm','burbul','pūkšt','spragsi','ūžia','girgžd'],
      '👁 Matomi požymiai': ['matom','vandens','skystis','dėmė','mirkš','purvas','drumzl','žalsvum','rūdys','nuosėd','putos'],
      '⚙ Įrenginio veikla': ['neveik','sustoj','neįsijung','neišsijung','siurbl','aerator','perkait','vibr','elektr','signaliz'],
    };
    function symCat(grp) {
      var g = (grp || '').toLowerCase();
      var ks = Object.keys(catMap);
      for (var ki = 0; ki < ks.length; ki++) {
        var kws = catMap[ks[ki]];
        for (var wi = 0; wi < kws.length; wi++) {
          if (g.indexOf(kws[wi]) >= 0) return ks[ki];
        }
      }
      return '📋 Kita';
    }
    var cats = {};
    keys.forEach(function(grp) {
      var cat = symCat(grp);
      if (!cats[cat]) cats[cat] = [];
      groups[grp].forEach(function(item) { cats[cat].push(item); });
    });
    var html = '';
    Object.keys(cats).sort().forEach(function(cat) {
      var items = cats[cat];
      var seen = {}, uniq = [];
      items.forEach(function(item) { if (!seen[item.s]) { seen[item.s] = true; uniq.push(item); } });
      html += '<div class="sym-cat" data-g="' + esc(cat) + '"><div class="sym-cat-lbl">' + esc(cat) + ' <span style="font-size:9px;opacity:.5">(' + uniq.length + ')</span></div><div class="sym-tiles">';
      uniq.forEach(function(item) {
        html += '<div class="sym-tile" data-sym="' + esc(item.s) + '" onclick="togTile(this)"><span class="sym-chk">✓</span>' + esc(item.s);
        if (item.n > 1) html += '<span class="sym-cnt">×' + item.n + '</span>';
        html += '</div>';
      });
      html += '</div></div>';
    });
    area.innerHTML = html;
    var p = new URLSearchParams(window.location.search);
    var s = p.get('syms');
    if (s) s.split(',').forEach(function(sym) {
      sym = decodeURIComponent(sym.trim());
      var el = document.querySelector('.sym-tile[data-sym="' + sym + '"]');
      if (el) togTile(el);
    });
  });
}

function togTile(el) {
  var s = el.getAttribute('data-sym');
  if (!s) return;
  var idx = diagSel.indexOf(s);
  if (idx >= 0) { diagSel.splice(idx, 1); el.classList.remove('sel'); }
  else           { diagSel.push(s);        el.classList.add('sel');    }
  renderChips();
  if (diagSel.length) runDiag();
}

function flt(q) {
  q = (q || '').toLowerCase();
  var tiles = document.querySelectorAll('.sym-tile');
  for (var i = 0; i < tiles.length; i++) {
    var sym = (tiles[i].getAttribute('data-sym') || '').toLowerCase();
    tiles[i].style.display = (!q || sym.indexOf(q) >= 0) ? '' : 'none';
  }
  var cats = document.querySelectorAll('.sym-cat');
  for (var j = 0; j < cats.length; j++) {
    var vis = cats[j].querySelectorAll('.sym-tile:not([style*="none"])');
    cats[j].style.display = vis.length ? '' : 'none';
  }
}

function renderChips() {
  var c = document.getElementById('chips');
  while (c.firstChild) c.removeChild(c.firstChild);
  if (!diagSel.length) {
    var sp = document.createElement('span');
    sp.style.cssText = 'opacity:.5;font-size:10px';
    sp.textContent = 'Nėra - pasirink kaireje';
    c.appendChild(sp);
    return;
  }
  for (var i = 0; i < diagSel.length; i++) {
    (function(s) {
      var d = document.createElement('div');
      d.className = 'sch';
      d.textContent = s;
      var x = document.createElement('span');
      x.textContent = ' ✕';
      x.style.cssText = 'opacity:.6;cursor:pointer;margin-left:2px';
      x.onclick = function() {
        var el = document.querySelector('.sym-tile[data-sym="' + s + '"]');
        if (el) togTile(el);
      };
      d.appendChild(x);
      c.appendChild(d);
    })(diagSel[i]);
  }
}

function senv(btn) {
  var g = btn.getAttribute('data-g');
  var v = btn.getAttribute('data-v');
  if (diagEnv[g] === v) { diagEnv[g] = ''; btn.classList.remove('on'); }
  else {
    diagEnv[g] = v;
    document.querySelectorAll('.eb[data-g="' + g + '"]').forEach(function(b) { b.classList.remove('on'); });
    btn.classList.add('on');
  }
  if (diagSel.length) runDiag();
}

function runDiag() {
  _aiHistory = []; // reset history on new diagnosis
  post({action:'diagnose', symptoms:diagSel, env:diagEnv, object:document.getElementById('obj-sel').value||''}, function(data) {
    if (!data || !data.ok) {
      document.getElementById('results').innerHTML = '<div class="no-sel"><div class="ico">🚨</div><h3>Klaida</h3><p>Nepavyko gauti rezultatų</p></div>';
      return;
    }
    var res = data.results || [];
    if (!res.length) {
      document.getElementById('results').innerHTML = '<div class="no-sel"><div class="ico">🤔</div><h3>Nerasta atitikmenų</h3><p>Pabandyk pasirinkti daugiau simptomų</p></div>';
      return;
    }
    var sevLabels = {critical:'🔴 Kritiniai', high:'🟠 Aukštas pavojus', med:'🟡 Vidutinis', low:'🟢 Žemas'};
    var html = '', lastSev = null;
    res.forEach(function(r) {
      if (r.severity !== lastSev) {
        lastSev = r.severity;
        var sevCol = ({critical:'#c62828',high:'#e65100',med:'#f57f17',low:'#2e7d32'})[r.severity] || '#666';
        html += '<div style="font-size:10px;font-weight:700;color:' + sevCol + ';text-transform:uppercase;letter-spacing:.5px;padding:8px 12px 4px;border-top:' + (html ? '1px solid var(--b1)' : 'none') + '">' + (sevLabels[r.severity] || r.severity || 'Kita') + '</div>';
      }
      var rc = r.score > 70 ? '#2e7d32' : r.score > 40 ? '#ff9800' : '#c62828';
      var sc = ({low:'#4caf50',med:'#ff9800',high:'#f44336',critical:'#e91e63'})[r.severity] || '#aaa';
      html += '<div class="dm"><div class="dm-head">';
      html += '<div class="ring" style="border-color:' + rc + ';color:' + rc + '">' + r.score + '%</div>';
      html += '<div style="flex:1">';
      html += '<div class="opath">' + esc(r.oid) + ' · <span style="color:' + sc + ';font-weight:700">' + (r.severity||'?').toUpperCase() + '</span>' + (r.base ? ' · <span style="color:var(--pri);font-weight:700">' + r.base + '% baz.</span>' : '') + '</div>';
      html += '<div class="fname">' + esc(r.name) + '</div>';
      html += '<div class="syms">';
      (r.hits||[]).forEach(function(h) { html += '<span class="sy h">✓ ' + esc(h) + '</span>'; });
      (r.miss||[]).forEach(function(m) { html += '<span class="sy m">✗ ' + esc(m) + '</span>'; });
      html += '</div>';
      if (r.chips && r.chips.length) {
        html += '<div style="margin-top:3px">';
        r.chips.forEach(function(ch) { html += '<span class="ec ' + (ch.m > 1 ? 'up' : 'dn') + '">' + (ch.m > 1 ? '↑' : '↓') + ch.k + ' ×' + ch.m + '</span>'; });
        html += '</div>';
      }
      html += '</div></div><div class="dm-body">';
      if (r.causes)     html += '<div class="ds"><h4>Priežastis</h4><p>' + esc(r.causes) + '</p></div>';
      if (r.resolution) html += '<div class="ds"><h4>Sprendimas</h4><p>' + esc(r.resolution) + '</p></div>';
      if (r.prevention) html += '<div class="ds"><h4>Profilaktika</h4><p>' + esc(r.prevention) + '</p></div>';
      if (r.diag_tree && r.diag_tree.length) {
        html += '<div class="ds" style="grid-column:span 2"><h4>Diagnostikos žingsniai</h4><ol style="list-style:none;padding:0">';
        r.diag_tree.forEach(function(step, di) {
          var q = step.question || '';
          if (!q) return;
          html += '<li style="display:flex;gap:6px;margin-bottom:3px;font-size:11px"><span style="min-width:17px;height:17px;border-radius:50%;background:var(--pri);color:#fff;font-size:9px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0">' + (di+1) + '</span>' + esc(q) + '</li>';
        });
        html += '</ol></div>';
      }
      html += '</div></div>';
    });
    // E6: susijusios problemos (leads_to)
    var related = data.related || [];
    if (related.length) {
      html += '<div style="margin-top:16px;border-top:2px dashed var(--b1);padding-top:12px">';
      html += '<div style="font-size:11px;font-weight:700;color:#7b1fa2;margin-bottom:8px">🔗 Taip pat patikrinkite (susijusios galimos problemos)</div>';
      related.forEach(function(r) {
        html += '<div style="font-size:11px;padding:5px 8px;background:#f3e5f5;border-left:3px solid #7b1fa2;border-radius:4px;margin-bottom:4px">';
        html += '→ <b>' + esc(r.name) + '</b> <span style="color:#9e9e9e;font-size:10px">(iš: ' + esc(r.from) + ')</span>';
        html += '</div>';
      });
      html += '</div>';
    }
    document.getElementById('results').innerHTML = html;
  });
}

function loadTree() {
  post({action:'tree'}, function(data) {
    if (!data || !data.ok) return;
    konData = data;
  });
}

function openCompPopup(cid) {
  if (!konData) return;
  curCompId = cid;
  var c = konData.components[cid];
  if (!c) return;
  var parentName = '';
  if      (konData.objects[c.parent_id])    parentName = konData.objects[c.parent_id].name;
  else if (konData.components[c.parent_id]) parentName = konData.components[c.parent_id].name;
  document.getElementById('comp-modal-id').textContent     = cid;
  document.getElementById('comp-modal-name').textContent   = c.name;
  document.getElementById('comp-modal-parent').textContent = parentName ? '↖ ' + parentName : '';
  showCompTab('info');
  document.getElementById('comp-popup').classList.add('show');
}

function showCompTab(tab) {
  if (!curCompId || !konData) return;
  var c    = konData.components[curCompId];
  var body = document.getElementById('comp-modal-body');
  document.getElementById('comp-modal-ico').textContent = ({info:'ℹ️', repair:'🔧', buy:'🛒'})[tab] || '🔧';
  if (tab === 'info') {
    var html = '';
    if (c.function)          html += '<div class="comp-info-block"><div class="comp-info-lbl">Funkcija</div><div class="comp-info-val">' + esc(c.function) + '</div></div>';
    if (c.normal_operation)  html += '<div class="comp-info-block"><div class="comp-info-lbl">Normalus veikimas</div><div class="comp-info-val">' + esc(c.normal_operation) + '</div></div>';
    var parentObj = null;
    if (konData.objects[c.parent_id]) {
      parentObj = c.parent_id;
    } else if (konData.components[c.parent_id] && konData.objects[konData.components[c.parent_id].parent_id]) {
      parentObj = konData.components[c.parent_id].parent_id;
    }
    if (parentObj && konData.objects[parentObj] && konData.objects[parentObj].failure_count > 0) {
      html += '<div class="comp-info-block"><div class="comp-info-lbl">⚠️ Susiję gedimai</div><div class="comp-info-val" style="color:#c62828">Objektas <b>' + parentObj + '</b> turi ' + konData.objects[parentObj].failure_count + ' aprašytų gedimų. Norėdami diagnozuoti — pasirinkite simptomus diagnostikos skirtuke.</div></div>';
    }
    if (!html) html = '<div class="comp-info-empty">Informacija dar neužpildyta</div>';
    body.innerHTML = html;
  } else if (tab === 'repair') {
    body.innerHTML = '<div class="comp-info-block"><div class="comp-info-lbl">Remonto rekomendacijos</div><div class="comp-info-val" style="line-height:1.8">1. Prieš atliekant bet kokius darbus — išjunkite elektros maitinimą<br>2. Apžiūrėkite komponentą vizualiai — ar nėra mechaninių pažeidimų<br>3. Patikrinkite jungčių ir sandariklių būklę<br>4. Jei komponentas gedęs — kreipkitės į specializuotą servisą</div></div><div class="comp-info-block" style="background:#fff8e1;border-radius:var(--r);padding:8px 10px"><div class="comp-info-lbl" style="color:#f57f17">⚠️ Svarbu</div><div class="comp-info-val" style="font-size:11px">Nuotekų sistemos komponentų keitimas reikalauja specialių žinių. Rekomenduojame kviesti sertifikuotą specialistą.</div></div>';
  } else if (tab === 'buy') {
    body.innerHTML = '<div class="comp-info-block"><div class="comp-info-lbl">Kur pirkti / užsakyti</div><div class="comp-info-empty">Susisiekite su mumis ir mes padėsime rasti tinkamą detalę.</div></div><div class="comp-info-block" style="margin-top:12px"><div class="comp-info-lbl">Kontaktai dėl dalių</div><div class="comp-info-val"><a href="mailto:info@manonuotekos.lt" style="color:var(--pri);font-weight:700">info@manonuotekos.lt</a></div></div>';
  }
}

function closePopup() {
  document.getElementById('comp-popup').classList.remove('show');
  curCompId = null;
}
document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closePopup(); });

var _aiHistory = [];

function _konLink(text) {
  // Convert [KON:BNVI] -> clickable button
  return text.replace(/\[KON:([A-Z0-9]+)\]/g, function(m, oid) {
    return '<button onclick="openInKon(\''+oid+'\',this)" style="display:inline-flex;align-items:center;gap:4px;background:var(--pri);color:#fff;border:none;border-radius:4px;padding:2px 8px;font-size:11px;cursor:pointer;margin:0 2px;font-family:inherit">🔍 '+oid+' konstruktoriuje</button>';
  });
}

function openInKon(oid, btn) {
  var url = '/kon/#obj=' + oid;
  window.open(url, '_blank');
}

function askAI(userText) {
  var aiBox = document.getElementById('ai-box');
  var aiText = document.getElementById('ai-text');
  var aiStatus = document.getElementById('ai-status');
  if (!aiBox || !aiText) return;
  aiBox.className = 'show';
  aiText.innerHTML = '';
  if (aiStatus) aiStatus.textContent = 'Analizuoju...';

  // Add user message to history
  _aiHistory.push({role:'user', content: userText});

  post({
    action: 'ai',
    message: userText,
    history: _aiHistory.slice(0, -1)  // send history without current message
  }, function(data) {
    if (data && data.text) {
      lastAIText = data.text;
      // Render with deep links
      var safe = data.text
        .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
        .replace(/\n/g,'<br>');
      aiText.innerHTML = _konLink(safe);
      if (aiStatus) aiStatus.textContent = 'Atsakyta';
      // Add AI response to history
      _aiHistory.push({role:'assistant', content: data.text});
      // Keep history max 12 messages
      if (_aiHistory.length > 12) _aiHistory = _aiHistory.slice(-12);
    } else {
      aiText.textContent = 'Nepavyko prisijungti prie AI.';
      if (aiStatus) aiStatus.textContent = 'Klaida';
      _aiHistory.pop(); // remove failed user message
    }
  });
}

function getTop3() {
  var res = [];
  document.querySelectorAll('.dm').forEach(function(dm) {
    if (res.length >= 3) return;
    var name    = (dm.querySelector('.fname') || {}).textContent || '';
    var score   = parseInt((dm.querySelector('.ring') || {}).textContent) || 0;
    var causeEl = dm.querySelector('.ds h4');
    var causes  = (causeEl && causeEl.textContent === 'Priežastis') ? ((causeEl.nextElementSibling || {}).textContent || '') : '';
    res.push({name:name, score:score, causes:causes});
  });
  return res;
}

function sendContact() {
  var n = document.getElementById('c-n').value.trim();
  var p = document.getElementById('c-p').value.trim();
  var em = document.getElementById('c-e').value.trim();
  var m = document.getElementById('c-m').value.trim();
  if (!n || (!p && !em)) { alert('Įveskite vardą ir bent vieną kontaktą'); return; }
  fetch('/api/v1/contact', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({name:n, phone:p, email:em, message:m, symptoms:diagSel})
  })
  .then(function(r){ return r.json(); })
  .then(function(d){
    if (d && d.ok) {
      alert('Išsiųsta ✓ Susisieksime su jumis netrukus.');
      document.getElementById('c-n').value='';
      document.getElementById('c-p').value='';
      document.getElementById('c-e').value='';
      document.getElementById('c-m').value='';
    } else {
      alert('Klaida siunčiant. Bandykite dar kartą arba rašykite tiesiogiai.');
    }
  })
  .catch(function(){ alert('Ryšio klaida. Patikrinkite internetą.'); });
}

function post(payload, cb) {
  var xhr = new XMLHttpRequest();
  xhr.open('POST', API_BASE + '/' + (payload.action || ''), true);
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.onload = function() {
    if (xhr.status === 200) { try { cb(JSON.parse(xhr.responseText)); } catch(e) { cb(null); } }
    else { cb(null); }
  };
  xhr.onerror = function() { cb(null); };
  xhr.send(JSON.stringify(payload));
}

function esc(s) { return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
