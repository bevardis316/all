<?php
session_name('ibnvs_gate');
session_set_cookie_params([
    'lifetime' => 28800,
    'path'     => '/',
    'secure'   => true,
    'httponly' => true,
    'samesite' => 'Strict',
]);
session_start();

$TTL = 28800;
if (
    empty($_SESSION['ibnvs_auth']) ||
    empty($_SESSION['ibnvs_time']) ||
    (time() - $_SESSION['ibnvs_time']) > $TTL
) {
    $_SESSION = [];
    session_destroy();
    header('Location: /gate.php?dest=' . urlencode('/'));
    exit;
}
$_SESSION['ibnvs_time'] = time();
?>
<!doctype html>
<html lang="lt">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Virtualus Konsultantas</title>
    <link rel="stylesheet" href="index.css" />
  </head>

  <body>
    <div class="container">
      <header>
        <p>
          Dauguma problemų kyla ne dėl įrangos, o dėl to, kad niekas
          nepaaiškino, kaip ja naudotis. IBNVS - vietą, kurioje yra viskas: kas, kaip, kodėl, kur ir ką daryti kur ir už kiek viską pirkti. Viskas vienoje vietoje. Visiškai nemokamai. Nuolat tobulinama.
        </p>
      </header>

      <div class="chat-wrapper">
        <div class="messages" id="messages"></div>
        <form class="input-form" id="chatForm">
          <input id="input" type="text" placeholder="Klauskite..." autocomplete="off" />
          <button type="button" id="micBtn" title="Kalbėti" style="background:none;border:none;cursor:pointer;font-size:18px;padding:0 4px;line-height:1;opacity:0.7">🎙</button>
          <button type="submit">➤</button>
        </form>
      </div>

      <div class="buttons-wrapper">
        <div class="action-item">
          <span class="button-header">Konstruktorius</span>
          <button
            class="action-button"
            style="background-image: url('pav1.png')"
            onclick="window.open('kon/index.php', '_blank')"
          ></button>
          <span class="button-description">Planuojate montuoti patys? Čia – mano rekomendacijos, kaip tai daryti, ir tikslių medžiagų kiekiai su kainomis.</span>
        </div>

        <div class="action-item">
          <span class="button-header">Gedimų diagnostika</span>
          <button
            class="action-button"
            style="background-image: url('diag1.jpg')"
            onclick="window.open('diag/diagnose.php')"
          ></button>
          <span class="button-description">Kažkas neveikia? Nurodykite simptomus kuriuos matote, girdite, jaučiate, o aš pameginsiu jums padėti.</span>
        </div>

        <div class="action-item">
          <span class="button-header">Kontaktų bazė</span>
          <button
            class="action-button"
            style="background-image: url('map1.jpg')"
            onclick="window.open('map/', '_blank')"
          ></button>
          <span class="button-description">Neieškokite meistrų už 300 km. Čia matysite, kur yra bazė – kad žinotumėte, kurie meistrai bazuojasi šalia jūsų.</span>
        </div>
      </div>
    </div>

    <script src="index.min.js"></script>
    <script>
    (function(){
      var _start = Date.now();
      var _page  = 'chat';
      var _ep    = 'kon/track.php';
      function _send(dur) {
        try {
          navigator.sendBeacon(_ep, JSON.stringify({action:'track', page:_page, duration:dur}));
        } catch(e) {}
      }
      window.addEventListener('pagehide', function(){ _send(Math.round((Date.now()-_start)/1000)); });
      setTimeout(function(){ _send(0); }, 1500);
    })();
    </script>
  </body>
</html>
