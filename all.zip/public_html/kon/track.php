<?php
require_once dirname(__DIR__, 2) . '/private/bootstrap.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

apiHeaders();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['ok' => false]); exit; }

$body   = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $body['action'] ?? '';

if ($action === 'track') {
    $page     = $body['page'] ?? 'unknown';
    $duration = (int)($body['duration'] ?? 0);
    $ua       = $_SERVER['HTTP_USER_AGENT'] ?? '';

    $device = 'desktop';
    if (preg_match('/Mobile|Android|iPhone|iPad/i', $ua)) {
        $device = preg_match('/iPad/i', $ua) ? 'tablet' : 'mobile';
    }

    $browser = 'other';
    if (str_contains($ua, 'Chrome') && !str_contains($ua, 'Edg')) $browser = 'chrome';
    elseif (str_contains($ua, 'Firefox')) $browser = 'firefox';
    elseif (str_contains($ua, 'Safari') && !str_contains($ua, 'Chrome')) $browser = 'safari';
    elseif (str_contains($ua, 'Edg')) $browser = 'edge';

    $entry = [
        'ts'       => date('c'),
        'page'     => $page,
        'device'   => $device,
        'browser'  => $browser,
        'duration' => $duration,
    ];

    if (!is_dir(ANALYTICS_DIR)) mkdir(ANALYTICS_DIR, 0755, true);
    $file = ANALYTICS_DIR . date('Y-m') . '.json';
    $data = file_exists($file) ? (json_decode(file_get_contents($file), true) ?? []) : [];
    $data[] = $entry;
    if (count($data) > 5000) $data = array_slice($data, -5000);
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE), LOCK_EX);

    echo json_encode(['ok' => true]);
    exit;
}

echo json_encode(['ok' => false, 'err' => 'Nežinomas veiksmas']);
