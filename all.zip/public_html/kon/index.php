<?php
require_once dirname(__DIR__, 2) . '/private/auth_check.php';
require_once dirname(__DIR__, 2) . '/private/bootstrap.php';
require_once dirname(__DIR__) . '/shared/php/domain-reader.php';
?>
<!DOCTYPE html>
<html lang="lt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IBNVS Virtualus konstruktorius</title>
<link rel="stylesheet" href="../shared/css/theme.css">
<link rel="stylesheet" href="css/styles.css">
<script src="https://cdn.jsdelivr.net/npm/d3@7/dist/d3.min.js"></script>
</head>

<body>

  <div class="header">Virtualus konstruktorius</div>

  <div class="container">

    <div class="left">

      
      <div class="image-box" style="display:flex;flex-direction:column;overflow:hidden;padding:0;">
        <div id="map-toolbar" style="display:flex;align-items:center;gap:8px;padding:6px 10px;border-bottom:1px solid var(--b1);background:var(--s2);flex-shrink:0;flex-wrap:wrap;">
          <select id="map-sys" style="display:none"><option value="0">0</option></select>
          <div id="map-comp-mode" style="display:flex;align-items:center;gap:4px;flex:1;min-width:0;"></div>
          <button class="btn ghost sm" onclick="map3dReset()" style="font-size:10px;padding:2px 8px;">↺ Atstatyti kamerą</button>
        </div>
        <div id="map-area" style="position:relative;flex:1;min-height:0;">
          <canvas id="map-canvas" style="width:100%;height:100%;display:block;cursor:default;"></canvas>
          <div id="map-info-panel"></div>
          <div style="position:absolute;top:8px;right:8px;font-size:9px;color:var(--td);background:var(--s1);padding:5px 9px;border-radius:var(--r);border:1px solid var(--b1);line-height:1.9;pointer-events:none;">
            <b style="color:var(--pri)">X</b> Sektorius ⇢<br>
            <b style="color:var(--pri)">Y</b> Gylis ⇣<br>
            <span style="color:#888"></span>
          </div>
          <div style="position:absolute;bottom:8px;left:8px;font-size:9px;color:var(--td);background:var(--s1);padding:4px 8px;border-radius:var(--r);border:1px solid var(--b1);pointer-events:none;">
            🖱 Valdykite su pelyte arba ekrane
          </div>
        </div>
      </div>

      <div class="bottom-boxes">

        <div class="box controls">
          <button onclick="atgal()">Vienu atgal</button>
          <button onclick="resetSystem()">Iš naujo</button>
          <button id="btn-sys" class="wave" onclick="detectSystemType()">Pasirinkti sistemą</button>
          <button onclick="eksportuotiJPG()">Išsaugoti Foto</button>
        </div>
        <div class="box system-box wave" id="objectMenu">
           Kraunama...
         </div>
        <div class="box info-box">
          <div id="objectInfo">Pasirinkite gruntinio vandens lygį jūsų sklype.</div>
        </div>

      </div>

    </div>

    
    <div class="right"></div>

  </div>

  <script src="js/labels-loader.js"></script>
  <script src="js/ui.min.js"></script>

  <script>const _DOMAIN_DATA = <?php echo getDomainPublicJson(); ?>;</script>
  <script src="../shared/js/state.min.js"></script>
  <script src="../shared/js/state-bridge.js"></script>

  <script src="js/kb-loader.min.js"></script>
  <script src="../shared/js/map3d-core.min.js?v=<?php echo filemtime(__DIR__.'/../shared/js/map3d-core.min.js'); ?>"></script>  
  <script src="js/konstruktorius.js?v=<?php echo filemtime(__DIR__.'/js/konstruktorius.js'); ?>"></script>

  <script>
  // Įkelti THREE.js ir GLTFLoader prieš viską
  function _loadThreeWithGltf() {
    return new Promise(function(resolve) {
      if (typeof THREE !== 'undefined' && typeof THREE.GLTFLoader !== 'undefined') {
        return resolve();
      }
      function loadGltf() {
        if (typeof THREE.GLTFLoader !== 'undefined') return resolve();
        var gl = document.createElement('script');
        gl.src = 'https://unpkg.com/three@0.134.0/examples/js/loaders/GLTFLoader.js';
        gl.onload = resolve;
        gl.onerror = resolve; // net jei nepavyko - tęsiame
        document.head.appendChild(gl);
      }
      if (typeof THREE === 'undefined') {
        var sc = document.createElement('script');
        sc.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r134/three.min.js';
        sc.onload = loadGltf;
        sc.onerror = resolve;
        document.head.appendChild(sc);
      } else {
        loadGltf();
      }
    });
  }

  document.addEventListener('DOMContentLoaded', async () => {
    initObjs();
    await loadKB();
    await loadCompScene3d();
    await _loadThreeWithGltf();
    renderMap();
    // Sustabdyti tool1 sceną – konstruktoriuje ji nereikalinga (tai sukelia ryškų foną)
    if (typeof _3d !== 'undefined' && _3d && typeof _3d.stop === 'function') {
      _3d.stop(); _3d = null;
    }
    // Rodyti 3D sceną iš karto – be objektų, bet jau scenoje
    const _kCanvas = document.getElementById('map-canvas');
    if (_kCanvas && typeof _K_build3d === 'function') _K_build3d(_kCanvas);

    // Paslėpti ryšio linijas tarp objektų ir komponentų
    if (typeof _line3d !== 'undefined' && typeof THREE !== 'undefined') {
      _line3d = function(sc, x1, y1, z1, x2, y2, z2, col, op) {
        const g = new THREE.BufferGeometry().setFromPoints([
          new THREE.Vector3(x1, y1, z1),
          new THREE.Vector3(x2, y2, z2)
        ]);
        const l = new THREE.Line(g, new THREE.LineBasicMaterial({ transparent: true, opacity: 0 }));
        l.visible = false;
        return l; // NE-pridedame į sceną – tik grąžiname dummy objektą
      };
    }

    konstruktoriusInit();

    // Deep link palaikymas:
    //   /kon/#obj=BNVI                — atidaro BNVI objektą + kamera nuskrenda
    //   /kon/#obj=BNVI&comp=AERAT     — atidaro BNVI + komponentą AERAT + kamera nuskrenda prie komponento
    //   /kon/#comp=AERAT              — automatiškai randa komponento parent objektą
    var hash = window.location.hash;
    if (hash) {
      var params = {};
      hash.replace('#','').split('&').forEach(function(p){
        var kv = p.split('=');
        if (kv[0] && kv[1]) params[kv[0]] = decodeURIComponent(kv[1]);
      });

      var oid = params.obj ? params.obj.toUpperCase() : null;
      var cid = params.comp ? params.comp.toUpperCase() : null;

      // Jei tik comp= - randame parent objektą
      if (!oid && cid && typeof KB !== 'undefined' && KB.components && KB.components[cid]) {
        var pid = KB.components[cid].parent_id;
        // Eikim aukštyn iki root objekto
        while (pid && KB.components && KB.components[pid]) {
          pid = KB.components[pid].parent_id;
        }
        if (pid) oid = pid;
      }

      if (oid) {
        setTimeout(function() {
          if (typeof mapSysClickObj === 'function') {
            mapSysClickObj(oid);
            // Po objekto pasirinkimo - jei yra ir komponentas, jį paspausti
            if (cid) {
              setTimeout(function() {
                if (typeof mapClickComp === 'function') mapClickComp(cid);
              }, 600);
            }
          }
        }, 800);
      }
    }
  });
  </script>
<!-- FOOTER + MODAL -->
<div id="ibnvs-footer" style="text-align:center;padding:18px 16px 24px;font-size:0.72rem;color:rgba(150,150,150,0.8);border-top:1px solid rgba(0,0,0,0.07);margin-top:auto">
  © 2026 IBNVS. Visos teisės saugomos. &nbsp;·&nbsp;
  <a href="#" onclick="ibnvsModal('salygos');return false;" style="color:inherit;text-decoration:underline;text-underline-offset:3px">Naudojimo sąlygos</a>
  &nbsp;·&nbsp;
  <a href="#" onclick="ibnvsModal('privatumas');return false;" style="color:inherit;text-decoration:underline;text-underline-offset:3px">Privatumo politika</a>
  &nbsp;·&nbsp;
  <a href="#" onclick="ibnvsModal('atsakomybe');return false;" style="color:inherit;text-decoration:underline;text-underline-offset:3px">Atsakomybės atsisakymas</a>
</div>

<div id="ibnvs-modal-overlay" onclick="ibnvsModalClose()" style="display:none;position:fixed;inset:0;z-index:9000;background:rgba(0,0,0,0.6);backdrop-filter:blur(4px);align-items:center;justify-content:center;padding:20px">
  <div onclick="event.stopPropagation()" style="background:#fff;border-radius:16px;max-width:680px;width:100%;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,0.3)">
    <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 22px 14px;border-bottom:1px solid #eee;flex-shrink:0">
      <div id="ibnvs-modal-title" style="font-size:1rem;font-weight:700;color:#1b5e20"></div>
      <button onclick="ibnvsModalClose()" style="background:none;border:none;font-size:1.4rem;cursor:pointer;color:#999;line-height:1;padding:0">✕</button>
    </div>
    <div id="ibnvs-modal-body" style="overflow-y:auto;padding:20px 22px;font-size:0.82rem;line-height:1.7;color:#333"></div>
  </div>
</div>

<script>
var _ibnvsDocs = {
  salygos: {
    title: 'Naudojimo sąlygos',
    html: '<h3 style="color:#1b5e20;margin:0 0 8px">1. Bendroji informacija</h3><p>IBNVS (manonuotekos.lt) – asmeninė informacinė svetainė, sukurta remiantis praktine patirtimi nuotekų valymo ir nusodinimo sistemų srityje. Tikslas – nemokamai dalintis žiniomis su visais norinčiais.</p><h3 style="color:#1b5e20;margin:16px 0 8px">2. Informacinio pobūdžio turinys</h3><p>Visa pateikta informacija – skaičiavimai, rekomendacijos, diagnostikos išvados – yra <b>asmeninė autoriaus nuomonė</b>, pagrįsta praktine patirtimi. Tai nėra oficialus inžinerinis projektas ar juridiškai įpareigojantis dokumentas.</p><h3 style="color:#1b5e20;margin:16px 0 8px">3. Atsakomybės ribojimas</h3><p>IBNVS autorius neprisiima atsakomybės dėl nuostolių, atsiradusių naudojantis svetainės informacija, neteisingai įrengtos sistemos pasekmių ar trečiųjų šalių paslaugų kokybės. Kainos ir techniniai duomenys pateikiami orientaciniai.</p><h3 style="color:#1b5e20;margin:16px 0 8px">4. Intelektinė nuosavybė</h3><p>Programinis kodas, 3D modeliai, tekstai ir duomenų bazė yra IBNVS autoriaus intelektinė nuosavybė. Draudžiama kopijuoti ar naudoti komerciniais tikslais be raštiško sutikimo.</p><h3 style="color:#1b5e20;margin:16px 0 8px">5. Žemėlapio registracija</h3><p>Žemėlapyje registruodamiesi specialistai patvirtina, kad pateikia teisingą informaciją ir sutinka būti viešai matomi. IBNVS negarantuoja jų paslaugų kokybės ir gali pašalinti įrašą be įspėjimo.</p><p style="margin-top:16px;color:#888;font-size:0.78rem">© 2026 IBNVS · manonuotekos.lt</p>'
  },
  privatumas: {
    title: 'Privatumo politika',
    html: '<h3 style="color:#1b5e20;margin:0 0 8px">Kokie duomenys renkami</h3><p>Svetainė renka anoniminius lankymosi statistikos duomenis: apsilankymo laikas, trukmė, įrenginio tipas, naršyklė. Šie duomenys nesiejami su jūsų asmeniu.</p><p style="margin-top:10px">Žemėlapyje savanoriškai registruodamiesi pateikiate: vardą / įmonės pavadinimą, telefono numerį, miestą. Šie duomenys yra <b>viešai matomi</b> svetainėje.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Ko nerenkame</h3><p>IBNVS nerenka el. pašto adresų, mokėjimo duomenų, asmens kodų ar tikslios geografinės vietos.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Slapukai</h3><p>Naudojamas tik vienas techninis sesijos slapukas, būtinas svetainės veikimui. Reklaminiai slapukai nenaudojami.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Jūsų teisės</h3><p>Turite teisę prašyti ištaisyti ar ištrinti savo duomenis iš žemėlapio. Duomenys neparduodami ir neperduodami trečiosioms šalims.</p><p style="margin-top:16px;color:#888;font-size:0.78rem">© 2026 IBNVS · manonuotekos.lt</p>'
  },
  atsakomybe: {
    title: 'Atsakomybės atsisakymas',
    html: '<p>IBNVS – vieno žmogaus sukurta informacinė svetainė. Autorius turi daugiametę praktinę patirtį nuotekų valymo sistemų srityje ir nori ja <b>nemokamai dalintis</b> su visais.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Apie pateikiamą informaciją</h3><p>Konstruktoriaus skaičiavimai, diagnostikos rekomendacijos ir kainos yra <b>orientaciniai</b>. Kiekvienas objektas yra skirtingas. Prieš pradėdami darbus – konsultuokitės su specialistu, patikrinkite norminius reikalavimus ir kainas tiesiogiai pas tiekėjus.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Apie žemėlapio specialistus</h3><p>Žemėlapyje rodomi specialistai savanoriškai pateikė savo kontaktus. IBNVS netikrina jų kvalifikacijos ir neatsako už jų darbų kokybę.</p><h3 style="color:#1b5e20;margin:16px 0 8px">Baigiamasis žodis</h3><p>Ši svetainė sukurta iš noro padėti. Jei informacija netinka – tiesiog ja nesinaudokite. Naudodamiesi svetaine patvirtinate, kad suprantate jos informacinį pobūdį ir prisiimate atsakomybę už savo sprendimus.</p><p style="margin-top:16px;color:#888;font-size:0.78rem">© 2026 IBNVS · manonuotekos.lt</p>'
  }
};
function ibnvsModal(doc) {
  var d = _ibnvsDocs[doc]; if (!d) return;
  document.getElementById('ibnvs-modal-title').textContent = d.title;
  document.getElementById('ibnvs-modal-body').innerHTML = d.html;
  document.getElementById('ibnvs-modal-overlay').style.display = 'flex';
  document.body.style.overflow = 'hidden';
}
function ibnvsModalClose() {
  document.getElementById('ibnvs-modal-overlay').style.display = 'none';
  document.body.style.overflow = '';
}
document.addEventListener('keydown', function(e) { if (e.key === 'Escape') ibnvsModalClose(); });
</script>

</body>
</html>
