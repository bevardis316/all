const API_URL = './api.php';

let sistema        = [];
let dabartinisSektorius = 'A';
let processing     = false;
let gruntinisVanduo = null;
let gruntasTipas   = null;

let _K3d           = null;   
let _K3dSel        = null;   
let _KOrbSave      = null;   
let _KUserMovedCam = false;

const _K_Z_Y = {
  '@zempav': 2, '@ipgil': 1, '@gilu': 0,
  '0': 2,   
  '-1': 1,  
  '-2': 0,  
  '-3': 0,  
};

const GVL_COLORS = {
  'gvl-1': { sky: 0xd6eaf8, grid: 0x2471a3 },
  'gvl-2': { sky: 0xd5f5e3, grid: 0x1e8449 },
  'gvl-3': { sky: 0xfef9e7, grid: 0x9a7d0a },
  null:     { sky: 0xf2f8f3, grid: 0x4a9d6f },
};

let _objMeta = {};

function _K_objPos(obj, overrideX) {
  const sek  = obj.sektorius || 'B';
  // gylis ateina kaip skaičius-string iš API ('0', '-1', '-2', '-3')
  // _K_Z_Y naudoja '@zempav', '@ipgil', '@gilu' raktus — reikia konvertuoti
  const _gylisToZ = { '0': '@zempav', '-1': '@ipgil', '-2': '@gilu', '-3': '@gilu' };
  const gyl  = _gylisToZ[String(obj.gylis)] ?? String(obj.gylis ?? '@ipgil');
  const xIdx = overrideX !== undefined ? overrideX : (_SEK_X[sek] !== undefined ? _SEK_X[sek] : 2);

  // NAM1/NAM2: nepiešiamas kol nepasirinktas antrasis objektas
  // Y pozicija = sekančio objekto Y + 0.5*_CELL (namas aukščiau už nuotekų sistemą)
  if (obj.tipas === 'NAM1' || obj.tipas === 'NAM2') {
    if (sistema.length < 2) return null;
    const next = sistema[1];
    const nextPos = _K_objPos(next, 1); // antrojo objekto pozicija
    const nextY = nextPos ? nextPos.y : 1.0 * _CELL;
    return { x: xIdx * _CELL, y: nextY + 0.5 * _CELL, z: 0 };
  }

  const yIdx = _K_Z_Y[gyl] !== undefined ? _K_Z_Y[gyl] : 1;
  return {
    x: xIdx * _CELL,
    y: yIdx * _CELL,
    z: 0,
  };
}

function _K_addSphere(scene, pos, col, r, userData, meshList, s3d) {
  const mx = pos.x + (s3d?.delta_x||0);
  const my = pos.y + (s3d?.delta_y||0);
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(r, 18, 18),
    new THREE.MeshPhongMaterial({ color: col, shininess: 80 })
  );
  mesh.position.set(mx, my, 0);
  mesh.userData = userData;
  scene.add(mesh);
  meshList.push(mesh);
}

// === KAMERŲ POZICIJŲ FIKSAS ===
// cam_click.tx/ty yra absoliučios koordinatės - reikia koreguoti pagal dabartinę objekto poziciją
// (pvz. BNVI sistemose 1-5 yra ties x=2.8, bet sistemose 6-12 ties x=5.6)
function _getObjBaseX(oid) {
  if (typeof TECH === 'undefined' || !TECH.sistemu_tipai) return 0;
  for (const sys of TECH.sistemu_tipai) {
    const idx = (sys.grandine || []).indexOf(oid);
    if (idx >= 0) return idx * _CELL;
  }
  return 0;
}

function _camClickCorrected(oid, currentIdx) {
  const cam = KB.objects[oid]?.scene_3d?.cam_click;
  if (!cam) return null;
  const baseX    = _getObjBaseX(oid);
  const currentX = currentIdx * _CELL;
  return {
    r:     cam.r,
    theta: cam.theta,
    phi:   cam.phi,
    tx:    currentX + (cam.tx - baseX),  // perkeliame offsetą į dabartinę poziciją
    ty:    cam.ty,
    tz:    cam.tz || 0,
  };
}

function _K_buildEmpty(canvas) {
  if (_K3d) { _K3d.stop(); _K3d = null; }

  const cont = canvas.parentElement;
  const W    = cont.clientWidth  || 900;
  const H    = cont.clientHeight || 400;
  canvas.width  = W;
  canvas.height = H;

  const scene    = new THREE.Scene();
  scene.background = new THREE.Color(0xf2f8f3);
  const camera   = new THREE.PerspectiveCamera(42, W / H, 0.1, 300);
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setSize(W, H);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  const CX = 2 * _CELL;
  camera.position.set(CX, 2, 16);
  camera.lookAt(CX, 2, 0);

  scene.add(new THREE.AmbientLight(0xffffff, (function(){try{var v=parseFloat(localStorage.getItem("adm_amb"));return(v>0?v:1.2);}catch(e){return 1.2;}})()));
  _drawGrid(scene);
  _drawAxisLabels(scene, null);
  _txt3d(scene, UI.get('scene.select_gvl','Pasirinkite gruntinio vandens lygį ↓'), CX, 2.8 * _CELL, 0, '#4a9d6f', 17);

  let animId, stopped = false;
  function animate() { if (stopped) return; animId = requestAnimationFrame(animate); renderer.render(scene, camera); }
  animate();

  _K3d = {
    stop: () => { stopped = true; cancelAnimationFrame(animId); renderer.dispose(); },
    orb: {}, applyOrbit: () => {}, DEF_ORB: {},
    scene, renderer, camera,
  };
}

function _K_build3d(canvas) {
  if (_K3d) {
    if (_K3d.orb && _K3d.orb.target && _KUserMovedCam) {
      _KOrbSave = {
        r: _K3d.orb.r, theta: _K3d.orb.theta, phi: _K3d.orb.phi,
        tx: _K3d.orb.target.x, ty: _K3d.orb.target.y, tz: _K3d.orb.target.z,
      };
    }
    _K3d.stop();
    _K3d = null;
  }
  _K3dSel = null;

  const cont = canvas.parentElement;
  let W = cont.clientWidth  || 900;
  let H = cont.clientHeight || 400;
  canvas.width  = W;
  canvas.height = H;

  const _ac  = new AbortController();
  const _sig = { signal: _ac.signal };

  const gvlCol = GVL_COLORS[gruntinisVanduo] || GVL_COLORS[null];

  const scene    = new THREE.Scene();
  scene.background = new THREE.Color(gvlCol.sky);
  const camera   = new THREE.PerspectiveCamera(42, W / H, 0.1, 300);
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setSize(W, H);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  const _resObs = new ResizeObserver(() => {
    W = cont.clientWidth  || 900;
    H = cont.clientHeight || 400;
    canvas.width  = W;
    canvas.height = H;
    camera.aspect = W / H;
    camera.updateProjectionMatrix();
    renderer.setSize(W, H);
  });
  _resObs.observe(cont);

  scene.add(new THREE.AmbientLight(0xffffff, (function(){try{var v=parseFloat(localStorage.getItem("adm_amb"));return(v>0?v:1.2);}catch(e){return 1.2;}})()));
  const dl = new THREE.DirectionalLight(0xffffff, 0.6);
  dl.position.set(5, 10, 15);
  scene.add(dl);

  const posMap = {};
  sistema.forEach((obj, idx) => { posMap[obj.tipas] = idx; });

  const sysLen = sistema.length;
  const CX = 2 * _CELL; // Fiksuotas centras - kamera nešokinėja
  const CY = 1.0 * _CELL;

  const _gridRef = _drawGrid(scene);
  if (_gridRef) { _gridRef.renderOrder = 2; }
  _drawAxisLabels(scene, sistema.map(o => o.tipas));
  // Fonas su opacity efektu - identiškas _build3d scenai
  const _bgRef = (typeof _drawBackground === 'function') ? _drawBackground(scene, CX) : null;

  const objMeshes = [];

  sistema.forEach((obj, idx) => {
    const pos = _K_objPos(obj, idx);
    if (!pos) return;

    const hasData = !!(obj.infoTekstas);
    const col     = hasData ? 0x2e7d32 : 0x7a9e7e;
    const r       = 0.38;
    const userData = { type: 'obj', id: obj.tipas, idx, obj };

    const s3d = KB.objects[obj.tipas]?.scene_3d;

    if (s3d?.glb && typeof THREE.GLTFLoader !== 'undefined') {
      // Spheres-first: sferos rodomos iš karto, GLB tyliai pakeičia jas
      _K_addSphere(scene, pos, col, r, userData, objMeshes, s3d);
      THREE.Cache.enabled = false;
      const loader = new THREE.GLTFLoader();
      const _glbUrl = '/shared/glb/' + s3d.glb + '?v=' + (window._glbVer||(window._glbVer=localStorage.getItem('glb_ver')||'1'));
      loader.load(_glbUrl, gltf => {
        for (let i = objMeshes.length - 1; i >= 0; i--) {
          if (objMeshes[i].userData === userData && objMeshes[i].geometry?.type === 'SphereGeometry') {
            scene.remove(objMeshes[i]); objMeshes.splice(i, 1);
          }
        }
        const model = gltf.scene;
        const _sx=s3d.scale_x||s3d.scale||1, _sy=s3d.scale_y||s3d.scale||1, _sz=s3d.scale_z||s3d.scale||1;
        model.scale.set(_sx, _sy, _sz);
        model.rotation.set(
          (s3d.rotation_x||0)*Math.PI/180,
          (s3d.rotation_y||0)*Math.PI/180,
          (s3d.rotation_z||0)*Math.PI/180
        );
        model.position.set(
          pos.x + (s3d.delta_x||0),
          pos.y + (s3d.delta_y||0) + (s3d.offset_y||0),
          0
        );
        model.userData = userData;
        model.traverse(c => { if (c.isMesh) { c.userData = userData; objMeshes.push(c); } });
        scene.add(model);
      }, null, () => { /* sferos jau rodomos */ });
    } else {
      _K_addSphere(scene, pos, col, r, userData, objMeshes, s3d);
    }


    _txt3d(scene, obj.trumpinimas || obj.tipas, pos.x, pos.y + r + 0.52, 0.05,
      hasData ? '#1e5c30' : '#666', 16);

    if (idx < sistema.length - 1) {
      const nextObj = sistema[idx + 1];
      const np      = _K_objPos(nextObj, idx + 1);
      if (np) {
        const isPVC   = nextObj.vamzdis === 'PVC';
        const _ptype2 = KB.objects[obj.tipas]?.scene_3d?.pipe_type || (isPVC ? 'PVC' : 'PE');
        const lineCol = _ptype2==='PVC' ? 0x8B4513 : _ptype2==='PVC_grey' ? 0x808080 : 0x1565C0;
        _pipe3d(scene, pos.x, pos.y, 0.05, np.x, np.y, 0.05, lineCol, 0.07);
      }
    }
  });

  if (sistema.length === 0) {
    _txt3d(scene, UI.get('scene.select_first','Pasirinkite pirmą objektą ↓'), CX, CY + _CELL, 0, '#4a9d6f', 17);
  }

  // Fiksuota default pozicija - kamera nejuda pridedant objektus
  if (!_KOrbSave) {
    _KOrbSave = { r: 14, theta: 0, phi: Math.PI/2, tx: CX, ty: CY, tz: 0 };
  }
  const orbData = (_KUserMovedCam && _KOrbSave)
    ? { target: new THREE.Vector3(_KOrbSave.tx, _KOrbSave.ty, _KOrbSave.tz), r: _KOrbSave.r, theta: _KOrbSave.theta, phi: _KOrbSave.phi }
    : { target: new THREE.Vector3(CX, CY, 0), r: 14, theta: 0, phi: Math.PI/2 };
  const orb = orbData;

  function applyOrbit() {
    const sp = Math.sin(orb.phi), cp = Math.cos(orb.phi);
    const st = Math.sin(orb.theta), ct = Math.cos(orb.theta);
    camera.position.set(
      orb.target.x + orb.r * sp * st,
      orb.target.y + orb.r * cp,
      orb.target.z + orb.r * sp * ct
    );
    camera.lookAt(orb.target);
    camera.updateMatrixWorld();
  }
  applyOrbit();

  let drag = false, isPan = false, lastM = { x: 0, y: 0 };

  canvas.addEventListener('mousedown', e => {
    drag  = true;
    isPan = (e.button === 0);
    lastM = { x: e.clientX, y: e.clientY };
    canvas.style.cursor = 'grabbing';
    e.preventDefault();
  }, _sig);

  canvas.addEventListener('contextmenu', e => e.preventDefault(), _sig);

  document.addEventListener('mouseup', () => {
    drag = false;
    canvas.style.cursor = 'default';
  }, { signal: _ac.signal });

  canvas.addEventListener('mousemove', e => {
    if (!drag) {
      const rect = canvas.getBoundingClientRect();
      const mp   = new THREE.Vector2(
        ((e.clientX - rect.left) / W) * 2 - 1,
        -((e.clientY - rect.top)  / H) * 2 + 1
      );
      const ray = new THREE.Raycaster();
      ray.setFromCamera(mp, camera);
      canvas.style.cursor = ray.intersectObjects(objMeshes).length ? 'pointer' : 'default';
      return;
    }

    _KUserMovedCam = true;
    const dx = e.clientX - lastM.x;
    const dy = e.clientY - lastM.y;
    lastM = { x: e.clientX, y: e.clientY };

    if (isPan) {
      const right = new THREE.Vector3(), up = new THREE.Vector3();
      camera.matrix.extractBasis(right, up, new THREE.Vector3());
      orb.target.addScaledVector(right, -dx * 0.015);
      orb.target.addScaledVector(up,     dy * 0.015);
    } else {
      orb.theta -= dx * 0.008;
      orb.phi    = Math.max(0.05, Math.min(Math.PI - 0.05, orb.phi + dy * 0.008));
    }
    applyOrbit();
  }, _sig);

  canvas.addEventListener('wheel', e => {
    _KUserMovedCam = true;
    orb.r = Math.max(4, Math.min(80, orb.r + e.deltaY * 0.04));
    applyOrbit();
    e.preventDefault();
  }, { passive: false, signal: _ac.signal });

  const DEAD = 3;
  let _clickStart = { x: 0, y: 0 }, _moved = false;

  canvas.addEventListener('mousedown', e => {
    _clickStart = { x: e.clientX, y: e.clientY };
    _moved      = false;
  }, { capture: true, signal: _ac.signal });

  canvas.addEventListener('mousemove', e => {
    if (drag && (Math.abs(e.clientX - _clickStart.x) > DEAD || Math.abs(e.clientY - _clickStart.y) > DEAD))
      _moved = true;
  }, { capture: true, signal: _ac.signal });

  // ── TOUCH palaikymas _K_build3d scenoje ─────────────────────────────────
  let _tStart = null, _tDist = 0, _tMoved = false;

  canvas.addEventListener('touchstart', e => {
    e.preventDefault();
    _tMoved = false;
    if (e.touches.length === 1) {
      const r = canvas.getBoundingClientRect();
      _tStart = { x: e.touches[0].clientX - r.left, y: e.touches[0].clientY - r.top };
    } else if (e.touches.length === 2) {
      const dx = e.touches[1].clientX - e.touches[0].clientX;
      const dy = e.touches[1].clientY - e.touches[0].clientY;
      _tDist  = Math.sqrt(dx*dx + dy*dy);
      _tStart = null;
    }
  }, { passive: false, signal: _ac.signal });

  canvas.addEventListener('touchmove', e => {
    e.preventDefault();
    _KUserMovedCam = true;
    if (e.touches.length === 1 && _tStart) {
      const r  = canvas.getBoundingClientRect();
      const tx = e.touches[0].clientX - r.left;
      const ty = e.touches[0].clientY - r.top;
      const dx = tx - _tStart.x, dy = ty - _tStart.y;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) _tMoved = true;
      orb.theta -= dx * 0.008;
      orb.phi    = Math.max(0.05, Math.min(Math.PI - 0.05, orb.phi + dy * 0.008));
      _tStart    = { x: tx, y: ty };
      applyOrbit();
    } else if (e.touches.length === 2) {
      _tMoved = true;
      const dx  = e.touches[1].clientX - e.touches[0].clientX;
      const dy  = e.touches[1].clientY - e.touches[0].clientY;
      const nd  = Math.sqrt(dx*dx + dy*dy);
      orb.r     = Math.max(4, Math.min(80, orb.r * (_tDist / Math.max(nd, 1))));
      _tDist    = nd;
      applyOrbit();
    }
  }, { passive: false, signal: _ac.signal });

  canvas.addEventListener('touchend', e => {
    e.preventDefault();
    if (!_tMoved && _tStart && e.changedTouches.length) {
      // Tap — ieškome objekto
      const mp  = new THREE.Vector2(
        (_tStart.x / W) * 2 - 1,
        -(_tStart.y / H) * 2 + 1
      );
      const ray = new THREE.Raycaster();
      ray.setFromCamera(mp, camera);
      const hits = ray.intersectObjects(objMeshes);
      if (hits.length) _K_handleSelect(hits[0].object.userData, canvas);
    }
    _tStart = null;
  }, { passive: false, signal: _ac.signal });
  // ─────────────────────────────────────────────────────────────────────────

  canvas.addEventListener('click', e => {
    if (_moved) return;
    const rect = canvas.getBoundingClientRect();
    const mp   = new THREE.Vector2(
      ((e.clientX - rect.left) / W) * 2 - 1,
      -((e.clientY - rect.top)  / H) * 2 + 1
    );
    const ray  = new THREE.Raycaster();
    ray.setFromCamera(mp, camera);
    const hits = ray.intersectObjects(objMeshes);
    if (!hits.length) return;

    _K_handleSelect(hits[0].object.userData, canvas);
    updateInfo();
  }, _sig);

  // Bendra logika click + touch (išvengiame dublikato)
  function _K_handleSelect(d, cv) {
    if (_K3dSel === d.id) {
      _K3dSel = null;
      if (typeof _hidePanel === 'function') _hidePanel();
      _selObj = null; _selComp = null; _3dSel = null;
      const _sysN = parseInt(document.getElementById('map-sys')?.value || '0');
      if (_sysN && typeof _renderPanelSys === 'function') _renderPanelSys(_sysN);
    } else {
      _K3dSel = d.id;
      if (!_KUserMovedCam) {
        orb.theta = 0.4; orb.phi = 1.2; applyOrbit(); _KUserMovedCam = true;
      }
      if (typeof _build3d === 'function') {
        if (_K3d) { _K3d.stop(); }
        const konTipai = sistema.map(o => o.tipas);
        const matchSys = TECH.sistemu_tipai.find(t =>
          t.grandine.length === konTipai.length &&
          t.grandine.every((g,i) => g === konTipai[i])
        ) || TECH.sistemu_tipai.find(t =>
          konTipai.length <= t.grandine.length &&
          konTipai.every((k,i) => t.grandine[i] === k)
        ) || TECH.sistemu_tipai.find(t => t.grandine.includes(d.id));
        const sel = document.getElementById('map-sys');
        if (sel && matchSys) sel.value = matchSys.id;
        _selObj = d.id;
        _selComp = null; _openedComps = []; _3dSel = d.id; _panelLevel = 'obj';
        const _objCam = _camClickCorrected(d.id, d.idx);
        if (_objCam) {
          _orbSave = { r: _objCam.r, theta: _objCam.theta, phi: _objCam.phi,
                       tx: _objCam.tx, ty: _objCam.ty, tz: _objCam.tz };
          _userMovedCam = true;
        } else { _userMovedCam = true; }
        _build3d(cv);
        _renderPanel();
      }
    }
  }

  let animId, stopped = false;
  function animate() {
    if (stopped) return;
    animId = requestAnimationFrame(animate);
    // Fonas + GVL blunka sukant kamerą, tinklelis ryškėja
    const _t2 = ((orb.theta % (Math.PI*2)) + Math.PI*2) % (Math.PI*2);
    const _rs2 = Math.abs(Math.sin(_t2));
    const _rp2 = Math.abs(orb.phi - Math.PI/2) / (Math.PI/2);
    const _fac = Math.max(_rs2, _rp2);
    const _bgOp = 0.95 * Math.max(0, 1 - _fac * 6);
    const _fadeRatio = _bgOp / 0.95; // 1=pilnas fonas, 0=fonas dingęs
    if (_bgRef) {
      const _bgMesh = _bgRef.getMesh();
      if (_bgMesh) _bgMesh.material.opacity = _bgOp;
    }
    // GVL vanduo dingsta kartu su fonu
    const _gvlMesh = scene ? scene.getObjectByName('_gvlWater') : null;
    if (_gvlMesh) _gvlMesh.material.opacity = 0.32 * _fadeRatio;
    // Tinklelis: ryškėja kai fonas dingsta (0 → 0.70)
    if (_gridRef) {
      const _gridOp = window._gridVisible===false ? 0 : (_fadeRatio<0.15 ? Math.max(0,(1-_fadeRatio*6.67)*0.35) : 0);
      _gridRef.material.opacity = Math.max(0, Math.min(0.35, _gridOp));
    }
    renderer.render(scene, camera);
  }
  animate();

  const DEF_ORB = { r: 14, theta: 0, phi: Math.PI/2, tx: CX, ty: CY };
  _K3d = {
    stop: () => {
      _ac.abort();
      _resObs.disconnect();
      if (_KUserMovedCam) {
        _KOrbSave = { r: orb.r, theta: orb.theta, phi: orb.phi, tx: orb.target.x, ty: orb.target.y, tz: orb.target.z };
      }
      stopped = true;
      cancelAnimationFrame(animId);
      renderer.dispose();
    },
    orb, applyOrbit, DEF_ORB,
    scene, renderer, camera,
  };
}

function renderSistema() {
  const canvas = document.getElementById('map-canvas');
  if (!canvas || typeof _build3d === 'undefined') return;

  const konTipai = sistema.map(o => o.tipas);

  const gylisToZ = { '0': '@zempav', '-1': '@ipgil', '-2': '@gilu', '-3': '@gilu' };

  sistema.forEach((obj, idx) => {
    const normId = obj.tipas;
    const def = DEF_OBJS.find(d => d.id === normId);
    const zFromApi = obj.gylis !== undefined ? (gylisToZ[String(obj.gylis)] || '@ipgil') : null;
    const zFinal = zFromApi || def?.z || '@ipgil';

    KB.objects_meta[normId] = {
      ...(def || {}),
      id: normId,
      name: obj.aprasymas || def?.name || normId,
      sek: [obj.sektorius || def?.sek?.[0] || 'A'],
      z: zFinal,
    };
    if (!KB.objects[normId]) {
      KB.objects[normId] = { name: obj.aprasymas || normId, function: obj.infoTekstas || '', failure_modes: {}, models: [] };
    }
    // Išsaugoti scene_3d iš loadKB() - neperrašyti tuščiu objektu
    if (!KB.objects[normId].scene_3d && obj.scene3d) {
      KB.objects[normId].scene_3d = obj.scene3d;
    }
  });

  const bestSys = TECH.sistemu_tipai.find(t =>
    t.grandine.length === konTipai.length &&
    t.grandine.every((g, i) => g === konTipai[i])
  ) || TECH.sistemu_tipai.find(t =>
    konTipai.length > 0 &&
    konTipai.length <= t.grandine.length &&
    konTipai.every((k, i) => t.grandine[i] === k)
  );

  const sel = document.getElementById('map-sys');
  if (sel) sel.value = bestSys ? bestSys.id : '0';

  window._konSistemaLength = sistema.length;

  if (typeof _hidePanel === 'function') _hidePanel();
  _selObj = null; _selComp = null; _3dSel = null;

  const doBuild = () => {
    if (sistema.length > 0 && bestSys) {
      // Issaugoti esama kameros pozicija kad nesersoktu pridedant nauja objekta.
      // Jei zmogus dar nejudino - naudojama fiksuota default pozicija.
      if (!_userMovedCam) {
        // Ieškome cam_click pirmam objektui sistemoje - jei yra, naudojame ją
        const _firstObjId = sistema[0]?.tipas;
        const _firstCam = _firstObjId ? KB.objects[_firstObjId]?.scene_3d?.cam_click : null;
        if (_firstCam) {
          _orbSave = { r: _firstCam.r, theta: _firstCam.theta, phi: _firstCam.phi,
                       tx: _firstCam.tx||0, ty: _firstCam.ty||0, tz: _firstCam.tz||0 };
        } else {
          _orbSave = { r: 9.5, theta: 0, phi: Math.PI / 2, tx: 2 * 2.8, ty: 1.0 * 2.8, tz: 0 };
        }
        _userMovedCam = true;
      }
      _viewMode = 'expand';
      _build3d(canvas);
      if (typeof _renderModeButtons === 'function') _renderModeButtons();
      if (typeof _renderPanelSys === 'function') _renderPanelSys(bestSys.id);
      setTimeout(_K_addGvlToScene, 10);
    } else {
      _K_build3d(canvas);
    }
  };

  if (typeof THREE === 'undefined') {
    const sc = document.createElement('script');
    sc.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r134/three.min.js';
    sc.onload = () => {
      if (typeof THREE.GLTFLoader === 'undefined') {
        const gl = document.createElement('script');
        gl.src = 'https://unpkg.com/three@0.134.0/examples/js/loaders/GLTFLoader.js';
        gl.onload = doBuild;
        gl.onerror = doBuild;
        document.head.appendChild(gl);
      } else { doBuild(); }
    };
    document.head.appendChild(sc);
  } else if (typeof THREE.GLTFLoader === 'undefined') {
    const gl = document.createElement('script');
    gl.src = 'https://unpkg.com/three@0.134.0/examples/js/loaders/GLTFLoader.js';
    gl.onload = doBuild;
    gl.onerror = doBuild;
    document.head.appendChild(gl);
  } else {
    doBuild();
  }
}


function _K_addGvlToScene() {
  if (!gruntinisVanduo || gruntinisVanduo === 'gvl-3') return;
  // Šlaito sistemose GVL nerodomas (vanduo nesiekia)
  if (sistema && sistema.some(o => o.tipas === 'SLAIT')) return;
  const _sc = (_3d && _3d.scene) ? _3d.scene : (_K3d && _K3d.scene) ? _K3d.scene : null;
  if (!_sc) return;

  // Pašalinti seną GVL mesh
  const _old = _sc.getObjectByName('_gvlWater');
  if (_old) _sc.remove(_old);

  // GVL Y pozicija scenos koordinatėse
  const _gvlDefs = { 'gvl-1': 1.5, 'gvl-2': 0.5 };
  let _saved = {};
  try { _saved = JSON.parse(localStorage.getItem('gvl_lines') || '{}'); } catch(e) {}
  const _yVal = _saved[gruntinisVanduo] !== undefined ? _saved[gruntinisVanduo] : _gvlDefs[gruntinisVanduo];
  const _gvlY  = _yVal * _CELL;          // GVL linijos viršus
  const _bgBot = 0;                       // Fono apačia (fono y centras=H/2, H=(3-1)*_CELL)
  const _bgW   = (6-1) * _CELL;          // Fono plotis - tiek pat kiek fonas
  const _h     = Math.max(0.01, _gvlY - _bgBot);
  const _cx    = 2.5 * _CELL;            // Fono X centras

  const _mat = new THREE.MeshBasicMaterial({
    color: 0x5ba8d4,
    transparent: true,
    opacity: 0,                           // Pradeda nuo 0, fade-in
    side: THREE.DoubleSide,
    depthWrite: false
  });
  const _mesh = new THREE.Mesh(new THREE.PlaneGeometry(_bgW, _h), _mat);
  _mesh.name = '_gvlWater';
  _mesh.position.set(_cx, _bgBot + _h / 2, -0.008);  // Virš fono (-0.01), po objektais
  _sc.add(_mesh);

  // Fade-in animacija iki opacity 0.15
  const _t0 = performance.now();
  const _dur = 800;
  function _fadeIn() {
    const _p = Math.min(1, (performance.now() - _t0) / _dur);
    _mat.opacity = _p * 0.32;
    if (_p < 1) requestAnimationFrame(_fadeIn);
  }
  requestAnimationFrame(_fadeIn);
}

function konstruktoriusInit() {
  // Atstatyti GVL pasirinkimą po refresh
  try {
    const _savedGvl = localStorage.getItem('kon_gvl');
    if (_savedGvl) gruntinisVanduo = _savedGvl;
  } catch(e) {}
  updateMenu();
  // Palaukti kol UI tekstai užkraunami, tada atnaujinti info bloką
  UI.onReady(function() { updateInfo(); });
}

async function apiKlausimas(veiksmas, duomenys = {}) {
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: veiksmas, ...duomenys }),
    });
    if (!response.ok) throw new Error('API klaida: ' + response.status);
    return JSON.parse(await response.text());
  } catch (error) {
    console.error('Klaida:', error);
    alert('Klaida: ' + error.message);
    return null;
  }
}

function _updateSummaryBar() {}

function _getSisId() {
  if (sistema.length === 0) return null;
  const tipai = sistema.map(o => o.tipas);
  const match = TECH.sistemu_tipai.find(function(t) {
    return t.grandine.length === tipai.length &&
           t.grandine.every(function(g, i) { return g === tipai[i]; });
  }) || TECH.sistemu_tipai.find(function(t) {
    return tipai.length <= t.grandine.length &&
           tipai.every(function(k, i) { return t.grandine[i] === k; });
  });
  return match ? match.id : null;
}

function updateInfo() {
  const info = document.getElementById('objectInfo');
  if (!info) return;
  _updateSummaryBar();

  const gvlLabels = {'gvl-1':'Aukštas GVL','gvl-2':'Žemas GVL','gvl-3':'Nėra GVL'};
  const parts = [];

  // --- Konteksto blokas: dabartiniai pasirinkimai ---
  if (gruntinisVanduo || gruntasTipas) {
    var ctx = '<div style="font-size:11px;color:#4a9d6f;margin-bottom:6px;">';
    if (gruntinisVanduo) ctx += '&#127796; <b>' + (gvlLabels[gruntinisVanduo] || gruntinisVanduo) + '</b>';
    if (gruntinisVanduo && gruntasTipas) ctx += ' &nbsp;·&nbsp; ';
    if (gruntasTipas) ctx += '&#127759; <b>' + (gruntasTipas === 'mol' ? 'Molis / Priemolis' : 'Smėlis / Žvyras') + '</b>';
    ctx += '</div>';
    parts.push(ctx);
  }

  // --- Įspėjimų blokas ---
  const warnings = [];
  const sysId = _getSisId();

  if (sistema.length > 0) {
    if (!gruntinisVanduo) {
      warnings.push('Dar nepasirinktas gruntinio vandens lygis (GVL). Infiltracinės sistemos gali būti netinkamos.');
    }
    if (!gruntasTipas) {
      warnings.push('Dar nepasirinktas grunto tipas. Molio grunte infiltracinės sistemos neveikia.');
    }
    if (gruntinisVanduo && sysId !== null) {
      const gvlBlocked = (TECH.gvl_blokuoja && TECH.gvl_blokuoja[gruntinisVanduo]) || [];
      if (gvlBlocked.indexOf(sysId) !== -1) {
        warnings.push('Pasirinkta sistema nesuderinama su <b>' + (gvlLabels[gruntinisVanduo] || gruntinisVanduo) + '</b> — infiltracija tokiomis sąlygomis neveikia.');
      }
    }
    if (gruntasTipas === 'mol' && sysId !== null) {
      const molBlocked = [1, 4, 5, 6, 11, 12];
      if (molBlocked.indexOf(sysId) !== -1) {
        warnings.push('Pasirinkta sistema nesuderinama su <b>molio / priemolio</b> grunte — gruntas neįleidžia vandens.');
      }
    }
  }

  if (warnings.length > 0) {
    parts.push(warnings.map(function(w) {
      return '<div class="info-warn-text" style="background:#fff8e1;border-left:4px solid #ffc107;border-radius:4px;padding:8px 12px;margin-bottom:4px;color:#5d4037;">&#9888; ' + w + '</div>';
    }).join(''));
  }

  // --- Pagrindinis tekstas ---
  var mainText = '';
  if (!gruntinisVanduo) {
    mainText = UI.get('info.gvl', 'Gruntinis vanduo. Tai pirmas klausimas, ne atsitiktinai. Jei gruntinis vanduo aukštai, infiltracija tokiomis sąlygomis neveikia iš principo.');
  } else if (!gruntasTipas) {
    // Rodyti GVL-specifinį tekstą
    var gvlInfoKey = {'gvl-1':'info.gvl_high','gvl-2':'info.gvl_low','gvl-3':'info.gvl_none'}[gruntinisVanduo] || 'info.gvl';
    mainText = UI.get(gvlInfoKey, UI.get('info.soil', 'Pasirinkite grunto tipą.'));
  } else if (sistema.length === 0) {
    // Rodyti GT-specifinį tekstą
    var soilInfoKey = (gruntasTipas === 'mol') ? 'info.soil_clay' : 'info.soil_sand';
    mainText = UI.get(soilInfoKey, UI.get('info.depth', 'Pasirinkite išvado gylį.'));
  } else if (_K3dSel) {
    const sel = sistema.find(o => o.tipas === _K3dSel);
    // Pirma žiūrim UI labels, tada fallback į API infoTekstas
    mainText = UI.get('objects.' + _K3dSel + '.aprasymas', sel?.infoTekstas || _K3dSel);
  } else {
    const pask = sistema[sistema.length - 1];
    mainText = UI.get('objects.' + pask.tipas + '.aprasymas', pask.infoTekstas || '');
  }

  if (mainText) {
    parts.push('<div class="info-main-text">' + mainText + '</div>');
  }

  info.innerHTML = parts.join('');
  // Taikyti stiliaus nustatymus iš UI labels
  var sz = UI.get('style.info_font_size', '13px');
  var ff = UI.get('style.info_font_family', 'inherit');
  var lh = UI.get('style.info_line_height', '1.6');
  info.style.fontSize   = sz;
  info.style.fontFamily = ff;
  info.style.lineHeight = lh;
  // Įkelti Google Fonts jei reikia
  if (ff && ff !== 'inherit' && ff.indexOf("'") !== -1) {
    var fname = ff.replace(/'/g,'').split(',')[0].trim().replace(/ /g,'+');
    var linkId = 'gfont-' + fname;
    if (!document.getElementById(linkId)) {
      var lk = document.createElement('link');
      lk.id   = linkId;
      lk.rel  = 'stylesheet';
      lk.href = 'https://fonts.googleapis.com/css2?family=' + fname + ':wght@400;600&display=swap';
      document.head.appendChild(lk);
    }
  }
}


async function updateMenu() {
  const menu = document.getElementById('objectMenu');
  if (!menu) return;
  menu.innerHTML = '';

  if (!gruntinisVanduo) {
    const label = document.createElement('div');
    label.className   = 'menu-label';
    label.textContent = UI.get('menu.gvl_label','Gruntinio vandens lygis:');
    menu.appendChild(label);

    [['gvl-1', 'Aukštai'], ['gvl-2', 'Žemai'], ['gvl-3', 'Nėra']].forEach(([val, txt]) => {
      const btn     = document.createElement('button');
      btn.className = 'object-btn';
      btn.textContent = txt;
      btn.onclick   = () => {
        gruntinisVanduo = val;
        gruntasTipas    = null;
        try { localStorage.setItem('kon_gvl', val); } catch(e) {}
        document.body.classList.add('wave-calm');
        renderSistema();
        updateMenu();
        updateInfo();
        setTimeout(_K_addGvlToScene, 10);
      };
      menu.appendChild(btn);
    });
    return;
  }

  if (gruntinisVanduo && !gruntasTipas) {
    const label = document.createElement('div');
    label.className   = 'menu-label';
    label.textContent = UI.get('menu.soil_label','Grunto tipas:');
    menu.appendChild(label);

    [['smel', UI.get('menu.soil_sand','Smėlis / Žvyras / Priesmėlis')], ['mol', UI.get('menu.soil_clay','Molis / Priemolis')]].forEach(([val, txt]) => {
      const btn     = document.createElement('button');
      btn.className = 'object-btn';
      btn.textContent = txt;
      btn.onclick   = () => {
        gruntasTipas = val;
        document.body.classList.add('wave-calm');
        renderSistema();
        updateMenu();
        updateInfo();
      };
      menu.appendChild(btn);
    });
    return;
  }

  const rezultatas = await apiKlausimas('getGalimiObjektai', {
    sistema: sistema.map(o => o.tipas),
    gvl:     gruntinisVanduo,
    gruntas: gruntasTipas,
  });
  if (!rezultatas) return;

  if (rezultatas.galimi.length === 0) {
    menu.innerHTML = '<div style="padding:10px;color:#4a9d6f;font-weight:600;">Sistema užbaigta ✓</div>';
      return;
  }

  if (sistema.length === 0) {
    const depthLabel = document.createElement('div');
    depthLabel.className   = 'menu-label';
    depthLabel.textContent = UI.get('menu.depth_label', 'Pasirinkite išvado gylį:');
    menu.appendChild(depthLabel);
  }

  rezultatas.galimi.forEach(obj => {
    const btn     = document.createElement('button');
    btn.className = 'object-btn';
    btn.textContent = obj.aprasymas;
    btn.disabled  = processing;
    btn.onclick   = () => pridetiObjekta(obj.tipas);
    menu.appendChild(btn);
  });
}

async function pridetiObjekta(tipas) {
  if (processing) return;
  processing = true;
  document.querySelectorAll('.object-btn').forEach(b => b.disabled = true);

  const rezultatas = await apiKlausimas('pridetiObjekta', {
    sistema:          sistema.map(o => o.tipas),
    naujasTipas:      tipas,
    dabartinisSektorius,
  });

  if (!rezultatas?.objektas) {
    processing = false;
    document.querySelectorAll('.object-btn').forEach(b => b.disabled = false);
    return;
  }

  sistema.push(rezultatas.objektas);
  dabartinisSektorius = rezultatas.naujasSektorius;

  renderSistema();
  updateMenu();
  updateInfo();
  processing = false;
}

function atgal() {
  if (sistema.length === 0) return;
  sistema.pop();
  _K3dSel = null;
  if (sistema.length > 0) {
    const idx = ['A', 'B', 'C', 'D', 'E'].indexOf(sistema[sistema.length - 1].sektorius);
    dabartinisSektorius = idx < 4 ? ['A', 'B', 'C', 'D', 'E'][idx + 1] : 'E';
  } else {
    dabartinisSektorius = 'A';
  }
  renderSistema();
  updateMenu();
  updateInfo();
}

function resetSystem() {
  sistema           = [];
  dabartinisSektorius = 'A';
  gruntinisVanduo   = null;
  gruntasTipas      = null;
  if (typeof _updateSummaryBar === 'function') _updateSummaryBar(); 
  _K3dSel            = null;
  _KUserMovedCam     = false;
  _KOrbSave          = null;
  renderSistema();
  updateMenu();
  updateInfo();
}

function map3dReset() {
  // Reset kameros pozicija — veikia ir su _K3d (pradinė scena) ir su _3d (shared, po objekto paspaudimo)
  _KUserMovedCam = false;
  _KOrbSave      = null;
  _userMovedCam  = false;
  _orbSave       = null;

  if (_K3d && _K3d.DEF_ORB && _K3d.DEF_ORB.r) {
    const d = _K3d.DEF_ORB;
    _K3d.orb.r     = d.r;
    _K3d.orb.theta = d.theta;
    _K3d.orb.phi   = d.phi;
    _K3d.orb.target.set(d.tx, d.ty, 0);
    _K3d.applyOrbit();
  }

  if (_3d && _3d.DEF_ORB && _3d.DEF_ORB.r) {
    const d = _3d.DEF_ORB;
    _3d.orb.r     = d.r;
    _3d.orb.theta = d.theta;
    _3d.orb.phi   = d.phi;
    _3d.orb.target.set(d.tx, d.ty, 0);
    _3d.applyOrbit();
  }

  // Grizti i zingnini rezima ir pasalinti pasirinkima
  _viewMode    = 'expand';
  _openedComps = [];
  _selObj      = null;
  _selComp     = null;
  _3dSel       = null;
  _K3dSel      = null;
  if (typeof _hidePanel         === 'function') _hidePanel();
  if (typeof _renderModeButtons === 'function') _renderModeButtons();

  // Perpiesti scena - naudoti renderSistema kad kamera būtų tokia pat kaip "Iš naujo"
  if (typeof renderSistema === 'function') renderSistema();
}

function detectSystemType() {
  const current = sistema.map(o => o.tipas);

  const SYS_NAMES = [
    [1,  UI.get('sys.1',  'Įrenginys su infiltraciniu šuliniu')],
    [2,  UI.get('sys.2',  'Kiemas su dideliu šlaitu / nuokalne')],
    [3,  UI.get('sys.3',  'Įrenginys su drenažine siurbline + išleidimas ant žemės paviršiaus')],
    [4,  UI.get('sys.4',  'Įrenginys su drenažine siurbline + infiltracinis laukas')],
    [5,  UI.get('sys.5',  'Sistema su infiltraciniu žemės kauburiu')],
    [6,  UI.get('sys.6',  'Infiltracinis šulinys — pakėlimas iš gilaus į įprastą gylį')],
    [7,  UI.get('sys.7',  'Uždara nuotekų kaupimo talpykla (be valymo). Išsiurbiama')],
    [8,  UI.get('sys.8',  'Uždara talpykla — pakėlimas į įprastą gylį arba kitą sklypo vietą')],
    [9,  UI.get('sys.9',  'Nuotekų pakėlimas į kitą sklypo vietą (įrenginys aukščiau šaltinio)')],
    [10, UI.get('sys.10', 'Nuotekų pakėlimas į įprastą gylį + išleidimas ant žemės paviršiaus')],
    [11, UI.get('sys.11', 'Nuotekų pakėlimas į įprastą gylį + infiltracinis laukas')],
    [12, UI.get('sys.12', 'Nuotekų pakėlimas į įprastą gylį + infiltracinis žemės kauburys')],
  ];

  const rows = SYS_NAMES.map(function(item) {
    var sid = item[0], label = item[1];
    var t = TECH.sistemu_tipai.find(function(s){ return s.id === sid; });
    if (!t) return '';
    var matches = current.length > 0 && current.every(function(k,i){ return t.grandine[i] === k; });
    var bg = matches ? '#cacaca' : '#c8ffca';
    var border = matches ? '1px solid #c0d8c4' : '1px solid #eef3ef';
    var badge = matches ? '<span style="margin-left:auto;font-size:10px;color:#1e5c30;font-weight:700;flex-shrink:0">\u2713 pasirinkta</span>' : '';
    var html = '<div style="display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:8px;cursor:pointer;background:' + bg + ';border:' + border + ';margin-bottom:3px;" '
      + 'onclick="pasirinktiSistema(' + sid + ');closeModal();">'
      + '<div style="flex:1;min-width:0">'
      + '<div style="font-size:15px;font-weight:600;color:#1e3d2f;line-height:1.4">' + label + '</div>'
      + '</div>'
      + badge + '</div>';
    return html;
  }).join('');

  openModal(
    'Pasirinkiti sistemos tip\u0105',
    '<div style="display:flex;flex-direction:column;">' + rows + '</div>',
    null
  );
}

async function pasirinktiSistema(sysId) {
  const tipai = TECH.sistemu_tipai.find(t => t.id === sysId)?.grandine;
  if (!tipai) return;

  // Atstatyti kameros poziciją į pradinę (sistema pasikeitė)
  _KUserMovedCam = false;
  _KOrbSave      = null;
  _userMovedCam  = false;
  _orbSave       = null;
  _K3dSel        = null;
  _selObj        = null;
  _selComp       = null;

  // Rodyti overlay su IBNVS logotipu kol sistema kraunasi
  const area = document.getElementById('map-area');
  if (area) {
    const _old = document.getElementById('map-load-overlay');
    if (_old) _old.remove();
    const ov = document.createElement('div');
    ov.id = 'map-load-overlay';
    ov.style.cssText = 'position:absolute;inset:0;z-index:50;display:flex;flex-direction:column;align-items:center;justify-content:center;background:var(--bg,#f2f8f3);pointer-events:none;';
    ov.innerHTML =
      '<div style="font-family:inherit;font-size:28px;font-weight:800;letter-spacing:2px;color:var(--pri,#2e7d32);margin-bottom:16px">IBN<span style="color:var(--acc,#4a9d6f)">VS</span></div>' +
      '<div style="display:flex;gap:6px;margin-bottom:14px">' +
        '<div style="width:8px;height:8px;border-radius:50%;background:var(--pri,#2e7d32);animation:mloBounce 1.1s ease-in-out infinite;animation-delay:0s"></div>' +
        '<div style="width:8px;height:8px;border-radius:50%;background:var(--pri,#2e7d32);animation:mloBounce 1.1s ease-in-out infinite;animation-delay:0.18s"></div>' +
        '<div style="width:8px;height:8px;border-radius:50%;background:var(--pri,#2e7d32);animation:mloBounce 1.1s ease-in-out infinite;animation-delay:0.36s"></div>' +
      '</div>' +
      '<div style="font-size:11px;color:var(--td,#888);font-weight:500">Kraunama sistema\u2026</div>';
    if (!document.getElementById('mlo-style')) {
      const st = document.createElement('style'); st.id = 'mlo-style';
      st.textContent = '@keyframes mloBounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-10px)}}';
      document.head.appendChild(st);
    }
    area.appendChild(ov);
  }

  sistema = [];
  dabartinisSektorius = 'A';
  document.body.classList.add('wave-calm');

  for (const tipas of tipai) {
    const rez = await apiKlausimas('pridetiObjekta', {
      sistema: sistema.map(o => o.tipas),
      naujasTipas: tipas,
      dabartinisSektorius,
    });
    if (rez?.objektas) {
      sistema.push(rez.objektas);
      dabartinisSektorius = rez.naujasSektorius;
    }
  }

  renderSistema();
  updateMenu();
  updateInfo();

  // Paslėpti overlay po 5s (GLB modeliams pakrauti)
  setTimeout(() => {
    const o = document.getElementById('map-load-overlay');
    if (o) { o.style.transition = 'opacity 0.4s'; o.style.opacity = '0'; setTimeout(() => o.remove(), 400); }
  }, 5000);
}


// ============================================================
// KONSTRUKTORIAUS PERKROVOS (veikia po map3d-core.min.js)
// ============================================================

// ── PAGRINDINIS FIKSAS: _build3d monkey patch ──────────────────────────────
// Problema: _build3d viduje kamera skrenda, tada iškart vėl kviečiamas
// _build3d (naujas scenos rendereris naikina skrydžio animaciją).
// Sprendimas: po kiekvieno _build3d iškvietimo automatiškai skrandiname
// kamerą į pasirinkto objekto poziciją.
(function() {
  var _origBuild3d = _build3d;
  _build3d = function(canvas) {
    _origBuild3d(canvas);
    // Skraidinti kamerą į _selObj poziciją (veikia ir iš _K_build3d ir iš tool1)
    if (_selObj && typeof _camFlyTo === 'function' && _3d && _3d.orb && _3d.applyOrbit) {
      var _idx = typeof sistema !== 'undefined'
        ? sistema.findIndex(function(o){ return o.tipas === _selObj; }) : -1;
      var _cam = _idx >= 0
        ? _camClickCorrected(_selObj, _idx)
        : (KB.objects[_selObj] && KB.objects[_selObj].scene_3d && KB.objects[_selObj].scene_3d.cam_click);
      if (_cam) _camFlyTo(_cam, _3d.orb, _3d.applyOrbit);
    }
  };
})();

// ── mapSysClickObj — be papildomo camFlyTo (monkey patch jau rūpinasi) ────
mapSysClickObj = function(oid) {
  _selObj = oid; _selComp = null; _openedComps = []; _panelLevel = 'obj';
  var canvas = document.getElementById('map-canvas');
  var sysN   = parseInt((document.getElementById('map-sys') || {}).value || '0');
  if (canvas && sysN) _build3d(canvas); // monkey patch skraidina kamerą
  _renderPanel();
  _kpInjectNav();
};

// ── mapPanelClose — rodo sistemos sąrašą (ne tuščią panelį) ────────────────
mapPanelClose = function() {
  _selObj = null; _selComp = null; _openedComps = []; _3dSel = null;
  _K3dSel = null; _panelLevel = 'obj';
  var canvas = document.getElementById('map-canvas');
  var sysN   = parseInt((document.getElementById('map-sys') || {}).value || '0');
  // Konstruktoriuje: grįžti į apžvalgos sceną (_K_build3d), ne tool1
  if (canvas && typeof _K_build3d === 'function') {
    _K_build3d(canvas);
  } else if (canvas && sysN) {
    _build3d(canvas);
  }
  if (sysN && typeof _renderPanelSys === 'function') _renderPanelSys(sysN);
  else if (typeof _hidePanel === 'function') _hidePanel();
};

// ── mapPanelBack — DIDELIS mygtukas, tiesiai į objektą arba sistemą ────────
mapPanelBack = function() {
  if (_panelLevel === 'comp' && _selComp) {
    // Grįžti į objekto panelį (ne į tarpinį komponentą)
    _selComp = null; _panelLevel = 'obj'; _renderPanel();
    // Kamera atgal į objektą
    var _i = typeof sistema !== 'undefined' && _selObj
      ? sistema.findIndex(function(o){ return o.tipas === _selObj; }) : -1;
    var _c = _i >= 0 ? _camClickCorrected(_selObj, _i) :
      (_selObj && KB.objects[_selObj] && KB.objects[_selObj].scene_3d && KB.objects[_selObj].scene_3d.cam_click);
    if (_c && typeof _camFlyTo === 'function' && _3d && _3d.orb && _3d.applyOrbit)
      _camFlyTo(_c, _3d.orb, _3d.applyOrbit);
    _kpInjectNav();
    return;
  }
  // Objekto lygis → sistemos sąrašas
  mapPanelClose();
};

// ── Panel navigacijos CSS ───────────────────────────────────────────────────
(function() {
  if (document.getElementById('kp-nav-style')) return;
  var st = document.createElement('style');
  st.id = 'kp-nav-style';
  st.textContent = [
    '.kp-nav{display:flex;align-items:stretch;border-bottom:2px solid var(--pri,#2e7d32);background:var(--s1,#f8fcf8);flex-shrink:0;}',
    '.kp-back{flex:1;min-height:48px;padding:10px 14px;background:var(--s2,#eef7ef);border:none;',
    '  font-size:14px;font-weight:700;color:var(--pri,#2e7d32);cursor:pointer;',
    '  text-align:left;font-family:inherit;display:flex;align-items:center;gap:6px;',
    '  transition:background .1s;border-right:1px solid var(--b1,#d0e8d2);}',
    '.kp-back:hover,.kp-back:active{background:var(--s3,#d4ecd6);}',
    '.kp-back-arrow{font-size:20px;line-height:1;}',
    '.kp-close{width:48px;min-height:48px;background:none;border:none;',
    '  font-size:22px;color:var(--td,#888);cursor:pointer;font-family:inherit;}',
    '.kp-close:hover{color:var(--text);}',
    '#map-side-panel .msp-close { display:none !important; }',
  ].join('');
  document.head.appendChild(st);
})();

// ── _kpInjectNav — įterpia navigacijos juostą į panelį ────────────────────
function _kpInjectNav() {
  var panel = typeof _panelEl === 'function' ? _panelEl() : document.getElementById('map-side-panel');
  if (!panel || panel.style.display === 'none') return;
  var old = panel.querySelector('.kp-nav');
  if (old) old.remove();

  var sysN  = parseInt((document.getElementById('map-sys') || {}).value || '0');
  var nav   = document.createElement('div');
  nav.className = 'kp-nav';

  if (_panelLevel === 'comp' && _selComp) {
    var objName = _selObj ? ((KB.objects_meta[_selObj] || {}).name || _selObj) : 'Objektas';
    nav.innerHTML =
      '<button class="kp-back" onclick="mapPanelBack()">' +
        '<span class="kp-back-arrow">&#8592;</span>' + objName +
      '</button>' +
      '<button class="kp-close" onclick="mapPanelClose()">&#215;</button>';
  } else if (_panelLevel === 'obj' && _selObj) {
    var sysLabel = sysN ? 'Sistema ' + sysN : 'Atgal';
    nav.innerHTML =
      '<button class="kp-back" onclick="mapPanelClose()">' +
        '<span class="kp-back-arrow">&#8592;</span>' + sysLabel +
      '</button>' +
      '<button class="kp-close" onclick="mapPanelClose()">&#215;</button>';
  } else {
    return; // Sistemos lygis — nav nereikia
  }
  panel.insertBefore(nav, panel.firstChild);
}

// ── Prikabinti _kpInjectNav prie _renderPanel ──────────────────────────────
var _origRenderPanel = typeof _renderPanel === 'function' ? _renderPanel : null;
_renderPanel = function() {
  if (_origRenderPanel) _origRenderPanel();
  setTimeout(_kpInjectNav, 0);
};

function eksportuotiJPG() {
  const canvas = document.getElementById('map-canvas');
  if (!canvas) { alert('Pirmiausia sukurkite sistemą'); return; }

  // Rasti aktyvų bgRef ir nustatyti opacity 0.40 prieš snapshot
  const _bgRef3 = (_3d && _3d.bgRef) ? _3d.bgRef : (_K3d && _K3d.bgRef) ? _K3d.bgRef : null;
  const _bgM = _bgRef3 ? _bgRef3.getMesh() : null;
  const _prevOp = _bgM ? _bgM.material.opacity : null;
  if (_bgM) _bgM.material.opacity = 0.40;

  // Render į canvas (preserveDrawingBuffer:true garantuoja vaizdą)
  if (_3d && _3d.renderer) _3d.renderer.render(_3d.scene, _3d.camera);
  else if (_K3d && _K3d.renderer) _K3d.renderer.render(_K3d.scene, _K3d.camera);

  // Sukurti output su baltu fonu
  const out = document.createElement('canvas');
  out.width  = canvas.width  || 900;
  out.height = canvas.height || 500;
  const ctx = out.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, out.width, out.height);
  ctx.drawImage(canvas, 0, 0);

  // Grąžinti opacity
  if (_bgM && _prevOp !== null) _bgM.material.opacity = _prevOp;

  out.toBlob(function(blob) {
    if (!blob) { alert('Nepavyko sukurti nuotraukos.'); return; }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ibnvs-schema.jpg';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function() { URL.revokeObjectURL(url); }, 2000);
  }, 'image/jpeg', 0.92);
}
