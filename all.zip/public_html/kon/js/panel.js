const KON_API = './api.php';

const _NO_PRICE_OBJS = new Set(['ZEMPAV', 'SLAIT', 'NAM1', 'NAM2']);

let _lastShoppingTree   = null;
let _lastShoppingTotals = null;

let _panelObjId  = null;
let _panelCompId = null;
let _openedComps = []; 

const _KB = {}; 

function _panelEl() {
  return document.getElementById('kon-side-panel');
}

function panelShow() {
  const p = _panelEl();
  if (p) { p.style.display = 'flex'; p.classList.add('panel-visible'); }
}

function panelHide() {
  const p = _panelEl();
  if (p) { p.style.display = 'none'; p.classList.remove('panel-visible'); }
  _panelObjId  = null;
  _panelCompId = null;
  _openedComps = [];
}

async function panelObjClick(tipas) {
  if (_panelObjId === tipas) {
    
    panelHide();
    return;
  }
  _panelObjId  = tipas;
  _panelCompId = null;
  _openedComps = [];

  _renderPanelLoading(tipas);
  panelShow();

  
  if (!_KB[tipas]) {
    try {
      const res = await fetch(KON_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'getObjektasInfo', tipas })
      });
      _KB[tipas] = await res.json();
    } catch(e) {
      _renderPanelError(tipas);
      return;
    }
  }

  _renderPanelObj(tipas);
}

function _renderPanelLoading(tipas) {
  const p = _panelEl(); if (!p) return;
  p.innerHTML = `
    <div class="msp-head">
      <div class="msp-obj-name">${_objName(tipas) || tipas}</div>
      <button class="msp-close" onclick="panelHide()">&#215;</button>
    </div>
    <div class="msp-body" style="display:flex;align-items:center;justify-content:center;color:#aaa;font-size:13px">
      ⏳ Kraunama...
    </div>`;
}

function _renderPanelError(tipas) {
  const p = _panelEl(); if (!p) return;
  p.innerHTML = `
    <div class="msp-head">
      <div class="msp-obj-name">${_objName(tipas) || tipas}</div>
      <button class="msp-close" onclick="panelHide()">&#215;</button>
    </div>
    <div class="msp-body" style="padding:20px;color:#c0392b;font-size:12px">
      Klaida kraunant duomenis.
    </div>`;
}

function _renderPanelObj(tipas) {
  const p = _panelEl(); if (!p) return;
  const kb = _KB[tipas] || {};
  const baze = kb.baze || {};
  const komponentai = kb.komponentai || [];
  const aprasymas = kb.aprasymas || tipas;
  const infoTekstas = kb.infoTekstas || '';

  
  const objModels = baze.models || [];
  const modelsHtml = objModels.length
    ? `<div class="msp-section-title msp-mt">Modeliai</div>
       <div class="msp-models">` +
       objModels.map(m => `<div class="msp-model-row">
         <span class="msp-model-name">${m.name || m.id || '–'}</span>
         ${m.supplier ? `<span class="msp-supplier">${m.supplier}</span>` : ''}
         ${m.price_eur ? `<span class="msp-price">${m.price_eur} €</span>` : ''}
       </div>`).join('') +
       `</div>`
    : '';

  
  const kompsHtml = komponentai.length
    ? _renderCompList(komponentai, 0)
    : `<div class="msp-empty">Komponentų nėra</div>`;

  const descr = baze.function || infoTekstas || '';

  p.innerHTML = `
    <div class="msp-head">
      <div class="msp-obj-name">${aprasymas}</div>
      <button class="msp-close" onclick="panelHide()">&#215;</button>
    </div>
    <div class="msp-body">
      ${descr ? `<div class="msp-text msp-mb">${descr}</div>` : ''}
      <div class="msp-inline-btns">
        <!-- Kaip atrodo / Kaip montuoti: paslėpta — turinys dar nepridėtas (Fazė 3.4) -->
        <button class="msp-ibtn" onclick="panelBtnPirkti('${tipas}')">&#128222; Kur pirkti</button>
      </div>
      ${modelsHtml}
      <div class="msp-section-title msp-mt">Komponentai</div>
      <div class="msp-comp-list">${kompsHtml}</div>
      <div class="msp-divider msp-mt"></div>
      <button class="msp-action msp-action-buy" onclick="panelShoppingList('obj')">&#128722; Pirkimo sąrašas (šis objektas)</button>
      <button class="msp-action msp-action-buy" style="margin-top:4px" onclick="panelShoppingList('sys')">&#128722; Pirkimo sąrašas (visa sistema)</button>
    </div>`;
}

function _renderCompList(items, depth) {
  const dotCols = ['#1565c0', '#7b1fa2', '#1b5e20', '#4a148c'];
  return items.map(c => {
    const hasSub = c._children && c._children.length > 0;
    const isOpen = _openedComps.includes(c.id);
    const dot = `<span class="msp-dot" style="background:${dotCols[Math.min(depth, 3)]}"></span>`;
    const indent = depth > 0 ? `style="padding-left:${8 + depth * 14}px"` : '';
    const subHtml = isOpen
      ? `<div id="msp-sub-${c.id}">${_renderCompList(c._children || [], depth + 1)}</div>`
      : `<div id="msp-sub-${c.id}" style="display:none"></div>`;
    return `<div id="msp-row-${c.id}" class="msp-comp-row" ${indent} onclick="panelCompClick('${c.id}','${_panelObjId}')">
      ${dot}
      <span class="msp-comp-name">${c.name || c.id}</span>
      ${hasSub ? `<span class="msp-expand-btn" data-tog="${c.id}" onclick="event.stopPropagation();panelToggleSub('${c.id}')">
        ${isOpen ? '&#9662;' : '&#9658;'}</span>` : ''}
    </div>${subHtml}`;
  }).join('');
}

function panelCompClick(compId, oid) {
  _panelCompId = compId;

  
  const kb = _KB[oid] || {};
  const comp = _findComp(kb.komponentai || [], compId);
  if (!comp) return;

  const p = _panelEl(); if (!p) return;

  const pricing = comp.pricing || {};
  const models  = comp.models  || [];
  const sub      = comp._children || [];

  const priceHtml = (pricing.part_price || pricing.install_price)
    ? `<div class="msp-price-box">
        ${pricing.part_price    ? `<div class="msp-price-row"><span>Dalies kaina</span><b>${pricing.part_price} €</b></div>` : ''}
        ${pricing.install_price ? `<div class="msp-price-row"><span>Montavimas</span><b>${pricing.install_price} €</b></div>` : ''}
        ${pricing.quantity_per_system > 1 ? `<div class="msp-price-row"><span>Kiekis</span><b>${pricing.quantity_per_system} vnt.</b></div>` : ''}
        ${pricing.diy_possible === false
          ? `<div class="msp-diy-no">Reikia specialisto</div>`
          : `<div class="msp-diy-yes">Galima montuoti pačiam</div>`}
      </div>` : '';

  const modelsHtml = models.length
    ? `<div class="msp-section-title msp-mt">Modeliai / tiekėjai</div>
       <div class="msp-models">` +
       models.map(m => `<div class="msp-model-row">
         <span class="msp-model-name">${m.name || '–'}</span>
         ${m.supplier ? `<span class="msp-supplier">${m.supplier}</span>` : ''}
         ${m.price_eur ? `<span class="msp-price">${m.price_eur} €</span>` : ''}
       </div>`).join('') +
       `</div>` : '';

  const subHtml = sub.length
    ? `<div class="msp-section-title msp-mt">Sudedamosios dalys</div>
       <div class="msp-comp-list">` +
       sub.map(s => `<div class="msp-comp-row" onclick="panelCompClick('${s.id}','${oid}')">
         <span class="msp-dot msp-dot-l2"></span>
         <span class="msp-comp-name">${s.name || s.id}</span>
         <span class="msp-arrow-r">&#8250;</span>
       </div>`).join('') +
       `</div>` : '';

  const descr = comp.function || comp.description || '';

  p.innerHTML = `
    <div class="msp-head">
      <button class="msp-back" onclick="panelCompBack('${oid}')">&#8592; Atgal</button>
      <div class="msp-obj-name">${comp.name || comp.id}</div>
      <button class="msp-close" onclick="panelHide()">&#215;</button>
    </div>
    <div class="msp-body">
      ${descr ? `<div class="msp-text msp-mb">${descr}</div>` : ''}
      <div class="msp-inline-btns">
        <!-- Kaip atrodo / Kaip montuoti: paslėpta — turinys dar nepridėtas (Fazė 3.4) -->
      </div>
      ${priceHtml}${modelsHtml}${subHtml}
    </div>`;
}

function panelCompBack(oid) {
  _panelCompId = null;
  _renderPanelObj(oid);
}

function panelToggleSub(compId) {
  const isOpen = _openedComps.includes(compId);
  const subEl  = document.getElementById('msp-sub-' + compId);
  const btn    = document.querySelector(`[data-tog="${compId}"]`);

  if (isOpen) {
    _openedComps = _openedComps.filter(id => id !== compId);
    if (subEl) subEl.style.display = 'none';
    if (btn)   btn.innerHTML = '&#9658;';
  } else {
    _openedComps = [..._openedComps, compId];
    if (subEl) subEl.style.display = 'block';
    if (btn)   btn.innerHTML = '&#9662;';
  }
}

function _findComp(nodes, id) {
  for (const n of nodes) {
    if (n.id === id) return n;
    if (n._children) {
      const f = _findComp(n._children, id);
      if (f) return f;
    }
  }
  return null;
}

async function panelShoppingList(scope) {
  
  const sysObjIds = typeof sistema !== 'undefined'
    ? sistema.map(o => o.tipas)
    : (_panelObjId ? [_panelObjId] : []);

  const rootIds = scope === 'obj' && _panelObjId
    ? [_panelObjId]
    : sysObjIds.filter(id => !_NO_PRICE_OBJS.has(id));

  if (!rootIds.length) { alert('Nėra sistemos'); return; }

  
  for (const tipas of rootIds) {
    if (!_KB[tipas]) {
      try {
        const res = await fetch(KON_API, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'getObjektasInfo', tipas })
        });
        _KB[tipas] = await res.json();
      } catch(e) {}
    }
  }

  const tree = rootIds.map(tipas => {
    const kb = _KB[tipas] || {};
    const baze = kb.baze || {};
    const objModels = baze.models || [];
    const objPrice  = objModels[0]?.price_eur || 0;
    return {
      tipas,
      name:      kb.aprasymas || tipas,
      objModels,
      objPrice,
      children:  kb.komponentai || []
    };
  });

  _showShoppingModal(tree, scope);
}

function _showShoppingModal(tree, scope) {
  let totalObjs = 0, totalParts = 0, totalInstall = 0;

  tree.forEach(r => { totalObjs += r.objPrice || 0; });

  function sumTree(nodes) {
    nodes.forEach(n => {
      const p   = n.pricing || {};
      const qty = p.quantity_per_system || 1;
      const unit = (n.models && n.models[0]?.price_eur) || p.part_price || 0;
      totalParts   += unit * qty;
      totalInstall += (p.install_price || 0) * qty;
      sumTree(n._children || []);
    });
  }
  tree.forEach(r => sumTree(r.children));

  const grandTotal = totalObjs + totalParts + totalInstall;

  const listHtml = tree.map(r => {
    const objPriceStr = r.objPrice ? `<span class="sl-price">${r.objPrice} €</span>` : '';
    const objModelsHtml = r.objModels.length > 1
      ? `<div class="sl-models">${r.objModels.map(m =>
          `<span class="sl-model-tag">${m.name || '–'}${m.price_eur ? ' ' + m.price_eur + '€' : ''}</span>`
        ).join('')}</div>`
      : (r.objModels[0]?.name
          ? `<div class="sl-supplier">${r.objModels[0].name}${r.objModels[0].notes ? ' · ' + r.objModels[0].notes : ''}</div>`
          : '');

    return `<div class="sl-obj-block">
      <div class="sl-obj-head">
        <span class="sl-obj-title">${r.name}</span>
        ${objPriceStr}
      </div>
      ${objModelsHtml}
      ${r.children.length
        ? `<div class="sl-comps-label">Komponentai ir medžiagos:</div>${_renderTreeRows(r.children, 0)}`
        : ''}
    </div>`;
  }).join('');

  const totalHtml = `<div class="sl-total">
    ${totalObjs    ? `<span>Įrenginiai: <b>${totalObjs} €</b></span>` : ''}
    ${totalParts   ? `<span>Medžiagos/dalys: <b>${totalParts} €</b></span>` : ''}
    ${totalInstall ? `<span>Montavimas: <b>${totalInstall} €</b></span>` : ''}
    <span class="sl-grand">Viso: <b>~${grandTotal} €</b></span>
  </div>`;

  _lastShoppingTree   = tree;
  _lastShoppingTotals = { objs: totalObjs, parts: totalParts, install: totalInstall, grand: grandTotal, scope };

  konPopupShow(
    scope === 'obj' ? 'Pirkimo sąrašas' : 'Visos sistemos komponentai',
    `<div class="sl-wrap">${listHtml}</div>${totalHtml}
     <div style="margin-top:12px">
       <button class="popup-info-btn" style="flex:none;padding:10px 20px" onclick="panelDownloadInvoice()">&#8681; Atsisiųsti kainraštį</button>
     </div>`
  );
}

function _renderTreeRows(nodes, depth) {
  return nodes.map(n => {
    const p    = n.pricing || {};
    const qty  = p.quantity_per_system || 1;
    const unit = (n.models && n.models[0]?.price_eur) || p.part_price || 0;
    const total = unit * qty;
    const priceStr = total ? `<span class="sl-price">${total} €${qty > 1 ? ' ×' + qty : ''}</span>` : '';
    const diy = p.diy_possible === false ? `<span class="sl-spec">Specialistas</span>` : '';
    const modelsHtml = (n.models || []).length > 1
      ? `<div class="sl-models">${n.models.map(m =>
          `<span class="sl-model-tag">${m.name || '–'}${m.price_eur ? ' ' + m.price_eur + '€' : ''}${m.supplier ? ' · ' + m.supplier : ''}</span>`
        ).join('')}</div>`
      : (n.models && n.models[0]?.supplier
          ? `<div class="sl-supplier">${n.models[0].supplier}${n.models[0].name ? ' · ' + n.models[0].name : ''}</div>`
          : '');

    return `<div class="sl-row sl-depth-${Math.min(depth, 3)}">
      <div class="sl-row-main">
        <span class="sl-bullet">${depth === 0 ? '&#9679;' : '&#9675;'}</span>
        <span class="sl-name">${n.name || n.id}</span>
        ${priceStr}${diy}
      </div>
      ${modelsHtml}
      ${(n._children || []).length ? _renderTreeRows(n._children, depth + 1) : ''}
    </div>`;
  }).join('');
}

function panelDownloadInvoice() {
  const tree   = _lastShoppingTree;
  const totals = _lastShoppingTotals || {};
  if (!tree) return;

  const date = new Date().toLocaleDateString('lt-LT');
  const nr   = 'SAR-' + Date.now().toString().slice(-6);

  function buildRows(nodes, depth) {
    return nodes.map(n => {
      const p    = n.pricing || {};
      const qty  = p.quantity_per_system || 1;
      const unit = (n.models && n.models[0]?.price_eur) || p.part_price || 0;
      const total = unit * qty;
      const indent = depth > 0 ? `padding-left:${depth * 20}px;` : '';
      const supplierCell = (n.models || []).length > 1
        ? n.models.map(m => (m.name || '') + (m.supplier ? ' (' + m.supplier + ')' : '')).join('<br>')
        : (n.models && n.models[0])
          ? [n.models[0].name || '', n.models[0].supplier || ''].filter(Boolean).join(' · ')
          : '–';
      const rows = [`<tr>
        <td style="${indent}color:${depth === 0 ? '#1a1a1a' : '#333'};font-weight:${depth === 0 ? '600' : '400'}">${n.name || n.id}</td>
        <td style="text-align:center">${qty}</td>
        <td style="text-align:right">${unit ? unit + ' €' : '–'}</td>
        <td style="text-align:right;font-weight:600">${total ? total + ' €' : '–'}</td>
        <td style="font-size:10px;color:#555">${supplierCell}</td>
      </tr>`];
      if (p.install_price && p.install_price > 0) {
        rows.push(`<tr style="color:#666;font-size:11px">
          <td style="padding-left:${(depth + 1) * 20}px;font-style:italic">↳ Montavimas</td>
          <td style="text-align:center">${qty}</td>
          <td style="text-align:right">${p.install_price} €</td>
          <td style="text-align:right">${p.install_price * qty} €</td>
          <td></td>
        </tr>`);
      }
      if (n._children && n._children.length) rows.push(...buildRows(n._children, depth + 1));
      return rows.join('');
    }).join('');
  }

  const sectionsHtml = tree.map(r => {
    const objModelName  = r.objModels && r.objModels[0]?.name  || '';
    const objModelNotes = r.objModels && r.objModels[0]?.notes || '';
    const objSupplierCell = [objModelName, objModelNotes].filter(Boolean).join(' · ') || '–';
    const objRow = `<tr style="background:#f1f8e9">
      <td style="font-weight:700;color:#1b5e20">${r.name}</td>
      <td style="text-align:center">1</td>
      <td style="text-align:right">${r.objPrice ? r.objPrice + ' €' : '–'}</td>
      <td style="text-align:right;font-weight:700;color:#1b5e20">${r.objPrice ? r.objPrice + ' €' : '–'}</td>
      <td style="font-size:10px;color:#555">${objSupplierCell}</td>
    </tr>`;
    const compRows = r.children && r.children.length
      ? `<tr><td colspan="5" style="font-size:10px;color:#888;padding:4px 10px;background:#fafafa;font-style:italic">↳ Komponentai ir medžiagos:</td></tr>` + buildRows(r.children, 1)
      : '';
    return objRow + compRows;
  }).join(`<tr><td colspan="5" style="padding:6px 0;border:none"></td></tr>`);

  const html = `<!DOCTYPE html>
<html lang="lt"><head><meta charset="UTF-8">
<title>Kainraštis ${nr}</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:'Arial',sans-serif;font-size:12px;color:#1a1a1a;padding:32px}
  h1{font-size:20px;font-weight:700;margin-bottom:4px}
  .meta{color:#666;font-size:11px;margin-bottom:24px}
  table{width:100%;border-collapse:collapse;margin-top:16px}
  th{background:#2e7d32;color:#fff;padding:8px 10px;text-align:left;font-size:11px;font-weight:600}
  th:nth-child(2),th:nth-child(3),th:nth-child(4){text-align:center}
  td{padding:7px 10px;border-bottom:1px solid #e0e0e0;vertical-align:top}
  tr:hover td{background:#f9fbe7}
  .total-row td{border-top:2px solid #1b5e20;font-weight:700;font-size:13px;padding-top:10px}
  .footer{margin-top:24px;font-size:10px;color:#999;text-align:center}
  @media print{body{padding:16px}}
</style>
</head><body>
  <h1>Kainraštis</h1>
  <div class="meta">Nr: ${nr} &nbsp;|&nbsp; Data: ${date} &nbsp;|&nbsp; IBNVS sistema</div>
  <table>
    <thead><tr>
      <th>Įrenginys / Komponentas</th>
      <th style="width:60px">Kiekis</th>
      <th style="width:90px">Vnt. kaina</th>
      <th style="width:90px">Suma</th>
      <th style="width:150px">Modelis / Tiekėjas</th>
    </tr></thead>
    <tbody>${sectionsHtml}</tbody>
    <tfoot>
      <tr style="background:#f9f9f9;font-size:11px;color:#555">
        <td colspan="3" style="padding:6px 10px">Įrenginiai</td>
        <td style="text-align:right;padding:6px 10px">${totals.objs || 0} €</td><td></td>
      </tr>
      <tr style="background:#f9f9f9;font-size:11px;color:#555">
        <td colspan="3" style="padding:6px 10px">Medžiagos ir dalys</td>
        <td style="text-align:right;padding:6px 10px">${totals.parts || 0} €</td><td></td>
      </tr>
      <tr style="background:#f9f9f9;font-size:11px;color:#555">
        <td colspan="3" style="padding:6px 10px">Montavimo darbai</td>
        <td style="text-align:right;padding:6px 10px">${totals.install || 0} €</td><td></td>
      </tr>
      <tr class="total-row">
        <td colspan="3">VISO (apytiksliai)</td>
        <td style="color:#2e7d32;font-size:15px">${totals.grand || 0} €</td>
        <td style="font-size:10px;color:#888;font-weight:400">Kainos orientacinės</td>
      </tr>
    </tfoot>
  </table>
  <div class="footer">Šis dokumentas yra apytikslinis. Kainos gali skirtis priklausomai nuo tiekėjo ir montavimo sąlygų.</div>
</body></html>`;

  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const w    = window.open(url, '_blank', 'width=900,height=700');
  if (w) setTimeout(() => w.print(), 600);
}

function panelBtnAtrodo(id) {
  konPopupShow('Kaip atrodo',
    `<div style="text-align:center;padding:40px 20px;color:#aaa">
      <div style="font-size:52px;margin-bottom:12px">&#128444;</div>
      <div style="font-size:13px;font-weight:600;margin-bottom:6px">Foto / video</div>
      <div style="font-size:11px">Turinys bus pridėtas</div>
    </div>`);
}
function panelBtnMontuoti(id) {
  konPopupShow('Kaip montuoti',
    `<div style="text-align:center;padding:40px 20px;color:#aaa">
      <div style="font-size:52px;margin-bottom:12px">&#128295;</div>
      <div style="font-size:13px;font-weight:600;margin-bottom:6px">Montavimo instrukcija</div>
      <div style="font-size:11px">Tekstas ir video bus pridėtas</div>
    </div>`);
}
function panelBtnPirkti(id) {
  
  const kb   = _KB[_panelObjId] || {};
  const baze = kb.baze || {};
  const models = (baze.models || []).filter(m => m.supplier || m.price_eur);
  konPopupShow('Kur pirkti',
    models.length
      ? `<div style="padding:12px">${models.map(m =>
          `<div style="display:flex;align-items:center;gap:10px;padding:8px;border:1px solid #d4e8da;border-radius:8px;margin-bottom:6px">
            <div style="flex:1">
              <div style="font-weight:600;font-size:12px">${m.name || 'Modelis'}</div>
              ${m.supplier ? `<div style="font-size:11px;color:#888">${m.supplier}</div>` : ''}
            </div>
            ${m.price_eur ? `<div style="font-weight:700;color:#2e7d32">${m.price_eur} €</div>` : ''}
          </div>`
        ).join('')}</div>`
      : `<div style="text-align:center;padding:40px 20px;color:#aaa">
          <div style="font-size:52px;margin-bottom:12px">&#128222;</div>
          <div style="font-size:11px">Tiekėjų sąrašas bus pridėtas</div>
        </div>`
  );
}

function konPopupShow(title, bodyHtml) {
  
  if (typeof popupOpen === 'function') {
    
    popupOpen({ title, html: bodyHtml });
    return;
  }
  
  let overlay = document.getElementById('kon-modal-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'kon-modal-overlay';
    overlay.style.cssText = `
      display:none;position:fixed;inset:0;background:rgba(0,0,0,0.6);
      z-index:2000;align-items:center;justify-content:center;padding:16px;
      backdrop-filter:blur(4px);
    `;
    overlay.innerHTML = `
      <div id="kon-modal-box" style="
        background:#fff;border-radius:16px;width:min(720px,95vw);
        max-height:85vh;display:flex;flex-direction:column;
        box-shadow:0 28px 70px rgba(0,0,0,0.35);overflow:hidden;
      ">
        <div id="kon-modal-head" style="
          display:flex;align-items:center;padding:14px 18px;
          background:#1e3d2f;color:#fff;flex-shrink:0;gap:10px;
        ">
          <div id="kon-modal-title" style="flex:1;font-size:15px;font-weight:700"></div>
          <button onclick="document.getElementById('kon-modal-overlay').style.display='none'"
            style="background:rgba(255,255,255,0.15);border:none;color:#fff;
                   width:32px;height:32px;border-radius:8px;cursor:pointer;font-size:16px">&#215;</button>
        </div>
        <div id="kon-modal-body" style="overflow-y:auto;padding:16px;flex:1"></div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener('click', e => {
      if (e.target === overlay) overlay.style.display = 'none';
    });
  }
  document.getElementById('kon-modal-title').textContent = title;
  document.getElementById('kon-modal-body').innerHTML = bodyHtml;
  overlay.style.display = 'flex';
}

function _injectPanelCSS() {
  if (document.getElementById('kon-panel-style')) return;
  const s = document.createElement('style');
  s.id = 'kon-panel-style';
  s.textContent = `
    #kon-side-panel {
      font-family: 'Inter', Arial, sans-serif;
      font-size: 12px;
      color: #1e3d2f;
      display: none;
      flex-direction: column;
      overflow: hidden;
      height: 100%;
    }
    #kon-side-panel.panel-visible { display: flex; }
    .msp-head {
      padding: 12px 14px 10px;
      background: #eaf4ee;
      border-bottom: 2px solid #d4e8da;
      flex-shrink: 0;
      position: relative;
      padding-right: 36px;
    }
    .msp-back {
      background: none; border: none; color: #2e7d32;
      font-size: 11px; cursor: pointer; padding: 0;
      font-family: inherit; font-weight: 600;
      margin-bottom: 6px; display: flex; align-items: center; gap: 3px;
    }
    .msp-back:hover { text-decoration: underline; }
    .msp-obj-name {
      font-size: 13px; font-weight: 700; color: #1b5e20; line-height: 1.3;
    }
    .msp-close {
      position: absolute; top: 10px; right: 10px;
      background: none; border: none; font-size: 18px;
      color: #7aab8a; cursor: pointer; padding: 0 4px;
      border-radius: 6px; line-height: 1;
    }
    .msp-close:hover { background: #d4e8da; color: #1e3d2f; }
    .msp-body { flex: 1; overflow-y: auto; padding: 12px; }
    .msp-mb { margin-bottom: 10px; }
    .msp-mt { margin-top: 12px; }
    .msp-section-title {
      font-size: 10px; font-weight: 700; color: #7aab8a;
      text-transform: uppercase; letter-spacing: .5px; margin-bottom: 6px;
    }
    .msp-text { font-size: 11px; color: #2c4a38; line-height: 1.6; }
    .msp-empty { font-size: 11px; color: #aaa; font-style: italic; padding: 8px 0; }
    .msp-empty-sm { font-size: 11px; color: #aaa; font-style: italic; margin-bottom: 10px; }
    .msp-models { display: flex; flex-direction: column; gap: 3px; margin-bottom: 2px; }
    .msp-model-row {
      display: flex; align-items: center; gap: 6px;
      padding: 5px 8px; background: #f7fcf8;
      border: 1px solid #d4e8da; border-radius: 7px; font-size: 11px;
    }
    .msp-model-name { flex: 1; font-weight: 500; }
    .msp-supplier { font-size: 10px; color: #7aab8a; }
    .msp-price { font-weight: 700; color: #2e7d32; white-space: nowrap; }
    .msp-price-box {
      background: #f7fcf8; border: 1px solid #d4e8da;
      border-radius: 8px; padding: 8px 10px; margin: 8px 0;
    }
    .msp-price-row { display: flex; justify-content: space-between; font-size: 11px; padding: 2px 0; }
    .msp-price-row b { color: #2e7d32; }
    .msp-diy-yes { font-size: 10px; color: #2e7d32; margin-top: 4px; font-weight: 600; }
    .msp-diy-no  { font-size: 10px; color: #c0392b; margin-top: 4px; font-weight: 600; }
    .msp-dot {
      width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0;
    }
    .msp-dot-l2 { background: #7b1fa2; }
    .msp-comp-list { display: flex; flex-direction: column; gap: 2px; }
    .msp-comp-row {
      display: flex; align-items: center; gap: 7px;
      padding: 7px 8px; border-radius: 7px;
      cursor: pointer; transition: background .12s; font-size: 11px;
    }
    .msp-comp-row:hover { background: #eaf4ee; }
    .msp-comp-name { flex: 1; color: #1e3d2f; }
    .msp-expand-btn {
      color: #7aab8a; font-size: 11px; padding: 2px 5px; border-radius: 3px;
      background: none; border: none; cursor: pointer;
    }
    .msp-expand-btn:hover { background: #d4e8da; }
    .msp-arrow-r { color: #aaa; font-size: 14px; }
    .msp-divider { height: 1px; background: #d4e8da; margin: 6px 0; }
    .msp-inline-btns { display: flex; flex-direction: column; gap: 4px; margin: 10px 0; }
    .msp-ibtn {
      padding: 7px 10px; background: #f7fcf8;
      border: 1px solid #d4e8da; border-radius: 8px;
      font-size: 11px; font-weight: 600; color: #2e7d32;
      cursor: pointer; text-align: left; transition: all .12s;
      font-family: inherit;
    }
    .msp-ibtn:hover { background: #eaf4ee; border-color: #4a9d6f; }
    .msp-action {
      display: block; width: 100%; padding: 8px 10px;
      background: #f7fcf8; border: 1px solid #d4e8da;
      border-radius: 8px; font-size: 11px; font-weight: 600;
      color: #2e7d32; cursor: pointer; text-align: left;
      transition: all .12s; font-family: inherit; margin-top: 4px;
    }
    .msp-action:hover { background: #eaf4ee; border-color: #4a9d6f; }
    .msp-action-buy { color: #e65100; background: rgba(230,81,0,.05); border-color: rgba(230,81,0,.2); }
    .msp-action-buy:hover { background: rgba(230,81,0,.1); }
    /* Pirkimo sąrašas */
    .sl-wrap { max-height: 50vh; overflow-y: auto; }
    .sl-obj-block { margin-bottom: 16px; }
    .sl-obj-head { display: flex; align-items: center; justify-content: space-between; padding: 8px 0 4px; border-bottom: 2px solid #2e7d32; }
    .sl-obj-title { font-size: 13px; font-weight: 700; color: #1b5e20; }
    .sl-comps-label { font-size: 10px; color: #aaa; text-transform: uppercase; letter-spacing: .4px; margin: 8px 0 4px; padding-left: 4px; }
    .sl-row { padding: 4px 0; }
    .sl-depth-0 { padding-left: 0; }
    .sl-depth-1 { padding-left: 16px; }
    .sl-depth-2 { padding-left: 30px; }
    .sl-depth-3 { padding-left: 44px; }
    .sl-row-main { display: flex; align-items: center; gap: 7px; padding: 4px 6px; border-radius: 6px; }
    .sl-row-main:hover { background: #f7fcf8; }
    .sl-bullet { font-size: 8px; color: #ccc; flex-shrink: 0; }
    .sl-depth-0 .sl-bullet { color: #2e7d32; font-size: 9px; }
    .sl-name { flex: 1; font-size: 12px; color: #1e3d2f; }
    .sl-depth-0 .sl-name { font-weight: 600; }
    .sl-price { font-size: 11px; font-weight: 700; color: #2e7d32; white-space: nowrap; }
    .sl-spec { font-size: 10px; color: #e65100; background: rgba(230,81,0,.08); border-radius: 10px; padding: 1px 6px; white-space: nowrap; }
    .sl-supplier { font-size: 10px; color: #aaa; padding-left: 24px; margin-top: -2px; }
    .sl-models { padding-left: 24px; margin-top: 2px; display: flex; flex-wrap: wrap; gap: 3px; }
    .sl-model-tag { font-size: 10px; color: #7aab8a; background: #f7fcf8; border: 1px solid #d4e8da; border-radius: 10px; padding: 1px 7px; }
    .sl-total { display: flex; gap: 12px; padding: 10px 0 4px; border-top: 2px solid #d4e8da; margin-top: 8px; flex-wrap: wrap; align-items: center; }
    .sl-total span { font-size: 12px; color: #1e3d2f; }
    .sl-total b { color: #2e7d32; }
    .sl-grand { font-size: 13px !important; font-weight: 700; color: #1b5e20 !important; margin-left: auto; background: #eaf4ee; padding: 4px 12px; border-radius: 8px; border: 1px solid #d4e8da; }
  `;
  document.head.appendChild(s);
}

_injectPanelCSS();

function _objName(tipas) {
  return UI.get('objects.' + tipas + '.name', tipas);
}
