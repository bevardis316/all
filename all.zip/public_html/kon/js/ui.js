function toast(msg) {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    t.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#1e3d2f;color:#fff;padding:9px 18px;border-radius:8px;font-size:12px;font-weight:600;z-index:9999;opacity:0;transition:opacity .2s;pointer-events:none;';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.style.opacity = '1';
  clearTimeout(t._tid);
  t._tid = setTimeout(() => { t.style.opacity = '0'; }, 2400);
}

let _mok = null;

function openModal(title, html, onOk) {
  let modal = document.getElementById('modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'modal';
    modal.style.cssText = 'display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9000;align-items:center;justify-content:center;';
    modal.innerHTML =
      '<div id="modal-box" style="background:#fff;border-radius:14px;padding:24px;max-width:640px;width:90%;max-height:80vh;display:flex;flex-direction:column;gap:12px;box-shadow:0 8px 40px rgba(0,0,0,.18);">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;">' +
          '<h2 id="modal-t" style="font-size:15px;font-weight:700;color:#1e3d2f;margin:0;"></h2>' +
          '<button onclick="closeModal()" style="background:none;border:none;font-size:20px;cursor:pointer;color:#7a9e84;line-height:1;">✕</button>' +
        '</div>' +
        '<div id="modal-b" style="overflow-y:auto;flex:1;font-size:13px;"></div>' +
        '<div style="display:flex;gap:8px;justify-content:flex-end;">' +
          '<button class="btn pri" id="modal-ok" onclick="modalOk()" style="display:none;">OK</button>' +
          '<button class="btn ghost" onclick="closeModal()">Uždaryti</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(modal);
    modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
  }
  document.getElementById('modal-t').textContent = title;
  document.getElementById('modal-b').innerHTML = html;
  const okBtn = document.getElementById('modal-ok');
  if (onOk) { okBtn.style.display = ''; _mok = onOk; }
  else { okBtn.style.display = 'none'; _mok = null; }
  modal.style.display = 'flex';
}

function modalOk()    { if (typeof _mok === 'function') _mok(); closeModal(); }
function closeModal() {
  const m = document.getElementById('modal');
  if (m) m.style.display = 'none';
  
  const sb = document.querySelector('#modal-box > div:last-child');
  if (sb) sb.style.display = '';
  _mok = null;
}

function markDirty(key) {
  
}
