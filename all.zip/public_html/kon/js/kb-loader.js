async function loadCompScene3d() {
  try {
    const r = await fetch('/api/v1/comp_scene3d');
    if (!r.ok) return;
    const d = await r.json();
    if (!d.ok || !d.scene3d) return;
    // Pridėti scene_3d į KB.components
    for (const [cid, s3d] of Object.entries(d.scene3d)) {
      if (KB.components[cid]) {
        KB.components[cid].scene_3d = s3d;
      }
    }
  } catch(e) {
    console.warn('scene3d load klaida:', e);
  }
}

async function loadKB() {
  try {
    const r = await fetch('/api/v1/kb', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'load_all' })
    });
    if (!r.ok) return;
    const resp = await r.json();
    if (!resp.ok || !resp.kb) return;
    const d = resp.kb;

    
    if (d.objects_meta) {
      for (const [oid, meta] of Object.entries(d.objects_meta)) {
        KB.objects_meta[oid] = meta;
      }
    }

    
    if (d.objects) {
      for (const [oid, obj] of Object.entries(d.objects)) {
        if (!KB.objects[oid]) KB.objects[oid] = { failure_modes: {} };
        const kb = KB.objects[oid];
        // API gali grąžinti plokščią formatą ARBA įdėtą { base:{}, env:{}, ... }
        const base = obj.base || obj;
        const env  = obj.env  || obj.env_behavior || null;
        kb.name               = base.name || oid;
        kb.function           = base.function || '';
        kb.normal_operation   = base.normal_operation || '';
        kb.normal_signs       = base.normal_signs || [];
        kb.tags               = base.tags || [];
        kb.models             = base.models || [];
        kb.packages           = base.packages || [];
        kb.maintenance_schedule = base.maintenance_schedule || {};
        if (base.scene_3d)           kb.scene_3d            = base.scene_3d;
        if (env)                     kb.env_behavior        = env;
        if (obj.relations)           kb.relations           = obj.relations;
        if (obj.exploitation_errors) kb.exploitation_errors = obj.exploitation_errors;
        if (obj.failure_modes) {
          for (const [fid, fm] of Object.entries(obj.failure_modes)) {
            kb.failure_modes[fid] = fm;
          }
        }
      }
    }

    
    if (d.components) {
      for (const [cid, comp] of Object.entries(d.components)) {
        KB.components[cid] = comp;
      }
    }
    if (d.components_meta) {
      for (const [cid, meta] of Object.entries(d.components_meta)) {
        KB.components_meta[cid] = meta;
      }
    }

  } catch (e) {
    console.warn('KB load klaida:', e);
  }
}
