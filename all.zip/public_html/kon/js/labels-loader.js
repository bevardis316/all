// UI Labels loader - užkrauna ui_labels.json vieną kartą
// Visi kon/ JS failai naudoja window.UI.get(key, fallback)

window.UI = (function() {
  var _labels = null;
  var _ready   = false;
  var _queue   = [];

  function get(path, fallback) {
    if (!_labels) return fallback !== undefined ? fallback : path;
    var parts = path.split('.');
    var val   = _labels;
    for (var i = 0; i < parts.length; i++) {
      if (val && typeof val === 'object' && parts[i] in val) {
        val = val[parts[i]];
      } else {
        return fallback !== undefined ? fallback : path;
      }
    }
    return (typeof val === 'string') ? val : (fallback !== undefined ? fallback : path);
  }

  function onReady(fn) {
    if (_ready) { fn(); } else { _queue.push(fn); }
  }

  function load() {
    // Cache bust: naudoti localStorage versiją kad išvengti PHP/CDN kešo
    var _ver = '';
    try { _ver = localStorage.getItem('ui_labels_ver') || ''; } catch(e) {}
    fetch('/api/v1/labels?v=' + Date.now() + '&lv=' + _ver, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' },
      body: JSON.stringify({})
    })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d && d.ok && d.labels) {
        _labels = d.labels;
        // Išsaugoti versiją localStorage kad žinotume ar pasikeitė
        try {
          var newVer = String(d.labels.version || '');
          localStorage.setItem('ui_labels_ver', newVer);
        } catch(e) {}
      }
    })
    .catch(function(e) {
      console.warn('UI labels nepavyko užkrauti:', e);
    })
    .finally(function() {
      _ready = true;
      _queue.forEach(function(fn) { try { fn(); } catch(e) {} });
      _queue = [];
    });
  }

  load();

  return { get: get, onReady: onReady };
})();
