// Touch gestai 3D scenai
(function() {
  'use strict';

  var _t1 = null, _t2 = null;
  var _dist0 = 0, _r0 = 0;
  var _canvas = null;

  function _pos(e) {
    var r = _canvas.getBoundingClientRect();
    return Array.from(e.touches).map(function(t) {
      return { x: t.clientX - r.left, y: t.clientY - r.top };
    });
  }

  function _dist(a, b) {
    var dx = b.x - a.x, dy = b.y - a.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  function onTouchStart(e) {
    // Jei liečiama objekto sritis - leisti click veikti
    // Bet pirmiausia išsaugoti pradinę poziciją judėjimo aptikimui
    var pts = _pos(e);
    _t1 = pts[0];
    _t2 = e.touches.length >= 2 ? pts[1] : null;
    _dist0 = _t2 ? _dist(_t1, _t2) : 0;
    if (_t2 && typeof _3d !== 'undefined' && _3d && _3d.orb) {
      _r0 = _3d.orb.r;
    }
    // Neblokuojam default - leidžiame click veikti
  }

  function onTouchMove(e) {
    e.preventDefault(); // Čia blokuojame - judėjimas
    var pts = _pos(e);
    if (typeof _3d === 'undefined' || !_3d || !_3d.orb || !_3d.applyOrbit) return;
    var orb = _3d.orb;
    var apply = _3d.applyOrbit;

    if (e.touches.length === 1 && _t1) {
      var dx = pts[0].x - _t1.x;
      var dy = pts[0].y - _t1.y;
      // Jei judėjimas mažas - tai click, ne drag
      if (Math.abs(dx) < 3 && Math.abs(dy) < 3) return;
      orb.theta -= dx * 0.01;
      orb.phi = Math.max(0.05, Math.min(Math.PI - 0.05, orb.phi + dy * 0.01));
      _t1 = pts[0];
      if (typeof _userMovedCam !== 'undefined') _userMovedCam = true;
      apply();
    } else if (e.touches.length >= 2 && _dist0 > 0) {
      var d = _dist(pts[0], pts[1]);
      orb.r = Math.max(4, Math.min(80, _r0 * (_dist0 / Math.max(d, 1))));
      if (typeof _userMovedCam !== 'undefined') _userMovedCam = true;
      apply();
    }
  }

  function onTouchEnd(e) {
    if (e.touches.length === 0) { _t1 = null; _t2 = null; }
    else if (e.touches.length === 1) { _t2 = null; }
  }

  function attach(canvas) {
    if (!canvas) return;
    _canvas = canvas;
    // Visada šalinti senus ir pridėti naujus
    canvas.removeEventListener('touchstart', onTouchStart);
    canvas.removeEventListener('touchmove', onTouchMove);
    canvas.removeEventListener('touchend', onTouchEnd);
    canvas.style.touchAction = 'pan-y'; // pan-y leidžia scroll bet blokuoja x
    canvas.addEventListener('touchstart', onTouchStart, { passive: true });
    canvas.addEventListener('touchmove',  onTouchMove,  { passive: false });
    canvas.addEventListener('touchend',   onTouchEnd,   { passive: true });
  }

  // Patchinti _build3d kad po kiekvieno iškvietimo pridėtų touch
  function patchBuild3d() {
    if (typeof _build3d === 'undefined') return false;
    if (_build3d._touchPatched) return true;
    var orig = _build3d;
    window._build3d = function(canvas) {
      orig(canvas);
      // Po _build3d - pridėti touch
      setTimeout(function() { attach(canvas); }, 50);
    };
    window._build3d._touchPatched = true;
    // Taip pat patchinti _buildEmpty
    if (typeof _buildEmpty !== 'undefined' && !_buildEmpty._touchPatched) {
      var origEmpty = _buildEmpty;
      window._buildEmpty = function(canvas) {
        origEmpty(canvas);
        setTimeout(function() { attach(canvas); }, 50);
      };
      window._buildEmpty._touchPatched = true;
    }
    return true;
  }

  function init() {
    var canvas = document.getElementById('map-canvas');
    if (canvas) attach(canvas);

    // Bandyti patchinti kol _build3d bus prieinamas
    var tries = 0;
    var iv = setInterval(function() {
      if (patchBuild3d()) {
        clearInterval(iv);
        var canvas = document.getElementById('map-canvas');
        if (canvas) attach(canvas);
      }
      if (++tries > 20) clearInterval(iv);
    }, 250);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
