<?php
require_once dirname(__DIR__, 2) . '/private/bootstrap.php';
require_once dirname(__DIR__, 2) . '/public_html/shared/php/helpers.php';

apiHeaders();
requirePost();

$raw  = file_get_contents('php://input');
$body = json_decode($raw, true) ?? [];
$action = $body['action'] ?? '';

function mapEnsureDir() {
    $dir = MAP_DATA_DIR;
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $ha = $dir . '.htaccess';
    if (!file_exists($ha)) file_put_contents($ha, "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
}

function mapLoadAll(): array {
    mapEnsureDir();
    $f = MAP_DATA_DIR . 'entries.json';
    if (!file_exists($f)) return [];
    return json_decode(file_get_contents($f), true) ?: [];
}

function mapSaveAll(array $entries): void {
    mapEnsureDir();
    file_put_contents(MAP_DATA_DIR . 'entries.json', json_encode($entries, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
}

function mapLoadPending(): array {
    mapEnsureDir();
    $f = MAP_DATA_DIR . 'pending.json';
    if (!file_exists($f)) return [];
    return json_decode(file_get_contents($f), true) ?: [];
}

function mapSavePending(array $pending): void {
    mapEnsureDir();
    file_put_contents(MAP_DATA_DIR . 'pending.json', json_encode($pending, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
}

function safeStr(?string $s, int $max): string {
    $s = trim(strip_tags($s ?? ''));
    return mb_substr($s, 0, $max);
}

function geocodeCity(string $city): ?array {
    $url = 'https://nominatim.openstreetmap.org/search?q=' . urlencode($city . ', Lietuva') .
           '&format=json&limit=1&countrycodes=lt';
    $ctx = stream_context_create(['http'=>['timeout'=>5,'header'=>'User-Agent: manonuotekos.lt/1.0']]);
    $raw = @file_get_contents($url, false, $ctx);
    if (!$raw) return null;
    $d = json_decode($raw, true);
    if (!empty($d[0]['lat'])) return ['lat'=>(float)$d[0]['lat'], 'lng'=>(float)$d[0]['lon']];
    return null;
}

if ($action === 'list') {
    $entries = mapLoadAll();
    $now = time();
    $active = array_values(array_filter($entries, function($e) use ($now) {
        if (!($e['approved'] ?? false)) return false;
        if (!empty($e['expires_at']) && $e['expires_at'] < $now) return false;
        return true;
    }));
    $public = array_map(fn($e) => [
        'id'   => $e['id'],
        'name' => $e['name'],
        'city' => $e['city'],
        'type' => $e['type'],
        'info' => $e['info'],
        'tel'  => $e['tel'],
        'lat'  => $e['lat'],
        'lng'  => $e['lng'],
    ], $active);
    echo json_encode(['ok'=>true,'entries'=>$public], JSON_UNESCAPED_UNICODE); exit;
}

if ($action === 'register') {
    $ip  = $_SERVER['REMOTE_ADDR'] ?? 'x';
    $rlf = sys_get_temp_dir() . '/map_reg_rl_' . md5($ip) . '.json';
    $now = time();
    $rl  = ['hits'=>[]];
    if (file_exists($rlf)) $rl = json_decode(file_get_contents($rlf), true) ?: $rl;
    $rl['hits'] = array_values(array_filter($rl['hits'], fn($t) => $t > $now - 3600));
    if (count($rl['hits']) >= 3) {
        http_response_code(429);
        echo json_encode(['ok'=>false,'error'=>'Per daug paraiškų. Bandykite vėliau.']); exit;
    }
    $rl['hits'][] = $now;
    file_put_contents($rlf, json_encode($rl), LOCK_EX);

    $name = safeStr($body['name'] ?? '', 80);
    $tel  = safeStr($body['tel']  ?? '', 20);
    $city = safeStr($body['city'] ?? '', 60);
    $type  = safeStr($body['type']  ?? '', 30);
    $rawTypes = $body['types'] ?? [];
    $types = is_array($rawTypes) ? array_values(array_filter(array_map(fn($t)=>safeStr($t,30), $rawTypes))) : ($type ? [$type] : []);
    $info = safeStr($body['info'] ?? '', 300);

    if (!$name || !$tel || !$city) {
        echo json_encode(['ok'=>false,'error'=>'Trūksta privalomų laukų']); exit;
    }

    $tel = preg_replace('/[^+\d\s\-()]/', '', $tel);

    $entry = [
        'id'         => uniqid('m_', true),
        'name'       => $name,
        'tel'        => $tel,
        'city'       => $city,
        'type'       => $types[0] ?? '',
        'types'      => $types,
        'info'       => $info,
        'ip'         => md5($ip),
        'created_at' => date('c'),
        'approved'   => false,
        'lat'        => null,
        'lng'        => null,
        'expires_at' => null,
        'value_eur'  => 0,
    ];

    // Geocoding pagal miestą
    $coords = geocodeCity($city);
    if ($coords) {
        $entry['lat'] = $coords['lat'];
        $entry['lng'] = $coords['lng'];
    }

    $pending = mapLoadPending();
    $pending[] = $entry;
    mapSavePending($pending);

    echo json_encode(['ok'=>true]); exit;
}

http_response_code(400);
echo json_encode(['ok'=>false,'error'=>'Nežinomas veiksmas']); exit;
