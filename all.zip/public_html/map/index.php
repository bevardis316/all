<?php
require_once dirname(__DIR__, 2) . '/private/auth_check.php';
require_once dirname(__DIR__, 2) . '/private/bootstrap.php';
?>
<!DOCTYPE html>
<html lang="lt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Montavimo specialistai | manonuotekos.lt</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.3/MarkerCluster.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.3/MarkerCluster.Default.css">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body { height:100%; font-family:Arial,sans-serif; font-size:13px; color:#333; overflow:hidden; }

/* ── Layout ── */
#layout { display:flex; height:100vh; }

/* ── Kairė juosta ── */
#sidebar {
  width:380px; flex-shrink:0;
  display:flex; flex-direction:column;
  background:#fff;
  box-shadow:2px 0 8px rgba(0,0,0,.15);
  z-index:10;
  height:100vh;
  overflow:hidden;
}

/* Viršus su logotipu */
#sb-header {
  background:#1b5e20; color:#fff;
  padding:14px 16px 12px;
  flex-shrink:0;
}
#sb-logo { font-size:14px; font-weight:700; margin-bottom:10px; }

/* Paieška */
#sb-search-wrap {
  display:flex; gap:6px; margin-bottom:8px;
}
#sb-search {
  flex:1; padding:8px 12px;
  border:1.5px solid rgba(255,255,255,.4);
  border-radius:8px;
  background:rgba(255,255,255,.15);
  color:#fff; font-size:13px; font-family:Arial,sans-serif;
}
#sb-search::placeholder { color:rgba(255,255,255,.6); }
#sb-search:focus { outline:none; border-color:#fff; background:rgba(255,255,255,.25); }
#sb-search-btn {
  padding:8px 14px; background:#fff; color:#1b5e20;
  border:none; border-radius:8px;
  font-size:12px; font-weight:700; cursor:pointer;
  white-space:nowrap; transition:background .12s;
}
#sb-search-btn:hover { background:#f0fdf4; }
#sb-search-btn:disabled { opacity:.6; cursor:not-allowed; }

/* Spindulys */
#sb-radius { display:flex; align-items:center; gap:8px; }
#sb-radius-lbl { font-size:11px; color:rgba(255,255,255,.8); white-space:nowrap; min-width:90px; }
#sb-radius-lbl b { color:#fff; }
#radiusSlider { flex:1; accent-color:#fff; height:3px; cursor:pointer; }
#sb-clear-btn {
  background:none; border:none; color:rgba(255,255,255,.7);
  cursor:pointer; font-size:18px; line-height:1; padding:0; flex-shrink:0;
  display:none;
}
#sb-clear-btn:hover { color:#fff; }

/* Filtras ir skaičius */
#sb-filter-bar {
  display:flex; align-items:center; gap:8px;
  padding:10px 14px 8px;
  border-bottom:1px solid #e8f5e9;
  flex-shrink:0;
}
#typeFilter {
  flex:1; padding:6px 10px;
  border:1.5px solid #c8e6c9; border-radius:8px;
  background:#f9fbe7; color:#1b5e20;
  font-size:12px; font-family:Arial,sans-serif; cursor:pointer;
  width:100%;
}
#typeFilter-wrap {
  flex:1; border-radius:8px;
  animation: pulse-wrap 2s ease-in-out infinite;
}
#typeFilter-wrap.selected {
  animation: none;
}
@keyframes pulse-wrap {
  0%, 100% { box-shadow: 0 0 0 0px rgba(27,94,32,0); }
  50%       { box-shadow: 0 0 0 5px rgba(27,94,32,.3); }
}
#list-count-lbl { font-size:11px; color:#888; white-space:nowrap; }

/* Sąrašas */
#sb-list {
  flex:1; overflow-y:auto;
  padding:8px 0;
}
#sb-list::-webkit-scrollbar { width:4px; }
#sb-list::-webkit-scrollbar-thumb { background:#c8e6c9; border-radius:2px; }

.entry-card {
  padding:12px 16px;
  border-bottom:1px solid #f1f8e9;
  cursor:pointer;
  transition:background .1s;
}
.entry-card:hover { background:#f9fbe7; }
.entry-card.active { background:#e8f5e9; border-left:3px solid #1b5e20; }
.ec-name { font-size:13px; font-weight:700; color:#1a1a1a; margin-bottom:4px; }
.ec-meta { display:flex; align-items:center; gap:6px; margin-bottom:5px; flex-wrap:wrap; }
.ec-badge {
  font-size:10px; font-weight:600;
  padding:2px 8px; border-radius:20px;
}
.ec-city { font-size:11px; color:#666; }
.ec-dist { font-size:10px; font-weight:700; color:#1b5e20; background:#e8f5e9; padding:2px 7px; border-radius:20px; }
.ec-info { font-size:11px; color:#555; line-height:1.4; margin-bottom:6px;
  overflow:hidden; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; }
.ec-tel {
  display:inline-flex; align-items:center; gap:4px;
  font-size:12px; font-weight:700; color:#1b5e20;
  text-decoration:none; padding:4px 10px;
  background:#f1f8e9; border:1px solid #c8e6c9; border-radius:20px;
  transition:all .12s;
}
.ec-tel:hover { background:#1b5e20; color:#fff; }

.empty-state { text-align:center; padding:40px 20px; color:#999; }
.empty-icon { font-size:32px; margin-bottom:8px; }
.empty-txt { font-size:12px; line-height:1.5; }

/* Registracijos mygtukas apačioje */
#sb-reg-btn {
  flex-shrink:0; padding:12px 16px;
  border-top:1px solid #e8f5e9;
  background:#fff;
}
#sb-reg-btn button {
  width:100%; padding:10px;
  background:#1b5e20; color:#fff;
  border:none; border-radius:8px;
  font-size:13px; font-weight:700; cursor:pointer;
  font-family:Arial,sans-serif; transition:background .12s;
}
#sb-reg-btn button:hover { background:#2e7d32; }

/* ── Žemėlapis ── */
#map { flex:1; }

/* Taškai žemėlapyje */
.map-pin {
  width:16px; height:16px;
  background:#e53935; border:2.5px solid #fff;
  border-radius:50%;
  box-shadow:0 1px 4px rgba(0,0,0,.4);
  cursor:pointer;
  transition:transform .1s;
}
.map-pin:hover { transform:scale(1.3); }
.map-pin.blue   { background:#1565c0; }
.map-pin.orange { background:#e65100; }
.map-pin.purple { background:#6a1b9a; }
.map-pin.green  { background:#33691e; }
.map-pin.grey   { background:#757575; }

/* Cluster */
.cluster-icon {
  width:100%; height:100%;
  background:#1b5e20; color:#fff;
  border:3px solid #fff;
  border-radius:50%;
  display:flex; align-items:center; justify-content:center;
  font-size:13px; font-weight:700;
  box-shadow:0 2px 6px rgba(0,0,0,.35);
  cursor:pointer;
}

/* Popup */
.popup-body { min-width:180px; max-width:240px; }
.popup-name { font-size:14px; font-weight:700; color:#1a1a1a; margin-bottom:5px; }
.popup-type { display:inline-block; padding:2px 8px; border-radius:20px; font-size:10px; font-weight:600; margin-bottom:6px; }
.popup-city { font-size:11px; color:#666; margin-bottom:3px; }
.popup-info { font-size:11px; color:#444; line-height:1.4; margin-bottom:8px; }
.popup-tel { display:flex; align-items:center; gap:5px; font-size:13px; font-weight:700; color:#1b5e20; text-decoration:none; }
.popup-tel:hover { text-decoration:underline; }

/* ── Registracijos panel (slide-in) ── */
#reg-panel {
  position:fixed; top:0; right:0; width:400px; max-width:100vw;
  height:100vh; background:#fff;
  box-shadow:-4px 0 20px rgba(0,0,0,.15);
  z-index:1000; overflow-y:auto;
  transform:translateX(100%);
  transition:transform .25s ease;
}
#reg-panel.open { transform:translateX(0); }
#reg-hdr {
  display:flex; align-items:flex-start; justify-content:space-between;
  padding:16px; border-bottom:1px solid #e8f5e9;
  background:#f9fbe7; position:sticky; top:0; z-index:1;
}
#reg-hdr h2 { font-size:15px; color:#1b5e20; margin-bottom:2px; }
#reg-hdr p  { font-size:11px; color:#888; }
#reg-close  { background:none; border:none; font-size:20px; cursor:pointer; color:#999; }
#reg-close:hover { color:#333; }
#reg-body { padding:16px; }
.form-group { margin-bottom:14px; }
.form-group label { display:block; font-size:11px; font-weight:700; color:#666; margin-bottom:5px; text-transform:uppercase; letter-spacing:.03em; }
.form-group input, .form-group select, .form-group textarea {
  width:100%; padding:9px 12px;
  border:1.5px solid #ddd; border-radius:8px;
  font-size:13px; font-family:Arial,sans-serif; color:#333;
  transition:border-color .12s;
}
.form-group input:focus, .form-group select:focus, .form-group textarea:focus {
  outline:none; border-color:#1b5e20;
}
.form-group textarea { resize:vertical; min-height:80px; line-height:1.5; }
.char-count { font-size:10px; color:#999; text-align:right; margin-top:3px; }
.privacy-note { font-size:11px; color:#999; line-height:1.4; margin-top:6px; }

.type-toggles { display:flex; flex-wrap:wrap; gap:8px; margin-top:4px; }
.type-btn {
  padding:7px 14px; border:1.5px solid #c8e6c9;
  border-radius:20px; background:#f9fbe7;
  color:#1b5e20; font-size:12px; font-weight:600;
  cursor:pointer; transition:all .15s; font-family:Arial,sans-serif;
}
.type-btn:hover { border-color:#1b5e20; background:#e8f5e9; }
.type-btn.on {
  background:#1b5e20; color:#fff;
  border-color:#1b5e20;
}
.btn-submit {
  width:100%; padding:11px; margin-top:8px;
  background:#1b5e20; color:#fff;
  border:none; border-radius:8px;
  font-size:13px; font-weight:700; cursor:pointer;
  font-family:Arial,sans-serif; transition:background .12s;
}
.btn-submit:hover { background:#2e7d32; }
.success-msg { background:#e8f5e9; border:1px solid #a5d6a7; color:#1b5e20; padding:12px 14px; border-radius:8px; font-size:13px; display:none; margin-bottom:14px; line-height:1.5; }
.error-msg   { background:#fef2f2; border:1px solid #fecaca; color:#c62828; padding:12px 14px; border-radius:8px; font-size:13px; display:none; margin-bottom:14px; }

/* ── Mobilusis ── */
@media(max-width:700px){
  #layout { flex-direction:column; }
  #sidebar { width:100%; height:auto; max-height:50vh; box-shadow:none; border-bottom:1px solid #ddd; }
  #map { flex:1; min-height:50vh; }
  #sb-list { max-height:200px; }
}
</style>
</head>
<body>
<div id="layout">

  <!-- ── Kairė juosta ── -->
  <div id="sidebar">
    <div id="sb-header">
      <div id="sb-logo">🌿 Montavimo specialistai</div>
      <div id="sb-search-wrap">
        <input type="text" id="sb-search" placeholder="Miestas arba adresas..." autocomplete="off">
        <button id="sb-search-btn" onclick="doSearch()">Ieškoti</button>
        <button id="sb-clear-btn" onclick="clearSearch()">✕</button>
      </div>
      <div id="sb-radius">
        <span id="sb-radius-lbl">Spindulys: <b id="radius-val">50</b> km</span>
        <input type="range" id="radiusSlider" min="5" max="200" value="50" step="5">
      </div>
    </div>

    <div id="sb-filter-bar">
      <div id="typeFilter-wrap">
        <select id="typeFilter" onchange="renderAll()">
          <option value="">✦ Pasirinkite paslaugą</option>
          <option value="montavimas">Montavimas</option>
          <option value="aptarnavimas">Aptarnavimas</option>
          <option value="gamintojas">Gamintojas</option>
          <option value="pardavejas">Pardavėjas</option>
        </select>
      </div>
      <span id="list-count-lbl"></span>
    </div>
    <div id="sb-list-title" style="padding:6px 14px 0;font-size:11px;font-weight:700;color:#1b5e20;min-height:20px">
      <span id="list-title-lbl">Visi specialistai</span>
    </div>

    <div id="sb-list"></div>

    <div id="sb-reg-btn">
      <button onclick="openReg()">+ Registruotis žemėlapyje</button>
    </div>
  </div>

  <!-- ── Žemėlapis ── -->
  <div id="map"></div>
</div>

<!-- ── Registracijos panel ── -->
<div id="reg-panel">
  <div id="reg-hdr">
    <div><h2>Registracija žemėlapyje</h2><p>Duomenys bus patvirtinti prieš publikuojant</p></div>
    <button id="reg-close" onclick="closeReg()">✕</button>
  </div>
  <div id="reg-body">
    <div class="success-msg" id="successMsg">✓ Paraiška gauta. Peržiūrėsime ir susisieksime artimiausiomis dienomis.</div>
    <div class="error-msg"   id="errorMsg"></div>
    <div id="regForm">
      <div class="form-group"><label>Vardas / įmonės pavadinimas *</label><input type="text" id="f_name" maxlength="80" placeholder="Jonas Jonaitis arba UAB Montažas"></div>
      <div class="form-group"><label>Telefono numeris *</label><input type="tel" id="f_tel" maxlength="20" placeholder="+370 600 00000"></div>
      <div class="form-group"><label>Miestas / vietovė *</label><input type="text" id="f_city" maxlength="60" placeholder="Vilnius, Kaunas..."></div>
      <div class="form-group">
        <label>Veiklos sritis (galima kelios)</label>
        <div class="type-toggles" id="f_types">
          <button type="button" class="type-btn" data-val="montavimas" onclick="toggleType(this)">Montavimas</button>
          <button type="button" class="type-btn" data-val="aptarnavimas" onclick="toggleType(this)">Aptarnavimas</button>
          <button type="button" class="type-btn" data-val="gamintojas" onclick="toggleType(this)">Gamintojas</button>
          <button type="button" class="type-btn" data-val="pardavejas" onclick="toggleType(this)">Pardavėjas</button>
        </div>
      </div>
      <div class="form-group">
        <label>Apie save</label>
        <textarea id="f_info" maxlength="300" placeholder="Patirtis, specializacija, aptarnaujami regionai..."></textarea>
        <div class="char-count"><span id="charCount">0</span>/300</div>
      </div>
      <div class="privacy-note">🔒 Tel. numeris matomas tik po patvirtinimo.</div>
      <button class="btn-submit" onclick="submitReg()">Siųsti paraišką</button>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.3/leaflet.markercluster.js"></script>
<script>
// ── Žemėlapis – Lietuva centre ───────────────────────────────────
const map = L.map('map', {zoomControl:true}).setView([55.3, 23.9], 7);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution:'© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  maxZoom:18
}).addTo(map);

// ── Cluster grupė ────────────────────────────────────────────────
const clusterGroup = L.markerClusterGroup({
  maxClusterRadius: 60,
  iconCreateFunction: function(cluster) {
    const cnt = cluster.getChildCount();
    const size = cnt > 9 ? 44 : 36;
    return L.divIcon({
      html: '<div class="cluster-icon">'+cnt+'</div>',
      className: '',
      iconSize: [size, size],
      iconAnchor: [size/2, size/2]
    });
  }
});
map.addLayer(clusterGroup);

// ── Tipų konfigūracija ───────────────────────────────────────────
const TYPES = {
  montavimas:   {label:'Montavimas',   bg:'#e3f2fd', col:'#1565c0', pin:'blue'},
  aptarnavimas: {label:'Aptarnavimas', bg:'#fff3e0', col:'#e65100', pin:'orange'},
  gamintojas:   {label:'Gamintojas',   bg:'#f3e5f5', col:'#6a1b9a', pin:'purple'},
  pardavejas:   {label:'Pardavėjas',   bg:'#f1f8e9', col:'#33691e', pin:'green'},
  remontas:     {label:'Aptarnavimas', bg:'#fff3e0', col:'#e65100', pin:'orange'},
  projektavimas:{label:'Montavimas',   bg:'#e3f2fd', col:'#1565c0', pin:'blue'},
  kita:         {label:'Kita',         bg:'#f5f5f5', col:'#757575', pin:'grey'},
};

// ── Būsena ───────────────────────────────────────────────────────
let allEntries=[], searchLatLng=null, radiusKm=50;
let radiusCircle=null, searchMarker=null;
let activeCity=null;

// ── Atstumas ─────────────────────────────────────────────────────
function dist(f, t) {
  const R=6371, a=(+t.lat-f.lat)*Math.PI/180, b=(+t.lng-f.lng)*Math.PI/180;
  const c=Math.sin(a/2)**2+Math.cos(f.lat*Math.PI/180)*Math.cos(+t.lat*Math.PI/180)*Math.sin(b/2)**2;
  return R*2*Math.atan2(Math.sqrt(c),Math.sqrt(1-c));
}

// ── Duomenys ─────────────────────────────────────────────────────
async function loadEntries() {
  try {
    const r = await fetch('./api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'list'})});
    const d = await r.json();
    if (d.ok && d.entries) { allEntries=d.entries; renderAll(); }
  } catch(e){}
}

// ── Filtruoti įrašai ─────────────────────────────────────────────
function getFiltered() {
  const tf = document.getElementById('typeFilter').value;
  return allEntries.filter(e => {
    if (!e.lat || !e.lng) return false;
    if (tf) {
      const entryTypes = Array.isArray(e.types) && e.types.length ? e.types : (e.type ? [e.type] : []);
      const norm = t => (t==='remontas')?'aptarnavimas':(t==='projektavimas')?'montavimas':t;
      if (!entryTypes.some(t => norm(t) === tf)) return false;
    }
    if (searchLatLng) return dist(searchLatLng,e)<=radiusKm;
    return true;
  });
}

// ── Renderinimas ─────────────────────────────────────────────────
function renderAll() {
  clusterGroup.clearLayers();
  activeCity = null;

  let entries = getFiltered();
  if (searchLatLng) entries.sort((a,b)=>dist(searchLatLng,a)-dist(searchLatLng,b));

  // Žymekliai
  const markerMap = new Map(); // entry.id -> marker
  entries.forEach(e => {
    const tp = TYPES[e.type] || TYPES.kita;
    const entryTypes = Array.isArray(e.types) && e.types.length ? e.types : (e.type ? [e.type] : []);
    const popupBadges = entryTypes.map(t => {
      const tp2 = TYPES[t] || TYPES.kita;
      return '<span class="popup-type" style="background:'+tp2.bg+';color:'+tp2.col+'">'+tp2.label+'</span>';
    }).join(' ');
    const badges = entryTypes.map(t => {
      const tp2 = TYPES[t] || TYPES.kita;
      return '<span class="ec-badge" style="background:'+tp2.bg+';color:'+tp2.col+'">'+tp2.label+'</span>';
    }).join('');
    const pin = L.divIcon({className:'',html:'<div class="map-pin '+tp.pin+'"></div>',iconSize:[16,16],iconAnchor:[8,8]});
    const m = L.marker([+e.lat,+e.lng],{icon:pin});
    m._entryId = e.id;
    m.bindPopup(
      '<div class="popup-body">'+
      '<div class="popup-name">'+esc(e.name)+'</div>'+
      popupBadges+
      '<div class="popup-city">📍 '+esc(e.city)+'</div>'+
      (e.info?'<div class="popup-info">'+esc(e.info)+'</div>':'')+
      '<a class="popup-tel" href="tel:'+esc(e.tel)+'">📞 '+esc(e.tel)+'</a>'+
      '</div>'
    );
    markerMap.set(e.id, m);
    clusterGroup.addLayer(m);
  });

  // Cluster paspaudimas
  clusterGroup.on('clusterclick', function(ev) {
    const childMarkers = ev.layer.getAllChildMarkers();
    const cityEntries = childMarkers.map(m => {
      return entries.find(e => e.id === m._entryId);
    }).filter(Boolean);

    if (cityEntries.length) {
      activeCity = cityEntries[0].city;
      const lbl = '📍 ' + activeCity + ' (' + cityEntries.length + ')';
      renderList(cityEntries, lbl);
    }
    map.fitBounds(ev.layer.getBounds().pad(0.4));
    ev.originalEvent.stopPropagation();
  });

  // Atskiras žymeklis paspaustas – atšaukia city filtrą
  clusterGroup.on('click', function() {
    activeCity = null;
    renderList(entries);
  });

  renderList(entries);
}

// ── Sąrašo renderinimas ──────────────────────────────────────────
function renderList(entries, title) {
  const cnt = entries.length;
  document.getElementById('list-count-lbl').textContent = cnt ? cnt+' specialistas'+(cnt!==1?'ų':'') : '';

  // Antraštė su "Visi" mygtuku jei aktyvus city filtras
  const titleEl = document.getElementById('list-title-lbl');
  if (titleEl) {
    titleEl.innerHTML = (title||'') +
      (activeCity ? ' <button onclick="resetCityFilter()" style="font-size:10px;padding:2px 8px;margin-left:6px;background:#f1f8e9;border:1px solid #c8e6c9;border-radius:10px;cursor:pointer;color:#1b5e20">✕ Visi</button>' : '');
  }

  const list = document.getElementById('sb-list');
  if (!cnt) {
    list.innerHTML='<div class="empty-state"><div class="empty-icon">🔍</div><div class="empty-txt">'+(searchLatLng?'Bandykite padidinti spindulį':'Dar nėra specialistų')+'</div></div>';
    return;
  }

  list.innerHTML='';
  entries.forEach(e => {
    const tp  = TYPES[e.type] || TYPES.kita;
    const entryTypes = Array.isArray(e.types) && e.types.length ? e.types : (e.type ? [e.type] : []);
    const badges = entryTypes.map(t => {
      const tp2 = TYPES[t] || TYPES.kita;
      return '<span class="ec-badge" style="background:'+tp2.bg+';color:'+tp2.col+'">'+tp2.label+'</span>';
    }).join('');
    const popupBadges = entryTypes.map(t => {
      const tp2 = TYPES[t] || TYPES.kita;
      return '<span class="popup-type" style="background:'+tp2.bg+';color:'+tp2.col+'">'+tp2.label+'</span>';
    }).join(' ');
    const km  = searchLatLng ? dist(searchLatLng,e) : null;
    const kmTxt = km!==null ? (km<1?'<1':Math.round(km))+' km' : null;

    const card = document.createElement('div');
    card.className='entry-card';
    card.innerHTML=
      '<div class="ec-name">'+esc(e.name)+'</div>'+
      '<div class="ec-meta">'+
        badges+
        '<span class="ec-city">📍 '+esc(e.city)+'</span>'+
        (kmTxt?'<span class="ec-dist">'+kmTxt+'</span>':'')+
      '</div>'+
      (e.info?'<div class="ec-info">'+esc(e.info)+'</div>':'')+
      '<a class="ec-tel" href="tel:'+esc(e.tel)+'" onclick="event.stopPropagation()">📞 '+esc(e.tel)+'</a>';

    card.onclick=()=>{
      document.querySelectorAll('.entry-card').forEach(c=>c.classList.remove('active'));
      card.classList.add('active');
      if (e.lat && e.lng) map.setView([+e.lat,+e.lng],13);
    };
    list.appendChild(card);
  });
}

function resetCityFilter() {
  activeCity = null;
  renderList(getFiltered(), searchLatLng ? 'Artimiausiai ('+radiusKm+' km)' : 'Visi specialistai');
}

// ── Paieška ──────────────────────────────────────────────────────
document.getElementById('sb-search').addEventListener('keydown',e=>{if(e.key==='Enter')doSearch();});
document.getElementById('radiusSlider').addEventListener('input',function(){
  radiusKm=+this.value;
  document.getElementById('radius-val').textContent=radiusKm;
  updateCircle(); renderAll();
});

async function doSearch(){
  const q=document.getElementById('sb-search').value.trim();
  if(!q) return;
  const btn=document.getElementById('sb-search-btn');
  btn.textContent='...'; btn.disabled=true;
  try{
    const r=await fetch('https://nominatim.openstreetmap.org/search?q='+encodeURIComponent(q+', Lietuva')+'&format=json&limit=1&countrycodes=lt',{headers:{'Accept-Language':'lt'}});
    const d=await r.json();
    if(d.length){
      searchLatLng={lat:+d[0].lat,lng:+d[0].lon};
      map.setView([searchLatLng.lat,searchLatLng.lng],9);
      if(searchMarker) map.removeLayer(searchMarker);
      searchMarker=L.circleMarker([searchLatLng.lat,searchLatLng.lng],
        {radius:8,color:'#c62828',fillColor:'#c62828',fillOpacity:.9,weight:2}
      ).addTo(map);
      updateCircle();
      document.getElementById('sb-clear-btn').style.display='inline';
    }
  }catch(e){}
  btn.textContent='Ieškoti'; btn.disabled=false;
  renderAll();
}

function clearSearch(){
  searchLatLng=null;
  document.getElementById('sb-search').value='';
  document.getElementById('sb-clear-btn').style.display='none';
  if(searchMarker){map.removeLayer(searchMarker);searchMarker=null;}
  if(radiusCircle){map.removeLayer(radiusCircle);radiusCircle=null;}
  map.setView([55.3,23.9],7);
  renderAll();
}

function updateCircle(){
  if(!searchLatLng) return;
  if(radiusCircle) map.removeLayer(radiusCircle);
  radiusCircle=L.circle([searchLatLng.lat,searchLatLng.lng],{
    radius:radiusKm*1000,
    color:'#1b5e20',fillColor:'#1b5e20',fillOpacity:.06,
    weight:1.5,dashArray:'6 4'
  }).addTo(map);
}

// ── Pagalbinės ───────────────────────────────────────────────────
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function openReg() { document.getElementById('reg-panel').classList.add('open'); }
function closeReg(){ document.getElementById('reg-panel').classList.remove('open'); }

document.getElementById('f_info').addEventListener('input',function(){
  document.getElementById('charCount').textContent=this.value.length;
});

function toggleType(btn) {
  btn.classList.toggle('on');
}

function getSelectedTypes() {
  return Array.from(document.querySelectorAll('#f_types .type-btn.on')).map(b=>b.dataset.val);
}

// ── Registracija ─────────────────────────────────────────────────
async function submitReg(){
  const errEl=document.getElementById('errorMsg'); errEl.style.display='none';
  const name=document.getElementById('f_name').value.trim();
  const tel =document.getElementById('f_tel').value.trim();
  const city=document.getElementById('f_city').value.trim();
  const types=getSelectedTypes();
  const info=document.getElementById('f_info').value.trim();
  if(!name||!tel||!city){errEl.textContent='Užpildykite privalomus laukus (*)';errEl.style.display='block';return;}
  const btn=event.target; btn.disabled=true; btn.textContent='Siunčiama...';
  try{
    const r=await fetch('./api.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'register',name,tel,city,types,info})});
    const d=await r.json();
    if(d.ok){
      document.getElementById('regForm').style.display='none';
      document.getElementById('successMsg').style.display='block';
    } else {
      errEl.textContent=d.error||'Klaida.'; errEl.style.display='block';
      btn.disabled=false; btn.textContent='Siųsti paraišką';
    }
  }catch(e){
    errEl.textContent='Ryšio klaida.'; errEl.style.display='block';
    btn.disabled=false; btn.textContent='Siųsti paraišką';
  }
}

// ── Paleidimas ───────────────────────────────────────────────────
document.getElementById('typeFilter').addEventListener('change', function() {
  const wrap = document.getElementById('typeFilter-wrap');
  if (this.value) wrap.classList.add('selected');
  else wrap.classList.remove('selected');
});

loadEntries();
setInterval(loadEntries, 60000);


</script>
</body>
</html>
