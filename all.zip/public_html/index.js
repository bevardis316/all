// IBNVS chat'o frontend (v4, 2026-05)
// v4: Telefono balso režimas su TTS sinchronizacija, pašalintas senasis mic mygtukas

var _chatHistory       = [];
var _blockedUntil      = 0;
var _blockedKind       = '';
var _countdownInterval = null;

var _chatForm = document.getElementById('chatForm');
if (_chatForm) {
    _chatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        getData();
    });
}

var _inputEl = document.getElementById("input");
if (_inputEl) _inputEl.focus();

// ─── Bendras AudioContext (iOS autoplay fix) ──────────────────────────────────

var _sharedAudioCtx = null;
var _sharedAudioSrc = null;

function _unlockAudioCtx() {
    if (_sharedAudioCtx) {
        if (_sharedAudioCtx.state === 'suspended') _sharedAudioCtx.resume().catch(function(){});
        return;
    }
    try { _sharedAudioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch(e) {}
}

async function _playAudioBlob(blob) {
    var ctx = _sharedAudioCtx;
    if (ctx) {
        try {
            if (ctx.state === 'suspended') await ctx.resume();
            var buf = await ctx.decodeAudioData(await blob.arrayBuffer());
            var src = ctx.createBufferSource();
            src.buffer = buf;
            src.connect(ctx.destination);
            _sharedAudioSrc = src;
            return new Promise(function(res) {
                src.onended = function() { _sharedAudioSrc = null; res(); };
                src.start();
            });
        } catch(e) { _sharedAudioSrc = null; }
    }
    // HTMLAudio fallback (Desktop / Android)
    var url = URL.createObjectURL(blob);
    var audio = new Audio(url);
    return new Promise(function(res) {
        audio.onended = function() { URL.revokeObjectURL(url); res(); };
        audio.onerror = function() { URL.revokeObjectURL(url); res(); };
        audio.play().catch(res);
    });
}

function _stopSharedAudio() {
    if (_sharedAudioSrc) { try { _sharedAudioSrc.stop(); } catch(e) {} _sharedAudioSrc = null; }
}

// ─── Telefono stiliaus balso pokalbis ─────────────────────────────────────────

(function _initPhoneMode() {
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;

    // ── Atidarymo mygtukas ──
    var openBtn   = document.createElement('button');
    openBtn.type  = 'button';
    openBtn.id    = 'ppOpenBtn';
    openBtn.title = 'Balso pokalbis';
    openBtn.textContent = '📞';
    var sb = _chatForm ? _chatForm.querySelector('button[type=submit]') : null;
    if (sb) _chatForm.insertBefore(openBtn, sb);

    if (!SR) {
        openBtn.style.opacity = '0.3';
        openBtn.title = 'Jūsų naršyklė nepalaiko balso įvesties';
        return;
    }

    var _on      = false;
    var _busy    = false;
    var _lis     = false;
    var _holding = false;
    var _audio   = null;
    var _heard   = '';
    var _rec     = null;

    // ── Panelė ──
    var panel = document.createElement('div');
    panel.id  = 'ppPanel';
    panel.innerHTML =
        '<div id="ppStatus">Laikykite mygtuką ir kalbėkite</div>' +
        '<button id="ppMic" type="button">🎙</button>' +
        '<div id="ppHint">Laikykite — klauso &nbsp;·&nbsp; Atleiskite — siunčia</div>' +
        '<button id="ppEnd" type="button">Baigti pokalbį</button>';
    document.body.appendChild(panel);

    var statusEl = document.getElementById('ppStatus');
    var micBtnEl = document.getElementById('ppMic');
    var endBtnEl = document.getElementById('ppEnd');

    function _ui(status, mode, icon) {
        if (statusEl) statusEl.textContent = status;
        if (micBtnEl) micBtnEl.textContent = icon || '🎙';
        panel.dataset.mode = mode || '';
    }

    function _makeRec() {
        var r            = new SR();
        r.lang           = 'lt-LT';
        r.continuous     = false;
        r.interimResults = false;
        r.maxAlternatives = 1;

        r.onstart = function() { _lis = true; };

        r.onresult = function(e) {
            _heard = (e.results[0][0].transcript || '').trim();
        };

        r.onend = function() {
            _lis     = false;
            _holding = false;
            var txt  = _heard;
            _heard   = '';
            if (_on && txt) {
                _sendAndSpeak(txt);
            } else if (_on && !_busy) {
                _ui('Laikykite mygtuką ir kalbėkite', 'ready', '🎙');
            }
        };

        r.onerror = function(ev) {
            _lis     = false;
            _holding = false;
            _heard   = '';
            if (!_on) return;
            if (ev.error === 'not-allowed') {
                _ui('Mikrofonas užblokuotas — tikrinkite leidimus', 'error', '🚫');
                return;
            }
            if (!_busy) _ui('Laikykite mygtuką ir kalbėkite', 'ready', '🎙');
        };

        return r;
    }

    // ── Hold-to-talk: laikyk → klauso, atleisk → siunčia ──

    function _holdStart(e) {
        e.preventDefault();
        if (!_on) return;
        _unlockAudioCtx();

        // Jei AI kalba — nutraukti ir klausyti
        if (_audio || _sharedAudioSrc) { _stopAudio(); _stopSharedAudio(); _busy = false; }

        // Jei dar galvoja (fetch) — ignoruoti
        if (_busy || _lis || _holding) return;

        _holding = true;
        _heard   = '';
        _rec     = _makeRec();
        _ui('Klausau…', 'listening', '🎙');
        try {
            _rec.start();
        } catch(err) {
            _holding = false;
            _ui('Klaida — bandykite dar kartą', 'error', '⚠️');
        }
    }

    function _holdEnd(e) {
        if (e) e.preventDefault();
        if (!_holding) return;
        // onend pats suveiks ir apdoros _heard
        if (_rec) try { _rec.stop(); } catch(err) {}
    }

    // Mouse/pen: pointer events; Touch: skip pointer events (handled by touch listeners below)
    micBtnEl.addEventListener('pointerdown',   function(e) { if (e.pointerType === 'touch') return; _holdStart(e); });
    micBtnEl.addEventListener('pointerup',     function(e) { if (e.pointerType === 'touch') return; _holdEnd(e); });
    micBtnEl.addEventListener('pointercancel', function(e) { if (e.pointerType === 'touch') return; _holdEnd(e); });
    micBtnEl.addEventListener('pointerleave',  function(e) { if (e.pointerType === 'touch') return; _holdEnd(e); });
    micBtnEl.addEventListener('touchstart',  _holdStart,  {passive: false});
    micBtnEl.addEventListener('touchend',    _holdEnd,    {passive: false});
    micBtnEl.addEventListener('touchcancel', _holdEnd,    {passive: false});

    function _stopAudio() {
        if (_audio) { try { _audio.pause(); } catch(e) {} _audio = null; }
    }

    async function _sendAndSpeak(txt) {
        _busy = true;
        _ui('Galvoja…', 'thinking', '💭');

        var msgs = document.getElementById('messages');
        var um   = document.createElement('div');
        um.className   = 'mess-user';
        um.textContent = txt;
        msgs.appendChild(um);
        scrollToBottom();

        if (_chatHistory.length >= 14) {
            _ui('Pokalbis per ilgas — pradėkite naują', 'error', '⚠️');
            _showLimitMessage('session', 300, '');
            _chatHistory = [];
            _deactivate();
            return;
        }

        _chatHistory.push({ role: 'user', content: txt });

        try {
            var resp = await fetch('/api/v1/ai', {
                method:  'POST',
                headers: { 'Content-Type': 'application/json' },
                body:    JSON.stringify({ message: txt, history: _chatHistory.slice(0, -1) })
            });
            var d = await resp.json();

            if (resp.status === 429) {
                _chatHistory.pop();
                _showLimitMessage(d.limit_kind || 'minute', Math.max(1, parseInt(d.retry_after_sec || 60, 10)), d.error || '');
                _deactivate();
                return;
            }

            if (d && d.ok && d.text) {
                _chatHistory.push({ role: 'assistant', content: d.text });
                if (_chatHistory.length > 16) _chatHistory = _chatHistory.slice(-16);

                // Paruošti žinutę bet dar nerodyti
                var am       = document.createElement('div');
                am.className = 'mess-chat';
                am.innerHTML = _renderLinks(d.text);

                // Gauti TTS
                _ui('Ruošia balsą…', 'thinking', '💭');
                var clean = _ttsClean(d.text);
                var played = false;

                if (clean) {
                    try {
                        var ttsR = await fetch('/api/v1/tts', {
                            method:  'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body:    JSON.stringify({ text: clean })
                        });
                        if (ttsR.ok) {
                            var blob = await ttsR.blob();
                            msgs.appendChild(am);
                            scrollToBottom();
                            _ui('Kalba… (laikykite mygtuką norėdami nutraukti)', 'speaking', '🔊');
                            played = true;
                            await _playAudioBlob(blob);
                        }
                    } catch(e) { /* TTS klaida — parodys tekstą žemiau */ }
                }

                if (!played) { msgs.appendChild(am); scrollToBottom(); }

            } else {
                _chatHistory.pop();
                _ui('Klaida. Bandykite dar kartą.', 'error', '⚠️');
            }
        } catch(e) {
            _chatHistory.pop();
            _ui('Ryšio klaida.', 'error', '⚠️');
        }

        _busy = false;
        if (_on) _ui('Laikykite mygtuką ir kalbėkite', 'ready', '🎙');
    }

    function _activate() {
        _on = true;
        panel.classList.add('active');
        openBtn.style.display = 'none';
        _ui('Laikykite mygtuką ir kalbėkite', 'ready', '🎙');
    }

    function _deactivate() {
        _on      = false;
        _busy    = false;
        _holding = false;
        if (_rec) try { _rec.stop(); } catch(e) {}
        _stopAudio();
        panel.classList.remove('active');
        openBtn.style.display = '';
    }

    endBtnEl.addEventListener('click',  _deactivate);
    openBtn.addEventListener('click',   _activate);
})();

// ─── TTS išvestis (teksto žinutės garsiakalbio mygtukas) ──────────────────────

function _ttsClean(text) {
    return text
        .replace(/\[KONSTRUKTORIUS\]/g, '')
        .replace(/\[DIAGNOSTIKA\]/g, '')
        .replace(/\[ŽEMĖLAPIS\]/g, '')
        .replace(/\[KON:[A-Z0-9]+\]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}

async function _ttsPlay(text) {
    var clean = _ttsClean(text);
    if (!clean) return;
    _unlockAudioCtx();
    try {
        var resp = await fetch('/api/v1/tts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: clean })
        });
        if (!resp.ok) return;
        var blob = await resp.blob();
        await _playAudioBlob(blob);
    } catch(e) {}
}

function _addSpeakerBtn(messageDiv, text) {
    var btn = document.createElement('button');
    btn.textContent = '🔊';
    btn.title = 'Klausyti';
    btn.style.cssText = 'background:none;border:none;cursor:pointer;font-size:14px;opacity:0.5;margin-left:6px;padding:0;vertical-align:middle;line-height:1';
    btn.addEventListener('click', function() { _ttsPlay(text); });
    messageDiv.appendChild(btn);
}

// ─── Nuorodų atvaizdavimas ────────────────────────────────────────────────────

function _renderLinks(text) {
    var links = [];
    var PH = '\x00L\x00';

    text = text.replace(/\[DIAGNOSTIKA\]/g, function() {
        links.push('<a href="/diag/diagnose.php" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#1b5e20;color:#fff;border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;text-decoration:none;margin:0 2px">🔍 Gedimų diagnostika</a>');
        return PH + (links.length-1) + PH;
    });
    text = text.replace(/\[KONSTRUKTORIUS\]/g, function() {
        links.push('<a href="/kon/index.php" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#1565c0;color:#fff;border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;text-decoration:none;margin:0 2px">🔧 Konstruktorius</a>');
        return PH + (links.length-1) + PH;
    });
    text = text.replace(/\[ŽEMĖLAPIS\]/g, function() {
        links.push('<a href="/map/" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#4a148c;color:#fff;border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;text-decoration:none;margin:0 2px">📍 Specialistų žemėlapis</a>');
        return PH + (links.length-1) + PH;
    });
    text = text.replace(/\[KON:([A-Z0-9]+)\]/g, function(m, oid) {
        links.push('<a href="/kon/#obj='+oid+'" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#e65100;color:#fff;border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;text-decoration:none;margin:0 2px">🔍 '+oid+'</a>');
        return PH + (links.length-1) + PH;
    });

    text = text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\n/g, '<br>');

    text = text.replace(/\x00L\x00(\d+)\x00L\x00/g, function(m, i) {
        return links[parseInt(i)];
    });

    return text;
}

// ─── Pagalbinės funkcijos ────────────────────────────────────────────────────

function _fmtTime(sec) {
    if (sec < 60)   return sec + ' s';
    if (sec < 3600) return Math.ceil(sec / 60) + ' min';
    return Math.floor(sec / 3600) + ' val ' + Math.ceil((sec % 3600) / 60) + ' min';
}

function _showLimitMessage(kind, retryAfterSec, customMsg) {
    var messagesDiv = document.getElementById("messages");
    var inputField  = document.getElementById("input");
    var submitBtn   = _chatForm ? _chatForm.querySelector('button[type=submit]') : null;

    _blockedUntil = Math.floor(Date.now()/1000) + retryAfterSec;
    _blockedKind  = kind;

    var box = document.createElement('div');
    box.className = 'mess-chat chat-limit-box';
    box.style.cssText = 'background:rgba(255,152,0,0.1);border:1px solid rgba(255,152,0,0.4);border-radius:8px;padding:12px 14px;margin:10px 0;font-size:13px;color:#bf6000;line-height:1.5';

    var title = '⏱ ';
    if (kind === 'minute')       title += 'Per daug žinučių per minutę';
    else if (kind === 'hour')    title += 'Pasiektas valandos limitas';
    else if (kind === 'day')     title += 'Pasiektas dienos limitas';
    else if (kind === 'session') title += 'Pokalbis baigtas';
    else                         title += 'Per daug užklausų';

    var html = '<div style="font-weight:700;margin-bottom:6px">' + title + '</div>';
    if (customMsg) html += '<div style="margin-bottom:8px">' + customMsg + '</div>';
    html += '<div id="chatCountdown" style="margin-bottom:8px">Vėl rašyti galėsite po <b><span id="chatCountdownVal">' + _fmtTime(retryAfterSec) + '</span></b>.</div>';
    html += '<div style="font-size:12px;opacity:0.9">Tarpu kuo galite pasinaudoti įrankiais:</div>';
    html += '<div style="margin-top:6px">'
         + '<a href="/diag/diagnose.php" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#1b5e20;color:#fff;border-radius:6px;padding:3px 10px;font-size:11px;font-weight:700;text-decoration:none;margin:2px">🔍 Diagnostika</a> '
         + '<a href="/kon/index.php" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#1565c0;color:#fff;border-radius:6px;padding:3px 10px;font-size:11px;font-weight:700;text-decoration:none;margin:2px">🔧 Konstruktorius</a> '
         + '<a href="/map/" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#4a148c;color:#fff;border-radius:6px;padding:3px 10px;font-size:11px;font-weight:700;text-decoration:none;margin:2px">📍 Specialistų žemėlapis</a>'
         + '</div>';
    box.innerHTML = html;
    messagesDiv.appendChild(box);
    scrollToBottom();

    if (inputField) inputField.disabled = true;
    if (submitBtn)  submitBtn.disabled  = true;

    if (_countdownInterval) clearInterval(_countdownInterval);
    _countdownInterval = setInterval(function() {
        var remaining = _blockedUntil - Math.floor(Date.now() / 1000);
        var span = document.getElementById('chatCountdownVal');
        if (remaining <= 0) {
            clearInterval(_countdownInterval);
            _countdownInterval = null;
            if (span) span.parentElement.innerHTML = '✅ Galite vėl rašyti.';
            if (inputField) { inputField.disabled = false; inputField.focus(); }
            if (submitBtn)  submitBtn.disabled = false;
            box.style.opacity = '0.6';
        } else if (span) {
            span.textContent = _fmtTime(remaining);
        }
    }, 1000);
}

// ─── Pagrindinis siuntimas (teksto režimas) ───────────────────────────────────

async function getData() {
    var nowS = Math.floor(Date.now()/1000);
    if (_blockedUntil > nowS) {
        if (_inputEl) _inputEl.value = '';
        return;
    }

    var userData = _inputEl ? _inputEl.value.trim() : '';
    if (!userData) return false;

    var messagesDiv = document.getElementById("messages");
    var inputField  = document.getElementById("input");

    var userMessage = document.createElement('div');
    userMessage.className = 'mess-user';
    userMessage.textContent = userData;
    messagesDiv.appendChild(userMessage);
    inputField.value = "";
    scrollToBottom();

    var typingIndicator = document.createElement('div');
    typingIndicator.className = 'mess-chat';
    typingIndicator.innerHTML = '<span style="opacity:0.5">Rašo...</span>';
    typingIndicator.id = 'typing';
    messagesDiv.appendChild(typingIndicator);
    scrollToBottom();

    if (_chatHistory.length >= 14) {
        var typing0 = document.getElementById('typing');
        if (typing0) typing0.remove();
        _showLimitMessage(
            'session',
            300,
            'Šis pokalbis užtruko ilgokai. Pradėsime naują po atvėsimo, arba pasinaudokite žemiau esančiais įrankiais.'
        );
        _chatHistory = [];
        return;
    }

    _chatHistory.push({ role: 'user', content: userData });

    try {
        var response = await fetch("/api/v1/ai", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                message: userData,
                history: _chatHistory.slice(0, -1)
            }),
        });

        var data   = await response.json();
        var typing = document.getElementById('typing');
        if (typing) typing.remove();

        if (response.status === 429) {
            _chatHistory.pop();
            _showLimitMessage(
                data.limit_kind || 'minute',
                Math.max(1, parseInt(data.retry_after_sec || 60, 10)),
                data.error || ''
            );
            return;
        }

        if (data && data.ok && data.text) {
            _chatHistory.push({ role: 'assistant', content: data.text });
            if (_chatHistory.length > 16) _chatHistory = _chatHistory.slice(-16);

            var chatMessage = document.createElement('div');
            chatMessage.className = 'mess-chat';
            chatMessage.innerHTML = _renderLinks(data.text);
            _addSpeakerBtn(chatMessage, data.text);
            messagesDiv.appendChild(chatMessage);

        } else if (data && data.error) {
            _chatHistory.pop();
            var errorMessage = document.createElement('div');
            errorMessage.className = 'mess-chat';
            errorMessage.style.color = '#ef4444';
            errorMessage.textContent = 'Klaida: ' + data.error;
            messagesDiv.appendChild(errorMessage);
        } else {
            _chatHistory.pop();
            var errorMessage2 = document.createElement('div');
            errorMessage2.className = 'mess-chat';
            errorMessage2.style.color = '#ef4444';
            errorMessage2.textContent = 'Netikėta klaida. Bandykite dar kartą.';
            messagesDiv.appendChild(errorMessage2);
        }

        scrollToBottom();

    } catch (error) {
        _chatHistory.pop();
        var typing2 = document.getElementById('typing');
        if (typing2) typing2.remove();
        var errorMessage3 = document.createElement('div');
        errorMessage3.className = 'mess-chat';
        errorMessage3.style.color = '#ef4444';
        errorMessage3.textContent = 'Ryšio klaida. Bandykite dar kartą.';
        messagesDiv.appendChild(errorMessage3);
        scrollToBottom();
    }

    if (inputField) inputField.focus();
}

function scrollToBottom() {
    var messagesDiv = document.getElementById("messages");
    if (messagesDiv) messagesDiv.scrollTo({ top: messagesDiv.scrollHeight, behavior: 'smooth' });
}
