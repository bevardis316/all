// IBNVS chat'o frontend (v3, 2026-05)
// v3: Balso įvestis (Web Speech API) + TTS išvestis (garsiakalbio mygtukas / auto-play)
// v2: 429 countdown, rate limit kind, sesijos limitas

var _chatHistory       = [];
var _blockedUntil      = 0;
var _blockedKind       = '';
var _countdownInterval = null;
var _voiceMode         = false;  // true kai paskutinis input buvo balso — auto-play TTS

var _chatForm = document.getElementById('chatForm');
if (_chatForm) {
    _chatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        getData();
    });
}

var _inputEl = document.getElementById("input");
if (_inputEl) _inputEl.focus();

// ─── Balso įvestis (Web Speech API) ──────────────────────────────────────────

(function _initVoiceInput() {
    var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    var micBtn = document.getElementById('micBtn');
    if (!micBtn) return;

    if (!SpeechRecognition) {
        micBtn.style.display = 'none';
        return;
    }

    var recognition  = new SpeechRecognition();
    recognition.lang            = 'lt-LT';
    recognition.continuous      = false;
    recognition.interimResults  = false;

    var _listening = false;

    micBtn.addEventListener('click', function() {
        if (_listening) {
            recognition.stop();
        } else {
            try { recognition.start(); } catch(e) {}
        }
    });

    recognition.onstart = function() {
        _listening = true;
        micBtn.textContent = '⏹';
        micBtn.title = 'Stabdyti';
        micBtn.style.background = '#ef4444';
        micBtn.style.color = '#fff';
    };

    recognition.onresult = function(e) {
        var transcript = e.results[0][0].transcript;
        if (_inputEl) _inputEl.value = transcript;
        _voiceMode = true;
    };

    recognition.onend = function() {
        _listening = false;
        micBtn.textContent = '🎙';
        micBtn.title = 'Kalbėti';
        micBtn.style.background = '';
        micBtn.style.color = '';
        if (_inputEl && _inputEl.value.trim()) getData();
    };

    recognition.onerror = function() {
        _listening = false;
        micBtn.textContent = '🎙';
        micBtn.title = 'Kalbėti';
        micBtn.style.background = '';
        micBtn.style.color = '';
        _voiceMode = false;
    };
})();

// ─── TTS išvestis ─────────────────────────────────────────────────────────────

function _ttsClean(text) {
    return text
        .replace(/\[KONSTRUKTORIUS\]/g, '')
        .replace(/\[DIAGNOSTIKA\]/g, '')
        .replace(/\[ŽEMĖLAPIS\]/g, '')
        .replace(/\[KON:[A-Z0-9]+\]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}

async function _ttsPlay(text) {
    var clean = _ttsClean(text);
    if (!clean) return;
    try {
        var resp = await fetch('/api/tts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: clean })
        });
        if (!resp.ok) return;
        var blob = await resp.blob();
        var url  = URL.createObjectURL(blob);
        var audio = new Audio(url);
        audio.onended = function() { URL.revokeObjectURL(url); };
        audio.play().catch(function() { URL.revokeObjectURL(url); });
    } catch(e) {}
}

function _addSpeakerBtn(messageDiv, text) {
    var btn = document.createElement('button');
    btn.textContent = '🔊';
    btn.title = 'Klausyti';
    btn.style.cssText = 'background:none;border:none;cursor:pointer;font-size:14px;opacity:0.5;margin-left:6px;padding:0;vertical-align:middle;line-height:1';
    btn.addEventListener('click', function() { _ttsPlay(text); });
    messageDiv.appendChild(btn);
}

// ─── Nuorodų atvaizdavimas ────────────────────────────────────────────────────

function _renderLinks(text) {
    var links = [];
    var PH = '\x00L\x00';

    text = text.replace(/\[DIAGNOSTIKA\]/g, function() {
        links.push('<a href="/diag/diagnose.php" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#1b5e20;color:#fff;border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;text-decoration:none;margin:0 2px">🔍 Gedimų diagnostika</a>');
        return PH + (links.length-1) + PH;
    });
    text = text.replace(/\[KONSTRUKTORIUS\]/g, function() {
        links.push('<a href="/kon/index.php" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#1565c0;color:#fff;border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;text-decoration:none;margin:0 2px">🔧 Konstruktorius</a>');
        return PH + (links.length-1) + PH;
    });
    text = text.replace(/\[ŽEMĖLAPIS\]/g, function() {
        links.push('<a href="/map/" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#4a148c;color:#fff;border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;text-decoration:none;margin:0 2px">📍 Specialistų žemėlapis</a>');
        return PH + (links.length-1) + PH;
    });
    text = text.replace(/\[KON:([A-Z0-9]+)\]/g, function(m, oid) {
        links.push('<a href="/kon/#obj='+oid+'" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#e65100;color:#fff;border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;text-decoration:none;margin:0 2px">🔍 '+oid+'</a>');
        return PH + (links.length-1) + PH;
    });

    text = text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\n/g, '<br>');

    text = text.replace(/\x00L\x00(\d+)\x00L\x00/g, function(m, i) {
        return links[parseInt(i)];
    });

    return text;
}

// ─── Pagalbinės funkcijos ────────────────────────────────────────────────────

function _fmtTime(sec) {
    if (sec < 60)    return sec + ' s';
    if (sec < 3600)  return Math.ceil(sec / 60) + ' min';
    return Math.floor(sec / 3600) + ' val ' + Math.ceil((sec % 3600) / 60) + ' min';
}

function _showLimitMessage(kind, retryAfterSec, customMsg) {
    var messagesDiv = document.getElementById("messages");
    var inputField  = document.getElementById("input");
    var submitBtn   = _chatForm ? _chatForm.querySelector('button[type=submit]') : null;
    var micBtn      = document.getElementById('micBtn');

    _blockedUntil = Math.floor(Date.now()/1000) + retryAfterSec;
    _blockedKind  = kind;

    var box = document.createElement('div');
    box.className = 'mess-chat chat-limit-box';
    box.style.cssText = 'background:rgba(255,152,0,0.1);border:1px solid rgba(255,152,0,0.4);border-radius:8px;padding:12px 14px;margin:10px 0;font-size:13px;color:#bf6000;line-height:1.5';

    var title = '⏱ ';
    if (kind === 'minute')       title += 'Per daug žinučių per minutę';
    else if (kind === 'hour')    title += 'Pasiektas valandos limitas';
    else if (kind === 'day')     title += 'Pasiektas dienos limitas';
    else if (kind === 'session') title += 'Pokalbis baigtas';
    else                         title += 'Per daug užklausų';

    var html = '<div style="font-weight:700;margin-bottom:6px">' + title + '</div>';
    if (customMsg) html += '<div style="margin-bottom:8px">' + customMsg + '</div>';
    html += '<div id="chatCountdown" style="margin-bottom:8px">Vėl rašyti galėsite po <b><span id="chatCountdownVal">' + _fmtTime(retryAfterSec) + '</span></b>.</div>';
    html += '<div style="font-size:12px;opacity:0.9">Tarpu kuo galite pasinaudoti įrankiais:</div>';
    html += '<div style="margin-top:6px">'
         + '<a href="/diag/diagnose.php" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#1b5e20;color:#fff;border-radius:6px;padding:3px 10px;font-size:11px;font-weight:700;text-decoration:none;margin:2px">🔍 Diagnostika</a> '
         + '<a href="/kon/index.php" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#1565c0;color:#fff;border-radius:6px;padding:3px 10px;font-size:11px;font-weight:700;text-decoration:none;margin:2px">🔧 Konstruktorius</a> '
         + '<a href="/map/" target="_blank" style="display:inline-flex;align-items:center;gap:4px;background:#4a148c;color:#fff;border-radius:6px;padding:3px 10px;font-size:11px;font-weight:700;text-decoration:none;margin:2px">📍 Specialistų žemėlapis</a>'
         + '</div>';
    box.innerHTML = html;
    messagesDiv.appendChild(box);
    scrollToBottom();

    if (inputField) inputField.disabled = true;
    if (submitBtn)  submitBtn.disabled  = true;
    if (micBtn)     micBtn.disabled     = true;

    if (_countdownInterval) clearInterval(_countdownInterval);
    _countdownInterval = setInterval(function() {
        var remaining = _blockedUntil - Math.floor(Date.now() / 1000);
        var span = document.getElementById('chatCountdownVal');
        if (remaining <= 0) {
            clearInterval(_countdownInterval);
            _countdownInterval = null;
            if (span) span.parentElement.innerHTML = '✅ Galite vėl rašyti.';
            if (inputField) { inputField.disabled = false; inputField.focus(); }
            if (submitBtn)  submitBtn.disabled = false;
            if (micBtn)     micBtn.disabled    = false;
            box.style.opacity = '0.6';
        } else if (span) {
            span.textContent = _fmtTime(remaining);
        }
    }, 1000);
}

// ─── Pagrindinis siuntimas ────────────────────────────────────────────────────

async function getData() {
    var nowS = Math.floor(Date.now()/1000);
    if (_blockedUntil > nowS) {
        if (_inputEl) _inputEl.value = '';
        return;
    }

    var userData = _inputEl ? _inputEl.value.trim() : '';
    if (!userData) return false;

    var messagesDiv = document.getElementById("messages");
    var inputField  = document.getElementById("input");
    var wasVoice    = _voiceMode;
    _voiceMode      = false;

    var userMessage = document.createElement('div');
    userMessage.className = 'mess-user';
    userMessage.textContent = userData;
    messagesDiv.appendChild(userMessage);
    inputField.value = "";
    scrollToBottom();

    var typingIndicator = document.createElement('div');
    typingIndicator.className = 'mess-chat';
    typingIndicator.innerHTML = '<span style="opacity:0.5">Rašo...</span>';
    typingIndicator.id = 'typing';
    messagesDiv.appendChild(typingIndicator);
    scrollToBottom();

    // Sesijos limitas: ~7 žinučių apsikeitimai
    if (_chatHistory.length >= 14) {
        var typing0 = document.getElementById('typing');
        if (typing0) typing0.remove();
        _showLimitMessage(
            'session',
            300,
            'Šis pokalbis užtruko ilgokai. Pradėsime naują po atvėsimo, arba pasinaudokite žemiau esančiais įrankiais.'
        );
        _chatHistory = [];
        return;
    }

    _chatHistory.push({ role: 'user', content: userData });

    try {
        var response = await fetch("/api/v1/ai", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                message: userData,
                history: _chatHistory.slice(0, -1)
            }),
        });

        var data   = await response.json();
        var typing = document.getElementById('typing');
        if (typing) typing.remove();

        if (response.status === 429) {
            _chatHistory.pop();
            _showLimitMessage(
                data.limit_kind || 'minute',
                Math.max(1, parseInt(data.retry_after_sec || 60, 10)),
                data.error || ''
            );
            return;
        }

        if (data && data.ok && data.text) {
            _chatHistory.push({ role: 'assistant', content: data.text });
            if (_chatHistory.length > 16) _chatHistory = _chatHistory.slice(-16);

            var chatMessage = document.createElement('div');
            chatMessage.className = 'mess-chat';
            chatMessage.innerHTML = _renderLinks(data.text);

            if (wasVoice) {
                // Balso režimas: auto-play, garsiakalbio mygtuko nereikia
                _ttsPlay(data.text);
            } else {
                // Tekstinis režimas: garsiakalbio mygtukas
                _addSpeakerBtn(chatMessage, data.text);
            }

            messagesDiv.appendChild(chatMessage);

        } else if (data && data.error) {
            _chatHistory.pop();
            var errorMessage = document.createElement('div');
            errorMessage.className = 'mess-chat';
            errorMessage.style.color = '#ef4444';
            errorMessage.textContent = 'Klaida: ' + data.error;
            messagesDiv.appendChild(errorMessage);
        } else {
            _chatHistory.pop();
            var errorMessage2 = document.createElement('div');
            errorMessage2.className = 'mess-chat';
            errorMessage2.style.color = '#ef4444';
            errorMessage2.textContent = 'Netikėta klaida. Bandykite dar kartą.';
            messagesDiv.appendChild(errorMessage2);
        }

        scrollToBottom();

    } catch (error) {
        _chatHistory.pop();
        var typing2 = document.getElementById('typing');
        if (typing2) typing2.remove();
        var errorMessage3 = document.createElement('div');
        errorMessage3.className = 'mess-chat';
        errorMessage3.style.color = '#ef4444';
        errorMessage3.textContent = 'Ryšio klaida. Bandykite dar kartą.';
        messagesDiv.appendChild(errorMessage3);
        scrollToBottom();
    }

    if (inputField) inputField.focus();
}

function scrollToBottom() {
    var messagesDiv = document.getElementById("messages");
    if (messagesDiv) messagesDiv.scrollTo({ top: messagesDiv.scrollHeight, behavior: 'smooth' });
}
